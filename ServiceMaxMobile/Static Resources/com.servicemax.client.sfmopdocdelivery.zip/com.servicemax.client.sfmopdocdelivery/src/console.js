/**
 * SFM opdocconsole app
 * @class com.servicemax.client.sfmeventdelivery.console
 * @author Eric Ingram
 * @copyright 2013 ServiceMax, Inc.
 */
(function(){

	var console = SVMX.Package("com.servicemax.client.sfmopdocdelivery.console");

console.init = function(){

	console.Class("ConsoleAppImpl", com.servicemax.client.sfmconsole.ui.desktop.console.AbstractConsoleApp, {
		engine : null,

		start : function(options){
			this.options = options || {};

			//this.showLoadMask();
			
			var engine = SVMX.create("com.servicemax.client.sfmopdocdelivery.engine.DeliveryEngineImpl");
			this.engine = engine.getInterface();

			this.engine.initAsync({
				handler : SVMX.proxy(this,"onEngineInit", options), // need to rename this to onEneingInit for both online/offline/standalone/sfmconsole
				context : this
			});
		},

		onEngineInit: function(options) {
            this.engine.run({
                onReady: {
                    handler: this.onEngineReady,
                    context: this
                },
                container : this.getConsoleAppContainer(),
                options : options
            }, options);
        },

		onEngineReady : function(){
			this.setAppInfo({
				windowTitle: "Smart Docs"
			});
			this.hideLoadMask();
			this.__container.setTitle("Smart Docs");
			this.engine.getRoot().resize(this.getSize());
			this.setRootContainer(this.engine.getRoot());
		},

		onAppHide : function(event){
			// TODO: got to sleep
		},

		onAppShow : function(event){
			// TODO: wake up
		},

		onShow : function(event){
			if(this.__doReset === true && this.engine){
				this.engine.refreshData();
				this.__doReset = false;
			}
		},

		onHide : function(event) {

		},

		reset : function() {
			var isCalVisible = this.getVisibility();
			if(isCalVisible === true){
				if (this.engine) this.engine.refreshData();
			}
			else {
				this.__doReset = true;
			}
		},

		onAppResize : function(event){
			if(this.engine.getRoot()){
				try{
					this.engine.getRoot().resize(event);
				}catch(e){
					SVMX.getLoggingService().getLogger().warn("Could not resize smartdocs =>" + e);
				}
			}
		}

	}, {});

};
})();