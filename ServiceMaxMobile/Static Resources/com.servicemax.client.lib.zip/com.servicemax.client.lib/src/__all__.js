// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\jquery\jquery-1.8.0.min.js
/*! jQuery v@1.8.0 jquery.com | jquery.org/license */
(function(a,b){function G(a){var b=F[a]={};return p.each(a.split(s),function(a,c){b[c]=!0}),b}function J(a,c,d){if(d===b&&a.nodeType===1){var e="data-"+c.replace(I,"-$1").toLowerCase();d=a.getAttribute(e);if(typeof d=="string"){try{d=d==="true"?!0:d==="false"?!1:d==="null"?null:+d+""===d?+d:H.test(d)?p.parseJSON(d):d}catch(f){}p.data(a,c,d)}else d=b}return d}function K(a){var b;for(b in a){if(b==="data"&&p.isEmptyObject(a[b]))continue;if(b!=="toJSON")return!1}return!0}function ba(){return!1}function bb(){return!0}function bh(a){return!a||!a.parentNode||a.parentNode.nodeType===11}function bi(a,b){do a=a[b];while(a&&a.nodeType!==1);return a}function bj(a,b,c){b=b||0;if(p.isFunction(b))return p.grep(a,function(a,d){var e=!!b.call(a,d,a);return e===c});if(b.nodeType)return p.grep(a,function(a,d){return a===b===c});if(typeof b=="string"){var d=p.grep(a,function(a){return a.nodeType===1});if(be.test(b))return p.filter(b,d,!c);b=p.filter(b,d)}return p.grep(a,function(a,d){return p.inArray(a,b)>=0===c})}function bk(a){var b=bl.split("|"),c=a.createDocumentFragment();if(c.createElement)while(b.length)c.createElement(b.pop());return c}function bC(a,b){return a.getElementsByTagName(b)[0]||a.appendChild(a.ownerDocument.createElement(b))}function bD(a,b){if(b.nodeType!==1||!p.hasData(a))return;var c,d,e,f=p._data(a),g=p._data(b,f),h=f.events;if(h){delete g.handle,g.events={};for(c in h)for(d=0,e=h[c].length;d<e;d++)p.event.add(b,c,h[c][d])}g.data&&(g.data=p.extend({},g.data))}function bE(a,b){var c;if(b.nodeType!==1)return;b.clearAttributes&&b.clearAttributes(),b.mergeAttributes&&b.mergeAttributes(a),c=b.nodeName.toLowerCase(),c==="object"?(b.parentNode&&(b.outerHTML=a.outerHTML),p.support.html5Clone&&a.innerHTML&&!p.trim(b.innerHTML)&&(b.innerHTML=a.innerHTML)):c==="input"&&bv.test(a.type)?(b.defaultChecked=b.checked=a.checked,b.value!==a.value&&(b.value=a.value)):c==="option"?b.selected=a.defaultSelected:c==="input"||c==="textarea"?b.defaultValue=a.defaultValue:c==="script"&&b.text!==a.text&&(b.text=a.text),b.removeAttribute(p.expando)}function bF(a){return typeof a.getElementsByTagName!="undefined"?a.getElementsByTagName("*"):typeof a.querySelectorAll!="undefined"?a.querySelectorAll("*"):[]}function bG(a){bv.test(a.type)&&(a.defaultChecked=a.checked)}function bX(a,b){if(b in a)return b;var c=b.charAt(0).toUpperCase()+b.slice(1),d=b,e=bV.length;while(e--){b=bV[e]+c;if(b in a)return b}return d}function bY(a,b){return a=b||a,p.css(a,"display")==="none"||!p.contains(a.ownerDocument,a)}function bZ(a,b){var c,d,e=[],f=0,g=a.length;for(;f<g;f++){c=a[f];if(!c.style)continue;e[f]=p._data(c,"olddisplay"),b?(!e[f]&&c.style.display==="none"&&(c.style.display=""),c.style.display===""&&bY(c)&&(e[f]=p._data(c,"olddisplay",cb(c.nodeName)))):(d=bH(c,"display"),!e[f]&&d!=="none"&&p._data(c,"olddisplay",d))}for(f=0;f<g;f++){c=a[f];if(!c.style)continue;if(!b||c.style.display==="none"||c.style.display==="")c.style.display=b?e[f]||"":"none"}return a}function b$(a,b,c){var d=bO.exec(b);return d?Math.max(0,d[1]-(c||0))+(d[2]||"px"):b}function b_(a,b,c,d){var e=c===(d?"border":"content")?4:b==="width"?1:0,f=0;for(;e<4;e+=2)c==="margin"&&(f+=p.css(a,c+bU[e],!0)),d?(c==="content"&&(f-=parseFloat(bH(a,"padding"+bU[e]))||0),c!=="margin"&&(f-=parseFloat(bH(a,"border"+bU[e]+"Width"))||0)):(f+=parseFloat(bH(a,"padding"+bU[e]))||0,c!=="padding"&&(f+=parseFloat(bH(a,"border"+bU[e]+"Width"))||0));return f}function ca(a,b,c){var d=b==="width"?a.offsetWidth:a.offsetHeight,e=!0,f=p.support.boxSizing&&p.css(a,"boxSizing")==="border-box";if(d<=0){d=bH(a,b);if(d<0||d==null)d=a.style[b];if(bP.test(d))return d;e=f&&(p.support.boxSizingReliable||d===a.style[b]),d=parseFloat(d)||0}return d+b_(a,b,c||(f?"border":"content"),e)+"px"}function cb(a){if(bR[a])return bR[a];var b=p("<"+a+">").appendTo(e.body),c=b.css("display");b.remove();if(c==="none"||c===""){bI=e.body.appendChild(bI||p.extend(e.createElement("iframe"),{frameBorder:0,width:0,height:0}));if(!bJ||!bI.createElement)bJ=(bI.contentWindow||bI.contentDocument).document,bJ.write("<!doctype html><html><body>"),bJ.close();b=bJ.body.appendChild(bJ.createElement(a)),c=bH(b,"display"),e.body.removeChild(bI)}return bR[a]=c,c}function ch(a,b,c,d){var e;if(p.isArray(b))p.each(b,function(b,e){c||cd.test(a)?d(a,e):ch(a+"["+(typeof e=="object"?b:"")+"]",e,c,d)});else if(!c&&p.type(b)==="object")for(e in b)ch(a+"["+e+"]",b[e],c,d);else d(a,b)}function cy(a){return function(b,c){typeof b!="string"&&(c=b,b="*");var d,e,f,g=b.toLowerCase().split(s),h=0,i=g.length;if(p.isFunction(c))for(;h<i;h++)d=g[h],f=/^\+/.test(d),f&&(d=d.substr(1)||"*"),e=a[d]=a[d]||[],e[f?"unshift":"push"](c)}}function cz(a,c,d,e,f,g){f=f||c.dataTypes[0],g=g||{},g[f]=!0;var h,i=a[f],j=0,k=i?i.length:0,l=a===cu;for(;j<k&&(l||!h);j++)h=i[j](c,d,e),typeof h=="string"&&(!l||g[h]?h=b:(c.dataTypes.unshift(h),h=cz(a,c,d,e,h,g)));return(l||!h)&&!g["*"]&&(h=cz(a,c,d,e,"*",g)),h}function cA(a,c){var d,e,f=p.ajaxSettings.flatOptions||{};for(d in c)c[d]!==b&&((f[d]?a:e||(e={}))[d]=c[d]);e&&p.extend(!0,a,e)}function cB(a,c,d){var e,f,g,h,i=a.contents,j=a.dataTypes,k=a.responseFields;for(f in k)f in d&&(c[k[f]]=d[f]);while(j[0]==="*")j.shift(),e===b&&(e=a.mimeType||c.getResponseHeader("content-type"));if(e)for(f in i)if(i[f]&&i[f].test(e)){j.unshift(f);break}if(j[0]in d)g=j[0];else{for(f in d){if(!j[0]||a.converters[f+" "+j[0]]){g=f;break}h||(h=f)}g=g||h}if(g)return g!==j[0]&&j.unshift(g),d[g]}function cC(a,b){var c,d,e,f,g=a.dataTypes.slice(),h=g[0],i={},j=0;a.dataFilter&&(b=a.dataFilter(b,a.dataType));if(g[1])for(c in a.converters)i[c.toLowerCase()]=a.converters[c];for(;e=g[++j];)if(e!=="*"){if(h!=="*"&&h!==e){c=i[h+" "+e]||i["* "+e];if(!c)for(d in i){f=d.split(" ");if(f[1]===e){c=i[h+" "+f[0]]||i["* "+f[0]];if(c){c===!0?c=i[d]:i[d]!==!0&&(e=f[0],g.splice(j--,0,e));break}}}if(c!==!0)if(c&&a["throws"])b=c(b);else try{b=c(b)}catch(k){return{state:"parsererror",error:c?k:"No conversion from "+h+" to "+e}}}h=e}return{state:"success",data:b}}function cK(){try{return new a.XMLHttpRequest}catch(b){}}function cL(){try{return new a.ActiveXObject("Microsoft.XMLHTTP")}catch(b){}}function cT(){return setTimeout(function(){cM=b},0),cM=p.now()}function cU(a,b){p.each(b,function(b,c){var d=(cS[b]||[]).concat(cS["*"]),e=0,f=d.length;for(;e<f;e++)if(d[e].call(a,b,c))return})}function cV(a,b,c){var d,e=0,f=0,g=cR.length,h=p.Deferred().always(function(){delete i.elem}),i=function(){var b=cM||cT(),c=Math.max(0,j.startTime+j.duration-b),d=1-(c/j.duration||0),e=0,f=j.tweens.length;for(;e<f;e++)j.tweens[e].run(d);return h.notifyWith(a,[j,d,c]),d<1&&f?c:(h.resolveWith(a,[j]),!1)},j=h.promise({elem:a,props:p.extend({},b),opts:p.extend(!0,{specialEasing:{}},c),originalProperties:b,originalOptions:c,startTime:cM||cT(),duration:c.duration,tweens:[],createTween:function(b,c,d){var e=p.Tween(a,j.opts,b,c,j.opts.specialEasing[b]||j.opts.easing);return j.tweens.push(e),e},stop:function(b){var c=0,d=b?j.tweens.length:0;for(;c<d;c++)j.tweens[c].run(1);return b?h.resolveWith(a,[j,b]):h.rejectWith(a,[j,b]),this}}),k=j.props;cW(k,j.opts.specialEasing);for(;e<g;e++){d=cR[e].call(j,a,k,j.opts);if(d)return d}return cU(j,k),p.isFunction(j.opts.start)&&j.opts.start.call(a,j),p.fx.timer(p.extend(i,{anim:j,queue:j.opts.queue,elem:a})),j.progress(j.opts.progress).done(j.opts.done,j.opts.complete).fail(j.opts.fail).always(j.opts.always)}function cW(a,b){var c,d,e,f,g;for(c in a){d=p.camelCase(c),e=b[d],f=a[c],p.isArray(f)&&(e=f[1],f=a[c]=f[0]),c!==d&&(a[d]=f,delete a[c]),g=p.cssHooks[d];if(g&&"expand"in g){f=g.expand(f),delete a[d];for(c in f)c in a||(a[c]=f[c],b[c]=e)}else b[d]=e}}function cX(a,b,c){var d,e,f,g,h,i,j,k,l=this,m=a.style,n={},o=[],q=a.nodeType&&bY(a);c.queue||(j=p._queueHooks(a,"fx"),j.unqueued==null&&(j.unqueued=0,k=j.empty.fire,j.empty.fire=function(){j.unqueued||k()}),j.unqueued++,l.always(function(){l.always(function(){j.unqueued--,p.queue(a,"fx").length||j.empty.fire()})})),a.nodeType===1&&("height"in b||"width"in b)&&(c.overflow=[m.overflow,m.overflowX,m.overflowY],p.css(a,"display")==="inline"&&p.css(a,"float")==="none"&&(!p.support.inlineBlockNeedsLayout||cb(a.nodeName)==="inline"?m.display="inline-block":m.zoom=1)),c.overflow&&(m.overflow="hidden",p.support.shrinkWrapBlocks||l.done(function(){m.overflow=c.overflow[0],m.overflowX=c.overflow[1],m.overflowY=c.overflow[2]}));for(d in b){f=b[d];if(cO.exec(f)){delete b[d];if(f===(q?"hide":"show"))continue;o.push(d)}}g=o.length;if(g){h=p._data(a,"fxshow")||p._data(a,"fxshow",{}),q?p(a).show():l.done(function(){p(a).hide()}),l.done(function(){var b;p.removeData(a,"fxshow",!0);for(b in n)p.style(a,b,n[b])});for(d=0;d<g;d++)e=o[d],i=l.createTween(e,q?h[e]:0),n[e]=h[e]||p.style(a,e),e in h||(h[e]=i.start,q&&(i.end=i.start,i.start=e==="width"||e==="height"?1:0))}}function cY(a,b,c,d,e){return new cY.prototype.init(a,b,c,d,e)}function cZ(a,b){var c,d={height:a},e=0;for(;e<4;e+=2-b)c=bU[e],d["margin"+c]=d["padding"+c]=a;return b&&(d.opacity=d.width=a),d}function c_(a){return p.isWindow(a)?a:a.nodeType===9?a.defaultView||a.parentWindow:!1}var c,d,e=a.document,f=a.location,g=a.navigator,h=a.jQuery,i=a.$,j=Array.prototype.push,k=Array.prototype.slice,l=Array.prototype.indexOf,m=Object.prototype.toString,n=Object.prototype.hasOwnProperty,o=String.prototype.trim,p=function(a,b){return new p.fn.init(a,b,c)},q=/[\-+]?(?:\d*\.|)\d+(?:[eE][\-+]?\d+|)/.source,r=/\S/,s=/\s+/,t=r.test("� ")?/^[\s\xA0]+|[\s\xA0]+$/g:/^\s+|\s+$/g,u=/^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,v=/^<(\w+)\s*\/?>(?:<\/\1>|)$/,w=/^[\],:{}\s]*$/,x=/(?:^|:|,)(?:\s*\[)+/g,y=/\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,z=/"[^"\\\r\n]*"|true|false|null|-?(?:\d\d*\.|)\d+(?:[eE][\-+]?\d+|)/g,A=/^-ms-/,B=/-([\da-z])/gi,C=function(a,b){return(b+"").toUpperCase()},D=function(){e.addEventListener?(e.removeEventListener("DOMContentLoaded",D,!1),p.ready()):e.readyState==="complete"&&(e.detachEvent("onreadystatechange",D),p.ready())},E={};p.fn=p.prototype={constructor:p,init:function(a,c,d){var f,g,h,i;if(!a)return this;if(a.nodeType)return this.context=this[0]=a,this.length=1,this;if(typeof a=="string"){a.charAt(0)==="<"&&a.charAt(a.length-1)===">"&&a.length>=3?f=[null,a,null]:f=u.exec(a);if(f&&(f[1]||!c)){if(f[1])return c=c instanceof p?c[0]:c,i=c&&c.nodeType?c.ownerDocument||c:e,a=p.parseHTML(f[1],i,!0),v.test(f[1])&&p.isPlainObject(c)&&this.attr.call(a,c,!0),p.merge(this,a);g=e.getElementById(f[2]);if(g&&g.parentNode){if(g.id!==f[2])return d.find(a);this.length=1,this[0]=g}return this.context=e,this.selector=a,this}return!c||c.jquery?(c||d).find(a):this.constructor(c).find(a)}return p.isFunction(a)?d.ready(a):(a.selector!==b&&(this.selector=a.selector,this.context=a.context),p.makeArray(a,this))},selector:"",jquery:"1.8.0",length:0,size:function(){return this.length},toArray:function(){return k.call(this)},get:function(a){return a==null?this.toArray():a<0?this[this.length+a]:this[a]},pushStack:function(a,b,c){var d=p.merge(this.constructor(),a);return d.prevObject=this,d.context=this.context,b==="find"?d.selector=this.selector+(this.selector?" ":"")+c:b&&(d.selector=this.selector+"."+b+"("+c+")"),d},each:function(a,b){return p.each(this,a,b)},ready:function(a){return p.ready.promise().done(a),this},eq:function(a){return a=+a,a===-1?this.slice(a):this.slice(a,a+1)},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},slice:function(){return this.pushStack(k.apply(this,arguments),"slice",k.call(arguments).join(","))},map:function(a){return this.pushStack(p.map(this,function(b,c){return a.call(b,c,b)}))},end:function(){return this.prevObject||this.constructor(null)},push:j,sort:[].sort,splice:[].splice},p.fn.init.prototype=p.fn,p.extend=p.fn.extend=function(){var a,c,d,e,f,g,h=arguments[0]||{},i=1,j=arguments.length,k=!1;typeof h=="boolean"&&(k=h,h=arguments[1]||{},i=2),typeof h!="object"&&!p.isFunction(h)&&(h={}),j===i&&(h=this,--i);for(;i<j;i++)if((a=arguments[i])!=null)for(c in a){d=h[c],e=a[c];if(h===e)continue;k&&e&&(p.isPlainObject(e)||(f=p.isArray(e)))?(f?(f=!1,g=d&&p.isArray(d)?d:[]):g=d&&p.isPlainObject(d)?d:{},h[c]=p.extend(k,g,e)):e!==b&&(h[c]=e)}return h},p.extend({noConflict:function(b){return a.$===p&&(a.$=i),b&&a.jQuery===p&&(a.jQuery=h),p},isReady:!1,readyWait:1,holdReady:function(a){a?p.readyWait++:p.ready(!0)},ready:function(a){if(a===!0?--p.readyWait:p.isReady)return;if(!e.body)return setTimeout(p.ready,1);p.isReady=!0;if(a!==!0&&--p.readyWait>0)return;d.resolveWith(e,[p]),p.fn.trigger&&p(e).trigger("ready").off("ready")},isFunction:function(a){return p.type(a)==="function"},isArray:Array.isArray||function(a){return p.type(a)==="array"},isWindow:function(a){return a!=null&&a==a.window},isNumeric:function(a){return!isNaN(parseFloat(a))&&isFinite(a)},type:function(a){return a==null?String(a):E[m.call(a)]||"object"},isPlainObject:function(a){if(!a||p.type(a)!=="object"||a.nodeType||p.isWindow(a))return!1;try{if(a.constructor&&!n.call(a,"constructor")&&!n.call(a.constructor.prototype,"isPrototypeOf"))return!1}catch(c){return!1}var d;for(d in a);return d===b||n.call(a,d)},isEmptyObject:function(a){var b;for(b in a)return!1;return!0},error:function(a){throw new Error(a)},parseHTML:function(a,b,c){var d;return!a||typeof a!="string"?null:(typeof b=="boolean"&&(c=b,b=0),b=b||e,(d=v.exec(a))?[b.createElement(d[1])]:(d=p.buildFragment([a],b,c?null:[]),p.merge([],(d.cacheable?p.clone(d.fragment):d.fragment).childNodes)))},parseJSON:function(b){if(!b||typeof b!="string")return null;b=p.trim(b);if(a.JSON&&a.JSON.parse)return a.JSON.parse(b);if(w.test(b.replace(y,"@").replace(z,"]").replace(x,"")))return(new Function("return "+b))();p.error("Invalid JSON: "+b)},parseXML:function(c){var d,e;if(!c||typeof c!="string")return null;try{a.DOMParser?(e=new DOMParser,d=e.parseFromString(c,"text/xml")):(d=new ActiveXObject("Microsoft.XMLDOM"),d.async="false",d.loadXML(c))}catch(f){d=b}return(!d||!d.documentElement||d.getElementsByTagName("parsererror").length)&&p.error("Invalid XML: "+c),d},noop:function(){},globalEval:function(b){b&&r.test(b)&&(a.execScript||function(b){a.eval.call(a,b)})(b)},camelCase:function(a){return a.replace(A,"ms-").replace(B,C)},nodeName:function(a,b){return a.nodeName&&a.nodeName.toUpperCase()===b.toUpperCase()},each:function(a,c,d){var e,f=0,g=a.length,h=g===b||p.isFunction(a);if(d){if(h){for(e in a)if(c.apply(a[e],d)===!1)break}else for(;f<g;)if(c.apply(a[f++],d)===!1)break}else if(h){for(e in a)if(c.call(a[e],e,a[e])===!1)break}else for(;f<g;)if(c.call(a[f],f,a[f++])===!1)break;return a},trim:o?function(a){return a==null?"":o.call(a)}:function(a){return a==null?"":a.toString().replace(t,"")},makeArray:function(a,b){var c,d=b||[];return a!=null&&(c=p.type(a),a.length==null||c==="string"||c==="function"||c==="regexp"||p.isWindow(a)?j.call(d,a):p.merge(d,a)),d},inArray:function(a,b,c){var d;if(b){if(l)return l.call(b,a,c);d=b.length,c=c?c<0?Math.max(0,d+c):c:0;for(;c<d;c++)if(c in b&&b[c]===a)return c}return-1},merge:function(a,c){var d=c.length,e=a.length,f=0;if(typeof d=="number")for(;f<d;f++)a[e++]=c[f];else while(c[f]!==b)a[e++]=c[f++];return a.length=e,a},grep:function(a,b,c){var d,e=[],f=0,g=a.length;c=!!c;for(;f<g;f++)d=!!b(a[f],f),c!==d&&e.push(a[f]);return e},map:function(a,c,d){var e,f,g=[],h=0,i=a.length,j=a instanceof p||i!==b&&typeof i=="number"&&(i>0&&a[0]&&a[i-1]||i===0||p.isArray(a));if(j)for(;h<i;h++)e=c(a[h],h,d),e!=null&&(g[g.length]=e);else for(f in a)e=c(a[f],f,d),e!=null&&(g[g.length]=e);return g.concat.apply([],g)},guid:1,proxy:function(a,c){var d,e,f;return typeof c=="string"&&(d=a[c],c=a,a=d),p.isFunction(a)?(e=k.call(arguments,2),f=function(){return a.apply(c,e.concat(k.call(arguments)))},f.guid=a.guid=a.guid||f.guid||p.guid++,f):b},access:function(a,c,d,e,f,g,h){var i,j=d==null,k=0,l=a.length;if(d&&typeof d=="object"){for(k in d)p.access(a,c,k,d[k],1,g,e);f=1}else if(e!==b){i=h===b&&p.isFunction(e),j&&(i?(i=c,c=function(a,b,c){return i.call(p(a),c)}):(c.call(a,e),c=null));if(c)for(;k<l;k++)c(a[k],d,i?e.call(a[k],k,c(a[k],d)):e,h);f=1}return f?a:j?c.call(a):l?c(a[0],d):g},now:function(){return(new Date).getTime()}}),p.ready.promise=function(b){if(!d){d=p.Deferred();if(e.readyState==="complete"||e.readyState!=="loading"&&e.addEventListener)setTimeout(p.ready,1);else if(e.addEventListener)e.addEventListener("DOMContentLoaded",D,!1),a.addEventListener("load",p.ready,!1);else{e.attachEvent("onreadystatechange",D),a.attachEvent("onload",p.ready);var c=!1;try{c=a.frameElement==null&&e.documentElement}catch(f){}c&&c.doScroll&&function g(){if(!p.isReady){try{c.doScroll("left")}catch(a){return setTimeout(g,50)}p.ready()}}()}}return d.promise(b)},p.each("Boolean Number String Function Array Date RegExp Object".split(" "),function(a,b){E["[object "+b+"]"]=b.toLowerCase()}),c=p(e);var F={};p.Callbacks=function(a){a=typeof a=="string"?F[a]||G(a):p.extend({},a);var c,d,e,f,g,h,i=[],j=!a.once&&[],k=function(b){c=a.memory&&b,d=!0,h=f||0,f=0,g=i.length,e=!0;for(;i&&h<g;h++)if(i[h].apply(b[0],b[1])===!1&&a.stopOnFalse){c=!1;break}e=!1,i&&(j?j.length&&k(j.shift()):c?i=[]:l.disable())},l={add:function(){if(i){var b=i.length;(function d(b){p.each(b,function(b,c){p.isFunction(c)&&(!a.unique||!l.has(c))?i.push(c):c&&c.length&&d(c)})})(arguments),e?g=i.length:c&&(f=b,k(c))}return this},remove:function(){return i&&p.each(arguments,function(a,b){var c;while((c=p.inArray(b,i,c))>-1)i.splice(c,1),e&&(c<=g&&g--,c<=h&&h--)}),this},has:function(a){return p.inArray(a,i)>-1},empty:function(){return i=[],this},disable:function(){return i=j=c=b,this},disabled:function(){return!i},lock:function(){return j=b,c||l.disable(),this},locked:function(){return!j},fireWith:function(a,b){return b=b||[],b=[a,b.slice?b.slice():b],i&&(!d||j)&&(e?j.push(b):k(b)),this},fire:function(){return l.fireWith(this,arguments),this},fired:function(){return!!d}};return l},p.extend({Deferred:function(a){var b=[["resolve","done",p.Callbacks("once memory"),"resolved"],["reject","fail",p.Callbacks("once memory"),"rejected"],["notify","progress",p.Callbacks("memory")]],c="pending",d={state:function(){return c},always:function(){return e.done(arguments).fail(arguments),this},then:function(){var a=arguments;return p.Deferred(function(c){p.each(b,function(b,d){var f=d[0],g=a[b];e[d[1]](p.isFunction(g)?function(){var a=g.apply(this,arguments);a&&p.isFunction(a.promise)?a.promise().done(c.resolve).fail(c.reject).progress(c.notify):c[f+"With"](this===e?c:this,[a])}:c[f])}),a=null}).promise()},promise:function(a){return typeof a=="object"?p.extend(a,d):d}},e={};return d.pipe=d.then,p.each(b,function(a,f){var g=f[2],h=f[3];d[f[1]]=g.add,h&&g.add(function(){c=h},b[a^1][2].disable,b[2][2].lock),e[f[0]]=g.fire,e[f[0]+"With"]=g.fireWith}),d.promise(e),a&&a.call(e,e),e},when:function(a){var b=0,c=k.call(arguments),d=c.length,e=d!==1||a&&p.isFunction(a.promise)?d:0,f=e===1?a:p.Deferred(),g=function(a,b,c){return function(d){b[a]=this,c[a]=arguments.length>1?k.call(arguments):d,c===h?f.notifyWith(b,c):--e||f.resolveWith(b,c)}},h,i,j;if(d>1){h=new Array(d),i=new Array(d),j=new Array(d);for(;b<d;b++)c[b]&&p.isFunction(c[b].promise)?c[b].promise().done(g(b,j,c)).fail(f.reject).progress(g(b,i,h)):--e}return e||f.resolveWith(j,c),f.promise()}}),p.support=function(){var b,c,d,f,g,h,i,j,k,l,m,n=e.createElement("div");n.setAttribute("className","t"),n.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",c=n.getElementsByTagName("*"),d=n.getElementsByTagName("a")[0],d.style.cssText="top:1px;float:left;opacity:.5";if(!c||!c.length||!d)return{};f=e.createElement("select"),g=f.appendChild(e.createElement("option")),h=n.getElementsByTagName("input")[0],b={leadingWhitespace:n.firstChild.nodeType===3,tbody:!n.getElementsByTagName("tbody").length,htmlSerialize:!!n.getElementsByTagName("link").length,style:/top/.test(d.getAttribute("style")),hrefNormalized:d.getAttribute("href")==="/a",opacity:/^0.5/.test(d.style.opacity),cssFloat:!!d.style.cssFloat,checkOn:h.value==="on",optSelected:g.selected,getSetAttribute:n.className!=="t",enctype:!!e.createElement("form").enctype,html5Clone:e.createElement("nav").cloneNode(!0).outerHTML!=="<:nav></:nav>",boxModel:e.compatMode==="CSS1Compat",submitBubbles:!0,changeBubbles:!0,focusinBubbles:!1,deleteExpando:!0,noCloneEvent:!0,inlineBlockNeedsLayout:!1,shrinkWrapBlocks:!1,reliableMarginRight:!0,boxSizingReliable:!0,pixelPosition:!1},h.checked=!0,b.noCloneChecked=h.cloneNode(!0).checked,f.disabled=!0,b.optDisabled=!g.disabled;try{delete n.test}catch(o){b.deleteExpando=!1}!n.addEventListener&&n.attachEvent&&n.fireEvent&&(n.attachEvent("onclick",m=function(){b.noCloneEvent=!1}),n.cloneNode(!0).fireEvent("onclick"),n.detachEvent("onclick",m)),h=e.createElement("input"),h.value="t",h.setAttribute("type","radio"),b.radioValue=h.value==="t",h.setAttribute("checked","checked"),h.setAttribute("name","t"),n.appendChild(h),i=e.createDocumentFragment(),i.appendChild(n.lastChild),b.checkClone=i.cloneNode(!0).cloneNode(!0).lastChild.checked,b.appendChecked=h.checked,i.removeChild(h),i.appendChild(n);if(n.attachEvent)for(k in{submit:!0,change:!0,focusin:!0})j="on"+k,l=j in n,l||(n.setAttribute(j,"return;"),l=typeof n[j]=="function"),b[k+"Bubbles"]=l;return p(function(){var c,d,f,g,h="padding:0;margin:0;border:0;display:block;overflow:hidden;",i=e.getElementsByTagName("body")[0];if(!i)return;c=e.createElement("div"),c.style.cssText="visibility:hidden;border:0;width:0;height:0;position:static;top:0;margin-top:1px",i.insertBefore(c,i.firstChild),d=e.createElement("div"),c.appendChild(d),d.innerHTML="<table><tr><td></td><td>t</td></tr></table>",f=d.getElementsByTagName("td"),f[0].style.cssText="padding:0;margin:0;border:0;display:none",l=f[0].offsetHeight===0,f[0].style.display="",f[1].style.display="none",b.reliableHiddenOffsets=l&&f[0].offsetHeight===0,d.innerHTML="",d.style.cssText="box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;",b.boxSizing=d.offsetWidth===4,b.doesNotIncludeMarginInBodyOffset=i.offsetTop!==1,a.getComputedStyle&&(b.pixelPosition=(a.getComputedStyle(d,null)||{}).top!=="1%",b.boxSizingReliable=(a.getComputedStyle(d,null)||{width:"4px"}).width==="4px",g=e.createElement("div"),g.style.cssText=d.style.cssText=h,g.style.marginRight=g.style.width="0",d.style.width="1px",d.appendChild(g),b.reliableMarginRight=!parseFloat((a.getComputedStyle(g,null)||{}).marginRight)),typeof d.style.zoom!="undefined"&&(d.innerHTML="",d.style.cssText=h+"width:1px;padding:1px;display:inline;zoom:1",b.inlineBlockNeedsLayout=d.offsetWidth===3,d.style.display="block",d.style.overflow="visible",d.innerHTML="<div></div>",d.firstChild.style.width="5px",b.shrinkWrapBlocks=d.offsetWidth!==3,c.style.zoom=1),i.removeChild(c),c=d=f=g=null}),i.removeChild(n),c=d=f=g=h=i=n=null,b}();var H=/^(?:\{.*\}|\[.*\])$/,I=/([A-Z])/g;p.extend({cache:{},deletedIds:[],uuid:0,expando:"jQuery"+(p.fn.jquery+Math.random()).replace(/\D/g,""),noData:{embed:!0,object:"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000",applet:!0},hasData:function(a){return a=a.nodeType?p.cache[a[p.expando]]:a[p.expando],!!a&&!K(a)},data:function(a,c,d,e){if(!p.acceptData(a))return;var f,g,h=p.expando,i=typeof c=="string",j=a.nodeType,k=j?p.cache:a,l=j?a[h]:a[h]&&h;if((!l||!k[l]||!e&&!k[l].data)&&i&&d===b)return;l||(j?a[h]=l=p.deletedIds.pop()||++p.uuid:l=h),k[l]||(k[l]={},j||(k[l].toJSON=p.noop));if(typeof c=="object"||typeof c=="function")e?k[l]=p.extend(k[l],c):k[l].data=p.extend(k[l].data,c);return f=k[l],e||(f.data||(f.data={}),f=f.data),d!==b&&(f[p.camelCase(c)]=d),i?(g=f[c],g==null&&(g=f[p.camelCase(c)])):g=f,g},removeData:function(a,b,c){if(!p.acceptData(a))return;var d,e,f,g=a.nodeType,h=g?p.cache:a,i=g?a[p.expando]:p.expando;if(!h[i])return;if(b){d=c?h[i]:h[i].data;if(d){p.isArray(b)||(b in d?b=[b]:(b=p.camelCase(b),b in d?b=[b]:b=b.split(" ")));for(e=0,f=b.length;e<f;e++)delete d[b[e]];if(!(c?K:p.isEmptyObject)(d))return}}if(!c){delete h[i].data;if(!K(h[i]))return}g?p.cleanData([a],!0):p.support.deleteExpando||h!=h.window?delete h[i]:h[i]=null},_data:function(a,b,c){return p.data(a,b,c,!0)},acceptData:function(a){var b=a.nodeName&&p.noData[a.nodeName.toLowerCase()];return!b||b!==!0&&a.getAttribute("classid")===b}}),p.fn.extend({data:function(a,c){var d,e,f,g,h,i=this[0],j=0,k=null;if(a===b){if(this.length){k=p.data(i);if(i.nodeType===1&&!p._data(i,"parsedAttrs")){f=i.attributes;for(h=f.length;j<h;j++)g=f[j].name,g.indexOf("data-")===0&&(g=p.camelCase(g.substring(5)),J(i,g,k[g]));p._data(i,"parsedAttrs",!0)}}return k}return typeof a=="object"?this.each(function(){p.data(this,a)}):(d=a.split(".",2),d[1]=d[1]?"."+d[1]:"",e=d[1]+"!",p.access(this,function(c){if(c===b)return k=this.triggerHandler("getData"+e,[d[0]]),k===b&&i&&(k=p.data(i,a),k=J(i,a,k)),k===b&&d[1]?this.data(d[0]):k;d[1]=c,this.each(function(){var b=p(this);b.triggerHandler("setData"+e,d),p.data(this,a,c),b.triggerHandler("changeData"+e,d)})},null,c,arguments.length>1,null,!1))},removeData:function(a){return this.each(function(){p.removeData(this,a)})}}),p.extend({queue:function(a,b,c){var d;if(a)return b=(b||"fx")+"queue",d=p._data(a,b),c&&(!d||p.isArray(c)?d=p._data(a,b,p.makeArray(c)):d.push(c)),d||[]},dequeue:function(a,b){b=b||"fx";var c=p.queue(a,b),d=c.shift(),e=p._queueHooks(a,b),f=function(){p.dequeue(a,b)};d==="inprogress"&&(d=c.shift()),d&&(b==="fx"&&c.unshift("inprogress"),delete e.stop,d.call(a,f,e)),!c.length&&e&&e.empty.fire()},_queueHooks:function(a,b){var c=b+"queueHooks";return p._data(a,c)||p._data(a,c,{empty:p.Callbacks("once memory").add(function(){p.removeData(a,b+"queue",!0),p.removeData(a,c,!0)})})}}),p.fn.extend({queue:function(a,c){var d=2;return typeof a!="string"&&(c=a,a="fx",d--),arguments.length<d?p.queue(this[0],a):c===b?this:this.each(function(){var b=p.queue(this,a,c);p._queueHooks(this,a),a==="fx"&&b[0]!=="inprogress"&&p.dequeue(this,a)})},dequeue:function(a){return this.each(function(){p.dequeue(this,a)})},delay:function(a,b){return a=p.fx?p.fx.speeds[a]||a:a,b=b||"fx",this.queue(b,function(b,c){var d=setTimeout(b,a);c.stop=function(){clearTimeout(d)}})},clearQueue:function(a){return this.queue(a||"fx",[])},promise:function(a,c){var d,e=1,f=p.Deferred(),g=this,h=this.length,i=function(){--e||f.resolveWith(g,[g])};typeof a!="string"&&(c=a,a=b),a=a||"fx";while(h--)(d=p._data(g[h],a+"queueHooks"))&&d.empty&&(e++,d.empty.add(i));return i(),f.promise(c)}});var L,M,N,O=/[\t\r\n]/g,P=/\r/g,Q=/^(?:button|input)$/i,R=/^(?:button|input|object|select|textarea)$/i,S=/^a(?:rea|)$/i,T=/^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,U=p.support.getSetAttribute;p.fn.extend({attr:function(a,b){return p.access(this,p.attr,a,b,arguments.length>1)},removeAttr:function(a){return this.each(function(){p.removeAttr(this,a)})},prop:function(a,b){return p.access(this,p.prop,a,b,arguments.length>1)},removeProp:function(a){return a=p.propFix[a]||a,this.each(function(){try{this[a]=b,delete this[a]}catch(c){}})},addClass:function(a){var b,c,d,e,f,g,h;if(p.isFunction(a))return this.each(function(b){p(this).addClass(a.call(this,b,this.className))});if(a&&typeof a=="string"){b=a.split(s);for(c=0,d=this.length;c<d;c++){e=this[c];if(e.nodeType===1)if(!e.className&&b.length===1)e.className=a;else{f=" "+e.className+" ";for(g=0,h=b.length;g<h;g++)~f.indexOf(" "+b[g]+" ")||(f+=b[g]+" ");e.className=p.trim(f)}}}return this},removeClass:function(a){var c,d,e,f,g,h,i;if(p.isFunction(a))return this.each(function(b){p(this).removeClass(a.call(this,b,this.className))});if(a&&typeof a=="string"||a===b){c=(a||"").split(s);for(h=0,i=this.length;h<i;h++){e=this[h];if(e.nodeType===1&&e.className){d=(" "+e.className+" ").replace(O," ");for(f=0,g=c.length;f<g;f++)while(d.indexOf(" "+c[f]+" ")>-1)d=d.replace(" "+c[f]+" "," ");e.className=a?p.trim(d):""}}}return this},toggleClass:function(a,b){var c=typeof a,d=typeof b=="boolean";return p.isFunction(a)?this.each(function(c){p(this).toggleClass(a.call(this,c,this.className,b),b)}):this.each(function(){if(c==="string"){var e,f=0,g=p(this),h=b,i=a.split(s);while(e=i[f++])h=d?h:!g.hasClass(e),g[h?"addClass":"removeClass"](e)}else if(c==="undefined"||c==="boolean")this.className&&p._data(this,"__className__",this.className),this.className=this.className||a===!1?"":p._data(this,"__className__")||""})},hasClass:function(a){var b=" "+a+" ",c=0,d=this.length;for(;c<d;c++)if(this[c].nodeType===1&&(" "+this[c].className+" ").replace(O," ").indexOf(b)>-1)return!0;return!1},val:function(a){var c,d,e,f=this[0];if(!arguments.length){if(f)return c=p.valHooks[f.type]||p.valHooks[f.nodeName.toLowerCase()],c&&"get"in c&&(d=c.get(f,"value"))!==b?d:(d=f.value,typeof d=="string"?d.replace(P,""):d==null?"":d);return}return e=p.isFunction(a),this.each(function(d){var f,g=p(this);if(this.nodeType!==1)return;e?f=a.call(this,d,g.val()):f=a,f==null?f="":typeof f=="number"?f+="":p.isArray(f)&&(f=p.map(f,function(a){return a==null?"":a+""})),c=p.valHooks[this.type]||p.valHooks[this.nodeName.toLowerCase()];if(!c||!("set"in c)||c.set(this,f,"value")===b)this.value=f})}}),p.extend({valHooks:{option:{get:function(a){var b=a.attributes.value;return!b||b.specified?a.value:a.text}},select:{get:function(a){var b,c,d,e,f=a.selectedIndex,g=[],h=a.options,i=a.type==="select-one";if(f<0)return null;c=i?f:0,d=i?f+1:h.length;for(;c<d;c++){e=h[c];if(e.selected&&(p.support.optDisabled?!e.disabled:e.getAttribute("disabled")===null)&&(!e.parentNode.disabled||!p.nodeName(e.parentNode,"optgroup"))){b=p(e).val();if(i)return b;g.push(b)}}return i&&!g.length&&h.length?p(h[f]).val():g},set:function(a,b){var c=p.makeArray(b);return p(a).find("option").each(function(){this.selected=p.inArray(p(this).val(),c)>=0}),c.length||(a.selectedIndex=-1),c}}},attrFn:{},attr:function(a,c,d,e){var f,g,h,i=a.nodeType;if(!a||i===3||i===8||i===2)return;if(e&&p.isFunction(p.fn[c]))return p(a)[c](d);if(typeof a.getAttribute=="undefined")return p.prop(a,c,d);h=i!==1||!p.isXMLDoc(a),h&&(c=c.toLowerCase(),g=p.attrHooks[c]||(T.test(c)?M:L));if(d!==b){if(d===null){p.removeAttr(a,c);return}return g&&"set"in g&&h&&(f=g.set(a,d,c))!==b?f:(a.setAttribute(c,""+d),d)}return g&&"get"in g&&h&&(f=g.get(a,c))!==null?f:(f=a.getAttribute(c),f===null?b:f)},removeAttr:function(a,b){var c,d,e,f,g=0;if(b&&a.nodeType===1){d=b.split(s);for(;g<d.length;g++)e=d[g],e&&(c=p.propFix[e]||e,f=T.test(e),f||p.attr(a,e,""),a.removeAttribute(U?e:c),f&&c in a&&(a[c]=!1))}},attrHooks:{type:{set:function(a,b){if(Q.test(a.nodeName)&&a.parentNode)p.error("type property can't be changed");else if(!p.support.radioValue&&b==="radio"&&p.nodeName(a,"input")){var c=a.value;return a.setAttribute("type",b),c&&(a.value=c),b}}},value:{get:function(a,b){return L&&p.nodeName(a,"button")?L.get(a,b):b in a?a.value:null},set:function(a,b,c){if(L&&p.nodeName(a,"button"))return L.set(a,b,c);a.value=b}}},propFix:{tabindex:"tabIndex",readonly:"readOnly","for":"htmlFor","class":"className",maxlength:"maxLength",cellspacing:"cellSpacing",cellpadding:"cellPadding",rowspan:"rowSpan",colspan:"colSpan",usemap:"useMap",frameborder:"frameBorder",contenteditable:"contentEditable"},prop:function(a,c,d){var e,f,g,h=a.nodeType;if(!a||h===3||h===8||h===2)return;return g=h!==1||!p.isXMLDoc(a),g&&(c=p.propFix[c]||c,f=p.propHooks[c]),d!==b?f&&"set"in f&&(e=f.set(a,d,c))!==b?e:a[c]=d:f&&"get"in f&&(e=f.get(a,c))!==null?e:a[c]},propHooks:{tabIndex:{get:function(a){var c=a.getAttributeNode("tabindex");return c&&c.specified?parseInt(c.value,10):R.test(a.nodeName)||S.test(a.nodeName)&&a.href?0:b}}}}),M={get:function(a,c){var d,e=p.prop(a,c);return e===!0||typeof e!="boolean"&&(d=a.getAttributeNode(c))&&d.nodeValue!==!1?c.toLowerCase():b},set:function(a,b,c){var d;return b===!1?p.removeAttr(a,c):(d=p.propFix[c]||c,d in a&&(a[d]=!0),a.setAttribute(c,c.toLowerCase())),c}},U||(N={name:!0,id:!0,coords:!0},L=p.valHooks.button={get:function(a,c){var d;return d=a.getAttributeNode(c),d&&(N[c]?d.value!=="":d.specified)?d.value:b},set:function(a,b,c){var d=a.getAttributeNode(c);return d||(d=e.createAttribute(c),a.setAttributeNode(d)),d.value=b+""}},p.each(["width","height"],function(a,b){p.attrHooks[b]=p.extend(p.attrHooks[b],{set:function(a,c){if(c==="")return a.setAttribute(b,"auto"),c}})}),p.attrHooks.contenteditable={get:L.get,set:function(a,b,c){b===""&&(b="false"),L.set(a,b,c)}}),p.support.hrefNormalized||p.each(["href","src","width","height"],function(a,c){p.attrHooks[c]=p.extend(p.attrHooks[c],{get:function(a){var d=a.getAttribute(c,2);return d===null?b:d}})}),p.support.style||(p.attrHooks.style={get:function(a){return a.style.cssText.toLowerCase()||b},set:function(a,b){return a.style.cssText=""+b}}),p.support.optSelected||(p.propHooks.selected=p.extend(p.propHooks.selected,{get:function(a){var b=a.parentNode;return b&&(b.selectedIndex,b.parentNode&&b.parentNode.selectedIndex),null}})),p.support.enctype||(p.propFix.enctype="encoding"),p.support.checkOn||p.each(["radio","checkbox"],function(){p.valHooks[this]={get:function(a){return a.getAttribute("value")===null?"on":a.value}}}),p.each(["radio","checkbox"],function(){p.valHooks[this]=p.extend(p.valHooks[this],{set:function(a,b){if(p.isArray(b))return a.checked=p.inArray(p(a).val(),b)>=0}})});var V=/^(?:textarea|input|select)$/i,W=/^([^\.]*|)(?:\.(.+)|)$/,X=/(?:^|\s)hover(\.\S+|)\b/,Y=/^key/,Z=/^(?:mouse|contextmenu)|click/,$=/^(?:focusinfocus|focusoutblur)$/,_=function(a){return p.event.special.hover?a:a.replace(X,"mouseenter$1 mouseleave$1")};p.event={add:function(a,c,d,e,f){var g,h,i,j,k,l,m,n,o,q,r;if(a.nodeType===3||a.nodeType===8||!c||!d||!(g=p._data(a)))return;d.handler&&(o=d,d=o.handler,f=o.selector),d.guid||(d.guid=p.guid++),i=g.events,i||(g.events=i={}),h=g.handle,h||(g.handle=h=function(a){return typeof p!="undefined"&&(!a||p.event.triggered!==a.type)?p.event.dispatch.apply(h.elem,arguments):b},h.elem=a),c=p.trim(_(c)).split(" ");for(j=0;j<c.length;j++){k=W.exec(c[j])||[],l=k[1],m=(k[2]||"").split(".").sort(),r=p.event.special[l]||{},l=(f?r.delegateType:r.bindType)||l,r=p.event.special[l]||{},n=p.extend({type:l,origType:k[1],data:e,handler:d,guid:d.guid,selector:f,namespace:m.join(".")},o),q=i[l];if(!q){q=i[l]=[],q.delegateCount=0;if(!r.setup||r.setup.call(a,e,m,h)===!1)a.addEventListener?a.addEventListener(l,h,!1):a.attachEvent&&a.attachEvent("on"+l,h)}r.add&&(r.add.call(a,n),n.handler.guid||(n.handler.guid=d.guid)),f?q.splice(q.delegateCount++,0,n):q.push(n),p.event.global[l]=!0}a=null},global:{},remove:function(a,b,c,d,e){var f,g,h,i,j,k,l,m,n,o,q,r=p.hasData(a)&&p._data(a);if(!r||!(m=r.events))return;b=p.trim(_(b||"")).split(" ");for(f=0;f<b.length;f++){g=W.exec(b[f])||[],h=i=g[1],j=g[2];if(!h){for(h in m)p.event.remove(a,h+b[f],c,d,!0);continue}n=p.event.special[h]||{},h=(d?n.delegateType:n.bindType)||h,o=m[h]||[],k=o.length,j=j?new RegExp("(^|\\.)"+j.split(".").sort().join("\\.(?:.*\\.|)")+"(\\.|$)"):null;for(l=0;l<o.length;l++)q=o[l],(e||i===q.origType)&&(!c||c.guid===q.guid)&&(!j||j.test(q.namespace))&&(!d||d===q.selector||d==="**"&&q.selector)&&(o.splice(l--,1),q.selector&&o.delegateCount--,n.remove&&n.remove.call(a,q));o.length===0&&k!==o.length&&((!n.teardown||n.teardown.call(a,j,r.handle)===!1)&&p.removeEvent(a,h,r.handle),delete m[h])}p.isEmptyObject(m)&&(delete r.handle,p.removeData(a,"events",!0))},customEvent:{getData:!0,setData:!0,changeData:!0},trigger:function(c,d,f,g){if(!f||f.nodeType!==3&&f.nodeType!==8){var h,i,j,k,l,m,n,o,q,r,s=c.type||c,t=[];if($.test(s+p.event.triggered))return;s.indexOf("!")>=0&&(s=s.slice(0,-1),i=!0),s.indexOf(".")>=0&&(t=s.split("."),s=t.shift(),t.sort());if((!f||p.event.customEvent[s])&&!p.event.global[s])return;c=typeof c=="object"?c[p.expando]?c:new p.Event(s,c):new p.Event(s),c.type=s,c.isTrigger=!0,c.exclusive=i,c.namespace=t.join("."),c.namespace_re=c.namespace?new RegExp("(^|\\.)"+t.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,m=s.indexOf(":")<0?"on"+s:"";if(!f){h=p.cache;for(j in h)h[j].events&&h[j].events[s]&&p.event.trigger(c,d,h[j].handle.elem,!0);return}c.result=b,c.target||(c.target=f),d=d!=null?p.makeArray(d):[],d.unshift(c),n=p.event.special[s]||{};if(n.trigger&&n.trigger.apply(f,d)===!1)return;q=[[f,n.bindType||s]];if(!g&&!n.noBubble&&!p.isWindow(f)){r=n.delegateType||s,k=$.test(r+s)?f:f.parentNode;for(l=f;k;k=k.parentNode)q.push([k,r]),l=k;l===(f.ownerDocument||e)&&q.push([l.defaultView||l.parentWindow||a,r])}for(j=0;j<q.length&&!c.isPropagationStopped();j++)k=q[j][0],c.type=q[j][1],o=(p._data(k,"events")||{})[c.type]&&p._data(k,"handle"),o&&o.apply(k,d),o=m&&k[m],o&&p.acceptData(k)&&o.apply(k,d)===!1&&c.preventDefault();return c.type=s,!g&&!c.isDefaultPrevented()&&(!n._default||n._default.apply(f.ownerDocument,d)===!1)&&(s!=="click"||!p.nodeName(f,"a"))&&p.acceptData(f)&&m&&f[s]&&(s!=="focus"&&s!=="blur"||c.target.offsetWidth!==0)&&!p.isWindow(f)&&(l=f[m],l&&(f[m]=null),p.event.triggered=s,f[s](),p.event.triggered=b,l&&(f[m]=l)),c.result}return},dispatch:function(c){c=p.event.fix(c||a.event);var d,e,f,g,h,i,j,k,l,m,n,o=(p._data(this,"events")||{})[c.type]||[],q=o.delegateCount,r=[].slice.call(arguments),s=!c.exclusive&&!c.namespace,t=p.event.special[c.type]||{},u=[];r[0]=c,c.delegateTarget=this;if(t.preDispatch&&t.preDispatch.call(this,c)===!1)return;if(q&&(!c.button||c.type!=="click")){g=p(this),g.context=this;for(f=c.target;f!=this;f=f.parentNode||this)if(f.disabled!==!0||c.type!=="click"){i={},k=[],g[0]=f;for(d=0;d<q;d++)l=o[d],m=l.selector,i[m]===b&&(i[m]=g.is(m)),i[m]&&k.push(l);k.length&&u.push({elem:f,matches:k})}}o.length>q&&u.push({elem:this,matches:o.slice(q)});for(d=0;d<u.length&&!c.isPropagationStopped();d++){j=u[d],c.currentTarget=j.elem;for(e=0;e<j.matches.length&&!c.isImmediatePropagationStopped();e++){l=j.matches[e];if(s||!c.namespace&&!l.namespace||c.namespace_re&&c.namespace_re.test(l.namespace))c.data=l.data,c.handleObj=l,h=((p.event.special[l.origType]||{}).handle||l.handler).apply(j.elem,r),h!==b&&(c.result=h,h===!1&&(c.preventDefault(),c.stopPropagation()))}}return t.postDispatch&&t.postDispatch.call(this,c),c.result},props:"attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(a,b){return a.which==null&&(a.which=b.charCode!=null?b.charCode:b.keyCode),a}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(a,c){var d,f,g,h=c.button,i=c.fromElement;return a.pageX==null&&c.clientX!=null&&(d=a.target.ownerDocument||e,f=d.documentElement,g=d.body,a.pageX=c.clientX+(f&&f.scrollLeft||g&&g.scrollLeft||0)-(f&&f.clientLeft||g&&g.clientLeft||0),a.pageY=c.clientY+(f&&f.scrollTop||g&&g.scrollTop||0)-(f&&f.clientTop||g&&g.clientTop||0)),!a.relatedTarget&&i&&(a.relatedTarget=i===a.target?c.toElement:i),!a.which&&h!==b&&(a.which=h&1?1:h&2?3:h&4?2:0),a}},fix:function(a){if(a[p.expando])return a;var b,c,d=a,f=p.event.fixHooks[a.type]||{},g=f.props?this.props.concat(f.props):this.props;a=p.Event(d);for(b=g.length;b;)c=g[--b],a[c]=d[c];return a.target||(a.target=d.srcElement||e),a.target.nodeType===3&&(a.target=a.target.parentNode),a.metaKey=!!a.metaKey,f.filter?f.filter(a,d):a},special:{ready:{setup:p.bindReady},load:{noBubble:!0},focus:{delegateType:"focusin"},blur:{delegateType:"focusout"},beforeunload:{setup:function(a,b,c){p.isWindow(this)&&(this.onbeforeunload=c)},teardown:function(a,b){this.onbeforeunload===b&&(this.onbeforeunload=null)}}},simulate:function(a,b,c,d){var e=p.extend(new p.Event,c,{type:a,isSimulated:!0,originalEvent:{}});d?p.event.trigger(e,null,b):p.event.dispatch.call(b,e),e.isDefaultPrevented()&&c.preventDefault()}},p.event.handle=p.event.dispatch,p.removeEvent=e.removeEventListener?function(a,b,c){a.removeEventListener&&a.removeEventListener(b,c,!1)}:function(a,b,c){var d="on"+b;a.detachEvent&&(typeof a[d]=="undefined"&&(a[d]=null),a.detachEvent(d,c))},p.Event=function(a,b){if(this instanceof p.Event)a&&a.type?(this.originalEvent=a,this.type=a.type,this.isDefaultPrevented=a.defaultPrevented||a.returnValue===!1||a.getPreventDefault&&a.getPreventDefault()?bb:ba):this.type=a,b&&p.extend(this,b),this.timeStamp=a&&a.timeStamp||p.now(),this[p.expando]=!0;else return new p.Event(a,b)},p.Event.prototype={preventDefault:function(){this.isDefaultPrevented=bb;var a=this.originalEvent;if(!a)return;a.preventDefault?a.preventDefault():a.returnValue=!1},stopPropagation:function(){this.isPropagationStopped=bb;var a=this.originalEvent;if(!a)return;a.stopPropagation&&a.stopPropagation(),a.cancelBubble=!0},stopImmediatePropagation:function(){this.isImmediatePropagationStopped=bb,this.stopPropagation()},isDefaultPrevented:ba,isPropagationStopped:ba,isImmediatePropagationStopped:ba},p.each({mouseenter:"mouseover",mouseleave:"mouseout"},function(a,b){p.event.special[a]={delegateType:b,bindType:b,handle:function(a){var c,d=this,e=a.relatedTarget,f=a.handleObj,g=f.selector;if(!e||e!==d&&!p.contains(d,e))a.type=f.origType,c=f.handler.apply(this,arguments),a.type=b;return c}}}),p.support.submitBubbles||(p.event.special.submit={setup:function(){if(p.nodeName(this,"form"))return!1;p.event.add(this,"click._submit keypress._submit",function(a){var c=a.target,d=p.nodeName(c,"input")||p.nodeName(c,"button")?c.form:b;d&&!p._data(d,"_submit_attached")&&(p.event.add(d,"submit._submit",function(a){a._submit_bubble=!0}),p._data(d,"_submit_attached",!0))})},postDispatch:function(a){a._submit_bubble&&(delete a._submit_bubble,this.parentNode&&!a.isTrigger&&p.event.simulate("submit",this.parentNode,a,!0))},teardown:function(){if(p.nodeName(this,"form"))return!1;p.event.remove(this,"._submit")}}),p.support.changeBubbles||(p.event.special.change={setup:function(){if(V.test(this.nodeName)){if(this.type==="checkbox"||this.type==="radio")p.event.add(this,"propertychange._change",function(a){a.originalEvent.propertyName==="checked"&&(this._just_changed=!0)}),p.event.add(this,"click._change",function(a){this._just_changed&&!a.isTrigger&&(this._just_changed=!1),p.event.simulate("change",this,a,!0)});return!1}p.event.add(this,"beforeactivate._change",function(a){var b=a.target;V.test(b.nodeName)&&!p._data(b,"_change_attached")&&(p.event.add(b,"change._change",function(a){this.parentNode&&!a.isSimulated&&!a.isTrigger&&p.event.simulate("change",this.parentNode,a,!0)}),p._data(b,"_change_attached",!0))})},handle:function(a){var b=a.target;if(this!==b||a.isSimulated||a.isTrigger||b.type!=="radio"&&b.type!=="checkbox")return a.handleObj.handler.apply(this,arguments)},teardown:function(){return p.event.remove(this,"._change"),V.test(this.nodeName)}}),p.support.focusinBubbles||p.each({focus:"focusin",blur:"focusout"},function(a,b){var c=0,d=function(a){p.event.simulate(b,a.target,p.event.fix(a),!0)};p.event.special[b]={setup:function(){c++===0&&e.addEventListener(a,d,!0)},teardown:function(){--c===0&&e.removeEventListener(a,d,!0)}}}),p.fn.extend({on:function(a,c,d,e,f){var g,h;if(typeof a=="object"){typeof c!="string"&&(d=d||c,c=b);for(h in a)this.on(h,c,d,a[h],f);return this}d==null&&e==null?(e=c,d=c=b):e==null&&(typeof c=="string"?(e=d,d=b):(e=d,d=c,c=b));if(e===!1)e=ba;else if(!e)return this;return f===1&&(g=e,e=function(a){return p().off(a),g.apply(this,arguments)},e.guid=g.guid||(g.guid=p.guid++)),this.each(function(){p.event.add(this,a,e,d,c)})},one:function(a,b,c,d){return this.on(a,b,c,d,1)},off:function(a,c,d){var e,f;if(a&&a.preventDefault&&a.handleObj)return e=a.handleObj,p(a.delegateTarget).off(e.namespace?e.origType+"."+e.namespace:e.origType,e.selector,e.handler),this;if(typeof a=="object"){for(f in a)this.off(f,c,a[f]);return this}if(c===!1||typeof c=="function")d=c,c=b;return d===!1&&(d=ba),this.each(function(){p.event.remove(this,a,d,c)})},bind:function(a,b,c){return this.on(a,null,b,c)},unbind:function(a,b){return this.off(a,null,b)},live:function(a,b,c){return p(this.context).on(a,this.selector,b,c),this},die:function(a,b){return p(this.context).off(a,this.selector||"**",b),this},delegate:function(a,b,c,d){return this.on(b,a,c,d)},undelegate:function(a,b,c){return arguments.length==1?this.off(a,"**"):this.off(b,a||"**",c)},trigger:function(a,b){return this.each(function(){p.event.trigger(a,b,this)})},triggerHandler:function(a,b){if(this[0])return p.event.trigger(a,b,this[0],!0)},toggle:function(a){var b=arguments,c=a.guid||p.guid++,d=0,e=function(c){var e=(p._data(this,"lastToggle"+a.guid)||0)%d;return p._data(this,"lastToggle"+a.guid,e+1),c.preventDefault(),b[e].apply(this,arguments)||!1};e.guid=c;while(d<b.length)b[d++].guid=c;return this.click(e)},hover:function(a,b){return this.mouseenter(a).mouseleave(b||a)}}),p.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(a,b){p.fn[b]=function(a,c){return c==null&&(c=a,a=null),arguments.length>0?this.on(b,null,a,c):this.trigger(b)},Y.test(b)&&(p.event.fixHooks[b]=p.event.keyHooks),Z.test(b)&&(p.event.fixHooks[b]=p.event.mouseHooks)}),function(a,b){function bd(a,b,c,d){var e=0,f=b.length;for(;e<f;e++)Z(a,b[e],c,d)}function be(a,b,c,d,e,f){var g,h=$.setFilters[b.toLowerCase()];return h||Z.error(b),(a||!(g=e))&&bd(a||"*",d,g=[],e),g.length>0?h(g,c,f):[]}function bf(a,c,d,e,f){var g,h,i,j,k,l,m,n,p=0,q=f.length,s=L.POS,t=new RegExp("^"+s.source+"(?!"+r+")","i"),u=function(){var a=1,c=arguments.length-2;for(;a<c;a++)arguments[a]===b&&(g[a]=b)};for(;p<q;p++){s.exec(""),a=f[p],j=[],i=0,k=e;while(g=s.exec(a)){n=s.lastIndex=g.index+g[0].length;if(n>i){m=a.slice(i,g.index),i=n,l=[c],B.test(m)&&(k&&(l=k),k=e);if(h=H.test(m))m=m.slice(0,-5).replace(B,"$&*");g.length>1&&g[0].replace(t,u),k=be(m,g[1],g[2],l,k,h)}}k?(j=j.concat(k),(m=a.slice(i))&&m!==")"?B.test(m)?bd(m,j,d,e):Z(m,c,d,e?e.concat(k):k):o.apply(d,j)):Z(a,c,d,e)}return q===1?d:Z.uniqueSort(d)}function bg(a,b,c){var d,e,f,g=[],i=0,j=D.exec(a),k=!j.pop()&&!j.pop(),l=k&&a.match(C)||[""],m=$.preFilter,n=$.filter,o=!c&&b!==h;for(;(e=l[i])!=null&&k;i++){g.push(d=[]),o&&(e=" "+e);while(e){k=!1;if(j=B.exec(e))e=e.slice(j[0].length),k=d.push({part:j.pop().replace(A," "),captures:j});for(f in n)(j=L[f].exec(e))&&(!m[f]||(j=m[f](j,b,c)))&&(e=e.slice(j.shift().length),k=d.push({part:f,captures:j}));if(!k)break}}return k||Z.error(a),g}function bh(a,b,e){var f=b.dir,g=m++;return a||(a=function(a){return a===e}),b.first?function(b,c){while(b=b[f])if(b.nodeType===1)return a(b,c)&&b}:function(b,e){var h,i=g+"."+d,j=i+"."+c;while(b=b[f])if(b.nodeType===1){if((h=b[q])===j)return b.sizset;if(typeof h=="string"&&h.indexOf(i)===0){if(b.sizset)return b}else{b[q]=j;if(a(b,e))return b.sizset=!0,b;b.sizset=!1}}}}function bi(a,b){return a?function(c,d){var e=b(c,d);return e&&a(e===!0?c:e,d)}:b}function bj(a,b,c){var d,e,f=0;for(;d=a[f];f++)$.relative[d.part]?e=bh(e,$.relative[d.part],b):(d.captures.push(b,c),e=bi(e,$.filter[d.part].apply(null,d.captures)));return e}function bk(a){return function(b,c){var d,e=0;for(;d=a[e];e++)if(d(b,c))return!0;return!1}}var c,d,e,f,g,h=a.document,i=h.documentElement,j="undefined",k=!1,l=!0,m=0,n=[].slice,o=[].push,q=("sizcache"+Math.random()).replace(".",""),r="[\\x20\\t\\r\\n\\f]",s="(?:\\\\.|[-\\w]|[^\\x00-\\xa0])+",t=s.replace("w","w#"),u="([*^$|!~]?=)",v="\\["+r+"*("+s+")"+r+"*(?:"+u+r+"*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|("+t+")|)|)"+r+"*\\]",w=":("+s+")(?:\\((?:(['\"])((?:\\\\.|[^\\\\])*?)\\2|((?:[^,]|\\\\,|(?:,(?=[^\\[]*\\]))|(?:,(?=[^\\(]*\\))))*))\\)|)",x=":(nth|eq|gt|lt|first|last|even|odd)(?:\\((\\d*)\\)|)(?=[^-]|$)",y=r+"*([\\x20\\t\\r\\n\\f>+~])"+r+"*",z="(?=[^\\x20\\t\\r\\n\\f])(?:\\\\.|"+v+"|"+w.replace(2,7)+"|[^\\\\(),])+",A=new RegExp("^"+r+"+|((?:^|[^\\\\])(?:\\\\.)*)"+r+"+$","g"),B=new RegExp("^"+y),C=new RegExp(z+"?(?="+r+"*,|$)","g"),D=new RegExp("^(?:(?!,)(?:(?:^|,)"+r+"*"+z+")*?|"+r+"*(.*?))(\\)|$)"),E=new RegExp(z.slice(19,-6)+"\\x20\\t\\r\\n\\f>+~])+|"+y,"g"),F=/^(?:#([\w\-]+)|(\w+)|\.([\w\-]+))$/,G=/[\x20\t\r\n\f]*[+~]/,H=/:not\($/,I=/h\d/i,J=/input|select|textarea|button/i,K=/\\(?!\\)/g,L={ID:new RegExp("^#("+s+")"),CLASS:new RegExp("^\\.("+s+")"),NAME:new RegExp("^\\[name=['\"]?("+s+")['\"]?\\]"),TAG:new RegExp("^("+s.replace("[-","[-\\*")+")"),ATTR:new RegExp("^"+v),PSEUDO:new RegExp("^"+w),CHILD:new RegExp("^:(only|nth|last|first)-child(?:\\("+r+"*(even|odd|(([+-]|)(\\d*)n|)"+r+"*(?:([+-]|)"+r+"*(\\d+)|))"+r+"*\\)|)","i"),POS:new RegExp(x,"ig"),needsContext:new RegExp("^"+r+"*[>+~]|"+x,"i")},M={},N=[],O={},P=[],Q=function(a){return a.sizzleFilter=!0,a},R=function(a){return function(b){return b.nodeName.toLowerCase()==="input"&&b.type===a}},S=function(a){return function(b){var c=b.nodeName.toLowerCase();return(c==="input"||c==="button")&&b.type===a}},T=function(a){var b=!1,c=h.createElement("div");try{b=a(c)}catch(d){}return c=null,b},U=T(function(a){a.innerHTML="<select></select>";var b=typeof a.lastChild.getAttribute("multiple");return b!=="boolean"&&b!=="string"}),V=T(function(a){a.id=q+0,a.innerHTML="<a name='"+q+"'></a><div name='"+q+"'></div>",i.insertBefore(a,i.firstChild);var b=h.getElementsByName&&h.getElementsByName(q).length===2+h.getElementsByName(q+0).length;return g=!h.getElementById(q),i.removeChild(a),b}),W=T(function(a){return a.appendChild(h.createComment("")),a.getElementsByTagName("*").length===0}),X=T(function(a){return a.innerHTML="<a href='#'></a>",a.firstChild&&typeof a.firstChild.getAttribute!==j&&a.firstChild.getAttribute("href")==="#"}),Y=T(function(a){return a.innerHTML="<div class='hidden e'></div><div class='hidden'></div>",!a.getElementsByClassName||a.getElementsByClassName("e").length===0?!1:(a.lastChild.className="e",a.getElementsByClassName("e").length!==1)}),Z=function(a,b,c,d){c=c||[],b=b||h;var e,f,g,i,j=b.nodeType;if(j!==1&&j!==9)return[];if(!a||typeof a!="string")return c;g=ba(b);if(!g&&!d)if(e=F.exec(a))if(i=e[1]){if(j===9){f=b.getElementById(i);if(!f||!f.parentNode)return c;if(f.id===i)return c.push(f),c}else if(b.ownerDocument&&(f=b.ownerDocument.getElementById(i))&&bb(b,f)&&f.id===i)return c.push(f),c}else{if(e[2])return o.apply(c,n.call(b.getElementsByTagName(a),0)),c;if((i=e[3])&&Y&&b.getElementsByClassName)return o.apply(c,n.call(b.getElementsByClassName(i),0)),c}return bm(a,b,c,d,g)},$=Z.selectors={cacheLength:50,match:L,order:["ID","TAG"],attrHandle:{},createPseudo:Q,find:{ID:g?function(a,b,c){if(typeof b.getElementById!==j&&!c){var d=b.getElementById(a);return d&&d.parentNode?[d]:[]}}:function(a,c,d){if(typeof c.getElementById!==j&&!d){var e=c.getElementById(a);return e?e.id===a||typeof e.getAttributeNode!==j&&e.getAttributeNode("id").value===a?[e]:b:[]}},TAG:W?function(a,b){if(typeof b.getElementsByTagName!==j)return b.getElementsByTagName(a)}:function(a,b){var c=b.getElementsByTagName(a);if(a==="*"){var d,e=[],f=0;for(;d=c[f];f++)d.nodeType===1&&e.push(d);return e}return c}},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(a){return a[1]=a[1].replace(K,""),a[3]=(a[4]||a[5]||"").replace(K,""),a[2]==="~="&&(a[3]=" "+a[3]+" "),a.slice(0,4)},CHILD:function(a){return a[1]=a[1].toLowerCase(),a[1]==="nth"?(a[2]||Z.error(a[0]),a[3]=+(a[3]?a[4]+(a[5]||1):2*(a[2]==="even"||a[2]==="odd")),a[4]=+(a[6]+a[7]||a[2]==="odd")):a[2]&&Z.error(a[0]),a},PSEUDO:function(a){var b,c=a[4];return L.CHILD.test(a[0])?null:(c&&(b=D.exec(c))&&b.pop()&&(a[0]=a[0].slice(0,b[0].length-c.length-1),c=b[0].slice(0,-1)),a.splice(2,3,c||a[3]),a)}},filter:{ID:g?function(a){return a=a.replace(K,""),function(b){return b.getAttribute("id")===a}}:function(a){return a=a.replace(K,""),function(b){var c=typeof b.getAttributeNode!==j&&b.getAttributeNode("id");return c&&c.value===a}},TAG:function(a){return a==="*"?function(){return!0}:(a=a.replace(K,"").toLowerCase(),function(b){return b.nodeName&&b.nodeName.toLowerCase()===a})},CLASS:function(a){var b=M[a];return b||(b=M[a]=new RegExp("(^|"+r+")"+a+"("+r+"|$)"),N.push(a),N.length>$.cacheLength&&delete M[N.shift()]),function(a){return b.test(a.className||typeof a.getAttribute!==j&&a.getAttribute("class")||"")}},ATTR:function(a,b,c){return b?function(d){var e=Z.attr(d,a),f=e+"";if(e==null)return b==="!=";switch(b){case"=":return f===c;case"!=":return f!==c;case"^=":return c&&f.indexOf(c)===0;case"*=":return c&&f.indexOf(c)>-1;case"$=":return c&&f.substr(f.length-c.length)===c;case"~=":return(" "+f+" ").indexOf(c)>-1;case"|=":return f===c||f.substr(0,c.length+1)===c+"-"}}:function(b){return Z.attr(b,a)!=null}},CHILD:function(a,b,c,d){if(a==="nth"){var e=m++;return function(a){var b,f,g=0,h=a;if(c===1&&d===0)return!0;b=a.parentNode;if(b&&(b[q]!==e||!a.sizset)){for(h=b.firstChild;h;h=h.nextSibling)if(h.nodeType===1){h.sizset=++g;if(h===a)break}b[q]=e}return f=a.sizset-d,c===0?f===0:f%c===0&&f/c>=0}}return function(b){var c=b;switch(a){case"only":case"first":while(c=c.previousSibling)if(c.nodeType===1)return!1;if(a==="first")return!0;c=b;case"last":while(c=c.nextSibling)if(c.nodeType===1)return!1;return!0}}},PSEUDO:function(a,b,c,d){var e=$.pseudos[a]||$.pseudos[a.toLowerCase()];return e||Z.error("unsupported pseudo: "+a),e.sizzleFilter?e(b,c,d):e}},pseudos:{not:Q(function(a,b,c){var d=bl(a.replace(A,"$1"),b,c);return function(a){return!d(a)}}),enabled:function(a){return a.disabled===!1},disabled:function(a){return a.disabled===!0},checked:function(a){var b=a.nodeName.toLowerCase();return b==="input"&&!!a.checked||b==="option"&&!!a.selected},selected:function(a){return a.parentNode&&a.parentNode.selectedIndex,a.selected===!0},parent:function(a){return!$.pseudos.empty(a)},empty:function(a){var b;a=a.firstChild;while(a){if(a.nodeName>"@"||(b=a.nodeType)===3||b===4)return!1;a=a.nextSibling}return!0},contains:Q(function(a){return function(b){return(b.textContent||b.innerText||bc(b)).indexOf(a)>-1}}),has:Q(function(a){return function(b){return Z(a,b).length>0}}),header:function(a){return I.test(a.nodeName)},text:function(a){var b,c;return a.nodeName.toLowerCase()==="input"&&(b=a.type)==="text"&&((c=a.getAttribute("type"))==null||c.toLowerCase()===b)},radio:R("radio"),checkbox:R("checkbox"),file:R("file"),password:R("password"),image:R("image"),submit:S("submit"),reset:S("reset"),button:function(a){var b=a.nodeName.toLowerCase();return b==="input"&&a.type==="button"||b==="button"},input:function(a){return J.test(a.nodeName)},focus:function(a){var b=a.ownerDocument;return a===b.activeElement&&(!b.hasFocus||b.hasFocus())&&(!!a.type||!!a.href)},active:function(a){return a===a.ownerDocument.activeElement}},setFilters:{first:function(a,b,c){return c?a.slice(1):[a[0]]},last:function(a,b,c){var d=a.pop();return c?a:[d]},even:function(a,b,c){var d=[],e=c?1:0,f=a.length;for(;e<f;e=e+2)d.push(a[e]);return d},odd:function(a,b,c){var d=[],e=c?0:1,f=a.length;for(;e<f;e=e+2)d.push(a[e]);return d},lt:function(a,b,c){return c?a.slice(+b):a.slice(0,+b)},gt:function(a,b,c){return c?a.slice(0,+b+1):a.slice(+b+1)},eq:function(a,b,c){var d=a.splice(+b,1);return c?a:d}}};$.setFilters.nth=$.setFilters.eq,$.filters=$.pseudos,X||($.attrHandle={href:function(a){return a.getAttribute("href",2)},type:function(a){return a.getAttribute("type")}}),V&&($.order.push("NAME"),$.find.NAME=function(a,b){if(typeof b.getElementsByName!==j)return b.getElementsByName(a)}),Y&&($.order.splice(1,0,"CLASS"),$.find.CLASS=function(a,b,c){if(typeof b.getElementsByClassName!==j&&!c)return b.getElementsByClassName(a)});try{n.call(i.childNodes,0)[0].nodeType}catch(_){n=function(a){var b,c=[];for(;b=this[a];a++)c.push(b);return c}}var ba=Z.isXML=function(a){var b=a&&(a.ownerDocument||a).documentElement;return b?b.nodeName!=="HTML":!1},bb=Z.contains=i.compareDocumentPosition?function(a,b){return!!(a.compareDocumentPosition(b)&16)}:i.contains?function(a,b){var c=a.nodeType===9?a.documentElement:a,d=b.parentNode;return a===d||!!(d&&d.nodeType===1&&c.contains&&c.contains(d))}:function(a,b){while(b=b.parentNode)if(b===a)return!0;return!1},bc=Z.getText=function(a){var b,c="",d=0,e=a.nodeType;if(e){if(e===1||e===9||e===11){if(typeof a.textContent=="string")return a.textContent;for(a=a.firstChild;a;a=a.nextSibling)c+=bc(a)}else if(e===3||e===4)return a.nodeValue}else for(;b=a[d];d++)c+=bc(b);return c};Z.attr=function(a,b){var c,d=ba(a);return d||(b=b.toLowerCase()),$.attrHandle[b]?$.attrHandle[b](a):U||d?a.getAttribute(b):(c=a.getAttributeNode(b),c?typeof a[b]=="boolean"?a[b]?b:null:c.specified?c.value:null:null)},Z.error=function(a){throw new Error("Syntax error, unrecognized expression: "+a)},[0,0].sort(function(){return l=0}),i.compareDocumentPosition?e=function(a,b){return a===b?(k=!0,0):(!a.compareDocumentPosition||!b.compareDocumentPosition?a.compareDocumentPosition:a.compareDocumentPosition(b)&4)?-1:1}:(e=function(a,b){if(a===b)return k=!0,0;if(a.sourceIndex&&b.sourceIndex)return a.sourceIndex-b.sourceIndex;var c,d,e=[],g=[],h=a.parentNode,i=b.parentNode,j=h;if(h===i)return f(a,b);if(!h)return-1;if(!i)return 1;while(j)e.unshift(j),j=j.parentNode;j=i;while(j)g.unshift(j),j=j.parentNode;c=e.length,d=g.length;for(var l=0;l<c&&l<d;l++)if(e[l]!==g[l])return f(e[l],g[l]);return l===c?f(a,g[l],-1):f(e[l],b,1)},f=function(a,b,c){if(a===b)return c;var d=a.nextSibling;while(d){if(d===b)return-1;d=d.nextSibling}return 1}),Z.uniqueSort=function(a){var b,c=1;if(e){k=l,a.sort(e);if(k)for(;b=a[c];c++)b===a[c-1]&&a.splice(c--,1)}return a};var bl=Z.compile=function(a,b,c){var d,e,f,g=O[a];if(g&&g.context===b)return g;e=bg(a,b,c);for(f=0;d=e[f];f++)e[f]=bj(d,b,c);return g=O[a]=bk(e),g.context=b,g.runs=g.dirruns=0,P.push(a),P.length>$.cacheLength&&delete O[P.shift()],g};Z.matches=function(a,b){return Z(a,null,null,b)},Z.matchesSelector=function(a,b){return Z(b,null,null,[a]).length>0};var bm=function(a,b,e,f,g){a=a.replace(A,"$1");var h,i,j,k,l,m,p,q,r,s=a.match(C),t=a.match(E),u=b.nodeType;if(L.POS.test(a))return bf(a,b,e,f,s);if(f)h=n.call(f,0);else if(s&&s.length===1){if(t.length>1&&u===9&&!g&&(s=L.ID.exec(t[0]))){b=$.find.ID(s[1],b,g)[0];if(!b)return e;a=a.slice(t.shift().length)}q=(s=G.exec(t[0]))&&!s.index&&b.parentNode||b,r=t.pop(),m=r.split(":not")[0];for(j=0,k=$.order.length;j<k;j++){p=$.order[j];if(s=L[p].exec(m)){h=$.find[p]((s[1]||"").replace(K,""),q,g);if(h==null)continue;m===r&&(a=a.slice(0,a.length-r.length)+m.replace(L[p],""),a||o.apply(e,n.call(h,0)));break}}}if(a){i=bl(a,b,g),d=i.dirruns++,h==null&&(h=$.find.TAG("*",G.test(a)&&b.parentNode||b));for(j=0;l=h[j];j++)c=i.runs++,i(l,b)&&e.push(l)}return e};h.querySelectorAll&&function(){var a,b=bm,c=/'|\\/g,d=/\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g,e=[],f=[":active"],g=i.matchesSelector||i.mozMatchesSelector||i.webkitMatchesSelector||i.oMatchesSelector||i.msMatchesSelector;T(function(a){a.innerHTML="<select><option selected></option></select>",a.querySelectorAll("[selected]").length||e.push("\\["+r+"*(?:checked|disabled|ismap|multiple|readonly|selected|value)"),a.querySelectorAll(":checked").length||e.push(":checked")}),T(function(a){a.innerHTML="<p test=''></p>",a.querySelectorAll("[test^='']").length&&e.push("[*^$]="+r+"*(?:\"\"|'')"),a.innerHTML="<input type='hidden'>",a.querySelectorAll(":enabled").length||e.push(":enabled",":disabled")}),e=e.length&&new RegExp(e.join("|")),bm=function(a,d,f,g,h){if(!g&&!h&&(!e||!e.test(a)))if(d.nodeType===9)try{return o.apply(f,n.call(d.querySelectorAll(a),0)),f}catch(i){}else if(d.nodeType===1&&d.nodeName.toLowerCase()!=="object"){var j=d.getAttribute("id"),k=j||q,l=G.test(a)&&d.parentNode||d;j?k=k.replace(c,"\\$&"):d.setAttribute("id",k);try{return o.apply(f,n.call(l.querySelectorAll(a.replace(C,"[id='"+k+"'] $&")),0)),f}catch(i){}finally{j||d.removeAttribute("id")}}return b(a,d,f,g,h)},g&&(T(function(b){a=g.call(b,"div");try{g.call(b,"[test!='']:sizzle"),f.push($.match.PSEUDO)}catch(c){}}),f=new RegExp(f.join("|")),Z.matchesSelector=function(b,c){c=c.replace(d,"='$1']");if(!ba(b)&&!f.test(c)&&(!e||!e.test(c)))try{var h=g.call(b,c);if(h||a||b.document&&b.document.nodeType!==11)return h}catch(i){}return Z(c,null,null,[b]).length>0})}(),Z.attr=p.attr,p.find=Z,p.expr=Z.selectors,p.expr[":"]=p.expr.pseudos,p.unique=Z.uniqueSort,p.text=Z.getText,p.isXMLDoc=Z.isXML,p.contains=Z.contains}(a);var bc=/Until$/,bd=/^(?:parents|prev(?:Until|All))/,be=/^.[^:#\[\.,]*$/,bf=p.expr.match.needsContext,bg={children:!0,contents:!0,next:!0,prev:!0};p.fn.extend({find:function(a){var b,c,d,e,f,g,h=this;if(typeof a!="string")return p(a).filter(function(){for(b=0,c=h.length;b<c;b++)if(p.contains(h[b],this))return!0});g=this.pushStack("","find",a);for(b=0,c=this.length;b<c;b++){d=g.length,p.find(a,this[b],g);if(b>0)for(e=d;e<g.length;e++)for(f=0;f<d;f++)if(g[f]===g[e]){g.splice(e--,1);break}}return g},has:function(a){var b,c=p(a,this),d=c.length;return this.filter(function(){for(b=0;b<d;b++)if(p.contains(this,c[b]))return!0})},not:function(a){return this.pushStack(bj(this,a,!1),"not",a)},filter:function(a){return this.pushStack(bj(this,a,!0),"filter",a)},is:function(a){return!!a&&(typeof a=="string"?bf.test(a)?p(a,this.context).index(this[0])>=0:p.filter(a,this).length>0:this.filter(a).length>0)},closest:function(a,b){var c,d=0,e=this.length,f=[],g=bf.test(a)||typeof a!="string"?p(a,b||this.context):0;for(;d<e;d++){c=this[d];while(c&&c.ownerDocument&&c!==b&&c.nodeType!==11){if(g?g.index(c)>-1:p.find.matchesSelector(c,a)){f.push(c);break}c=c.parentNode}}return f=f.length>1?p.unique(f):f,this.pushStack(f,"closest",a)},index:function(a){return a?typeof a=="string"?p.inArray(this[0],p(a)):p.inArray(a.jquery?a[0]:a,this):this[0]&&this[0].parentNode?this.prevAll().length:-1},add:function(a,b){var c=typeof a=="string"?p(a,b):p.makeArray(a&&a.nodeType?[a]:a),d=p.merge(this.get(),c);return this.pushStack(bh(c[0])||bh(d[0])?d:p.unique(d))},addBack:function(a){return this.add(a==null?this.prevObject:this.prevObject.filter(a))}}),p.fn.andSelf=p.fn.addBack,p.each({parent:function(a){var b=a.parentNode;return b&&b.nodeType!==11?b:null},parents:function(a){return p.dir(a,"parentNode")},parentsUntil:function(a,b,c){return p.dir(a,"parentNode",c)},next:function(a){return bi(a,"nextSibling")},prev:function(a){return bi(a,"previousSibling")},nextAll:function(a){return p.dir(a,"nextSibling")},prevAll:function(a){return p.dir(a,"previousSibling")},nextUntil:function(a,b,c){return p.dir(a,"nextSibling",c)},prevUntil:function(a,b,c){return p.dir(a,"previousSibling",c)},siblings:function(a){return p.sibling((a.parentNode||{}).firstChild,a)},children:function(a){return p.sibling(a.firstChild)},contents:function(a){return p.nodeName(a,"iframe")?a.contentDocument||a.contentWindow.document:p.merge([],a.childNodes)}},function(a,b){p.fn[a]=function(c,d){var e=p.map(this,b,c);return bc.test(a)||(d=c),d&&typeof d=="string"&&(e=p.filter(d,e)),e=this.length>1&&!bg[a]?p.unique(e):e,this.length>1&&bd.test(a)&&(e=e.reverse()),this.pushStack(e,a,k.call(arguments).join(","))}}),p.extend({filter:function(a,b,c){return c&&(a=":not("+a+")"),b.length===1?p.find.matchesSelector(b[0],a)?[b[0]]:[]:p.find.matches(a,b)},dir:function(a,c,d){var e=[],f=a[c];while(f&&f.nodeType!==9&&(d===b||f.nodeType!==1||!p(f).is(d)))f.nodeType===1&&e.push(f),f=f[c];return e},sibling:function(a,b){var c=[];for(;a;a=a.nextSibling)a.nodeType===1&&a!==b&&c.push(a);return c}});var bl="abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",bm=/ jQuery\d+="(?:null|\d+)"/g,bn=/^\s+/,bo=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,bp=/<([\w:]+)/,bq=/<tbody/i,br=/<|&#?\w+;/,bs=/<(?:script|style|link)/i,bt=/<(?:script|object|embed|option|style)/i,bu=new RegExp("<(?:"+bl+")[\\s/>]","i"),bv=/^(?:checkbox|radio)$/,bw=/checked\s*(?:[^=]|=\s*.checked.)/i,bx=/\/(java|ecma)script/i,by=/^\s*<!(?:\[CDATA\[|\-\-)|[\]\-]{2}>\s*$/g,bz={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],area:[1,"<map>","</map>"],_default:[0,"",""]},bA=bk(e),bB=bA.appendChild(e.createElement("div"));bz.optgroup=bz.option,bz.tbody=bz.tfoot=bz.colgroup=bz.caption=bz.thead,bz.th=bz.td,p.support.htmlSerialize||(bz._default=[1,"X<div>","</div>"]),p.fn.extend({text:function(a){return p.access(this,function(a){return a===b?p.text(this):this.empty().append((this[0]&&this[0].ownerDocument||e).createTextNode(a))},null,a,arguments.length)},wrapAll:function(a){if(p.isFunction(a))return this.each(function(b){p(this).wrapAll(a.call(this,b))});if(this[0]){var b=p(a,this[0].ownerDocument).eq(0).clone(!0);this[0].parentNode&&b.insertBefore(this[0]),b.map(function(){var a=this;while(a.firstChild&&a.firstChild.nodeType===1)a=a.firstChild;return a}).append(this)}return this},wrapInner:function(a){return p.isFunction(a)?this.each(function(b){p(this).wrapInner(a.call(this,b))}):this.each(function(){var b=p(this),c=b.contents();c.length?c.wrapAll(a):b.append(a)})},wrap:function(a){var b=p.isFunction(a);return this.each(function(c){p(this).wrapAll(b?a.call(this,c):a)})},unwrap:function(){return this.parent().each(function(){p.nodeName(this,"body")||p(this).replaceWith(this.childNodes)}).end()},append:function(){return this.domManip(arguments,!0,function(a){(this.nodeType===1||this.nodeType===11)&&this.appendChild(a)})},prepend:function(){return this.domManip(arguments,!0,function(a){(this.nodeType===1||this.nodeType===11)&&this.insertBefore(a,this.firstChild)})},before:function(){if(!bh(this[0]))return this.domManip(arguments,!1,function(a){this.parentNode.insertBefore(a,this)});if(arguments.length){var a=p.clean(arguments);return this.pushStack(p.merge(a,this),"before",this.selector)}},after:function(){if(!bh(this[0]))return this.domManip(arguments,!1,function(a){this.parentNode.insertBefore(a,this.nextSibling)});if(arguments.length){var a=p.clean(arguments);return this.pushStack(p.merge(this,a),"after",this.selector)}},remove:function(a,b){var c,d=0;for(;(c=this[d])!=null;d++)if(!a||p.filter(a,[c]).length)!b&&c.nodeType===1&&(p.cleanData(c.getElementsByTagName("*")),p.cleanData([c])),c.parentNode&&c.parentNode.removeChild(c);return this},empty:function(){var a,b=0;for(;(a=this[b])!=null;b++){a.nodeType===1&&p.cleanData(a.getElementsByTagName("*"));while(a.firstChild)a.removeChild(a.firstChild)}return this},clone:function(a,b){return a=a==null?!1:a,b=b==null?a:b,this.map(function(){return p.clone(this,a,b)})},html:function(a){return p.access(this,function(a){var c=this[0]||{},d=0,e=this.length;if(a===b)return c.nodeType===1?c.innerHTML.replace(bm,""):b;if(typeof a=="string"&&!bs.test(a)&&(p.support.htmlSerialize||!bu.test(a))&&(p.support.leadingWhitespace||!bn.test(a))&&!bz[(bp.exec(a)||["",""])[1].toLowerCase()]){a=a.replace(bo,"<$1></$2>");try{for(;d<e;d++)c=this[d]||{},c.nodeType===1&&(p.cleanData(c.getElementsByTagName("*")),c.innerHTML=a);c=0}catch(f){}}c&&this.empty().append(a)},null,a,arguments.length)},replaceWith:function(a){return bh(this[0])?this.length?this.pushStack(p(p.isFunction(a)?a():a),"replaceWith",a):this:p.isFunction(a)?this.each(function(b){var c=p(this),d=c.html();c.replaceWith(a.call(this,b,d))}):(typeof a!="string"&&(a=p(a).detach()),this.each(function(){var b=this.nextSibling,c=this.parentNode;p(this).remove(),b?p(b).before(a):p(c).append(a)}))},detach:function(a){return this.remove(a,!0)},domManip:function(a,c,d){a=[].concat.apply([],a);var e,f,g,h,i=0,j=a[0],k=[],l=this.length;if(!p.support.checkClone&&l>1&&typeof j=="string"&&bw.test(j))return this.each(function(){p(this).domManip(a,c,d)});if(p.isFunction(j))return this.each(function(e){var f=p(this);a[0]=j.call(this,e,c?f.html():b),f.domManip(a,c,d)});if(this[0]){e=p.buildFragment(a,this,k),g=e.fragment,f=g.firstChild,g.childNodes.length===1&&(g=f);if(f){c=c&&p.nodeName(f,"tr");for(h=e.cacheable||l-1;i<l;i++)d.call(c&&p.nodeName(this[i],"table")?bC(this[i],"tbody"):this[i],i===h?g:p.clone(g,!0,!0))}g=f=null,k.length&&p.each(k,function(a,b){b.src?p.ajax?p.ajax({url:b.src,type:"GET",dataType:"script",async:!1,global:!1,"throws":!0}):p.error("no ajax"):p.globalEval((b.text||b.textContent||b.innerHTML||"").replace(by,"")),b.parentNode&&b.parentNode.removeChild(b)})}return this}}),p.buildFragment=function(a,c,d){var f,g,h,i=a[0];return c=c||e,c=(c[0]||c).ownerDocument||c[0]||c,typeof c.createDocumentFragment=="undefined"&&(c=e),a.length===1&&typeof i=="string"&&i.length<512&&c===e&&i.charAt(0)==="<"&&!bt.test(i)&&(p.support.checkClone||!bw.test(i))&&(p.support.html5Clone||!bu.test(i))&&(g=!0,f=p.fragments[i],h=f!==b),f||(f=c.createDocumentFragment(),p.clean(a,c,f,d),g&&(p.fragments[i]=h&&f)),{fragment:f,cacheable:g}},p.fragments={},p.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(a,b){p.fn[a]=function(c){var d,e=0,f=[],g=p(c),h=g.length,i=this.length===1&&this[0].parentNode;if((i==null||i&&i.nodeType===11&&i.childNodes.length===1)&&h===1)return g[b](this[0]),this;for(;e<h;e++)d=(e>0?this.clone(!0):this).get(),p(g[e])[b](d),f=f.concat(d);return this.pushStack(f,a,g.selector)}}),p.extend({clone:function(a,b,c){var d,e,f,g;p.support.html5Clone||p.isXMLDoc(a)||!bu.test("<"+a.nodeName+">")?g=a.cloneNode(!0):(bB.innerHTML=a.outerHTML,bB.removeChild(g=bB.firstChild));if((!p.support.noCloneEvent||!p.support.noCloneChecked)&&(a.nodeType===1||a.nodeType===11)&&!p.isXMLDoc(a)){bE(a,g),d=bF(a),e=bF(g);for(f=0;d[f];++f)e[f]&&bE(d[f],e[f])}if(b){bD(a,g);if(c){d=bF(a),e=bF(g);for(f=0;d[f];++f)bD(d[f],e[f])}}return d=e=null,g},clean:function(a,b,c,d){var f,g,h,i,j,k,l,m,n,o,q,r,s=0,t=[];if(!b||typeof b.createDocumentFragment=="undefined")b=e;for(g=b===e&&bA;(h=a[s])!=null;s++){typeof h=="number"&&(h+="");if(!h)continue;if(typeof h=="string")if(!br.test(h))h=b.createTextNode(h);else{g=g||bk(b),l=l||g.appendChild(b.createElement("div")),h=h.replace(bo,"<$1></$2>"),i=(bp.exec(h)||["",""])[1].toLowerCase(),j=bz[i]||bz._default,k=j[0],l.innerHTML=j[1]+h+j[2];while(k--)l=l.lastChild;if(!p.support.tbody){m=bq.test(h),n=i==="table"&&!m?l.firstChild&&l.firstChild.childNodes:j[1]==="<table>"&&!m?l.childNodes:[];for(f=n.length-1;f>=0;--f)p.nodeName(n[f],"tbody")&&!n[f].childNodes.length&&n[f].parentNode.removeChild(n[f])}!p.support.leadingWhitespace&&bn.test(h)&&l.insertBefore(b.createTextNode(bn.exec(h)[0]),l.firstChild),h=l.childNodes,l=g.lastChild}h.nodeType?t.push(h):t=p.merge(t,h)}l&&(g.removeChild(l),h=l=g=null);if(!p.support.appendChecked)for(s=0;(h=t[s])!=null;s++)p.nodeName(h,"input")?bG(h):typeof h.getElementsByTagName!="undefined"&&p.grep(h.getElementsByTagName("input"),bG);if(c){q=function(a){if(!a.type||bx.test(a.type))return d?d.push(a.parentNode?a.parentNode.removeChild(a):a):c.appendChild(a)};for(s=0;(h=t[s])!=null;s++)if(!p.nodeName(h,"script")||!q(h))c.appendChild(h),typeof h.getElementsByTagName!="undefined"&&(r=p.grep(p.merge([],h.getElementsByTagName("script")),q),t.splice.apply(t,[s+1,0].concat(r)),s+=r.length)}return t},cleanData:function(a,b){var c,d,e,f,g=0,h=p.expando,i=p.cache,j=p.support.deleteExpando,k=p.event.special;for(;(e=a[g])!=null;g++)if(b||p.acceptData(e)){d=e[h],c=d&&i[d];if(c){if(c.events)for(f in c.events)k[f]?p.event.remove(e,f):p.removeEvent(e,f,c.handle);i[d]&&(delete i[d],j?delete e[h]:e.removeAttribute?e.removeAttribute(h):e[h]=null,p.deletedIds.push(d))}}}}),function(){var a,b;p.uaMatch=function(a){a=a.toLowerCase();var b=/(chrome)[ \/]([\w.]+)/.exec(a)||/(webkit)[ \/]([\w.]+)/.exec(a)||/(opera)(?:.*version|)[ \/]([\w.]+)/.exec(a)||/(msie) ([\w.]+)/.exec(a)||a.indexOf("compatible")<0&&/(mozilla)(?:.*? rv:([\w.]+)|)/.exec(a)||[];return{browser:b[1]||"",version:b[2]||"0"}},a=p.uaMatch(g.userAgent),b={},a.browser&&(b[a.browser]=!0,b.version=a.version),b.webkit&&(b.safari=!0),p.browser=b,p.sub=function(){function a(b,c){return new a.fn.init(b,c)}p.extend(!0,a,this),a.superclass=this,a.fn=a.prototype=this(),a.fn.constructor=a,a.sub=this.sub,a.fn.init=function c(c,d){return d&&d instanceof p&&!(d instanceof a)&&(d=a(d)),p.fn.init.call(this,c,d,b)},a.fn.init.prototype=a.fn;var b=a(e);return a}}();var bH,bI,bJ,bK=/alpha\([^)]*\)/i,bL=/opacity=([^)]*)/,bM=/^(top|right|bottom|left)$/,bN=/^margin/,bO=new RegExp("^("+q+")(.*)$","i"),bP=new RegExp("^("+q+")(?!px)[a-z%]+$","i"),bQ=new RegExp("^([-+])=("+q+")","i"),bR={},bS={position:"absolute",visibility:"hidden",display:"block"},bT={letterSpacing:0,fontWeight:400,lineHeight:1},bU=["Top","Right","Bottom","Left"],bV=["Webkit","O","Moz","ms"],bW=p.fn.toggle;p.fn.extend({css:function(a,c){return p.access(this,function(a,c,d){return d!==b?p.style(a,c,d):p.css(a,c)},a,c,arguments.length>1)},show:function(){return bZ(this,!0)},hide:function(){return bZ(this)},toggle:function(a,b){var c=typeof a=="boolean";return p.isFunction(a)&&p.isFunction(b)?bW.apply(this,arguments):this.each(function(){(c?a:bY(this))?p(this).show():p(this).hide()})}}),p.extend({cssHooks:{opacity:{get:function(a,b){if(b){var c=bH(a,"opacity");return c===""?"1":c}}}},cssNumber:{fillOpacity:!0,fontWeight:!0,lineHeight:!0,opacity:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{"float":p.support.cssFloat?"cssFloat":"styleFloat"},style:function(a,c,d,e){if(!a||a.nodeType===3||a.nodeType===8||!a.style)return;var f,g,h,i=p.camelCase(c),j=a.style;c=p.cssProps[i]||(p.cssProps[i]=bX(j,i)),h=p.cssHooks[c]||p.cssHooks[i];if(d===b)return h&&"get"in h&&(f=h.get(a,!1,e))!==b?f:j[c];g=typeof d,g==="string"&&(f=bQ.exec(d))&&(d=(f[1]+1)*f[2]+parseFloat(p.css(a,c)),g="number");if(d==null||g==="number"&&isNaN(d))return;g==="number"&&!p.cssNumber[i]&&(d+="px");if(!h||!("set"in h)||(d=h.set(a,d,e))!==b)try{j[c]=d}catch(k){}},css:function(a,c,d,e){var f,g,h,i=p.camelCase(c);return c=p.cssProps[i]||(p.cssProps[i]=bX(a.style,i)),h=p.cssHooks[c]||p.cssHooks[i],h&&"get"in h&&(f=h.get(a,!0,e)),f===b&&(f=bH(a,c)),f==="normal"&&c in bT&&(f=bT[c]),d||e!==b?(g=parseFloat(f),d||p.isNumeric(g)?g||0:f):f},swap:function(a,b,c){var d,e,f={};for(e in b)f[e]=a.style[e],a.style[e]=b[e];d=c.call(a);for(e in b)a.style[e]=f[e];return d}}),a.getComputedStyle?bH=function(a,b){var c,d,e,f,g=getComputedStyle(a,null),h=a.style;return g&&(c=g[b],c===""&&!p.contains(a.ownerDocument.documentElement,a)&&(c=p.style(a,b)),bP.test(c)&&bN.test(b)&&(d=h.width,e=h.minWidth,f=h.maxWidth,h.minWidth=h.maxWidth=h.width=c,c=g.width,h.width=d,h.minWidth=e,h.maxWidth=f)),c}:e.documentElement.currentStyle&&(bH=function(a,b){var c,d,e=a.currentStyle&&a.currentStyle[b],f=a.style;return e==null&&f&&f[b]&&(e=f[b]),bP.test(e)&&!bM.test(b)&&(c=f.left,d=a.runtimeStyle&&a.runtimeStyle.left,d&&(a.runtimeStyle.left=a.currentStyle.left),f.left=b==="fontSize"?"1em":e,e=f.pixelLeft+"px",f.left=c,d&&(a.runtimeStyle.left=d)),e===""?"auto":e}),p.each(["height","width"],function(a,b){p.cssHooks[b]={get:function(a,c,d){if(c)return a.offsetWidth!==0||bH(a,"display")!=="none"?ca(a,b,d):p.swap(a,bS,function(){return ca(a,b,d)})},set:function(a,c,d){return b$(a,c,d?b_(a,b,d,p.support.boxSizing&&p.css(a,"boxSizing")==="border-box"):0)}}}),p.support.opacity||(p.cssHooks.opacity={get:function(a,b){return bL.test((b&&a.currentStyle?a.currentStyle.filter:a.style.filter)||"")?.01*parseFloat(RegExp.$1)+"":b?"1":""},set:function(a,b){var c=a.style,d=a.currentStyle,e=p.isNumeric(b)?"alpha(opacity="+b*100+")":"",f=d&&d.filter||c.filter||"";c.zoom=1;if(b>=1&&p.trim(f.replace(bK,""))===""&&c.removeAttribute){c.removeAttribute("filter");if(d&&!d.filter)return}c.filter=bK.test(f)?f.replace(bK,e):f+" "+e}}),p(function(){p.support.reliableMarginRight||(p.cssHooks.marginRight={get:function(a,b){return p.swap(a,{display:"inline-block"},function(){if(b)return bH(a,"marginRight")})}}),!p.support.pixelPosition&&p.fn.position&&p.each(["top","left"],function(a,b){p.cssHooks[b]={get:function(a,c){if(c){var d=bH(a,b);return bP.test(d)?p(a).position()[b]+"px":d}}}})}),p.expr&&p.expr.filters&&(p.expr.filters.hidden=function(a){return a.offsetWidth===0&&a.offsetHeight===0||!p.support.reliableHiddenOffsets&&(a.style&&a.style.display||bH(a,"display"))==="none"},p.expr.filters.visible=function(a){return!p.expr.filters.hidden(a)}),p.each({margin:"",padding:"",border:"Width"},function(a,b){p.cssHooks[a+b]={expand:function(c){var d,e=typeof c=="string"?c.split(" "):[c],f={};for(d=0;d<4;d++)f[a+bU[d]+b]=e[d]||e[d-2]||e[0];return f}},bN.test(a)||(p.cssHooks[a+b].set=b$)});var cc=/%20/g,cd=/\[\]$/,ce=/\r?\n/g,cf=/^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i,cg=/^(?:select|textarea)/i;p.fn.extend({serialize:function(){return p.param(this.serializeArray())},serializeArray:function(){return this.map(function(){return this.elements?p.makeArray(this.elements):this}).filter(function(){return this.name&&!this.disabled&&(this.checked||cg.test(this.nodeName)||cf.test(this.type))}).map(function(a,b){var c=p(this).val();return c==null?null:p.isArray(c)?p.map(c,function(a,c){return{name:b.name,value:a.replace(ce,"\r\n")}}):{name:b.name,value:c.replace(ce,"\r\n")}}).get()}}),p.param=function(a,c){var d,e=[],f=function(a,b){b=p.isFunction(b)?b():b==null?"":b,e[e.length]=encodeURIComponent(a)+"="+encodeURIComponent(b)};c===b&&(c=p.ajaxSettings&&p.ajaxSettings.traditional);if(p.isArray(a)||a.jquery&&!p.isPlainObject(a))p.each(a,function(){f(this.name,this.value)});else for(d in a)ch(d,a[d],c,f);return e.join("&").replace(cc,"+")};var ci,cj,ck=/#.*$/,cl=/^(.*?):[ \t]*([^\r\n]*)\r?$/mg,cm=/^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/,cn=/^(?:GET|HEAD)$/,co=/^\/\//,cp=/\?/,cq=/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,cr=/([?&])_=[^&]*/,cs=/^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,ct=p.fn.load,cu={},cv={},cw=["*/"]+["*"];try{ci=f.href}catch(cx){ci=e.createElement("a"),ci.href="",ci=ci.href}cj=cs.exec(ci.toLowerCase())||[],p.fn.load=function(a,c,d){if(typeof a!="string"&&ct)return ct.apply(this,arguments);if(!this.length)return this;var e,f,g,h=this,i=a.indexOf(" ");return i>=0&&(e=a.slice(i,a.length),a=a.slice(0,i)),p.isFunction(c)?(d=c,c=b):typeof c=="object"&&(f="POST"),p.ajax({url:a,type:f,dataType:"html",data:c,complete:function(a,b){d&&h.each(d,g||[a.responseText,b,a])}}).done(function(a){g=arguments,h.html(e?p("<div>").append(a.replace(cq,"")).find(e):a)}),this},p.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "),function(a,b){p.fn[b]=function(a){return this.on(b,a)}}),p.each(["get","post"],function(a,c){p[c]=function(a,d,e,f){return p.isFunction(d)&&(f=f||e,e=d,d=b),p.ajax({type:c,url:a,data:d,success:e,dataType:f})}}),p.extend({getScript:function(a,c){return p.get(a,b,c,"script")},getJSON:function(a,b,c){return p.get(a,b,c,"json")},ajaxSetup:function(a,b){return b?cA(a,p.ajaxSettings):(b=a,a=p.ajaxSettings),cA(a,b),a},ajaxSettings:{url:ci,isLocal:cm.test(cj[1]),global:!0,type:"GET",contentType:"application/x-www-form-urlencoded; charset=UTF-8",processData:!0,async:!0,accepts:{xml:"application/xml, text/xml",html:"text/html",text:"text/plain",json:"application/json, text/javascript","*":cw},contents:{xml:/xml/,html:/html/,json:/json/},responseFields:{xml:"responseXML",text:"responseText"},converters:{"* text":a.String,"text html":!0,"text json":p.parseJSON,"text xml":p.parseXML},flatOptions:{context:!0,url:!0}},ajaxPrefilter:cy(cu),ajaxTransport:cy(cv),ajax:function(a,c){function y(a,c,f,i){var k,s,t,u,w,y=c;if(v===2)return;v=2,h&&clearTimeout(h),g=b,e=i||"",x.readyState=a>0?4:0,f&&(u=cB(l,x,f));if(a>=200&&a<300||a===304)l.ifModified&&(w=x.getResponseHeader("Last-Modified"),w&&(p.lastModified[d]=w),w=x.getResponseHeader("Etag"),w&&(p.etag[d]=w)),a===304?(y="notmodified",k=!0):(k=cC(l,u),y=k.state,s=k.data,t=k.error,k=!t);else{t=y;if(!y||a)y="error",a<0&&(a=0)}x.status=a,x.statusText=""+(c||y),k?o.resolveWith(m,[s,y,x]):o.rejectWith(m,[x,y,t]),x.statusCode(r),r=b,j&&n.trigger("ajax"+(k?"Success":"Error"),[x,l,k?s:t]),q.fireWith(m,[x,y]),j&&(n.trigger("ajaxComplete",[x,l]),--p.active||p.event.trigger("ajaxStop"))}typeof a=="object"&&(c=a,a=b),c=c||{};var d,e,f,g,h,i,j,k,l=p.ajaxSetup({},c),m=l.context||l,n=m!==l&&(m.nodeType||m instanceof p)?p(m):p.event,o=p.Deferred(),q=p.Callbacks("once memory"),r=l.statusCode||{},t={},u={},v=0,w="canceled",x={readyState:0,setRequestHeader:function(a,b){if(!v){var c=a.toLowerCase();a=u[c]=u[c]||a,t[a]=b}return this},getAllResponseHeaders:function(){return v===2?e:null},getResponseHeader:function(a){var c;if(v===2){if(!f){f={};while(c=cl.exec(e))f[c[1].toLowerCase()]=c[2]}c=f[a.toLowerCase()]}return c===b?null:c},overrideMimeType:function(a){return v||(l.mimeType=a),this},abort:function(a){return a=a||w,g&&g.abort(a),y(0,a),this}};o.promise(x),x.success=x.done,x.error=x.fail,x.complete=q.add,x.statusCode=function(a){if(a){var b;if(v<2)for(b in a)r[b]=[r[b],a[b]];else b=a[x.status],x.always(b)}return this},l.url=((a||l.url)+"").replace(ck,"").replace(co,cj[1]+"//"),l.dataTypes=p.trim(l.dataType||"*").toLowerCase().split(s),l.crossDomain==null&&(i=cs.exec(l.url.toLowerCase()),l.crossDomain=!(!i||i[1]==cj[1]&&i[2]==cj[2]&&(i[3]||(i[1]==="http:"?80:443))==(cj[3]||(cj[1]==="http:"?80:443)))),l.data&&l.processData&&typeof l.data!="string"&&(l.data=p.param(l.data,l.traditional)),cz(cu,l,c,x);if(v===2)return x;j=l.global,l.type=l.type.toUpperCase(),l.hasContent=!cn.test(l.type),j&&p.active++===0&&p.event.trigger("ajaxStart");if(!l.hasContent){l.data&&(l.url+=(cp.test(l.url)?"&":"?")+l.data,delete l.data),d=l.url;if(l.cache===!1){var z=p.now(),A=l.url.replace(cr,"$1_="+z);l.url=A+(A===l.url?(cp.test(l.url)?"&":"?")+"_="+z:"")}}(l.data&&l.hasContent&&l.contentType!==!1||c.contentType)&&x.setRequestHeader("Content-Type",l.contentType),l.ifModified&&(d=d||l.url,p.lastModified[d]&&x.setRequestHeader("If-Modified-Since",p.lastModified[d]),p.etag[d]&&x.setRequestHeader("If-None-Match",p.etag[d])),x.setRequestHeader("Accept",l.dataTypes[0]&&l.accepts[l.dataTypes[0]]?l.accepts[l.dataTypes[0]]+(l.dataTypes[0]!=="*"?", "+cw+"; q=0.01":""):l.accepts["*"]);for(k in l.headers)x.setRequestHeader(k,l.headers[k]);if(!l.beforeSend||l.beforeSend.call(m,x,l)!==!1&&v!==2){w="abort";for(k in{success:1,error:1,complete:1})x[k](l[k]);g=cz(cv,l,c,x);if(!g)y(-1,"No Transport");else{x.readyState=1,j&&n.trigger("ajaxSend",[x,l]),l.async&&l.timeout>0&&(h=setTimeout(function(){x.abort("timeout")},l.timeout));try{v=1,g.send(t,y)}catch(B){if(v<2)y(-1,B);else throw B}}return x}return x.abort()},active:0,lastModified:{},etag:{}});var cD=[],cE=/\?/,cF=/(=)\?(?=&|$)|\?\?/,cG=p.now();p.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var a=cD.pop()||p.expando+"_"+cG++;return this[a]=!0,a}}),p.ajaxPrefilter("json jsonp",function(c,d,e){var f,g,h,i=c.data,j=c.url,k=c.jsonp!==!1,l=k&&cF.test(j),m=k&&!l&&typeof i=="string"&&!(c.contentType||"").indexOf("application/x-www-form-urlencoded")&&cF.test(i);if(c.dataTypes[0]==="jsonp"||l||m)return f=c.jsonpCallback=p.isFunction(c.jsonpCallback)?c.jsonpCallback():c.jsonpCallback,g=a[f],l?c.url=j.replace(cF,"$1"+f):m?c.data=i.replace(cF,"$1"+f):k&&(c.url+=(cE.test(j)?"&":"?")+c.jsonp+"="+f),c.converters["script json"]=function(){return h||p.error(f+" was not called"),h[0]},c.dataTypes[0]="json",a[f]=function(){h=arguments},e.always(function(){a[f]=g,c[f]&&(c.jsonpCallback=d.jsonpCallback,cD.push(f)),h&&p.isFunction(g)&&g(h[0]),h=g=b}),"script"}),p.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/javascript|ecmascript/},converters:{"text script":function(a){return p.globalEval(a),a}}}),p.ajaxPrefilter("script",function(a){a.cache===b&&(a.cache=!1),a.crossDomain&&(a.type="GET",a.global=!1)}),p.ajaxTransport("script",function(a){if(a.crossDomain){var c,d=e.head||e.getElementsByTagName("head")[0]||e.documentElement;return{send:function(f,g){c=e.createElement("script"),c.async="async",a.scriptCharset&&(c.charset=a.scriptCharset),c.src=a.url,c.onload=c.onreadystatechange=function(a,e){if(e||!c.readyState||/loaded|complete/.test(c.readyState))c.onload=c.onreadystatechange=null,d&&c.parentNode&&d.removeChild(c),c=b,e||g(200,"success")},d.insertBefore(c,d.firstChild)},abort:function(){c&&c.onload(0,1)}}}});var cH,cI=a.ActiveXObject?function(){for(var a in cH)cH[a](0,1)}:!1,cJ=0;p.ajaxSettings.xhr=a.ActiveXObject?function(){return!this.isLocal&&cK()||cL()}:cK,function(a){p.extend(p.support,{ajax:!!a,cors:!!a&&"withCredentials"in a})}(p.ajaxSettings.xhr()),p.support.ajax&&p.ajaxTransport(function(c){if(!c.crossDomain||p.support.cors){var d;return{send:function(e,f){var g,h,i=c.xhr();c.username?i.open(c.type,c.url,c.async,c.username,c.password):i.open(c.type,c.url,c.async);if(c.xhrFields)for(h in c.xhrFields)i[h]=c.xhrFields[h];c.mimeType&&i.overrideMimeType&&i.overrideMimeType(c.mimeType),!c.crossDomain&&!e["X-Requested-With"]&&(e["X-Requested-With"]="XMLHttpRequest");try{for(h in e)i.setRequestHeader(h,e[h])}catch(j){}i.send(c.hasContent&&c.data||null),d=function(a,e){var h,j,k,l,m;try{if(d&&(e||i.readyState===4)){d=b,g&&(i.onreadystatechange=p.noop,cI&&delete cH[g]);if(e)i.readyState!==4&&i.abort();else{h=i.status,k=i.getAllResponseHeaders(),l={},m=i.responseXML,m&&m.documentElement&&(l.xml=m);try{l.text=i.responseText}catch(a){}try{j=i.statusText}catch(n){j=""}!h&&c.isLocal&&!c.crossDomain?h=l.text?200:404:h===1223&&(h=204)}}}catch(o){e||f(-1,o)}l&&f(h,j,l,k)},c.async?i.readyState===4?setTimeout(d,0):(g=++cJ,cI&&(cH||(cH={},p(a).unload(cI)),cH[g]=d),i.onreadystatechange=d):d()},abort:function(){d&&d(0,1)}}}});var cM,cN,cO=/^(?:toggle|show|hide)$/,cP=new RegExp("^(?:([-+])=|)("+q+")([a-z%]*)$","i"),cQ=/queueHooks$/,cR=[cX],cS={"*":[function(a,b){var c,d,e,f=this.createTween(a,b),g=cP.exec(b),h=f.cur(),i=+h||0,j=1;if(g){c=+g[2],d=g[3]||(p.cssNumber[a]?"":"px");if(d!=="px"&&i){i=p.css(f.elem,a,!0)||c||1;do e=j=j||".5",i=i/j,p.style(f.elem,a,i+d),j=f.cur()/h;while(j!==1&&j!==e)}f.unit=d,f.start=i,f.end=g[1]?i+(g[1]+1)*c:c}return f}]};p.Animation=p.extend(cV,{tweener:function(a,b){p.isFunction(a)?(b=a,a=["*"]):a=a.split(" ");var c,d=0,e=a.length;for(;d<e;d++)c=a[d],cS[c]=cS[c]||[],cS[c].unshift(b)},prefilter:function(a,b){b?cR.unshift(a):cR.push(a)}}),p.Tween=cY,cY.prototype={constructor:cY,init:function(a,b,c,d,e,f){this.elem=a,this.prop=c,this.easing=e||"swing",this.options=b,this.start=this.now=this.cur(),this.end=d,this.unit=f||(p.cssNumber[c]?"":"px")},cur:function(){var a=cY.propHooks[this.prop];return a&&a.get?a.get(this):cY.propHooks._default.get(this)},run:function(a){var b,c=cY.propHooks[this.prop];return this.pos=b=p.easing[this.easing](a,this.options.duration*a,0,1,this.options.duration),this.now=(this.end-this.start)*b+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),c&&c.set?c.set(this):cY.propHooks._default.set(this),this}},cY.prototype.init.prototype=cY.prototype,cY.propHooks={_default:{get:function(a){var b;return a.elem[a.prop]==null||!!a.elem.style&&a.elem.style[a.prop]!=null?(b=p.css(a.elem,a.prop,!1,""),!b||b==="auto"?0:b):a.elem[a.prop]},set:function(a){p.fx.step[a.prop]?p.fx.step[a.prop](a):a.elem.style&&(a.elem.style[p.cssProps[a.prop]]!=null||p.cssHooks[a.prop])?p.style(a.elem,a.prop,a.now+a.unit):a.elem[a.prop]=a.now}}},cY.propHooks.scrollTop=cY.propHooks.scrollLeft={set:function(a){a.elem.nodeType&&a.elem.parentNode&&(a.elem[a.prop]=a.now)}},p.each(["toggle","show","hide"],function(a,b){var c=p.fn[b];p.fn[b]=function(d,e,f){return d==null||typeof d=="boolean"||!a&&p.isFunction(d)&&p.isFunction(e)?c.apply(this,arguments):this.animate(cZ(b,!0),d,e,f)}}),p.fn.extend({fadeTo:function(a,b,c,d){return this.filter(bY).css("opacity",0).show().end().animate({opacity:b},a,c,d)},animate:function(a,b,c,d){var e=p.isEmptyObject(a),f=p.speed(b,c,d),g=function(){var b=cV(this,p.extend({},a),f);e&&b.stop(!0)};return e||f.queue===!1?this.each(g):this.queue(f.queue,g)},stop:function(a,c,d){var e=function(a){var b=a.stop;delete a.stop,b(d)};return typeof a!="string"&&(d=c,c=a,a=b),c&&a!==!1&&this.queue(a||"fx",[]),this.each(function(){var b=!0,c=a!=null&&a+"queueHooks",f=p.timers,g=p._data(this);if(c)g[c]&&g[c].stop&&e(g[c]);else for(c in g)g[c]&&g[c].stop&&cQ.test(c)&&e(g[c]);for(c=f.length;c--;)f[c].elem===this&&(a==null||f[c].queue===a)&&(f[c].anim.stop(d),b=!1,f.splice(c,1));(b||!d)&&p.dequeue(this,a)})}}),p.each({slideDown:cZ("show"),slideUp:cZ("hide"),slideToggle:cZ("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(a,b){p.fn[a]=function(a,c,d){return this.animate(b,a,c,d)}}),p.speed=function(a,b,c){var d=a&&typeof a=="object"?p.extend({},a):{complete:c||!c&&b||p.isFunction(a)&&a,duration:a,easing:c&&b||b&&!p.isFunction(b)&&b};d.duration=p.fx.off?0:typeof d.duration=="number"?d.duration:d.duration in p.fx.speeds?p.fx.speeds[d.duration]:p.fx.speeds._default;if(d.queue==null||d.queue===!0)d.queue="fx";return d.old=d.complete,d.complete=function(){p.isFunction(d.old)&&d.old.call(this),d.queue&&p.dequeue(this,d.queue)},d},p.easing={linear:function(a){return a},swing:function(a){return.5-Math.cos(a*Math.PI)/2}},p.timers=[],p.fx=cY.prototype.init,p.fx.tick=function(){var a,b=p.timers,c=0;for(;c<b.length;c++)a=b[c],!a()&&b[c]===a&&b.splice(c--,1);b.length||p.fx.stop()},p.fx.timer=function(a){a()&&p.timers.push(a)&&!cN&&(cN=setInterval(p.fx.tick,p.fx.interval))},p.fx.interval=13,p.fx.stop=function(){clearInterval(cN),cN=null},p.fx.speeds={slow:600,fast:200,_default:400},p.fx.step={},p.expr&&p.expr.filters&&(p.expr.filters.animated=function(a){return p.grep(p.timers,function(b){return a===b.elem}).length});var c$=/^(?:body|html)$/i;p.fn.offset=function(a){if(arguments.length)return a===b?this:this.each(function(b){p.offset.setOffset(this,a,b)});var c,d,e,f,g,h,i,j,k,l,m=this[0],n=m&&m.ownerDocument;if(!n)return;return(e=n.body)===m?p.offset.bodyOffset(m):(d=n.documentElement,p.contains(d,m)?(c=m.getBoundingClientRect(),f=c_(n),g=d.clientTop||e.clientTop||0,h=d.clientLeft||e.clientLeft||0,i=f.pageYOffset||d.scrollTop,j=f.pageXOffset||d.scrollLeft,k=c.top+i-g,l=c.left+j-h,{top:k,left:l}):{top:0,left:0})},p.offset={bodyOffset:function(a){var b=a.offsetTop,c=a.offsetLeft;return p.support.doesNotIncludeMarginInBodyOffset&&(b+=parseFloat(p.css(a,"marginTop"))||0,c+=parseFloat(p.css(a,"marginLeft"))||0),{top:b,left:c}},setOffset:function(a,b,c){var d=p.css(a,"position");d==="static"&&(a.style.position="relative");var e=p(a),f=e.offset(),g=p.css(a,"top"),h=p.css(a,"left"),i=(d==="absolute"||d==="fixed")&&p.inArray("auto",[g,h])>-1,j={},k={},l,m;i?(k=e.position(),l=k.top,m=k.left):(l=parseFloat(g)||0,m=parseFloat(h)||0),p.isFunction(b)&&(b=b.call(a,c,f)),b.top!=null&&(j.top=b.top-f.top+l),b.left!=null&&(j.left=b.left-f.left+m),"using"in b?b.using.call(a,j):e.css(j)}},p.fn.extend({position:function(){if(!this[0])return;var a=this[0],b=this.offsetParent(),c=this.offset(),d=c$.test(b[0].nodeName)?{top:0,left:0}:b.offset();return c.top-=parseFloat(p.css(a,"marginTop"))||0,c.left-=parseFloat(p.css(a,"marginLeft"))||0,d.top+=parseFloat(p.css(b[0],"borderTopWidth"))||0,d.left+=parseFloat(p.css(b[0],"borderLeftWidth"))||0,{top:c.top-d.top,left:c.left-d.left}},offsetParent:function(){return this.map(function(){var a=this.offsetParent||e.body;while(a&&!c$.test(a.nodeName)&&p.css(a,"position")==="static")a=a.offsetParent;return a||e.body})}}),p.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(a,c){var d=/Y/.test(c);p.fn[a]=function(e){return p.access(this,function(a,e,f){var g=c_(a);if(f===b)return g?c in g?g[c]:g.document.documentElement[e]:a[e];g?g.scrollTo(d?p(g).scrollLeft():f,d?f:p(g).scrollTop()):a[e]=f},a,e,arguments.length,null)}}),p.each({Height:"height",Width:"width"},function(a,c){p.each({padding:"inner"+a,content:c,"":"outer"+a},function(d,e){p.fn[e]=function(e,f){var g=arguments.length&&(d||typeof e!="boolean"),h=d||(e===!0||f===!0?"margin":"border");return p.access(this,function(c,d,e){var f;return p.isWindow(c)?c.document.documentElement["client"+a]:c.nodeType===9?(f=c.documentElement,Math.max(c.body["scroll"+a],f["scroll"+a],c.body["offset"+a],f["offset"+a],f["client"+a])):e===b?p.css(c,d,e,h):p.style(c,d,e,h)},c,g?e:b,g)}})}),a.jQuery=a.$=p,typeof define=="function"&&define.amd&&define.amd.jQuery&&define("jquery",[],function(){return p})})(window);

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\jquery\jquery.inherit-1.3.2.js
/**
 * Inheritance plugin
 *
 * Copyright (c) 2010 Filatov Dmitry (alpha@zforms.ru)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 * @version 1.3.2.M
 */

(function($) {

var hasIntrospection = (function(){_}).toString().indexOf('_') > -1,
	needCheckProps = $.browser.msie, // fucking ie hasn't toString, valueOf in for
	specProps = needCheckProps? ['toString', 'valueOf'] : null,
	emptyBase = function() {};

function override(base, result, add) {

	var hasSpecProps = false;
	if(needCheckProps) {
		var addList = [];
		$.each(specProps, function() {
			add.hasOwnProperty(this) && (hasSpecProps = true) && addList.push({
				name : this,
				val  : add[this]
			});
		});
		if(hasSpecProps) {
			$.each(add, function(name) {
				addList.push({
					name : name,
					val  : this
				});
			});
			add = addList;
		}
	}

	$.each(add, function(name, prop) {
		if(hasSpecProps) {
			name = prop.name;
			prop = prop.val;
		}
		if($.isFunction(base[name]) && $.isFunction(prop) && (!hasIntrospection || prop.toString().indexOf('.__base') > -1)) {
			var baseMethod = base[name];
			result[name] = function() {
				var baseSaved = this.__base;
				this.__base = baseMethod;
				var result = prop.apply(this, arguments);
				this.__base = baseSaved;
				return result;
			};

		}
		else {
			result[name] = prop;
		}

	});

}

$.inherit = function() {

	var withMixins = $.isArray(arguments[0]),
		hasBase = withMixins || $.isFunction(arguments[0]),
		base = hasBase? withMixins? arguments[0][0] : arguments[0] : emptyBase,
		props = arguments[hasBase? 1 : 0] || {},
		staticProps = arguments[hasBase? 2 : 1],
		result = props.__constructor || (hasBase && base.prototype.__constructor)?
			function() {
				this.__constructor.apply(this, arguments);
			} : function() {};

	if(!hasBase) {
		result.prototype = props;
		result.prototype.__self = result.prototype.constructor = result;
		return $.extend(result, staticProps);
	}

	$.extend(result, base);

	var inheritance = function() {},
		basePtp = base.prototype;
	inheritance.prototype = base.prototype;
	result.prototype = new inheritance();
	var resultPtp = result.prototype;
	resultPtp.__self = resultPtp.constructor = result;

	override(basePtp, resultPtp, props);
	staticProps && override(base, result, staticProps);

	if(withMixins) {
		var i = 1, mixins = arguments[0], mixin, __constructors = [];
		while(mixin = mixins[i++]) {
			$.each(mixin.prototype, function(propName) {
				if(propName == '__constructor') {
					__constructors.push(this);
				}
				else if(propName != '__self') {
					resultPtp[propName] = this;
				}
			});
		}
		if(__constructors.length > 0) {
			resultPtp.__constructor && __constructors.push(resultPtp.__constructor);
			resultPtp.__constructor = function() {
				var i = 0, __constructor;
				while(__constructor = __constructors[i++]) {
					__constructor.apply(this, arguments);
				}
			};
		}
	}

	return result;

};

})(jQuery);

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\jquery\jquery.json-2.3.min.js

(function($){var escapeable=/["\\\x00-\x1f\x7f-\x9f]/g,meta={'\b':'\\b','\t':'\\t','\n':'\\n','\f':'\\f','\r':'\\r','"':'\\"','\\':'\\\\'};$.toJSON=typeof JSON==='object'&&JSON.stringify?JSON.stringify:function(o){if(o===null){return'null';}
var type=typeof o;if(type==='undefined'){return undefined;}
if(type==='number'||type==='boolean'){return''+o;}
if(type==='string'){return $.quoteString(o);}
if(type==='object'){if(typeof o.toJSON==='function'){return $.toJSON(o.toJSON());}
if(o.constructor===Date){var month=o.getUTCMonth()+1,day=o.getUTCDate(),year=o.getUTCFullYear(),hours=o.getUTCHours(),minutes=o.getUTCMinutes(),seconds=o.getUTCSeconds(),milli=o.getUTCMilliseconds();if(month<10){month='0'+month;}
if(day<10){day='0'+day;}
if(hours<10){hours='0'+hours;}
if(minutes<10){minutes='0'+minutes;}
if(seconds<10){seconds='0'+seconds;}
if(milli<100){milli='0'+milli;}
if(milli<10){milli='0'+milli;}
return'"'+year+'-'+month+'-'+day+'T'+
hours+':'+minutes+':'+seconds+'.'+milli+'Z"';}
if(o.constructor===Array){var ret=[];for(var i=0;i<o.length;i++){ret.push($.toJSON(o[i])||'null');}
return'['+ret.join(',')+']';}
var name,val,pairs=[];for(var k in o){type=typeof k;if(type==='number'){name='"'+k+'"';}else if(type==='string'){name=$.quoteString(k);}else{continue;}
type=typeof o[k];if(type==='function'||type==='undefined'){continue;}
val=$.toJSON(o[k]);pairs.push(name+':'+val);}
return'{'+pairs.join(',')+'}';}};$.evalJSON=typeof JSON==='object'&&JSON.parse?JSON.parse:function(src){return eval('('+src+')');};$.secureEvalJSON=typeof JSON==='object'&&JSON.parse?JSON.parse:function(src){var filtered=src.replace(/\\["\\\/bfnrtu]/g,'@').replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,']').replace(/(?:^|:|,)(?:\s*\[)+/g,'');if(/^[\],:{}\s]*$/.test(filtered)){return eval('('+src+')');}else{throw new SyntaxError('Error parsing JSON, source is not valid.');}};$.quoteString=function(string){if(string.match(escapeable)){return'"'+string.replace(escapeable,function(a){var c=meta[a];if(typeof c==='string'){return c;}
c=a.charCodeAt();return'\\u00'+Math.floor(c/16).toString(16)+(c%16).toString(16);})+'"';}
return'"'+string+'"';};})(jQuery);

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\utils.js
/**
 * @class SVMX
 * @singleton
 *
 * @author Unknown
 * @copyright ServiceMax, Inc
 * @since The minimum version where this file is supported
 */
;(function ($) {
    var packageCount = 0;
    var classCount = 0;

    var SVMX = {

        /**
         * Creates a package given a unique name
         *
         * + ie: creates a package com.servicemax.client.lib.api and add a Module class
         *
            var libApi = SVMX.Package("com.servicemax.client.lib.api");

            libApi.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
                __constructor : function(){

                }
            });
         *
         * @method
         * @param   {String}    name
         *
         * @return  {Object}    package object
         *
         */
        Package: function (name) {
            var arr = name.split(".");
            var fn = (window || this);
            for (var i = 0, len = arr.length; i < len; i++) {
                if (!fn[arr[i]]) fn[arr[i]] = {};

                fn = fn[arr[i]];
            }

            fn.name = name;

            // to create class declaration
            fn.Class = function (name, baseCls, instanceProps, staticProps) {

                var cls = $.inherit(baseCls, instanceProps, staticProps);
                cls.__className = name;
                this[name] = cls;
                cls.name = this.name + ":" + name;
                classCount++;
                return cls;
            };

            packageCount++;

            return fn;
        }
    };

    /**
     *
     *
     * @method
     * @return  {Number}    package count
     */
    SVMX.getPackageCount = function () {
        return packageCount;
    };

    /**
     *
     *
     * @method
     * @return  {Number}    class count
     */
    SVMX.getClassCount = function () {
        return classCount;
    };

    /**
     *
     *
     * @method
     * @param   {String}    str
     * @param   {String}    suffix
     *
     * @return  {Boolean} Defaults to returning true
     */
    SVMX.stringEndsWith = function (str, suffix) {
        var ret = false;
        if (str && str.length > 0) {
            ret = (str.indexOf(suffix, str.length - suffix.length) !== -1);
        }
        return ret;
    };

    SVMX.string = {};
    SVMX.string.capitalize = function (str) {
        return str[0].toUpperCase() + str.substring(1);
    };

    SVMX.string.camelCase = function (str) {
        return str.replace(/_[a-zA-Z]/g, function (inStr) {
            return inStr.substring(1).toUpperCase();
        });
    };

    // "Showing message {{current}} of {{total}}"
    SVMX.string.substitute = function (inString, inObject) {
        if (!inObject) inObject = {};
        return String(inString).replace(/\{\{.*?\}\}/g, function (inTerm) {
            inTerm = inTerm.substring(2, inTerm.length - 2);
            return inObject[inTerm] === undefined || inObject[inTerm] === null ? "" : inObject[inTerm];
        });
    };

    SVMX.forEachProperty = function (inObject, inFunc, inContext) {
        if (inContext) inFunc = SVMX.proxy(inContext, inFunc);
        for (key in inObject) {
            if (inObject.hasOwnProperty(key)) {
                inFunc(key, inObject[key]);
            }
        }
    };

    SVMX.isPlatform = function (plaformName) {
        var ret = true;
        try {
            ret = navigator.platform.slice(0, plaformName.length) == plaformName;
        } catch (e) {
            SVMX.getLoggingService().getLogger().error("Cannot detect the platform! " + e);
        }
        return ret;
    };

    SVMX.cloneObject = function (obj) {
        return SVMX.toObject(SVMX.toJSON(obj));
    };

    SVMX.write = function (content) {
        document.write(content);
    };

    SVMX.meta = function (name, content) {
        SVMX.write('<meta name="' + name + '" content="' + content + '">');
    };

    SVMX.getLoggingService = function () {
        return com.servicemax.client.lib.services.LoggingService.getInstance();
    };

    SVMX.getClient = function () {
        return com.servicemax.client.lib.core.Client.getInstance();
    };

    SVMX.getCurrentApplication = function () {
        return com.servicemax.client.lib.api.AbstractApplication.currentApp;
    };

    var __GUID__ = 0;
    SVMX.generateGUID = function () {
        // TODO: need a better way to generate GUIDs.
        return ++__GUID__;
    };

    var __SVMX_CREATE_HELPERS__ = [];
    SVMX.registerCreateHelper = function (helper) {
        __SVMX_CREATE_HELPERS__.push(helper);
    };

    SVMX.getCreateHelper = function (fullClassName) {
        var i, l = __SVMX_CREATE_HELPERS__.length;
        for (i = 0; i < l; i++) {
            var helper = __SVMX_CREATE_HELPERS__[i];
            if (helper.canCreate(fullClassName)) {
                return helper;
            }
        }

        return null;
    };

    SVMX.getClass = function (className, failSilently) {
        try {
            var arr = className.split(".");
            var fn = window;
            for (var i = 0, len = arr.length; i < len; i++) {
                if (failSilently && !fn) return;
                fn = fn[arr[i]];
            }

            if (typeof fn !== "function" && !failSilently) {
                SVMX.getLoggingService().getLogger().error("Cannot find definition for class : " + className);
            }
            return fn;
        } catch (e) {
            if (!failSilently) {
                SVMX.getLoggingService().getLogger().error("Error while resolving class <" + className + "> :" + e);
                throw e;
            }
        }
    };

    SVMX.create = function () {
        var fullClassName = '';
        try {
            if (arguments.length < 1) return null; // TODO log error

            fullClassName = arguments[0];

            var helper = SVMX.getCreateHelper(fullClassName);
            if (helper != null) {
                return helper.doCreate.apply(helper, arguments);
            } else {
                var i, l = arguments.length,
                    argsStr = "";
                for (i = 1; i < l; i++) {
                    argsStr += "arguments[" + i + "],";
                }

                if (argsStr.length > 0)
                    argsStr = argsStr.substring(0, argsStr.length - 1);

                var cls = SVMX.getClass(fullClassName);
                var clsObj = eval("new cls(" + argsStr + ")");

                return clsObj;
            }
        } catch (e) {
            SVMX.getLoggingService().getLogger().error("Error while creating class <" + fullClassName + " > : " + e);
            throw e;
        }
    };


    /**
     *
     * @method
     * @params value
     * @returns Class name
     * @description
     * While we Could use javascript's typeof x == "object" to test a value, there are three problems:
     * 1. javascript says that typeof null == "object" which
     * is almost never a usable result.  null and undefined return "" which allows us to write:
     *
     *  if (SVMX.typeOf(x)) {
     *      ...
     *  }
     *
     * 2. typeof does not respect classes; an instance of Date is "object" but except for anonymous objects, its usually more useful to get back "date"
     * 3. typeof [5] is "object"; knowing that its an Array is usually a lot more useful.
     *
     * LIMITATIONS: This method must be enhanced if we add new object systems
     * NOTES: The value returned starts with Uppercase if its an object "Object", "Number" or lower case if its a literal "number".
     *
       typeOf({a: 4}); //"Object"
       toType([1, 2, 3]); //"Array"
       (function() {console.log(typeOf(arguments))})(); //arguments
       typeOf(new ReferenceError); //"Error"
       typeOf(new Date); //"Date"
       typeOf(/a-z/); //"RegExp"
       typeOf(Math); //"Math"
       typeOf(JSON); //"JSON"
       typeOf(4); // "number"
       typeOf(new Number(4)); //"Number"
       typeOf("abc"); // "string"
       typeOf(new String("abc")); //"String"
       typeOf(new Boolean(true)); //"boolean"
       typeof(document.body); // "HtmlBodyElement"
       typeof(new Ext.Button()) // "Ext.button.Button"
       typeof(SVMX.getCurrentApplication()); // "Application"
     *
     * @param       value           any type of value
     *
     * @return      {String}        the object or literal type as a string
     */
    SVMX.typeOf = function(value) {
        if (value === null) {
            return "";
        } else if (value === undefined) {
            return "";
        } else if (typeof value == "object") {
            if (value.getClassName) return value.getClassName();
            else return  ({}).toString.call(value).match(/\s([a-zA-Z]+)/)[1];
        } else {
            return typeof value;
        }
    };


    /**
     * @public
     * @method
     * @params value
     * @param {[string]} typeList
     * @returns boolean
     * @description
     * Use the SVMX.typeOf method to test if this value is one of a set of types
     *
     *  if (SVMX.isTypeOf(x, ["number", "string", "Date"])) {
     *      ...
     *  }
     *
     */
    SVMX.isTypeOf = function(value, typeList) {
        return SVMX.array.contains(typeList, function(oneType) {
            return SVMX.typeOf(value) === oneType;
        });
    };


    SVMX.isObject = function(value) {
        if (value === null || value === undefined) return false;
        return typeof value == "object";
    };

    /**
     * @public
     * @method
     * @param  {Object}            inScope         Object that will be "this" within the function
     * @param  {Function|String}   inFunction      A function or the name of a function that exists within inScope
     * @param  {[arg1,arg2,arg3]}  arguments       Zero or more arguments that will be passed in when the function is called
     *
     * @return {Function}     a function that when called will have inScope as the "this" object.
     *
     * @description
     * Calls jQuery.proxy which is documented at http://api.jquery.com/jQuery.proxy/ but changes the arguments
     * so that the arguments do not vary in order
     */
    SVMX.proxy = function () {
        var context = arguments[0];
        var func = arguments[1];
        if (typeof (func) !== "string") {
            var tmp = arguments[0];
            arguments[0] = arguments[1];
            arguments[1] = tmp;
        }
        return jQuery.proxy.apply(window, arguments);
    };

    // Move this into utils/timer.js when it becomes big enough
    SVMX.timer = {
        doLater: function (inFunc, inContext) {
            var f = inContext ? SVMX.proxy(inContext, inFunc) : inFunc;
            window.setTimeout(f, 1);
        },

        /* Invokation:
         * SVMX.timer.job("myTimer", 100, this, function() {...}); // function executes with this as context
         * SVMX.timer.job("myTimer", 50, function() {}); // cancels previous timer and runs function with window context
         */
        job: function (inName, inDelay, inJob1, inJob2) {
            var inJob;
            if (inJob1 && inJob2) {
                inJob = SVMX.proxy(inJob1, inJob2);
            } else if (inJob2) {
                inJob = inJob2;
            } else {
                inJob = inJob1;
            }
            SVMX.timer.cancelJob(inName);
            var job = function () {
                delete SVMX.timer._jobs[inName];
                inJob();
            }
            SVMX.timer._jobs[inName] = setTimeout(job, inDelay);
        },
        cancelJob: function (inName) {
            clearTimeout(SVMX.timer._jobs[inName]);
            delete SVMX.timer._jobs[inName];
        },
        hasJob: function (inName) {
            return Boolean(SVMX, timer._jobs[inName]);
        },
        _jobs: {}
    };
    SVMX.doLater = SVMX.timer.doLater; // shortcut

    SVMX.ajax = function (options) {
        return $.ajax(options);
    };

    SVMX.openInBrowserWindow = function (url) {
        window.open(url, "_blank");
    };

    SVMX.setWindowTitle = function (title) {
        window.document.title = title || "";
    };

    SVMX.reloadPage = function () {
        window.location.reload();
    };

    SVMX.navigateTo = function (url) {
        window.location.href = url;
    };

    SVMX.navigateTopTo = function(url) {
        top.location.href = url;
    };

    SVMX.getInnerWidth = function (){
    	var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    	return width;
    }

    SVMX.onWindowResize = function (callback, context) {
    	var innerWidth =  SVMX.getInnerWidth();
        $(window).resize(function(evt) {
            var size = {
                height:window.innerHeight,
                width: innerWidth
            };
            SVMX.timer.job("windowResize", 50, function () {
                callback.call(context, size);
            });
        });
    };

    var bCachingEnabled = null;
    SVMX.isCachingEnabled = function () {

        if (bCachingEnabled === null) {
            var isEnabled = SVMX.getClient().getApplicationParameter("enable-cache");

            // configuration takes the highest precedence. if it is enabled in the configuration,
            // only then check is it is disabled/enabled via URL

            if (isEnabled != undefined && isEnabled != null && isEnabled === true) {
                isEnabled = SVMX.getUrlParameter("enable-cache");
                if (isEnabled != undefined && isEnabled != null && isEnabled === "false") {
                    isEnabled = false;
                } else {
                    isEnabled = true;
                }
            } else {
                isEnabled = false;
            }

            bCachingEnabled = isEnabled;
        }

        return bCachingEnabled;
    };

    var bLoggingEnabled = null;
    SVMX.isLoggingEnabled = function () {

        if (bLoggingEnabled === null) {
            var isEnabled = SVMX.getClient().getApplicationParameter("enable-log");

            // configuration takes the highest precedence. if it is enabled in the configuration,
            // only then check is it is disabled/enabled via URL

            if (isEnabled != undefined && isEnabled != null && isEnabled === true) {
                isEnabled = SVMX.getUrlParameter("enable-log");
                if (isEnabled != undefined && isEnabled != null && isEnabled === "false") {
                    isEnabled = false;
                } else {
                    isEnabled = true;
                }
            } else {
                isEnabled = false;
            }

            bLoggingEnabled = isEnabled;
        }

        return bLoggingEnabled;
    };

    var __SVMX_URL_PARAMS__ = null;
    SVMX.getUrlParameter = function (name) {
        if (__SVMX_URL_PARAMS__ == null) {
            __SVMX_URL_PARAMS__ = {};
            var Url = document.URL;
            var paramValues = Url.slice(Url.indexOf("?") + 1).split("&");

            for (var i = 0; i < paramValues.length; i++) {
                var val = paramValues[i].split("=");
                __SVMX_URL_PARAMS__[val[0]] = val[1];
            }
        }
        var ret = __SVMX_URL_PARAMS__[name];
        if (ret != null) {
            ret = decodeURIComponent(ret);

            // decodeURIComponent does not decode +!
            ret = ret.split("+").join(" ");
        }
        return ret;
    };

    SVMX.toJSON = function (data) {
        if (data) {
            return $.toJSON(data);
        }
        return null;
    };

    SVMX.stringToXML = function(data){
        if (data) {
            return $.parseXML(data);
        }
        return null;
    };

    // do not call with indent; just SVMX.prettyPrint(myObj)
    SVMX.prettyPrint = function (data, indent) {
        indent = indent || 0;

        function doIndent(indent) {
            return new Array(indent).join("    ");
        }
        var result = "";
        if ($.isArray(data)) {
            result += "[\n"
            for (var i = 0; i < data.length; i++) {
                result += doIndent(indent + 1) + i + ". " + SVMX.prettyPrint(data[i], indent + 1);
                if (i < data.length - 1) result += ",";
                result += "\n";
            }
            result += doIndent(indent) + "]"
        } else if (typeof data === "object" && data !== null) {
            result += "{\n";
            SVMX.forEachProperty(data, function (inKey, inValue) {
                result += doIndent(indent + 1) + inKey + ": " + SVMX.prettyPrint(inValue, indent + 1) + ",\n";
            });
            result += doIndent(indent) + "}";
        } else {
            result += data;
        }
        return result;
    };

    SVMX.dump = function (data) {
        console.log(SVMX.prettyPrint(data));
    };

    SVMX.toObject = function (data) {
        var ret = data;

        if (typeof (data) == 'string' && data.match(/^\s*\"|\'|\{|\[/)) {
            try {
                ret = $.secureEvalJSON(data);
            } catch (e) {
                SVMX.getLoggingService().getLogger().error("SVMX.toObject() failed!");
            }
        }

        return ret;
    };

    SVMX.toggleClass = function (selector, cssClass) {
        $(selector).toggleClass(cssClass);
    };

    SVMX.sort = function (items, fieldOrFunc) {
        // right now, only field name is supported
        if (typeof (fieldOrFunc) != 'string') return;

        var i, l = items.length;

        if (l < 2) return items;

        for (i = 0; i < (l - 1);) {
            var k = 0;
            for (; k < (l - 1); k++) {
                if (items[k][fieldOrFunc] > items[k + 1][fieldOrFunc]) {
                    var temp = items[k];
                    items[k] = items[k + 1];
                    items[k + 1] = temp;
                }
            }
            l--;
        }
        return items;
    };

    ////////////////// jQuery.Deffered Utilities ////////////
    // Utility for turning an array of deferreds into a single
    // deferred that evaluates when all deferreds are complete
    SVMX.when = function (arrayOfDeferred) {
        var args = "";
        for (var i = 0; i < arrayOfDeferred.length; i++) {
            if (i > 0) args += ",";
            args += "arrayOfDeferred[" + i + "]"
        }
        return eval("$.when(" + args + ")");
    };

    SVMX.Deferred = null; // This is actually set in core.js, but is placed here so it will be documented as part of utils.js


    /**
     * @param {Object} inParams A hash of arguments
     * @param {[any]} inParams.data An array of data to process
     * @param {function} inParams.process A function that will be called on each item of data; must return AND resolve an SVMX.Deferred
     * @param {any} inParams.process.item The only input to your process is the next item of data from inParams.data
     * @param {function} [inParams.onSuccess] A function to call once All of your data has been processed and all Deferreds resolved
     * @param {function} [inParams.onError] A function to call if any of your Deferreds are rejected/fail.  This will be called each time a defered fails.
     * @param {boolean} inParams.onError.returns Return true to abort all further execution of your data; returns false/undefined to continue processing
     * @param {int} [inParallelProcessCount=1] The number of parallel threads of execution to allow; if greater than 1, will allow more than one item in inArray to be processed at a time.  Each in its own thread.
     *
     * executeUntilDone takes an array of data and a process to execute and will execute one item of data at a time, and only start processing the
     * next itme of data when previous item has been fully processed.  To allow for asynchronous completion of processing each item
     * of data, inProcess must return an SVMX.Deferred, and will resolve it when its finished.
     *
     *   SVMX.executeUntilDone({
     *      data: [1,3,5,7],
     *      inParallelProcessCount: 1
     *      process: function(item) {
     *          var d = new SVMX.Deferred();
     *          window.setTimeout(function() {
     *              alert(item);
     *              d.resolve();
     *          }, 1000);
     *          return d;
     *      },
     *      onSuccess: function() {
     *          alert("All values processed");
     *      },
     *      onError: function(e) {
     *          alert("Error processing value: " + e);
     *      }
     *   });
     *
     * @todo Need to have a way to aggregate results and feed them into the onSuccess handler. mydeferred.resolve(value) should
     *       be a valid way to accumulate results.
     */
    SVMX.executeUntilDone = function(inParams) {
        var mainDeferred = new $.Deferred();
        var dataToProcess = {};
        var abort = false;
        var executeUntilDone = function(inProcessName, inProcess) {
            if (abort) return;
            var item = dataToProcess[inProcessName].shift();
            if (item) {
                var d = inParams.process(item);
                d.done(function() {
                    executeUntilDone(inProcessName, inProcess);
                });
                d.fail(function(e) {
                    if (inParams.onError) abort = inParams.onError(e);
                    if (!abort) {
                        executeUntilDone(inProcessName, inProcess);
                    } else {
                        mainDeferred.fail(e);
                    }

                });
            } else {
                delete dataToProcess[inProcessName];
                var count = 0;
                SVMX.forEachProperty(dataToProcess, function(inKey,inValue) {count++;});
                if (count === 0 && inParams.onSuccess) {
                    inParams.onSuccess();
                    mainDeferred.resolve();
                }
            }
        };

        if (!inParams.inParallelProcessCount) inParams.inParallelProcessCount = 1;

        for (var i = 0; i < inParams.inParallelProcessCount; i++) {
            dataToProcess["process" + i] = [];
        }
        for (i = 0; i < inParams.data.length; i++) {
            dataToProcess["process" + (i % inParams.inParallelProcessCount)].push(inParams.data[i]);
        }

        var hasRun = false;
        for (i = 0; i < inParams.inParallelProcessCount; i++) {
            executeUntilDone("process" + i, inParams.inProcess);
            hasRun = true;
        }
        if (!hasRun) mainDeferred.resolve();
        return mainDeferred;
    };



    // Callback must return and resolve/fail a Deferred
    SVMX.__serializedTasks = [];
    SVMX.serializeTasks = function(task) {
        if (SVMX.__serializedTasks.length > 0) {
            SVMX.__serializedTasks.push(callback);
        } else {
            var d = callback();
            d.resolve(SVMX.__serializeNext);
        }
    };

    SVMX.__serializeNext = function() {
        if (SVMX.__serializeTasks.length == 0) return;
        var task = SVMX.__serializedTasks.pop();
        var d = task();
        d.resolve(SVMX.__serializeNext);
    };

    // !!!!!! DEPRECATED !!!!
    SVMX.loadCss = function (path) {

        $.ajax({
            type: 'GET',
            url: path,
            dataType: 'css',
            async: false,
            success: function () {},
            error: function (jqXhr, status, e) {}
        });

        if (document.createStyleSheet) {
            document.createStyleSheet(path);
        } else {
            $("head").append($("<link rel='stylesheet' href='" + path + "' type='text/css' media='screen' />"));
        }
    };

    SVMX.requireStyleSheet = function (url, callback, context, options) {
        if (!$.isArray(url)) {
            url = [url];
        }

        var counter = 0;
        var prefix = options.prefix ? options.prefix : "";
        $.each(url, function () {

            var head = document.getElementsByTagName('head')[0],
                link = document.createElement('link');
            link.setAttribute('href', prefix + this);
            link.setAttribute('rel', 'stylesheet');
            link.setAttribute('type', 'text/css');

            var sheet, cssRules, interval_id = 0,
                attempt = 0;
            if ('sheet' in link) {
                sheet = 'sheet';
                cssRules = 'cssRules';
            } else {
                sheet = 'styleSheet';
                cssRules = 'rules';
            }

            interval_id = setInterval(function () {
              SVMX.getLoggingService().getLogger().debug("requireStyleSheet::setInterval()");
                attempt++;
                if (attempt > 200) {

                    // could not load...
                    clearInterval(interval_id);
                    SVMX.getLoggingService().getLogger().debug("Timeout! clearing interval with id => " + interval_id);
                    head.removeChild(link);
                    if (++counter == url.length) {
                        callback.apply(context);
                    }
                } else {

                    try {
                        if (link[sheet] && link[sheet][cssRules].length) {

                            clearInterval(interval_id);
                            SVMX.getLoggingService().getLogger().debug("clearing interval with id => " + interval_id);
                            if (++counter == url.length) {
                                callback.apply(context);
                            }
                        }
                    } catch (e) {
                        // !!! Important to note that loading style sheets is the last call before the application starts
                        // any un-caught errors in the application may end up here.
                        SVMX.getLoggingService().getLogger().error("There was an error! =>" + e);
                    }
                }
            }, 100);

            head.appendChild(link);
        });
    };

    /**
     * Loads a script file and executes the proper callback depend on a success or error
     *
     * @method
     * @param   {String/Array}      url     overloaded to handle string or array of {name:"", location:""} object
     * @param   {Function}          callback
     * @param   {Function}          errback
     * @param   {Oject}             context
     * @param   {Oject}             options
     */
    SVMX.requireScript = function (url, callback, errback, context, options) {
        if (!$.isArray(url)) {
            url = [url];
        }

        if (url.length == 0) {
            return;
        }

        var loadVersion = SVMX.getClient().getLoadVersion();

        // some JS files have only one version. For example language files from ExtJS
        if (options && options.ignoreLoadVersion) {
            loadVersion = "debug";
        }

        if (loadVersion == "micro") url = ["__all__-min.js"];

        var counter = 0;
        var cache = SVMX.isCachingEnabled();

        $.each(url, function (idx, item) {
            var prefix = "";
            var async = (options.async != undefined) ? options.async : true;
            var scriptToLoad = "";

            //check the type first
            if (typeof item == "string") {
                prefix = options.prefix ? options.prefix : "";
                scriptToLoad = item;
            } else if (typeof item == "object") {
                prefix = item.location ? item.location : "";
                scriptToLoad = item.name;
            }

            if (loadVersion == "min") {
                scriptToLoad = scriptToLoad.substring(0, scriptToLoad.length - 3) + "-min.js";
            }

            $.ajax({
                cache: cache,
                type: 'GET',
                url: prefix + scriptToLoad,
                dataType: 'text',
                async: async,
                success: function (status, statusText, responses, responseHeaders) {
                    // sourceMap tells the debugger what path this code is associated with,
                    // letting users both open it in the debugger, and also (if used differently from below where I simplify the path)
                    // letting users go from minified code to source code
                    var code = responses.responseText + "\r\n//@ sourceURL=/" + String(prefix).replace(/^.*client\./,"") + scriptToLoad;
                    try {
                        jQuery.globalEval(code);
                    } catch(e) {
                        SVMX.getLoggingService().getLogger().error("Error compiling => " + prefix + scriptToLoad + " =>" + e);
                        if (errback) errback(new Error(scriptToLoad + " Failed to compile"));
                        return; // DO NOT CONTINUE LOADING FRAMEWORK
                    }
                    if (++counter == url.length) {
                        callback.apply(context);
                    }
                },
                error: function (jqXhr, status, e) {
                    SVMX.getLoggingService().getLogger().error("Error while loading => " + prefix + scriptToLoad + " =>" + e);
                    if (errback) errback(new Error(scriptToLoad + " Failed to load"));
                    throw e;
                    //debugger;
                }
            });
        });
    };

    SVMX.requireTemplate = function (url, callback, context, options) {

        if (!$.isArray(url)) {
            url = [url];
        }

        var counter = 0;
        var prefix = options.prefix ? options.prefix : "";
        var templateList = [];

        $.each(url, function () {
            var async = (options.async != undefined) ? options.async : true;
            var name = this.toString();
            $.ajax({
                type: 'GET',
                url: prefix + this,
                dataType: 'text',
                async: async,
                success: function (data, status, jqXhr) {
                    templateList[templateList.length] = {
                        name: name,
                        data: data
                    };
                    if (++counter == url.length) {
                        callback.call(context, templateList);
                    }
                },
                error: function (jqXhr, status, e) {
                    // YUI Compressor cribs
                    //debugger;
                }
            });
        });
    };

    SVMX.getDisplayRootId = function () {

        // TODO : Could be in application definition??
        return "client_display_root";
    };

    var __allClientProperties = {};
    SVMX.getClientProperty = function (name) {
        return __allClientProperties[name];
    };

    SVMX.setClientProperty = function (name, value) {
        __allClientProperties[name] = value;
    };

    ////////////////// XML handling ////////////
    SVMX.toXML = function (data, rootElementName) {

        function format() {
            if (arguments.length == 0) return "";

            var formatted = arguments[0];

            for (var i = 1; i < arguments.length; i++) {
                var regexp = new RegExp('\\{' + (i - 1) + '\\}', 'gi');
                formatted = formatted.replace(regexp, arguments[i]);
            }
            return formatted;
        }

        function getElement(name, value) {
            var ret = "";
            if (value != null && value != undefined) {
                if (value instanceof Array) {
                    ret += getArrayElement(name, value);
                } else if (typeof (value) == 'object') {
                    ret += getObjectElement(name, value);
                } else {
                    ret += getSimpleElement(name, value);
                }
            }
            return ret;
        }

        function getArrayElement(name, value) {
            var ret = "",
                i, l = value.length,
                xml;
            for (var i = 0; i < l; i++) {
                var arrayItem = value[i];
                ret += getElement(name, arrayItem);
            }
            return ret;
        }

        function getSimpleElement(name, value) {
            // escape all the special characters
            if (value && typeof (value) == 'string') {
                value = value.split("&").join("&amp;");
                value = value.split("<").join("&lt;");
                value = value.split(">").join("&gt;");
                value = value.split('"').join("&quot;");
                value = value.split("'").join("&#39;");
            }
            // end escape special characters

            return format("<{0}>{1}</{0}>", name, value);
        }

        function getObjectElement(name, value) {
            var ret = "";
            for (var itemName in value) {
                var itemValue = value[itemName];
                ret += getElement(itemName, itemValue);
            }

            if (name)
                ret = format("<{0}>{1}</{0}>", name, ret);
            return ret;
        }

        if (typeof (data) == 'string') return data;

        var xml = getObjectElement(rootElementName, data);
        return xml;
    };

    SVMX.xmlToJson = function (xml) {
        var attr, child, attrs = xml.attributes,
            children = xml.childNodes,
            key = xml.nodeType,
            obj = {}, i = -1;

        if (key == 1 && attrs.length) {
            i = -1;
        } else if (key == 3) {
            obj = xml.nodeValue;
        }

        while (child = children.item(++i)) {
            key = child.nodeName;
            key = key.indexOf(":") != -1 ? key.split(":")[1] : key;

            if (obj.hasOwnProperty(key)) {
                if (obj.toString.call(obj[key]) != '[object Array]') {
                    obj[key] = [obj[key]];
                }
                obj[key].push(SVMX.xmlToJson(child));
            } else {
                obj[key] = SVMX.xmlToJson(child);
            }
        }

        // correct all text nodes
        for (var name in obj) {
            var objItem = obj[name];
            if (objItem && typeof (objItem) == 'object') {
                if (objItem.hasOwnProperty("#text")) {
                    obj[name] = objItem["#text"];

                    // also correct the boolean values
                    if (obj[name] === "false") obj[name] = false;
                    else if (obj[name] === "true") obj[name] = true;
                    // end boolean correction
                }
            }
        }
        // end correction

        return obj;
    };

    ////////////////// End - XML handling /////

    window["SVMX"] = SVMX;
})(jQuery);

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\utils\array.js
/**
 * @class SVMX.array  
 * @singleton  
 *   
 * @author Michael Kantor
 * @copyright ServiceMax, Inc
 * @since The minimum version where this file is supported
 *
 * All examples use the following array:
 *
    var arr = [
        {
            firstName: "Michael", 
            lastName: "Kantor"
        }, 
        {
            firstName: "Timothy", 
            lastName: "Ashton"
        }, 
        {   
            firstName: "Eric", 
            lastName: "Ingram"
        }, 
        {
            firstName: "Vinod", 
            lastName: "Kumar"
        }];
 */
(function ($) {

    SVMX.array = {

        /** 
         * Returns the matching index in the array.
         *
         * The indexOf method lets you search by value or search using a custom function.
         * The inValue parameter can be either a search function or value.
         *
         * + You can NOT search an array of functions for a matching function.
         * 
         *      SVMX.array.indexOf(arr, arr[3]); 
         *      -> 3
         *    
         *      SVMX.array.indexOf(arr, function(inItem) {
         *          return inItem.firstName == "Michael"
         *      }); 
         *      -> 0
         *
         * @method
         * @param {Object[]/string[]/number[]} inArray Array of objects or literals to search
         * @param {Function} inValue inValue can be a function or value.  If its a value, then we search for an exact match to this value.  Value to search for.  If value is a function, its treated as a callback
         *
         * that is used to evaluate whether an item is a match. Callback is function(inItem, inIndex)
         * @param {Mixed} inValue.inItem Current value to be tested by your callback function
         * @param {number} [inValue.inIndex] Current index in the array that you are testing
         * @param {boolean} inValue.return True if inItem matches your search criteria
         * @param {Object} [inContext] If a callback is provided, this can provide the function's "this" value.
         *          
         * @return {Number} -1 if not found, or the index of the element found.
         *
         */
        indexOf: function (inArray, inValue, inContext) {
            if (!inArray || !inArray.length) return -1;
            var isFunc = typeof inValue === "function";
            if (isFunc && inContext) inValue = SVMX.proxy(inContext, inValue);

            if (Array.prototype.indexOf && !isFunc) {
                return inArray.indexOf(inValue);
            } else {
                for (var i = 0; i < inArray.length; i++) {
                    if (isFunc) {
                        if (inValue(inArray[i], i)) return i;
                    } else if (inValue === inArray[i]) return i;
                }
            }
            return -1;
        },

        /** 
         * This is the same as indexOf but returns the matching element instead of its index
         *
         * The get method lets you search by value or search using a custom function.
         *
         * + You can NOT search an array of functions for a matching function.
         * 
            SVMX.array.get(arr, function(inItem) {
                return inItem.firstName == "Michael"
            }); 
            -> {firstName: "Michael", lastName: "Kantor"}
         *
         * @method
         * @param {Object[]/string[]/number[]} inArray Array of objects or literals to search
         * @param {Function} inCallback Determines if the value is the one we are looking for
         * @param {Mixed} inCallback.inItem Current value to be tested by your callback function
         * @param {number} [inCallback.inIndex] Current index in the array that you are testing
         * @param {boolean} inCallback.return True if inItem matches your search criteria
         * @param {Object} [inContext] Set's the context (value of the this object) in the callback function
         *          
         * @return {Mixed} Returns whatever matching elements were found or null if nothing is found
         *
         */        
         get: function (inArray, inValue, inContext) {
            var index = SVMX.array.indexOf(inArray, inValue, inContext);
            if (index == -1) return null;
            return inArray[index];
        },

        /** 
         * This is the same as calling SVMX.array.indexOf(array, inValue) != -1 but is more concise for if and loop condition expressions.
         *
            if (SVMX.array.contains(arr, arr[3])) {
                ...
            }
         * @method
         * @param {Object[]/string[]/number[]} inArray Array of objects or literals to search
         * @param {Function} inValue inValue can be a function or value.  If its a value, then we search for an exact match to this value.  Value to search for.  If value is a function, its treated as a callback
         * that is used to evaluate whether an item is a match. Callback is function(inItem, inIndex)
         * @param {Mixed} inValue.inItem Current value to be tested by your callback function
         * @param {number} [inValue.inIndex] Current index in the array that you are testing
         * @param {boolean} inValue.return True if inItem matches your search criteria
         * @param {Object} [inContext] If a callback is provided, this can provide the function's "this" value.
         *          
         * @return {Boolean} Returns true if inValue exists in inArray.
         */
        contains: function (inArray, inValue, inContext) {
            return SVMX.array.indexOf(inArray, inValue, inContext) != -1;
        },

        /** 
         * Maps one array to a second array.  Useful for transposing values, or extracting a field from every object
         * in an array and storing it in a new array.  Callbacks are of the form function(inItem, inIndex)
         *
            var firstNames = SVMX.array.map(arr, function(inItem) {
                return inItem.firstName
            }); 
            -> ["Michael", "Timothy", "Eric", "Vinod"]
         *
         * @method
         * @param {Mixed[]} inArray Array of objects or values
         * @param {Function} inCallback Callback that takes as input an array element and returns a value for the new array
         * @param {Mixed} inCallback.inItem An element of the array
         * @param {Mixed} inCallback.return Any value
         * @param {Object} [inContext] Optional context for inCallback
         *
         * @return {Mixed[]} a new array
         */
        map: function (inArray, inCallback, inContext) {
            if (inContext) inCallback = SVMX.proxy(inContext, inCallback);
            return $.map(inArray, inCallback);
        },

        /** 
         * Returns a new array with the desired elements from the original array
         *
            var haveLongNames = SVMX.array.filter(arr, function(inItem) {
                return inItem.firstName.length > 5
            }); 
            -> [{firstName: "Michael", lastName: "Kantor"}, {firstName: "Timothy", lastName: "Ashton"}]
         *
         * @method
         * @param {Mixed[]} inArray Array of objects or values
         * @param {Function} inCallback Callback that takes as input an array element for each one returns true/false
         * @param {Mixed} inCallback.inItem An element of the array
         * @param {boolean} inCallback.return True if this element should be in the new array
         * @param {Object} [inContext] Optional context for inCallback
         *
         * @return {Mixed[]} a new array
         */
        filter: function (inArray, inCallback, inContext) {
            if (inContext) inCallback = SVMX.proxy(inContext, inCallback);
            return $.grep(inArray, inCallback);
        },


        /** 
         * Used to test if something is true for every element of an array.  Callbacks are of the form function(inItem, inIndex)
         *
            if (SVMX.array.every(arr, function(inItem) {return inItem.firstName.length > 5;})) {
                alert("They are all true");
            }
         *
         * @method
         * @param {Mixed[]} inArray Array of objects or values
         * @param {Function} inCallback Callback that takes as input an array element and returns a boolean
         * @param {Mixed} inCallback.inItem An item of the array
         * @param {number} inCallback.inIndex The index in the array of inItem
         * @param {boolean} inCallback.return Returns true if the element matches the condition; returns false to make the entire every() call return false
         * @param {Object} [inContext] Optional context for inCallback
         * @return {boolean} If inCallback returns false for any element of inArray, returns false, else returns true
         */
        every: function (inArray, inCallback, inContext) {
            if (!inArray || !inArray.length) return false;
            if (inContext) inCallback = SVMX.proxy(inContext, inCallback);
            for (var i = 0; i < inArray.length; i++)
                if (!inCallback(inArray[i], i)) return false;
            return true;
        },

        /** 
         * Used to iterate over every element of an array and call a function on each element.
         * Its a good way to localize the scope for handling of each item.  Callbacks are of the form function(inItem, inIndex)
         *
            SVMX.array.forEach(arr, function(inItem) {
                console.log(inItem.firstName);
            });
         * @method
         * @param {Array} inArray The array to iterate over
         * @param {Function} inCallback Function to call on each item; of the forum function(inItem, inIndex)
         * @param {Object} [inContext] Optional context for inCallback
         * @param {null|Object} inContext Execute inCallback with inContext as the "this" value.
         *
         * @note If callback returns false, forEach exits.  Treat this as your loop s"break".
         */
        forEach: function (inArray, inCallback, inContext) {
            if (inContext) inCallback = SVMX.proxy(inContext, inCallback);
            for (var i = 0; i < inArray.length; i++) {
                var result = inCallback(inArray[i], i);
                if (result === false) return;
            }
        },

        /** 
         * I find this easier to remember than splice...
         *
             SVMX.array.insert(arr, {firstName: "Indresh", lastname: ""}, 0); 
            -> Indresh is first element in list
         * @method
         * @param {Array} inArray Array to modify
         * @param {Value} inElement Value to insert
         * @param {Number} inIndex Position to insert the new value
         */
        insert: function (inArray, inElement, inIndex) {
            inArray.splice(inIndex, 0, inElement);
        },

        /** 
         * I find this easier to remember than splice...
         *
         *           
            SVMX.array.removeElementAt(arr,0);  
            -> Indresh is removed from the array
         *
         * @method
         * @param {Array} inArray Array to modify
         * @param {Number} inIndex Position to remove the value from
         */
        removeElementAt: function (inArray, inIndex) {
            inArray.splice(inIndex, 1);
        },

        /** 
         * More general remove method lets you remove an element by passing in the element (note must be the exact element), 
         * or passing in a callback function to find all elements to remove.
         *
             SVMX.array.remove(arr, arr[0]); 
            -> Michael is removed from the array
            
            SVMX.array.remove(arr, function(inItem) {return inItem.firstName.length > 5;}, true) 
            -> Removes all elements where first name is longer than 5 characters
         *
         * @method
         * @param {Array} inArray Array to modify
         * @param {Function|Value} inValue If its a function, then its treated a
         *                         callback of the form function(inItem, inIndex)
         *                         and if it returns a truthy value, element is removed.
         *                         If its a value, remove the first occurance of that value
         * @param {Boolean} removeAll Defaults to false; if true then will iterate over every
         *                  item in your very long array and find and remove all matches.
         *
         */
        remove: function (inArray, inValue, removeAll) {
            var isFunc = typeof inValue === "function";
            for (var i = inArray.length - 1; i >= 0; i--) {
                var value = inArray[i];
                var isMatch = isFunc ? inValue(value, i) : value === inValue;
                if (isMatch) {
                    SVMX.array.removeElementAt(inArray, i);
                    if (!removeAll) return value;
                }
            }
        }
    };
})(jQuery);

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\utils\spin.js
/*
 * Copyright (c) 2011-2013 Felix Gnass
 * Licensed under the MIT license
 * 
 * fgnass.github.com/spin.js#v1.3  
 */
(function (root, factory) {

        /* CommonJS */
        if (typeof exports == 'object') module.exports = factory()

        /* AMD module */
        else if (typeof define == 'function' && define.amd) define(factory)

        /* Browser global */
        else root.Spinner = factory()
    }
    (this, function () {
        "use strict";

        var prefixes = ['webkit', 'Moz', 'ms', 'O'] /* Vendor prefixes */ ,
            animations = {} /* Animation rules keyed by their name */ , 
            useCssAnimations /* Whether to use CSS animations or setTimeout */

            /*
             * Utility function to create elements. If no tag name is given,
             * a DIV is created. Optionally properties can be passed.
             */

            function createEl(tag, prop) {
                var el = document.createElement(tag || 'div'),
                    n

                for (n in prop) el[n] = prop[n]
                return el
            }

            /*
             * Appends children and returns the parent.
             */

            function ins(parent /* child1, child2, ...*/ ) {
                for (var i = 1, n = arguments.length; i < n; i++)
                    parent.appendChild(arguments[i])

                return parent
            }

            /*
             * Insert a new stylesheet to hold the @keyframe or VML rules.
             */
        var sheet = (function () {
            var el = createEl('style', {
                type: 'text/css'
            })
            ins(document.getElementsByTagName('head')[0], el)
            return el.sheet || el.styleSheet
        }())

        /*
         * Creates an opacity keyframe animation rule and returns its name.
         * Since most mobile Webkits have timing issues with animation-delay,
         * we create separate rules for each line/segment.
         */

            function addAnimation(alpha, trail, i, lines) {
                var name = ['opacity', trail, ~~ (alpha * 100), i, lines].join('-'),
                    start = 0.01 + i / lines * 100,
                    z = Math.max(1 - (1 - alpha) / trail * (100 - start), alpha),
                    prefix = useCssAnimations.substring(0, useCssAnimations.indexOf('Animation')).toLowerCase(),
                    pre = prefix && '-' + prefix + '-' || ''

                if (!animations[name]) {
                    sheet.insertRule(
                        '@' + pre + 'keyframes ' + name + '{' +
                        '0%{opacity:' + z + '}' +
                        start + '%{opacity:' + alpha + '}' +
                        (start + 0.01) + '%{opacity:1}' +
                        (start + trail) % 100 + '%{opacity:' + alpha + '}' +
                        '100%{opacity:' + z + '}' +
                        '}', sheet.cssRules.length)

                    animations[name] = 1
                }

                return name
            }

            /*
             * Tries various vendor prefixes and returns the first supported property.
             */

            function vendor(el, prop) {
                var s = el.style,
                    pp, i

                if (s[prop] !== undefined) return prop
                prop = prop.charAt(0).toUpperCase() + prop.slice(1)
                for (i = 0; i < prefixes.length; i++) {
                    pp = prefixes[i] + prop
                    if (s[pp] !== undefined) return pp
                }
            }

            /*
             * Sets multiple style properties at once.
             */

            function css(el, prop) {
                for (var n in prop)
                    el.style[vendor(el, n) || n] = prop[n]

                return el
            }

            /*
             * Fills in default values.
             */

            function merge(obj) {
                for (var i = 1; i < arguments.length; i++) {
                    var def = arguments[i]
                    for (var n in def)
                        if (obj[n] === undefined) obj[n] = def[n]
                }
                return obj
            }

            /*
             * Returns the absolute page-offset of the given element.
             */

            function pos(el) {
                var o = {
                    x: el.offsetLeft,
                    y: el.offsetTop
                }
                while ((el = el.offsetParent))
                    o.x += el.offsetLeft, o.y += el.offsetTop

                return o
            }

            // Built-in defaults

        var defaults = {
            lines: 12, // The number of lines to draw
            length: 7, // The length of each line
            width: 5, // The line thickness
            radius: 10, // The radius of the inner circle
            rotate: 0, // Rotation offset
            corners: 1, // Roundness (0..1)
            color: '#000', // #rgb or #rrggbb
            direction: 1, // 1: clockwise, -1: counterclockwise
            speed: 1, // Rounds per second
            trail: 100, // Afterglow percentage
            opacity: 1 / 4, // Opacity of the lines
            fps: 20, // Frames per second when using setTimeout()
            zIndex: 2e9, // Use a high z-index by default
            className: 'spinner', // CSS class to assign to the element
            top: 'auto', // center vertically
            left: 'auto', // center horizontally
            position: 'relative' // element position
        }

        /* The constructor */

            function Spinner(o) {
                if (typeof this == 'undefined') return new Spinner(o)
                this.opts = merge(o || {}, Spinner.defaults, defaults)
            }

            // Global defaults that override the built-ins:
        Spinner.defaults = {}

        merge(Spinner.prototype, {

            /*
             * Adds the spinner to the given target element. If this instance is already
             * spinning, it is automatically removed from its previous target b calling
             * stop() internally.
             */
            spin: function (target) {
                this.stop()

                var self = this,
                    o = self.opts,
                    el = self.el = css(createEl(0, {
                        className: o.className
                    }), {
                        position: o.position,
                        width: 0,
                        zIndex: o.zIndex
                    }),
                    mid = o.radius + o.length + o.width,
                    ep // element position
                    , tp // target position

                if (target) {
                    target.insertBefore(el, target.firstChild || null)
                    tp = pos(target)
                    ep = pos(el)
                    css(el, {
                        left: (o.left == 'auto' ? tp.x - ep.x + (target.offsetWidth >> 1) : parseInt(o.left, 10) + mid) + 'px',
                        top: (o.top == 'auto' ? tp.y - ep.y + (target.offsetHeight >> 1) : parseInt(o.top, 10) + mid) + 'px'
                    })
                }

                el.setAttribute('role', 'progressbar')
                self.lines(el, self.opts)

                if (!useCssAnimations) {
                    // No CSS animation support, use setTimeout() instead
                    var i = 0,
                        start = (o.lines - 1) * (1 - o.direction) / 2,
                        alpha, fps = o.fps,
                        f = fps / o.speed,
                        ostep = (1 - o.opacity) / (f * o.trail / 100),
                        astep = f / o.lines

                        ;
                    (function anim() {
                        i++;
                        for (var j = 0; j < o.lines; j++) {
                            alpha = Math.max(1 - (i + (o.lines - j) * astep) % f * ostep, o.opacity)

                            self.opacity(el, j * o.direction + start, alpha, o)
                        }
                        self.timeout = self.el && setTimeout(anim, ~~ (1000 / fps))
                    })()
                }
                return self
            },

            /*
             * Stops and removes the Spinner.
             */
            stop: function () {
                var el = this.el
                if (el) {
                    clearTimeout(this.timeout)
                    if (el.parentNode) el.parentNode.removeChild(el)
                    this.el = undefined
                }
                return this
            },

            /*
             * Internal method that draws the individual lines. Will be overwritten
             * in VML fallback mode below.
             */
            lines: function (el, o) {
                var i = 0,
                    start = (o.lines - 1) * (1 - o.direction) / 2,
                    seg

                    function fill(color, shadow) {
                        return css(createEl(), {
                            position: 'absolute',
                            width: (o.length + o.width) + 'px',
                            height: o.width + 'px',
                            background: color,
                            boxShadow: shadow,
                            transformOrigin: 'left',
                            transform: 'rotate(' + ~~(360 / o.lines * i + o.rotate) + 'deg) translate(' + o.radius + 'px' + ',0)',
                            borderRadius: (o.corners * o.width >> 1) + 'px'
                        })
                    }

                for (; i < o.lines; i++) {
                    seg = css(createEl(), {
                        position: 'absolute',
                        top: 1 + ~(o.width / 2) + 'px',
                        transform: o.hwaccel ? 'translate3d(0,0,0)' : '',
                        opacity: o.opacity,
                        animation: useCssAnimations && addAnimation(o.opacity, o.trail, start + i * o.direction, o.lines) + ' ' + 1 / o.speed + 's linear infinite'
                    })

                    if (o.shadow) ins(seg, css(fill('#000', '0 0 4px ' + '#000'), {
                        top: 2 + 'px'
                    }))

                    ins(el, ins(seg, fill(o.color, '0 0 1px rgba(0,0,0,.1)')))
                }
                return el
            },

            /*
             * Internal method that adjusts the opacity of a single line.
             * Will be overwritten in VML fallback mode below.
             */
            opacity: function (el, i, val) {
                if (i < el.childNodes.length) el.childNodes[i].style.opacity = val
            }

        })


        function initVML() {

            /* Utility function to create a VML tag */

            function vml(tag, attr) {
                return createEl('<' + tag + ' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">', attr)
            }

            // No CSS transforms but VML support, add a CSS rule for VML elements:
            sheet.addRule('.spin-vml', 'behavior:url(#default#VML)')

            Spinner.prototype.lines = function (el, o) {
                var r = o.length + o.width,
                    s = 2 * r

                    function grp() {
                        return css(
                            vml('group', {
                                coordsize: s + ' ' + s,
                                coordorigin: -r + ' ' + -r
                            }), {
                                width: s,
                                height: s
                            }
                        )
                    }

                var margin = -(o.width + o.length) * 2 + 'px',
                    g = css(grp(), {
                        position: 'absolute',
                        top: margin,
                        left: margin
                    }),
                    i

                    function seg(i, dx, filter) {
                        ins(g,
                            ins(css(grp(), {
                                    rotation: 360 / o.lines * i + 'deg',
                                    left: ~~dx
                                }),
                                ins(css(vml('roundrect', {
                                        arcsize: o.corners
                                    }), {
                                        width: r,
                                        height: o.width,
                                        left: o.radius,
                                        top: -o.width >> 1,
                                        filter: filter
                                    }),
                                    vml('fill', {
                                        color: o.color,
                                        opacity: o.opacity
                                    }),
                                    vml('stroke', {
                                        opacity: 0
                                    }) // transparent stroke to fix color bleeding upon opacity change
                                )
                            )
                        )
                    }

                if (o.shadow)
                    for (i = 1; i <= o.lines; i++)
                        seg(i, -2, 'progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)')

                for (i = 1; i <= o.lines; i++) seg(i)
                return ins(el, g)
            }

            Spinner.prototype.opacity = function (el, i, val, o) {
                var c = el.firstChild
                o = o.shadow && o.lines || 0
                if (c && i + o < c.childNodes.length) {
                    c = c.childNodes[i + o];
                    c = c && c.firstChild;
                    c = c && c.firstChild
                    if (c) c.opacity = val
                }
            }
        }

        var probe = css(createEl('group'), {
            behavior: 'url(#default#VML)'
        })

        if (!vendor(probe, 'transform') && probe.adj) initVML()
        else useCssAnimations = vendor(probe, 'animation')

            return Spinner

    })
);

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\api.js
(function ($) {

    var libApi = SVMX.Package("com.servicemax.client.lib.api");

    /**
     * @class          com.servicemax.client.lib.api.Object
     * @description    Base class for all the client side classes
     */
    libApi.Class("Object", {

        __constructor: function () {},

        /**
         * @method
         * @return    {String}    class name or "unknown"
         */
        getClassName: function () {
            return this.constructor.__className || "unknown";
        },

        /**
         * The toString() method overrides the native toString method, and allows us to represent objects
         * within the debugger for easy interpretation.  Main use case: Identifying the type of an object
         * and especially, managing an array or hash of objects and knowing what the contents are.
         *
         * @public
         * @param    {String}    description
         *
         * @return    {String}    short class name  + description
         *
         * @note
         * While FireFox automatically represents all objects in its debugger using toString(), WebKit
         * does not; use instead the watch panel and add "this.toString()".
         * <br>
         * Individual classes can override toString and pass a description up to the parent method.
         * <br>
         * toString method for Sencha objects is set in com.servicemax.client.ui.components.impl
         */
        toString: function (description) {
            var shortClassName = this.getClassName().replace(/^com\.servicemax\.client\./, "client.");
            description = description ? " " + description : "";
            return shortClassName + (description ? " (" + description + ")" : "");
        }
    }, {});

    /**
     * @class           com.servicemax.client.lib.api.Event
     * @extends         com.servicemax.client.lib.api.Object
     *
     *
     * @param  {String}   type      some description
     * @param  {Object}   target    some description
     * @param  {Object}   data      some description
     *
     * @description     The event base class
     */
    libApi.Class("Event", com.servicemax.client.lib.api.Object, {
        /**
         * event type name
         *
         * @property
         * @type {String}
         * @default null
         * @description asdfasdf
         */
        type: null,
        /**
         * event target object
         *
         * @property
         * @type {Object}
         * @default null
         */
        target: null,
        /**
         * event data object
         *
         * @property
         * @type {Object}
         * @default null
         */
        data: null,
        __constructor: function (type, target, data) {
            this.type = type;
            this.target = target;
            this.data = data;
        }

    }, {});

    /**
     * @class           com.servicemax.client.lib.api.EventDispatcher
     * @extends         com.servicemax.client.lib.api.Object
     *
     *
     * @note
     *
     *
     * @description
     * Base classes for all those classes which want to be an event source
     */
    libApi.Class("EventDispatcher", libApi.Object, {
        /**
         * collection of event handlers
         *
         * @property
         * @type {Array}
         * @default []
         */
        eventHandlers: [],
        __constructor: function () {
            this.eventHandlers = [];
        },

        /**
         * adds the type, handler, and context into the event collection as an object
         *
         * @public
         * @method
         * @param   {String}        type        event type
         * @param   {Function}      handler     event handling function
         * @param   {Object}        context     object to reference event to
         *
         * @example
         * <p> 1)   this
         * </p>
         * <br>
         * <p> 2)   testing one t
         * </p>
         */
        bind: function (type, handler, context) {
            this.eventHandlers[this.eventHandlers.length] = {
                type: type,
                handler: handler,
                context: context
            };
        },
        /**
         * removes the event handler object from the collection given the type, handler, and context
         *
         * @public
         * @method
         * @param   {String}        type        event type
         * @param   {Function}      handler     event handling function
         * @param   {Object}        context     object to reference event to
         *
         *
         */
        unbind: function (type, handler, context) {
            for (var i = 0; i < this.eventHandlers.length; i++) {
                if (this.eventHandlers[i].handler == handler && this.eventHandlers[i].type == type) {
                    this.eventHandlers.splice(i, 1);
                }
            }
        },
        /**
         * triggers the event handler based on a given event object
         *
         * @public
         * @method
         * @param   {Event}    e   event type
         */
        triggerEvent: function (e) {
            var events = SVMX.array.filter(this.eventHandlers, function(eventHandler) {
                return eventHandler.type == e.type;
            });
            for (var i = 0; i < events.length; i++) {
                if (events[i].context) {
                    //bind arguments
                    events[i].handler.call(events[i].context, e);
                } else {
                    //Event type
                    events[i].handler(e);
                }
            }
        }

    }, {});

    /**
     * @class           com.servicemax.client.lib.api.ModuleActivator
     * @extends         com.servicemax.client.lib.api.Object
     *
     *
     * @description
     * The base module API, which is an entry point to all the modules. All the modules should implement
     * a class by deriving from this class.
     */
    libApi.Class("ModuleActivator", libApi.Object, {
        _logger: null,
        _module: null,
        __constructor: function () {},

        /**
         * before module initialization code goes here
         *
         * @public
         * @method
         */
        beforeInitialize: function () {},
        /**
         * module initialization code goes here
         *
         * @public
         * @method
         */
        initialize: function () {},
        /**
         * after module initialization code goes here
         *
         * @public
         * @method
         */
        afterInitialize: function () {},

        /**
         * sets the module to a given value
         *
         * @public
         * @method
         * @param   {Module}    value   module object
         */
        setModule: function (value) {
            this._module = value;
        },
        /**
         * get the module object
         *
         * @public
         * @method
         *
         * @return  {Module}
         */
        getModule: function () {
            return this._module;
        },
        /**
         * gets logger object
         *
         * @public
         * @method
         *
         * @return  {Logger}
         */
        getLogger: function () {
            return this._logger;
        },
        /**
         * returns the url given a path
         *
         * @public
         * @method
         * @param   {String}    path
         *
         * @return   {String}    resource url
         */
        getResourceUrl: function (path) {
            return this._module.getResourceUrl(path);
        }
    }, {});

    /**
     * @class           com.servicemax.client.lib.api.AbstractApplication
     * @extends         com.servicemax.client.lib.api.EventDispatcher
     *
     * @description     The application API
     */
    libApi.Class("AbstractApplication", libApi.EventDispatcher, {

        __constructor: function () {
            this.__base();
        },
        /**
         * returns the url given a path
         *
         * @public
         * @method
         * @param   {Object}
         */
        beforeRun: function (options) {
            options.handler.call(options.context);
        },
        /**
         * abstract method
         *
         * @public
         * @method
         */
        run: function () {}

    }, {
        /**
         * handle for the current application
         *
         * @property
         * @type {String}
         * @default null
         */
        currentApp: null
    });

    //////////////////////////////////////////

    // Set of utility classes which helps in inter-class communication (based on design patterns).
    // The candidate who can use these classes include;
    //     01. MVC implementations
    //     02. Call back handlers

    /**
     * @class           com.servicemax.client.lib.api.AbstractCommand
     * @extends         com.servicemax.client.lib.api.Object
     *
     *
     * @description     The command class
     */
    libApi.Class("AbstractCommand", libApi.Object, {
        __constructor: function () {},
        executeAsync: function (request, responder) {}

    }, {});

    /**
     * @class           com.servicemax.client.lib.api.AbstractOperation
     * @extends         com.servicemax.client.lib.api.Object
     *
     * @description     The operation class
     */
    libApi.Class("AbstractOperation", libApi.Object, {
        __constructor: function () {},
        performAsync: function (request, responder) {}

    }, {});

    /**
     * @class           com.servicemax.client.lib.api.AbstractResponder
     * @extends         com.servicemax.client.lib.api.Object
     *
     * @description     The responder class
     */

    libApi.Class("AbstractResponder", libApi.Object, {
        __constructor: function () {},
        result: function (data) {},
        fault: function (data) {}
    }, {});

    /**
     * @class           com.servicemax.client.lib.api.AbstractExtension
     * @extends         com.servicemax.client.lib.api.Object
     *
     * @description     Generic extension class
     */
    libApi.Class("AbstractExtension", com.servicemax.client.lib.api.Object, {
        perform: function (caller) {}
    }, {});

    /**
     * @class           com.servicemax.client.lib.api.ExtensionRunner
     * @extends         com.servicemax.client.lib.api.Object
     *
     * @description
     * Create an instance of this to quickly/easily run all extensions of the given
     * name.
     *
     * @note
     * Will execute extensions serially.
     * <br>TODO: some extensions that
     * make web reqeusts may want to specify execution in parallel.
     *
     * <br>TODO: Any extension that does not depend upon other extensions shoul be run
     * in parallel instead of serially.
     *
     *
     * @param   (Object)    caller
     * @param   (Object)    extensionName
     */
    libApi.Class("ExtensionRunner", com.servicemax.client.lib.api.Object, {
            /**
             * calling object
             *
             * @property    caller
             * @type {Object}
             * @default null
             */

            /**
             * name of extension
             *
             * @property    extensionName
             * @type {String}
             * @default null
             */

            __caller: null,
            __extensionName: null,
            __constructor: function (caller, extensionName) {
                this.__caller = caller;
                this.__extensionName = extensionName;
            },
            /**
             *
             *
             * @public
             * @method
             *
             * @return  (Object)       Deferred object
             */
            perform: function (inParams) {
                var logger = SVMX.getLoggingService().getLogger("EXTENSION-RUNNER");
                var done = function () {
                    var d = new $.Deferred();
                    d.resolve();
                    return d;
                };

                var client = SVMX.getClient();
                // TODO: should extensions only be called after a particular sync type is called?
                var declaration = client.getDeclaration("com.servicemax.client.extension");
                if (!declaration) return done();
                var definitions = client.getDefinitionsFor(declaration);
                var extensionName = this.__extensionName;
                definitions = SVMX.array.filter(definitions, function (def) {
                    return def.config["event"] === extensionName;
                });
                logger.info("Running " + extensionName + " with " + definitions.length + " extensions");
                if (definitions.length === 0) return done();

                var deferreds = [];

                for (var i = 0; i < definitions.length; i++) {
                    var definition = definitions[i];
                    var extClassName = definition.config['class-name'];
                    var extClass = SVMX.create(extClassName);

                    // NOTE: try/catch block can't catch async errors;
                    // The Extension must use its callback in an error handler!
                    try {
                        deferreds.push(extClass.perform(this.__caller, inParams));
                    } catch (e) {}
                }

                var result = SVMX.when(deferreds);
                result.done(function() {
                    logger.info("Running " + extensionName + " completed");
                });
                result.fail(function() {
                    logger.error("Running " + extensionName + " failed");
                });

                return result;
            }
        },
        // STATIC METHODS
        {
            /**
             * @static
             * @public
             * @method
             * @param   {Object}    inCaller
             * @param   {Object}    inName
             *
             * @return  (Object)
             */
            run: function (inCaller, inName, inParams) {
                var extensionRunner = new com.servicemax.client.lib.api.ExtensionRunner(inCaller, inName);
                return extensionRunner.perform(inParams);
            }
        });
    //////////////// end of utility classes ////////////////

})(jQuery);

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\services.js
(function ($) {

    var libServices = SVMX.Package("com.servicemax.client.lib.services");

    ////////////////////////////////// LOGGING /////////////////////////////

    /**
     * The central logging service.  Note that logTargetSettings are not available while loading modules; they only become available once Client.__run is called.
     *
     * @class           com.servicemax.client.lib.services.LoggingService
     * @extends         com.servicemax.client.lib.api.Object
     *
     */
    libServices.Class("LoggingService", com.servicemax.client.lib.api.Object, {
        __loggers: null,
        __uncreatedLoggers: null,
        __logTargetSettings: null,

        __constructor: function () {
            if (libServices.LoggingService.__instance != null)
                return libServices.LoggingService.__instance;

        // There should only be a single LoggingService class; set this static property to insure that this instance is that one.
            libServices.LoggingService.__instance = this;

            // no special characters allowed for the logger source
            this.__loggers = {};
        },

        setTargetSettings: function(targetSettings) {
            libServices.LoggingService.clearTargets();
            this.generateLogTargets(targetSettings.targets);

            var settings;
            this.__logTargetSettings = targetSettings.loggers;
            for (var source in this.__loggers) {
                var targetSettings = this.getLoggerSettings(source);
                this.__loggers[source].setTargetSettings(targetSettings);
            }
        },

        generateMissingLogTargets : function(targets) {
            if (this.__uncreatedLoggers) this.generateLogTargets(this.__uncreatedLoggers);
        },

        generateLogTargets: function(targets) {
            this.__uncreatedLoggers = {};
            var hasError = false;
            var sTargets = libServices.LoggingService.__targets;
            SVMX.forEachProperty(targets, function(targetName, targetDef) {
                if (!SVMX.array.contains(this.__targets, function(target) {
                    return target.targetName == targetName;
                })) {
                    var className = targetDef["class-name"];
                    var cls = SVMX.getClass(className, true);
                    if (!cls) {
                        this.__uncreatedLoggers[targetName] = targetDef;
                        hasError = true;
                    } else {
                        targetDef.options.targetName = targetName;
                        SVMX.create(className, targetDef.options);
                    }
                }
            }, this);
            if (!hasError) this.__uncreatedLoggers = null;
        },


        // Settings for this source take precedence
        // settings for DEFAULT take secondary precedence
        // "BrowserConsoleLogTarget": "DEBUG" is the default if no other setting is provided for BrowserConsoleLogTarget
            getLoggerSettings: function(source) {
                if (this.__logTargetSettings) {
                    return $.extend({}, this.__logTargetSettings.DEFAULT || {}, this.__logTargetSettings[source] || {});
                } else {
                    var targets = this.getTargets();
                    var result = {};
                    for (var i = 0; i < targets.length; i++) {
                        result[targets[i].targetName] = targets[i].defaultLogLevel;
                    }
                    return result;
                }
            },

        // Find or create the named Logger
            getLogger: function(source) {
                var ret = null;

                if (source == undefined || source == null) source = "SVMXCONSOLECORE";

                if (this.__loggers[source] == undefined) {
                    var targetSettings = this.getLoggerSettings(source);
                    ret = new libServices.Logger(this, source, targetSettings);
                    this.__loggers[source] = ret;
                } else {
                    ret = this.__loggers[source];
                }
                return ret;
            },


            getTargets: function(optionalTargetNames) {
                var ret = [];
                var targets = libServices.LoggingService.__targets;
                if (optionalTargetNames) {
                    for (var i = 0; i < targets.length; i++) {
                        if (optionalTargetNames[targets[i].targetName]) {
                            ret.push(targets[i]);
                        }
                    }
                } else {
                    for (var i = 0; i < targets.length; i++) {
                        if (targets[i].isDefaultTarget) {
                            ret.push(targets[i]);
                        }
                    }
                }
                return ret;
            }

        }, {
            __targets: [],
            __instance: null,
            getInstance: function (optionalLogSettings) {
                var ret = null;
                if (libServices.LoggingService.__instance == null) {
                    ret = new libServices.LoggingService(optionalLogSettings);
                } else {
                    ret = libServices.LoggingService.__instance;
                }
                return ret;
            },

            // Register a new log target
            registerTarget: function (target, options) {
                // Do not allow multiple log targets of the same name; only allow the last one created to exist
                SVMX.array.remove(libServices.LoggingService.__targets, function(tmptarget) {return target.targetName == tmptarget.targetName;}, true);

                libServices.LoggingService.__targets.push(target);
                SVMX.timer.job("generateMissingLogTargets", 10, function() {
                    libServices.LoggingService.getInstance().generateMissingLogTargets();
                });
            },
            clearTargets: function() {
                libServices.LoggingService.__targets = [];
            }
        }
    );


    /**
     * Log target API
     *
     * @class           com.servicemax.client.lib.services.AbstractLogTarget
     * @extends         com.servicemax.client.lib.api.Object
     *
     * @param   {Object}    options
     *
     */
    libServices.Class("AbstractLogTarget", com.servicemax.client.lib.api.Object, {
        /**
         * @property {string}
         * Name of the log target, "Browser", "Database", etc...
         * If svmx-logging-preferences is in use then all targetNames come from that setting.
         * Otherwise, target names can be assigned as part of the subclass definition.
         * The target name simply identifies this logger instance.
         */
        targetName: "",

        /**
         * @property {boolean}
         * If true, then this logging target will be used to log if there is no svmx-logging-preferences setting
         * ANY use of svmx-logging-preferences will cause those settings and not this property to determine who
         * logs what.
         */
        isDefaultTarget: false,

        /**
         * @property {string}
         * One of ERROR, DEBUG, INFO, WARNING or NONE.
         * This value is only used if isDefaultTarget is true AND there is no svmx-logging-preferences setting.
         * Indicates the log level that will be logged.
         */
        defaultLogLevel: "ERROR",
        __constructor: function (options) {
            if (!options) options = {};
            this.targetName = options.targetName;

            // register with the logging service
            libServices.LoggingService.registerTarget(this);
        },

        log: function (message, options) {}

    }, {});


    /**
     * Default logging target. Logs to the browser console.
     *
     * @class           com.servicemax.client.lib.services.BrowserConsoleLogTarget
     * @extends         com.servicemax.client.lib.services.AbstractLogTarget
     *
     */
    libServices.Class("BrowserConsoleLogTarget", libServices.AbstractLogTarget, {
        isDefaultTarget: true,
        defaultLogLevel: "DEBUG",

        __constructor: function (options) {
            if (!options) options = {targetName: "Browser"};
            this.__base(options);
        },

        log: function (message, options) {
            var console = window.console;
            if (!console) return;

            var type = options.type;

            if (message instanceof Error) {
                message = message.stack ? message.stack.toString() : message.toString();
            }

            var msg = options.timeStamp + ": " + options.source + " " + message;

            if (type == "INFO" || type == "CRITICAL") console.info(msg);
            else if (type == "ERROR") console.error(msg);
            else if (type == "WARNING") console.warn(msg);
            else if (type == "DEBUG") {
                if (console.debug) {
                    console.debug(msg);
                } else {
                    console.info("DEBUG=>INFO " + msg);
                }
            } else console.log(msg);
        }
    }, {});

    // As this is our Default Log Target until svmx-logging-preferences has specified otherwise, we need to create an instance of it.
    // Normally, Log Targets are created by the svmx-logging-preferences settings.
    new libServices.BrowserConsoleLogTarget({targetName: "Browser"});



    /**
     * The AlertLogTarget will present logged messages in the form of an obnoxious alert dialog.
     * Useful for really glaring errors that you want to be notified of without having to insert
     * alert code that might get checked in and irritate the rest of the developers (and perhaps users).
     * This log target was primarily added as an easy way of testing the Logging Targets, and
     * is not expected to receive much use.
     *
     * @class           com.servicemax.client.lib.services.AlertLogTarget
     * @extends         com.servicemax.client.lib.services.AbstractLogTarget
     *
     */
    libServices.Class("AlertLogTarget", libServices.AbstractLogTarget, {

        __constructor: function (options) {
            this.__base(options);
        },

        log: function (message, options) {
            var console = window.console;
            if (!console) return;

            var type = options.type;

            if (message instanceof Error) {
                message = message.stack ? message.stack.toString() : message.toString();
            }

            var msg = options.timeStamp + ": " + options.source + " " + message;
        alert(type + ": "+ msg);
        }

    }, {});



    /**
     * The logger API;
     *
     * This Logger class is really a Log Dispatcher that routes messages to the proper AbstractLogTarget subclass
     *
     * @class           com.servicemax.client.lib.services.Logger
     * @extends         com.servicemax.client.lib.api.Object
     *
     */
    libServices.Class("Logger", com.servicemax.client.lib.api.Object, {

    // LoggingService instance
        __parent: null,

    // Name of this logger "sfm-expressions"
        __source: "",

    // {targetName1: "ERROR", targetName2: "INFO", etc...}
    __targetSettings: null,

        __constructor: function (parent, source, targetSettings) {
            this.__parent = parent;
            this.__source = source;
        this.setTargetSettings(targetSettings);
        },

    /**
     * This method is currently called from core.js's run method, and is not expected to be
     * called from any other external point.
     *
     * @param {Object} A hash of settings: {targetName1: "ERROR", targetName2: "INFO", etc...}
     */
    setTargetSettings: function(targetSettings) {
        this.__targetSettings = targetSettings;
    },

        __shouldSkipLogging: function (type, target) {
            var ret = false,
                preferenceMap = {
                    "DEBUG": 5,
                    "INFO": 4,
                    "WARNING": 3,
                    "ERROR": 2,
            "CRITICAL": 1,
            "NONE": 0
                };
        var targetSetting = this.__targetSettings[target];
        if (!targetSetting) return true;

        var targetLevel = preferenceMap[targetSetting];
        var requestLevel = preferenceMap[type];

            if (targetLevel < requestLevel) {
                ret = true;
            }

            return ret;
        },

        getTimestamp: function () {
            return com.servicemax.client.lib.datetimeutils ? com.servicemax.client.lib.datetimeutils.DatetimeUtil.macroDrivenDatetime("Now") : new Date().toString();
        },

    /**
     * Logs the specified message at the "info" log level
     */
        info: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("INFO", t[i].targetName)) {
                    t[i].log(message, {
            type: "INFO",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        },

    /**
     * Logs the specified message at the "debug" log level
     */
        debug: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("DEBUG", t[i].targetName)) {
                    t[i].log(message, {
            type: "DEBUG",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        },

    /**
     * Logs the specified message at the "error" log level
     */
        error: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("ERROR", t[i].targetName)) {
                    t[i].log(message, {
            type: "ERROR",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        },

    /**
     * Logs the specified message at the "warning" log level
     */
        warning: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("WARNING", t[i].targetName)) {
                    t[i].log(message, {
            type: "WARNING",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        },

    /**
     * Same as warning
     */
        warn: function (message) {
            this.warning(message);
        },

    /**
     * Logs the specified message at the "critical" log level (not sure how well supported this is, and does not appear to get much use)
     */
        critical: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("CRITICAL", t[i].targetName)) {
                    t[i].log(message, {
            type: "CRITICAL",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        }

    }, {});

    ////////////////////////////////// END - LOGGING /////////////////////////////

    ////////////////////////////////// RESOURCE LOADING //////////////////////////

    /**
     *
     * @class           com.servicemax.client.lib.services.ResourceLoaderEvent
     * @extends         com.servicemax.client.lib.api.Event
     */
    libServices.Class("ResourceLoaderEvent", com.servicemax.client.lib.api.Event, {
        __constructor: function (type, target, data) {
            this.__base(type, target, data);
        }
    }, {});

    /**
     *
     * @class           com.servicemax.client.lib.services.ResourceLoader
     * @extends         com.servicemax.client.lib.api.EventDispatcher
     *
     * @note
     * Supported events
     *<br> 01. LOAD_COMPLETE
     *<br> 02. LOAD_ERROR
     */
    libServices.Class("ResourceLoader", com.servicemax.client.lib.api.EventDispatcher, {

        __constructor: function () {
            this.__base();
        },

        loadAsync: function (options) {
            $.ajax({
                type: "GET",
                dataType: options.responseType,
                data: options.data,
                cache: options.cache,
                url: options.url,
                context: this,
                async: true,
                success: function (data, status, jqXhr) {
                    this._loadSuccess(data, status);
                },
                error: function (jqXhr, status, e) {
                    this._loadError(jqXhr, status, e);
                }
            });
        },

        _loadSuccess: function (data, status) {
            var rle = new libServices.ResourceLoaderEvent("LOAD_COMPLETE", this, data);
            this.triggerEvent(rle);
        },

        _loadError: function (jqXhr, status, e) {
            var rle = new libServices.ResourceLoaderEvent("LOAD_ERROR", this);
            this.triggerEvent(rle);
        }
    }, {});

    /**
     *
     * @class           com.servicemax.client.lib.services.ResourceLoaderService
     * @extends         com.servicemax.client.lib.api.Object
     *
     */
    libServices.Class("ResourceLoaderService", com.servicemax.client.lib.api.Object, {

        __constructor: function () {
            if (libServices.ResourceLoaderService.__instance != null)
                return libServices.ResourceLoaderService.__instance;

            libServices.ResourceLoaderService.__instance = this;
        },

        createResourceLoader: function () {
            // TODO: should create appropriate loader types -> local (for devices), remote (http for PCs)
            return new libServices.ResourceLoader();
        }

    }, {
        __instance: null,

        getInstance: function () {
            var ret = null;
            if (libServices.ResourceLoaderService.__instance == null) {
                ret = new libServices.ResourceLoaderService();
            } else {
                ret = libServices.ResourceLoaderService.__instance;
            }
            return ret;
        }
    });

    ////////////////////////////////// END - RESOURCE LOADING ////////////////////

})(jQuery);

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\core.js
(function ($) {

    var libCore = SVMX.Package("com.servicemax.client.lib.core");

    /**
     * load progress event class
     *
     * @class           com.servicemax.client.lib.core.LoadProgressEvent
     * @extends         com.servicemax.client.lib.api.Event
     *
     */
    libCore.Class("LoadProgressEvent", com.servicemax.client.lib.api.Event, {

        __constructor: function (type, target, data) {
            this.__base(type, target, data);
        }
    }, {});

    /**
     * load progress event dispatcher class
     *
     * @class           com.servicemax.client.lib.core.LoadProgressMonitor
     * @extends         com.servicemax.client.lib.api.EventDispatcher
     */

    libCore.Class("LoadProgressMonitor", com.servicemax.client.lib.api.EventDispatcher, {

        totalSteps: 0,
        currentStep: 0,

        __constructor: function (type, target, data) {
            this.__base(type, target, data);
        },

        start: function (options) {
            this.totalSteps = options.totalSteps;
            this.currentStep = 1;
            var lpe = new libCore.LoadProgressEvent("LOAD_STARTED", this, options.params);
            this.triggerEvent(lpe);
        },

        finishStep: function (params) {
            var lpe = new libCore.LoadProgressEvent("STEP_FINISHED", this, params);
            this.triggerEvent(lpe);
            this.currentStep++;
        },

        finish: function () {
            var lpe = new libCore.LoadProgressEvent("LOAD_FINISHED", this);
            this.triggerEvent(lpe);
        }
    }, {});

    /**
     * The module loader event class
     *
     * @class           com.servicemax.client.lib.core.ModuleLoaderEvent
     * @extends         com.servicemax.client.lib.api.Event
     *
     * @note
     * Supported events : <br>
     * 01. LOAD_COMPLETE  <br>
     * 02. LOAD_ERROR     <br>
     */
    libCore.Class("ModuleLoaderEvent", com.servicemax.client.lib.api.Event, {

        __constructor: function (type, target, data) {
            this.__base(type, target, data);
        }
    }, {});


    /**
     * The module loader class
     *
     * @class           com.servicemax.client.lib.core.ModuleLoader
     * @extends         com.servicemax.client.lib.api.EventDispatcher
     *
     */
    libCore.Class("ModuleLoader", com.servicemax.client.lib.api.EventDispatcher, {

        __options: null,
        module: null,
        __logger: null,
        templateList: null,

        __constructor: function (options) {
            this.__base();
            this.__options = options;
            this.__logger = SVMX.getLoggingService().getLogger("MODULE-LOADER");
        },

        loadAsync: function () {

            if (this.__options.manifestOnly) {
                this.__loadManifest();
            } else {
                this.__loadModuleScripts();
            }
        },

        getOptions: function () {
            return this.__options;
        },

        __loadManifest: function () {
            // generate the right url
            var codebase = this.__getCodeBase(),
                cache = SVMX.isCachingEnabled();

            var url = codebase + "/" + "manifest/module.json";

            $.ajax({
                cache: cache,
                type: "GET",
                dataType: "json",
                url: url,
                context: this,
                async: true,
                success: function (data, status, jqXhr) {
                    this.__loadManifestSuccess(data, status);
                },
                error: function (jqXhr, status, e) {
                    this.__loadManifestError(jqXhr, status, e);
                }
            });
        },

        __loadManifestSuccess: function (data, status) {
            var rle = new libCore.ModuleLoaderEvent("LOAD_COMPLETE", this, data);
            this.triggerEvent(rle);
        },

        __loadManifestError: function (jqXhr, status, e) {
            this.__logger.error("Cannot load manifest for " + this.__options.id + ", XHR Status = " + status);
            var rle = new libCore.ModuleLoaderEvent("LOAD_ERROR", this);
            this.triggerEvent(rle);
        },

        __getCodeBase: function () {
            var codebase = this.__options.codebase;

            if (codebase != null) {
                if (codebase.charAt(codebase.length - 1) != '/') codebase += "/";
            } else {
                codebase = "";
            }

            codebase += this.__options.id;
            return codebase;
        },

        __loadModuleScripts: function () {
            // generate the right url prefix
            var codebase = this.__getCodeBase();
            var prefix = codebase + "/" + "src/";

            SVMX.requireScript(this.__options.module.scripts, this.__loadModuleScriptsComplete,
				SVMX.proxy(this, "__loadModuleError"),
                this, {
                    async: true,
                    prefix: prefix
                });
        },

        __loadModuleError: function (inError) {
            this.__logger.error(inError);
            var rle = new libCore.ModuleLoaderEvent("LOAD_ERROR", this);
            this.triggerEvent(rle);
        },

        __loadModuleScriptsComplete: function () {
            // TODO : generate the list of SUCCESS and ERROR load list

            this.__loadModuleTemplates();
        },

        __loadModuleTemplates: function () {
            // generate the right url prefix
            if (this.__options.module.templates && this.__options.module.templates.length > 0) {
                var codebase = this.__getCodeBase();
                var prefix = codebase + "/" + "resources/templates/";

                SVMX.requireTemplate(this.__options.module.templates, this.__loadModuleTemplatesComplete,
                    this, {
                        async: true,
                        prefix: prefix
                    });
            } else {
                this.__loadModuleTemplatesComplete();
            }
        },

        __loadModuleTemplatesComplete: function (templateList) {
            // TODO : generate the list of SUCCESS and ERROR load list
            this.templateList = templateList;
            var rle = new libCore.ModuleLoaderEvent("LOAD_COMPLETE", this);
            this.triggerEvent(rle);
        }

    }, {});

    /**
     * The module class
     *
     * @class           com.servicemax.client.lib.core.Module
     * @extends         com.servicemax.client.lib.api.Object
     */
    libCore.Class("Module", com.servicemax.client.lib.api.Object, {
        dependencies: null,
        declarations: null,
        definitions: null,
        scripts: null,
        services: null,
        tests: null,
        version: null,
        id: null,
        name: null,
        description: null,
        client: null,
        codebase: null,
        loadAtStartup: false,
        activatorClass: null,
        __activator: null,
        templates: null,
        loadedTemplates: null,

        // cache the definition, temporarily
        def: null,

        __constructor: function (client, def, options) {

            this.client = client;

            this.dependencies = [];
            this.declarations = [];
            this.definitions = [];
            this.services = [];

            // extract the relevant information
            this.id = def.id;
            this.version = def.version;
            this.name = def.name;
            this.description = def.description;
            this.def = def; // remove this
            this.scripts = def.scripts;
            this.tests = def.tests ? def.tests:[];
            this.activatorClass = def["module-activator"];
            this.loadAtStartup = def["load-at-startup"];
            this.codebase = options.codebase;
            this.templates = def.templates;

            this.__extractDependencies();
            this.__extractDeclaredInterfaces();
            this.__extractInterfaceImplementations();
            this.__extractServices();

            // register interfaces
            var i = 0;
            for (i = 0; i < this.declarations.length; i++) {
                client.registerDeclaration(this.declarations[i]);
            }
        },

        setLoadedTemplates: function (loadedTemplates) {
            this.loadedTemplates = loadedTemplates;
        },

        getTemplate: function (name) {
            if (!this.loadedTemplates) return null;

            for (var i = 0; i < this.loadedTemplates.length; i++) {
                if (name == this.loadedTemplates[i].name)
                    return this.loadedTemplates[i].data;
            }

            return null;
        },

        createActivator: function () {

            // create the module activator instance
            var maClass = SVMX.getClass(this.activatorClass);
            this.__activator = new maClass();
            this.__activator.setModule(this);
        },

        beforeInitialize: function () {
            this.__activator.beforeInitialize();
        },

        initialize: function () {
            this.__activator.initialize();
        },

        afterInitialize: function () {
            this.__activator.afterInitialize();
        },

        resolveDefinitions: function () {

            for (var i = 0; i < this.definitions.length; i++) {
                var ret = this.client.registerDefinition(this.definitions[i]);

                // cannot resolve one of the definitions! just return without proceeding further
                if (ret == false) return ret;
            }
            return true;
        },

        resolveServices: function () {
            for (var i = 0; i < this.services.length; i++) {
                var ret = this.client.registerService(this.services[i]);

                // cannot resolve one of the services! just return without proceeding further
                if (ret == false) return ret;
            }
            return true;
        },

        __extractServices: function () {
            var services = this.def.services,
                length = services.length;
            for (var i = 0; i < length; i++) {
                var service = new libCore.Service(this, services[i]);
                this.services[i] = service;
            }
        },

        __extractDependencies: function () {
            var depends = this.def.depends,
                length = depends.length;
            for (var i = 0; i < length; i++) {
                var dependency = new libCore.Dependency(this, depends[i]);
                this.dependencies[i] = dependency;
            }
        },

        __extractDeclaredInterfaces: function () {
            var declares = this.def.declares,
                length = declares.length;
            for (var i = 0; i < length; i++) {
                var declaration = new libCore.DeclaredInterface(this, declares[i]);
                this.declarations[i] = declaration;
            }
        },

        __extractInterfaceImplementations: function () {
            var defines = this.def.defines,
                length = defines.length;
            for (var i = 0; i < length; i++) {
                var definition = new libCore.InterfaceDefinition(this, defines[i]);
                this.definitions[i] = definition;
            }
        },

        getResourceUrl: function (path) {
            var url = this.__getCodeBase() + "/" + "resources/" + path;
            return url;
        },

        __getCodeBase: function () {
            var codebase = this.codebase;

            if (codebase != null) {
                if (codebase.charAt(codebase.length - 1) != '/') codebase += "/";
            } else {
                codebase = "";
            }

            codebase += this.id;
            return codebase;
        }
    }, {});

    /**
     * The class representing a single "declares" entity
     *
     * @class           com.servicemax.client.lib.core.DeclaredInterface
     * @extends         com.servicemax.client.lib.api.Object
     *
     */
    libCore.Class("DeclaredInterface", com.servicemax.client.lib.api.Object, {

        id: null,
        description: null,
        module: null,

        __constructor: function (module, def) {
            this.id = def.id;
            this.description = def.description;
            this.module = module;
        }
    }, {});

    /**
     * The class representing a single "defines" entity
     *
     * @class           com.servicemax.client.lib.core.InterfaceDefinition
     * @extends         com.servicemax.client.lib.api.Object
     */
    libCore.Class("InterfaceDefinition", com.servicemax.client.lib.api.Object, {
        type: null,
        id: null,
        config: null,
        module: null,
        __constructor: function (module, def) {
            this.type = def.type;
            this.id = def.id;
            this.config = def.config;
            this.module = module;
        },

        createInstanceAsync: function (name, options) {

            // TODO : load the module if it is already not loaded
            this.__createInstanceAsyncInternal(name, options);
        },

        __createInstanceAsyncInternal: function (name, options) {
            var cls = SVMX.getClass(name);
            var obj = new cls();
            options.handler.call(options.context, obj);

        },

        getResourceUrl: function (path) {
            return this.module.getResourceUrl(path);
        }

    }, {});

    /**
     * The class representing a single "depends" entity
     *
     * @class           com.servicemax.client.lib.core.Dependency
     * @extends         com.servicemax.client.lib.api.Object
     */
    libCore.Class("Dependency", com.servicemax.client.lib.api.Object, {
        id: null,
        version: null,
        module: null,

        __constructor: function (module, def) {
            this.id = def.id;
            this.version = def.version;
            this.module = module;
        }
    }, {});

    /**
     *
     *
     * @class           com.servicemax.client.lib.core.ModuleResourceLoader
     * @extends         com.servicemax.client.lib.aervices.ResourceLoader
     */

    libCore.Class("ModuleResourceLoader", com.servicemax.client.lib.services.ResourceLoader, {

        __module: null,
        __constructor: function (m) {
            this.__base();
            this.__module = m;
        },

        loadAsync: function (options) {
            options.url = this.__getCodeBase() + "/" + "resources/" + options.url;
            return this.__base(options);
        },

        __getCodeBase: function () {
            var codebase = this.__module.getModule().codebase;

            if (codebase != null) {
                if (codebase.charAt(codebase.length - 1) != '/') codebase += "/";
            } else {
                codebase = "";
            }

            codebase += this.__module.getModule().id;
            return codebase;
        },

        getResourceUrl: function (url) {
            return this.__getCodeBase() + "/" + "resources/" + url;
        }

    }, {});

    /**
     * The class representing a single "service" entity
     *
     * @class           com.servicemax.client.lib.core.Service
     * @extends         com.servicemax.client.lib.api.Object
     */
    libCore.Class("Service", com.servicemax.client.lib.api.Object, {
        id: null,
        module: null,
        __serviceClassName: null,
        __serviceInstance: null,

        __constructor: function (module, serviceDef) {
            this.id = serviceDef.id;
            this.__serviceClassName = serviceDef["class-name"];
            this.module = module;
        },

        // !!! Use this only when you are completely sure that service is loaded!
        getInstance: function () {
            if (this.__serviceInstance == null) {
                var serviceClass = SVMX.getClass(this.__serviceClassName);
                this.__serviceInstance = new serviceClass();
            }
            return this.__serviceInstance;
        },

        getInstanceAsync: function (options) {

            // There can be one instance per service type

            // TODO : load the module if it is already not loaded
            this.__getInstanceAsyncInternal(options);
        },

        __getInstanceAsyncInternal: function (options) {
            if (this.__serviceInstance == null) {
                var serviceClass = SVMX.getClass(this.__serviceClassName);
                this.__serviceInstance = new serviceClass();
            }

            options.handler.call(options.context, this.__serviceInstance);
        }
    }, {});

    /**
     * The client event class
     *
     * @class           com.servicemax.client.lib.core.ClientEvent
     * @extends         com.servicemax.client.lib.api.Event
     * @note
     * Supported events :
     * 01. READY
     *
     */

    libCore.Class("ClientEvent", com.servicemax.client.lib.api.Event, {

        __constructor: function (type, target, data) {
            this.__base(type, target, data);
        }
    }, {});

    /**
     * The core Client API.
     *
     * @class           com.servicemax.client.lib.core.Client
     * @extends         com.servicemax.client.lib.api.EventDispatcher
     *
     */
    libCore.Class("Client", com.servicemax.client.lib.api.EventDispatcher, {

        __moduleId2Modules: null,
        __serviceId2Services: null,
        __declarationId2Declarations: null,
        __declarationId2Definitions: null,
        __logger: null,
        __appParams: null,
        __progressMonitor: null,
        __loadVersion: "debug",
        __applicationTitle: null,

        __constructor: function () {

            if (libCore.Client.__instance != null) return libCore.Client.__instance;

            this.__base();
            this.__moduleId2Modules = {};
            this.__declarationId2Definitions = {};
            this.__declarationId2Declarations = {};
            this.__serviceId2Services = {};
            this.__appParams = {};

            this.__progressMonitor = new libCore.LoadProgressMonitor();
            this.__logger = SVMX.getLoggingService().getLogger();

            // set up the static client reference
            libCore.Client.__instance = this;

            // create the minisplash instance
            SVMX.create("com.servicemax.client.lib.core.MiniSplash", this.__progressMonitor);
        },

        run: function (options) {

            // Replaces jQuery's parseJson method with one that tolerates comments in the config file.
            jQuery.ajaxSettings.converters["text json"] =  this.__parseJSON;

            // Provides for an SVMX.Deferred object
            SVMX.Deferred = $.Deferred;

            if (options.loadVersion != undefined && options.loadVersion != null) {
                this.__loadVersion = options.loadVersion;
            }

            if (options.configType == "remote")
                this.__runWithRemoteConfig(options.data);
            else if (options.configType == "local")
                this.__runWithLocalConfig(options.data);
            else
                throw new Error("Unknown config type!");
        },

        // Copied from jquery-min.js, as you can tell from the variable names.  This method adds
        // better tolerance for comments on the json files.
        __parseJSON: function(b) {
            var w = /^[\],:{}\s]*$/,
                x = /(?:^|:|,)(?:\s*\[)+/g,
                y = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
                z = /"[^"\\\r\n]*"|true|false|null|-?(?:\d\d*\.|)\d+(?:[eE][\-+]?\d+|)/g;
            if (!b || typeof b != "string")
                return null;
            b = jQuery.trim(b);
            try {

                /* The window.JSON.parse method is the method with best performance, but throws
                 * errors if there are comments; so don't run this if comment-like structures
                 * appear.  Uses weak indexOf test rather than regex for performance reasons
                 */
                if (window.JSON && window.JSON.parse && b.indexOf("/*") == -1) {
                    return window.JSON.parse(b);
                }
            } catch(e) {}

            /* This test came from jQuery's code.  Full rationale unknown, but sanity-checks the json,
             * perhaps to verify that executing this function has no side-effects and can't be used
             * as part of an attack.  Test for comments was added by ServiceMax.  Will still fail on
             * json such as {hey: 5}; still must be {"hey": 5}
             */
            if (w.test(b.replace(y, "@").replace(z, "]").replace(x, "").replace(/\/\*.*?\*\//g,""))) {
                try {
                    return (new Function("return " + b))();
                } catch(e) {}
            }
            throw new Error("Invalid JSON: " + b);
        },

        getModuleForId: function (id) {
            return this.__moduleId2Modules[id];
        },

        getApplicationTitle: function () {
            return this.__applicationTitle;
        },

        getLoadVersion: function () {
            return this.__loadVersion;
        },

        getApplicationParameter: function (name) {
            return this.__appParams[name];
        },

        addApplicationParameter: function (name, value) {
            // TODO: Do not allow to add a new param if it is already added
            this.__appParams[name] = value;
        },

        getPlatformParameter: function (name) {
            // TODO:
        },

        getProgressMonitor: function () {
            return this.__progressMonitor;
        },

        __runWithRemoteConfig: function (url) {
            // load the config
            var loader = com.servicemax.client.lib.services
                .ResourceLoaderService.getInstance().createResourceLoader();

            loader.bind("LOAD_COMPLETE", this.__configLoadSuccess, this);
            loader.bind("LOAD_ERROR", this.__configLoadError, this);
            loader.loadAsync({
                url: url,
                responseType: "json",
                cache: false
            });
        },

        __configLoadSuccess: function (rle) {
            this.__run(rle.data);
        },

        __configLoadError: function (rle) {
            // YUI Compressor cribs
            //debugger;
        },

        __runWithLocalConfig: function (config) {
            this.__run(config);
        },

        __run: function (config) {
            // at this point configuration is success fully loaded
            // extract application parameters
            var params = config["app-config"];
            //console.log( config.modules )
            for (var param in params) {
                this.__appParams[param] = params[param];
            }

    	    var logSettings = this.getApplicationParameter("svmx-logging-preferences");
    	    if (logSettings) SVMX.getLoggingService().setTargetSettings(logSettings);

            // application title from configuration
            this.__applicationTitle = config.title;

            // TODO : TRANSLATION
            // +1 for status update of manifests loading
            this.__progressMonitor.start({
                totalSteps: config.modules.length + 1,
                params: {
                    stepTitle: "Starting module load"
                }
            });

            // extract platform parameters
            // TODO:

            // load the manifests first
            this.__loadModuleManifests(config.modules);
        },

        __loadModulesContext: 0,
        __allDependencies: null,
        __loadManifestTriggeredFor: null,
        __loadModuleManifests: function (moduleList) {
            // load state management
            this.__loadModulesContext = 0;
            this.__loadManifestTriggeredFor = {};
            // end load state management

            var i = 0,
                count = moduleList.length;
            for (i = 0; i < count; i++) {
                var m = moduleList[i];
                var options = {
                    manifestOnly: true,
                    id: m.id,
                    codebase: m.codebase
                };

                this.__loadModuleManifest(options);
            }

        },

        __loadModuleManifest: function (options) {
            // check if load is already triggered, if yes, then return
            if (this.__loadManifestTriggeredFor[options.id] != undefined) return;

            this.__loadModulesContext++;
            this.__loadManifestTriggeredFor[options.id] = options.id;

            var ml = new libCore.ModuleLoader(options);
            ml.bind("LOAD_COMPLETE", this.__loadModuleManifestSuccess, this);
            ml.bind(
                "LOAD_ERROR",
                SVMX.proxy(this, "__loadModuleManifestError", options),
                this
            );

            ml.loadAsync();
        },

        __loadModuleManifestSuccess: function (evt) {

            // create a module instance for this module
            var m = new libCore.Module(this, evt.data, evt.target.getOptions());
            this.__logger.info("Loaded Module " + m.id);

            // register the module
            this.__moduleId2Modules[m.id] = m;

            // for each of the dependencies, trigger the load
            // var dependencies = m.dependencies, count = dependencies.length;
            // for(var i = 0; i < count; i++){
            //	 var d = dependencies[i];

            // assume the code base of the dependent
            // !!!! will not work for vf pages since the "codebase" has to be got from VF macros !!!
            // }
            // end dependency load

            // check if all the modules are loaded
            this.__loadModulesContext--;
            if (this.__loadModulesContext == 0)
                this.__loadModuleManifestsComplete();
        },

        __loadModuleManifestError: function (options, evt) {
            // YUI Compressor cribs
            this.__logger.error("loadModuleManifestError: " + options.id + " failed to load");
        },

        __loadModuleManifestsComplete: function () {
            this.__progressMonitor.finishStep({
                stepTitle: "All module manifests loaded"
            });
            this.__logger.info("all module manifest are loaded!");

            // resolve the interfaces and their implementations
            if (!this.__resolveDefinitions()) {
                this.__logger.error("There was an error during definitions resolution! Client cannot proceed.");
                return;
            }

            // resolve service definitions
            if (!this.__resolveServices()) {
                this.__logger.error("There was an error during services resolution! Client cannot proceed.");
                return;
            }

            // start calculating the dependency. following are the entry point interfaces for which
            // the chain should be created.
            // 01. com.servicemax.client.runtime.application

            // right now load all the module as defined in the application configuration
            // TODO : Enable lazy loading
            this.__loadModules();
        },

        __loadModuleTriggeredFor: null,
        __loadModules: function () {
            // load state management
            this.__loadModulesContext = 0;
            this.__loadModuleTriggeredFor = {};
            // end load state management

            for (var mid in this.__moduleId2Modules) {
                var m = this.__moduleId2Modules[mid];
                this.__loadModule(m);
            }

        },

        __loadModule: function (module) {
            // check if load is already triggered, if yes, then return
            if (this.__loadModuleTriggeredFor[module.id] != undefined) return;

            this.__loadModulesContext++;
            this.__loadModuleTriggeredFor[module.id] = module.id;

            var options = {
                manifestOnly: false,
                id: module.id,
                codebase: module.codebase,
                module: module
            };
            var ml = new libCore.ModuleLoader(options);
            ml.bind("LOAD_COMPLETE", this.__loadModuleSuccess, this);
            ml.bind("LOAD_ERROR", this.__loadModuleError, this);
            ml.loadAsync();

        },

        __loadModuleSuccess: function (evt) {
            var module = evt.target.getOptions().module;
            this.__progressMonitor.finishStep({
                stepTitle: "Module loaded: " + module.id
            });

            this.__logger.info(module.id + " successfully loaded");

            // set up the loaded templates
            module.setLoadedTemplates(evt.target.templateList);

            // create the activator
            module.createActivator();

            // check if all the modules are loaded
            this.__loadModulesContext--;

            if (this.__loadModulesContext == 0)
                this.__loadModulesComplete();
        },

        __loadModuleError: function (evt) {
            // YUI Compressor cribs
            //debugger;
        },

        __loadModulesComplete: function () {
            this.__logger.info("all modules now loaded are loaded!");

            // pre-initialize all the modules
            for (var mid in this.__moduleId2Modules) {
                var m = this.__moduleId2Modules[mid];
                try {
                    m.beforeInitialize();
                } catch (e) {
                    this.__logger.error("Error during beforeInitialize() of =>" + mid);
                    throw e;
                }
            }

            // initialize all the modules
            for (var mid in this.__moduleId2Modules) {
                var m = this.__moduleId2Modules[mid];
                try {
                    m.initialize();
                } catch (e) {
                    this.__logger.error("Error during initialize() of =>" + mid);
                    throw e;
                }
            }

            // post initialize all the modules
            for (var mid in this.__moduleId2Modules) {
                var m = this.__moduleId2Modules[mid];
                try {
                    m.afterInitialize();
                } catch (e) {
                    this.__logger.error("Error during afterInitialize() of =>" + mid);
                    throw e;
                }
            }
            com.servicemax.client.lib.api.ExtensionRunner.run(this, "com.servicemax.client.onFrameworkLoad")
                .then(SVMX.proxy(this, function () {
                    // finally, the client is ready to run, dispatch the ready event
                    var ce = SVMX.create("com.servicemax.client.lib.core.ClientEvent", "READY", this);

                    this.triggerEvent(ce);
                }));
        },

        __resolveDefinitions: function () {
            for (var mid in this.__moduleId2Modules) {
                var ret = this.__moduleId2Modules[mid].resolveDefinitions();
                if (!ret) return false;
            }
            return true;
        },

        __resolveServices: function () {
            for (var mid in this.__moduleId2Modules) {
                var ret = this.__moduleId2Modules[mid].resolveServices();
                if (!ret) return false;
            }
            return true;
        },

        getDeclarationRegistry: function () {
            return this;
        },

        getServiceRegistry: function () {
            return this;
        },

        getDeclaration: function (name) {
            if (this.__declarationId2Declarations[name] == undefined) {
                // unknown declaration name
                this.__logger.warning("Cannot find declaration <" + name + ">!");
                return null;
            }
            return this.__declarationId2Declarations[name];
        },

        getDefinitionsFor: function (declaration) {
            var id = "";

            if (typeof (declaration) == 'string')
                id = declaration;
            else
                id = declaration.id;

            return this.__declarationId2Definitions[id];
        },

        forEachDefinition: function(name, callback) {
            var declaration = this.getDeclaration(name);
            var definitions = this.getDefinitionsFor(declaration);
            SVMX.array.forEach(definitions, callback);
        },

        registerDeclaration: function (declaration) {
            var id = declaration.id;
            if (this.__declarationId2Declarations[id] != undefined) {

                // someone else has already registered the declaration!!
                var preModuleId = this.__declarationId2Declarations[id].module.id;
                var thisModuleId = declaration.module.id;
                this.__logger.error("Module " + thisModuleId + " is trying to declare the interface <" + declaration.id + "> which is already declared by " + preModuleId + ". Please rectify!");
                return false;
            }

            this.__declarationId2Declarations[id] = declaration;
            this.__declarationId2Definitions[id] = [];
            return true;
        },

        registerDefinition: function (definition) {
            var type = definition.type;
            if (this.__declarationId2Definitions[type] == undefined) {

                // trying to define an unknown declaration!
                this.__logger.error("Module " + definition.module.id + " is trying to define an interface  <" + type + "> which is not declared. Please rectify!");
                return false;
            }

            var defs = this.__declarationId2Definitions[type];
            defs[defs.length] = definition;
            return true;
        },

        iterateOverDefinitionsForDeclaration: function (declarationName, callback) {
            var declaration = this.getDeclaration(declarationName);
            if (!declaration) return;
            var definitions = client.getDefinitionsFor(declaration);
            SVMX.array.forEach(definitions, callback);
        },

        registerService: function (service) {
            var id = service.id;
            if (this.__serviceId2Services[id] != undefined) {

                // trying to register a particlar service more than once!
                var preModuleId = this.__serviceId2Services[id].module.id;
                var thisModuleId = service.module.id;
                this.__logger.error("Module " + thisModuleId + " is trying to register the service <" + id + "> which is already declared by " + preModuleId + ". Please rectify!");
                return false;
            }
            this.__serviceId2Services[id] = service;
            return true;
        },

        //////// BEGIN - Service Registry //////////
        getServiceInstanceAsync: function (name, options) {
            var servDef = this.getService(name);
            if (servDef) {
                servDef.getInstanceAsync({
                    handler: function (service) {
                        if (options.context) options.handler.call(options.context, service);
                        else options.handler(service);
                    },
                    context: this
                });
            } else {
                if (options.context) options.handler.call(options.context, null);
                else options.handler(null);
            }
        },

        getService: function (name) {
            //            console.log(name, this.__serviceId2Services)
            if (this.__serviceId2Services[name] == undefined) {
                this.__logger.error("Cannot find service -> " + name);
                return null;
            }

            return this.__serviceId2Services[name];
        },

        getServiceInstance : function (name) {
            var serviceDef = this.getService(name);
            if (serviceDef) {
                return serviceDef.getInstance();
            }
        }
        ///////// END - Service Registry /////////

    }, {
        __instance: null,
        getInstance: function () {
            if (libCore.Client.__instance == null) {
                libCore.Client.__instance = new libCore.Client();
            }
            return libCore.Client.__instance;
        }
    });

    /**
     * The default mini splash scren.
     *
     * @class           com.servicemax.client.lib.core.MiniSplash
     * @extends         com.servicemax.client.lib.api.Object
     *
     * @note
     * !! Not the right file to be in. Find a better place
     *
     */
    libCore.Class("MiniSplash", com.servicemax.client.lib.api.Object, {
        __pm: null,
        __outerNode: null,
        __ms: null,
        _width: "100%",
        _height: "20px",
        __text: "",

        __constructor: function (pm) {
            var loadingId = libCore.MiniSplash.loadingDivId;
            libCore.MiniSplash.loadingDivId++;
            var body = $("body");

            pm.bind("LOAD_STARTED", this.handleLoadStarted, this);
            pm.bind("STEP_FINISHED", this.handleFinishStep, this);
            pm.bind("LOAD_FINISHED", this.handleFinish, this);

            this.__pm = pm;
            var url = window["__SVMX_CLIENT_LIB_PATH__"] || "";
            url += (url && !url.match(/\/$/) ? "/" : "") + "resources/images/loadingAnim.gif";
            body.append("<div class='loading_div' id='loading_div" + loadingId + "'>" +
                "<img style='padding-left:5px; float:right' src='" + url + "'/>" +
                "<span style='float:right; margin:2px 0 0 0; padding:0' class='loading_span'></span>" +
                "</div>");
            this.__ms = $("#loading_div" + loadingId + " .loading_span");
            this.__outerNode = $("#loading_div" + loadingId);
            var stylesToAdd = {
                width: this._width,
                minHeight: this._height,
                bottom: 0,
                left: 0,
                fontFamily: "tahoma, arial, verdana, sans-serif",
                textAlign: "right",
                fontSize: "12px",
                color: "#000",
                borderTop: "solid 1px #c7c7c7",
                padding: "1px 10px",
                display: "none",
                position: "absolute",
                boxSizing: "border-box",
                background: "#e0dfdf"
            };

            this.__outerNode.css(stylesToAdd);

            // Cache the function so we can disconnect it later
            // Note that SVMX.proxy insures that every MiniSplash gets
            // a unique copy of this function for safe disconnecting.
            this.__disconnectFunc = SVMX.proxy(this, "__onScroll");
            $(window).on("scroll", this.__disconnectFunc);
        },
        __onScroll: function () {
            if (this.__outerNode) {
                this.__outerNode.css("bottom", -$("body")[0].scrollTop);
            }
        },
        __setText: function (value) {
            this.__text = value;
            this.__ms.text(this.__text);
        },

        handleLoadStarted: function (e) {
            this.__outerNode.show();
            this.__setText(e.data.stepTitle);
        },

        handleFinishStep: function (e) {
            this.__setText(e.data.stepTitle);
        },

        handleFinish: function (e) {
            var me = this;
            this.__ms.text("Loading done");
            me.__pm.unbind("LOAD_STARTED", this.handleLoadStarted, this);
            me.__pm.unbind("STEP_FINISHED", this.handleFinishStep, this);
            me.__pm.unbind("LOAD_FINISHED", this.handleFinish, this);

            this.__outerNode.animate({
                opacity: 0
            }, 400, null, function () {
                me.__outerNode.remove();
                me.__ms = null;
                me.__outerNode = null;
                me.__pm = null;
                if (this.__disconnectFunc) {
                    $(window).off("scroll", this.__disconnectFunc);
                }
            });
        }
    }, {
        /* Using animation means asynchronous events.  Asynchronous events means that
         * there can be multiple instances of this class at the same time, and
         * multiple domNodes called "loading_div".  Every instance of this class
         * needs a dom node with a unique id.
         */
        loadingDivId: 0
    });

})(jQuery);
// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\jquery\jquery.parseXml-1.0.0.js
/**
 * Parse XML plugin
 *
 * Copyright (c) 2011 Indresh M S (indresh.ms@gmail.com)
 * 
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 * @version 1.0.0
 */

(function($) {

/**
 * The parseXml extension
 * 
 * @returns an instance of XML wrapper object
 */
$.parseXml = function(data, bHandleNamespaces) {
	var xmlDoc = new XMLObj(data, bHandleNamespaces);
	return xmlDoc;
};

/**
 * The wrapper XML Object
 * 
 * @param data the xml data either a string or xml document
 * @param bHandleNamespaces set this to true to manually identify the namespaces especially with I.E.
 */
function XMLObj(data, bHandleNamespaces) {
	this.xmlDoc = null;
	this.xmlData = data;
	this.namespaces = {};
	
	/**
	 * @private
	 */
	this.extractNamespaces = function (element){
		var nsURI = element.namespaceURI;
		var nsPrefix = element.prefix;
		
		if(nsPrefix && nsPrefix != "")
		this.namespaces[nsPrefix] = nsURI;
		
		var cn = element.childNodes;
		for(var cni=0; cni <cn.length; cni++){
			this.extractNamespaces(cn[cni]);
		}
	};
	
	/**
	 * returns the name of the element
	 * 
	 * @param element the xml element
	 * @returns the element's name
	 */
	this.getElementName = function(element){
		return element.nodeName;
	};
	
	/**
	 * Returns the first child element of this element
	 * 
	 * @param element the parent element
	 * @returns the first child if present, null otherwise
	 */
	this.getFirstChildElement = function(element){
		var ret  = null;
		var children = this.getChildElements(element);
		if(children && children.length > 0)
			ret = children[0];
		
		return ret;
	};
	
	/**
	 * Returns all the child nodes of type ELEMENT
	 * 
	 *  @param element the parent element
	 *  @returns all the child elements
	 */
	this.getChildElements = function(element){
		var ret = [];
		var cn = element.childNodes;
		
		// filter out only element nodes
		for(var i = 0; i < cn.length; i++){
			if(cn[i].nodeType == 1)		// 1 means Node.ELEMENT_NODE
				ret[ret.length] = cn[i];
		}
		return ret;
	};
	
	/**
	 * Returns the first element with a given name
	 * 
	 * @param tagName name of the element
	 * @param nameSpace the namespace, null if there is none
	 * @param parentElement the parent element
	 * @returns the first child matching the name if present, null otherwise
	 */
	this.getFirstElementByTagName = function(tagName, nameSpace, parentElement){
		var ret = this.getElementsByTagName(tagName, nameSpace, parentElement);
		if(ret && ret.length > 0)
			return ret[0];
		else
			return null;
	};
	
	/**
	 * Returns the all the elements with a given name
	 * 
	 * @param tagName name of the element
	 * @param nameSpace the namespace, null if there is none
	 * @param parentElement the parent element
	 * @returns all the child elements matching the name if present, null otherwise
	 */
	this.getElementsByTagName = function(tagName, nameSpace, parentElement){
		var ret = null;
		
		if(!parentElement)
			parentElement = this.documentElement;
		
		if ($.browser.msie) {
			var nsp = this.getPrefix4NS(nameSpace);
			if(nsp != "")
				tagName = nsp + ":" + tagName;
				
			ret = parentElement.getElementsByTagName(tagName);
		}
		else {
			if (!nameSpace) {
				ret = parentElement.getElementsByTagName(tagName);
			}
			else 
				ret = parentElement.getElementsByTagNameNS(nameSpace, tagName);
		}
		return ret;
	};
	
	/**
	 * Returns the attribute value as integer
	 * 
	 * @param name name of the attribute
	 * @param nameSpace the namespace, null if there is none
	 * @param element the parent element
	 * @return value of attribute if present, 0 otherwise
	 */
	this.getAttributeValueAsInt = function(name, nameSpace, element){
		var ret = this.getAttributeValue(name, nameSpace, element);
		if(ret)
			ret = parseInt(ret);
		else
			ret = 0;
		
		return ret;
	};
	
	/**
	 * Returns the attribute value as string
	 * 
	 * @param name name of the attribute
	 * @param nameSpace the namespace, null if there is none
	 * @param element the parent element
	 * @return value of attribute if present, null otherwise
	 */
	this.getAttributeValue = function(name, nameSpace, element){
		var ret = null;
		
		if(element){
			if($.browser.msie){
				var nsp = this.getPrefix4NS(nameSpace);
				if(nsp != "")
					name = nsp + ":" + name;
				
				ret = element.getAttribute(name);
			}else{
				if (!nameSpace) {
					ret = element.getAttribute(name);
				}
				else 
					ret = element.getAttributeNS(nameSpace, name);
			}
		}
		return ret;
	};
	
	// this will be used only when running in IE.
	/**
	 * @private
	 */
	this.getPrefix4NS = function(nameSpace){
		var ret = "";
		
		if(nameSpace && nameSpace != ""){
			for (var nsp in this.namespaces) {
				if (this.namespaces[nsp] == nameSpace) {
					ret = nsp;
					break;
				}
			}
		}
		return ret;
	};
	
	//TODO: Need a better way to identify the input - XML OR String
	var type = typeof(this.xmlData);
	if (type == "string") {
		if ($.browser.msie) {
			this.xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
			this.xmlDoc.async = "false";
			this.xmlDoc.loadXML(txt);
		}
		else {
			parser = new DOMParser();
			this.xmlDoc = parser.parseFromString(txt, "text/xml");
		}
	}else{
		this.xmlDoc = this.xmlData;
	}
	
	this.documentElement = this.xmlDoc.documentElement;
	
	if(!bHandleNamespaces)
		return;
	
	// IE has a problem that it does not support XML with namespaces. So, doing it manually
	this.extractNamespaces(this.xmlDoc.documentElement);
}

})(jQuery);

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\com.servicemax.client.lib\src\datetimeutils.js
(function () {

    var datetimeutil = SVMX.Package("com.servicemax.client.lib.datetimeutils");

    /**
     * @class           com.servicemax.client.lib.datetimeutils.DatetimeUtil
     * @extends         com.servicemax.client.lib.api.Object
     * @description
     * Class to provide all the utility methods for Datetime.
     * Currently contains util functions for datetime(format, renderer)
     */
    datetimeutil.Class("DatetimeUtil", com.servicemax.client.lib.api.Object, {
        __constructor: function () {
            //TODO :
        }
    }, {
        timeZone: "",
        dateFormat: "",
        timeFormat: "",
        setTimezoneOffset: function(timezoneOffset) {datetimeutil.DatetimeUtil.timeZone = timezoneOffset;},
        setDateFormat: function(format) {datetimeutil.DatetimeUtil.dateFormat = format;},
        setTimeFormat: function(format) {datetimeutil.DatetimeUtil.timeFormat = format;},
        getDefaultDateFormat: function() {return datetimeutil.DatetimeUtil.dateFormat || "MM/DD/YYYY";},
        getDefaultTimeFormat: function() {return datetimeutil.DatetimeUtil.timeFormat || "HH:mm i";},
        /**
         * Takes a date/datetime in various formats and returns a server formated date/datetime string.
         * To go the other way, see renderer methods.
         * @public
         * @method
         * @param   {String}    value A string representing a date or datetime some format described below
         * @param   {String}    displayMode One of dateTime or dateOnly.  Sigh.  Should have been date, time, datetime.
         * @param   {String}    format Date format; one of the values returned by getDateFormatTypes(), with time stripped out
         * @param   {String}    timeFormat 12 or 24 for 12 hour time or 24 hour time.
         * @param   {String}    todPlacement This is the REAL timeFormat; "H:s"
         *
         * @return  String      Server time formated date or datetime: "YYYY-MM-DD hh:mm:ss"
         */
        formatDatetime: function (value, displayMode, format, timeFormat, todPlacementFormat) {
            if (!value) return;
            var amText = SVMX.getClientProperty("amText") || "AM";
            var pmText = SVMX.getClientProperty("pmText") || "PM";

            if (displayMode == "dateTime") {
                if (timeFormat == '12') {
                    var tod = this.getTOD(value);

                    if (value.indexOf(amText) > -1 || value.indexOf(pmText) > -1) {
                        value = this.trimDatetimeTOD(value, tod);
                        if (value.indexOf(":") > -1) {
                            var ind = value.indexOf(":");
                            var hrValue = value.substr((ind - 2), 2);

                            var dtValueArray = value.match(/\d+/g);

                            value = this.__formatDatetimeValue(tod, hrValue, dtValueArray, format);
                        }
                    }
                } else {
                    if (value.indexOf(":") > -1) {
                        var ind = value.indexOf(":");
                        var hrValue = value.substr((ind - 2), 2);

                        var dtValueArray = value.match(/\d+/g);

                        value = this.__formatDatetimeValue(tod, hrValue, dtValueArray, format);
                    } else if (todPlacementFormat == "H.mm") {
                        var ind = value.indexOf(".");
                        var hrValue = value.substr((ind - 2), 2);

                        var dtValueArray = value.match(/\d+/g);

                        value = this.__formatDatetimeValue(tod, hrValue, dtValueArray, format);
                    }
                }
            } else if (displayMode == "dateOnly") {
                value = this.__formatDate(value, format);
            }

            return value;
        },

        //Engineer the value to save format
        __formatDatetimeValue: function (tod, hrValue, value, format) {
            var year = "",
                month = "",
                day = "",
                hour = "",
                mins = "";

            var amText = SVMX.getClientProperty("amText") || "AM";
            var pmText = SVMX.getClientProperty("pmText") || "PM";

            if (format != undefined) {
                if (format == 'm/d/Y' || format == 'm-d-Y' || format == 'm.d.Y') {
                    year = value[2], month = value[0];
                    day = value[1], hour = value[3], mins = value[4];
                }

                if (format == 'd/m/Y' || format == 'd-m-Y' || format == 'd.m.Y') {
                    year = value[2], month = value[1];
                    day = value[0], hour = value[3], mins = value[4];
                }

                if (format == 'Y/m/d' || format == 'Y-m-d' || format == 'Y.m.d' || format == "Y年m月d日") {
                    year = value[0], month = value[1];
                    day = value[2], hour = value[3], mins = value[4];
                }

                if (parseInt(hrValue, 10) < 12 && tod == pmText)
                    hour = (parseInt(hrValue, 10) + 12).toString();

                if (parseInt(hrValue, 10) == 12 && tod == amText)
                    hour = "00";

            } else { //for detail format is always undefined
                year = value[2];
                month = value[1];
                day = value[0];
            }

            //save format is YYYY-MM-DD Hr:mins:00
            return value = year + '-' + month + '-' + day + " " + hour + ":" + mins + ':' + "00";
        },

        //If dateOnly engineer the value to the corresponding save format(YYYY-MM-DD)
        __formatDate: function (dateValue, format) {
            if (!dateValue) return;

            var year = "",
                month = "",
                day = "";
            var value = dateValue.match(/\d+/g);

            if (format != undefined) {
                if (format == 'm/d/Y' || format == 'm-d-Y' || format == 'm.d.Y') {
                    year = value[2];
                    month = value[0];
                    day = value[1];
                }

                if (format == 'd/m/Y' || format == 'd-m-Y' || format == 'd.m.Y') {
                    year = value[2];
                    month = value[1];
                    day = value[0];
                }

                if (format == 'Y/m/d' || format == 'Y-m-d' || format == 'Y.m.d' || format == "Y年m月d日") {
                    year = value[0];
                    month = value[1];
                    day = value[2];
                    hour = value[3];
                    mins = value[4];
                }

                //TODO : revisit these conditions
                //this condition is required when save was trigerred and formatting of date was done but
                //save did not go through cause of other validations, on triggering save again the
                //formatted value is returned and hence these conditions.
                if (year.length != 4) {
                    year = value[0];
                    day = value[2];
                    month = value[1];
                }
            } else {
                //for detail format is always undefined
                year = value[2];
                month = value[0];
                day = value[1];
                //TODO : revisit these conditions
                if (year.length != 4) {
                    year = value[0];
                    day = value[2];
                }
            }

            //save format is YYYY-MM-DD
            return dateValue = year + '-' + month + '-' + day;
        },

        // Returns the format in which save happens, as per the current
        // flex delivery data model
        getDatetimeSaveFormat: function (mode) {
            var savedFormat;
            if (mode == "dateTime") {
                savedFormat = "Y-m-d H:i:s";
            } else {
                savedFormat = "Y-m-d";
            }

            return savedFormat;
        },

        //To be used to add all the different date format types
        getDateFormatTypes: function () {
            return {
                "MM/DD/YYYY": {
                    "format": "m/d/Y H:i",
                    value: "{1}/{0}/{2} {3}:{4}"
                },
                "YYYY/MM/DD": {
                    "format": "Y/m/d H:i",
                    value: "{2}/{1}/{0} {3}:{4}"
                },
                "DD/MM/YYYY": {
                    "format": "d/m/Y H:i",
                    value: "{0}/{1}/{2} {3}:{4}"
                },
                "DD.MM.YYYY": {
                    "format": "d.m.Y H:i",
                    value: "{0}.{1}.{2} {3}:{4}"
                },
                "MM.DD.YYYY": {
                    "format": "m.d.Y H:i",
                    value: "{1}.{0}.{2} {3}:{4}"
                },
                "YYYY.MM.DD": {
                    "format": "Y.m.d H:i",
                    value: "{2}.{1}.{0} {3}:{4}"
                },
                "YYYY-MM-DD": {
                    "format": "Y-m-d H:i",
                    value: "{2}-{1}-{0} {3}:{4}"
                },
                "MM-DD-YYYY": {
                    "format": "m-d-Y H:i",
                    value: "{1}-{0}-{2} {3}:{4}"
                },
                "DD-MM-YYYY": {
                    "format": "d-m-Y H:i",
                    value: "{0}-{1}-{2} {3}:{4}"
                },
                "YYYY. MM. DD": {
                    "format": "Y.m.d H:i",
                    value: "{2}.{1}.{0} {3}:{4}"
                },
                "YYYY年MM月DD日": {
                    "format": "Y年m月d日 H:i",
                    value: "{2}年{1}月{0}日 {3}:{4}"
                }
            };
        },

        getDatetimeDisplayValue: function (format, value, timeFormat) {
            var todInCenter = this.isTODInCenter(format, timeFormat);
            if (todInCenter) {
                var fmtDTVal = value.split(" "),
                    tod = this.getTOD(value);
                if (tod != "" && tod != null && tod != undefined) {
                    value = fmtDTVal[0] + " " + tod + " " + fmtDTVal[1];
                } else {
                    value = fmtDTVal[0] + " " + fmtDTVal[1];
                }
            }

            if (timeFormat == "H.mm") {
                var val = value.replace(":", "."); //replace : with . for italian locale
                value = val;
            }

            return value;
        },

        //find out where to place AM/PM based on format
        isTODInCenter: function (dateFormat, timeFormat) {
            var inCenter = false;
            if (dateFormat == "YYYY. MM. DD" || dateFormat == "YYYY年MM月DD日" ||
                dateFormat == "YYYY. MM. DD H:i:s" || dateFormat == "YYYY年MM月DD日 H:i:s" ||
                timeFormat == "a h:mm" || timeFormat == "ah:mm" || timeFormat == "a hh:mm") {
                inCenter = true;
            }

            return inCenter;
        },

        // Engineer the value in a format as to be read by Ext.date.parse i.e remove AM or PM
        // if PM convert the hour value to 24 hr format.
        setDatetimeValue: function (value, timeFormat) {
            if (value == null || value == undefined || value == '') return;

            var tod = this.getTOD(value);
            var amText = SVMX.getClientProperty("amText") || "AM";
            var pmText = SVMX.getClientProperty("pmText") || "PM";

            //Need to remove AM and PM if present;cause the
            //Ext.Date.parse(value, format) will return undefined
            if (value.indexOf(amText) > -1 || value.indexOf(pmText) > -1) {
                value = this.trimDatetimeTOD(value, tod);

                if (value.indexOf(":") > -1) {
                    var ind = value.indexOf(":");
                    var hrValue = value.substr((ind - 2), 2);
                    if (parseInt(hrValue, 10) < 12 && tod == pmText) {
                        hour = (parseInt(hrValue, 10) + 12).toString();
                        value = this._replaceHourValue(value, ind - 2, hour);
                    }
                }
            }

            if (timeFormat == "H.mm") {
                var val = value.replace(".", ":");
                value = val;
            }
            value = value + ":" + "00";

            return value;
        },

        //If 24 hr format convert the hour value if the tod is PM
        _replaceHourValue: function (value, index, strToReplace) {
            if (index > value.length - 1) return value;
            var displayValue = value.substr(0, index) + strToReplace + value.substr(index + 2);
            return displayValue;
        },


        /**
         * Takes a datetime in server formats and returns a datetime string in requested format
         *
         * @public
         * @method
         * @param   {String}    value A string representing a date or datetime using the server format YYYY-MM-DD hh:mm:ss
         * @param   {String}    dateFormat Date format; "MM/DD/YYYY"
         * @param   {String}    twentyFourHrTime 12 or 24 for 12 hour time or 24 hour time.
         * @param   {String}    todPlacementFormat This is the REAL timeFormat; "H:s"
         *
         * @return  String      Server time formated date or datetime: "YYYY-MM-DD hh:mm:ss"
         */
        datetimeRenderer: function (datetimeValue, dateFormat, twentyFourHrTime, todPlacementFormat) {
            if (!datetimeValue) return;
            if (!dateFormat) dateFormat = this.getDefaultDateFormat() || "YYYY-MM-DD";
            if (!twentyFourHrTime) twentyFourHrTime = this.getTimeFormat(this.getDefaultTimeFormat());
            if (!todPlacementFormat) todPlacementFormat = this.getDefaultTimeFormat();


            var amText = SVMX.getClientProperty("amText") || "AM";
            var pmText = SVMX.getClientProperty("pmText") || "PM";
            var formatValue = this.getDateFormatTypes()[dateFormat].value;
            dateFormat = dateFormat + " " + "H:i:s";

            if (datetimeValue.indexOf(amText) == -1 || datetimeValue.indexOf(pmText) == -1) {
                var tod;
                datetimeValue = datetimeValue.substring(0, datetimeValue.length - 3);
                if (datetimeValue.indexOf(":") > -1) {
                    var ind = datetimeValue.indexOf(":");
                    var hrValue = datetimeValue.substr((ind - 2), 2);
                    var arr = datetimeValue.match(/\d+/g);
                    var year = arr[0],
                        month = arr[1],
                        day = arr[2],
                        hour = arr[3],
                        mins = arr[4];
                    if (twentyFourHrTime == '12') {
                        if (parseInt(hrValue, 10) <= 12) {
                            if (parseInt(hrValue, 10) == 00) { // for 12 hr format only
                                hour = "12";
                            }
                            tod = amText;

                            if (parseInt(hrValue, 10) == 12) { // if hr is 12 then it is PM
                                tod = pmText;
                            }
                        } else {
                            tod = pmText;
                            hour = (parseInt(hrValue, 10) - 12).toString();
                            if (hour.toString().length == 1) {
                                hour = "0".concat(hour.toString());
                            }
                        }

                        datetimeValue = this.__formatDateStr(formatValue, day, month, year, hour, mins);
                        var todInCenter = this.isTODInCenter(dateFormat, todPlacementFormat);
                        if (todInCenter) {
                            var fmtDTVal = datetimeValue.split(" ");
                            return fmtDTVal[0] + " " + tod + " " + fmtDTVal[1];
                            //Need to revisit, cannot have so many return statements.
                        }
                        return datetimeValue + " " + tod;
                    } else {
                        datetimeValue = this.__formatDateStr(formatValue, day, month, year, hour, mins);
                        //if italian replace : with .
                        if (todPlacementFormat == "H.mm") {
                            var val = datetimeValue.replace(":", ".");
                            datetimeValue = val;
                        }

                        return datetimeValue;
                    }
                }
            }

            return datetimeValue;
        },

        dateRenderer: function (dateValue, format) {
            if (!dateValue) return;
            if (!format) format = this.getDefaultDateFormat();
            var formatValue = this.getDateFormatTypes()[format].value.split(" ")[0];
            var value = dateValue.match(/\d+/g);
            var year = value[0],
                month = value[1],
                day = value[2];

            return this.__formatDateStr(formatValue, day, month, year);
        },

        //engineer the renderer's value
        __formatDateStr: function () {
            var format = arguments[0];
            for (var i = 1; i < arguments.length; i++) {
                format = format.split("{" + (i - 1) + "}").join(arguments[i]);
            }
            return format;
        },

        //TOD == time of the day, possible values AM/PM
        getTOD: function (value) {
            var tod = '';
            var amText = SVMX.getClientProperty("amText") || "AM";
            var pmText = SVMX.getClientProperty("pmText") || "PM";

            if (value != null && value != undefined) {
                if (value.indexOf(amText) > -1 || value.indexOf(pmText) > -1) {
                    if (value.indexOf(amText) > -1) {
                        tod = amText;
                    } else if (value.indexOf(pmText) > -1) {
                        tod = pmText;
                    }
                }
            }

            return tod;
        },

        //check if datetime value has AM/PM
        valueHasTOD: function (value) {
            var bool;
            var amText = SVMX.getClientProperty("amText") || "AM";
            var pmText = SVMX.getClientProperty("pmText") || "PM";

            if (value.indexOf(amText) > -1 || value.indexOf(pmText) > -1) {
                bool = true;
            } else {
                bool = false;
            }

            return bool;
        },

        //check if tod is the last 2 chars or in between in datetime as in korean/vietnam locale.
        trimDatetimeTOD: function (value, tod) {
            var amText = SVMX.getClientProperty("amText") || "AM";
            var pmText = SVMX.getClientProperty("pmText") || "PM";

            if (value.slice(-2) == amText || value.slice(-2) == pmText) {
                value = value.substring(0, value.length - 3);
            } else {
                var val = value.replace(tod, ""); //remove tod - AM/PM from string
                val = val.replace(/\s+/g, ' '); //Since replace introduced extra whitespace remove it
                value = val;
            }

            return value;
        },

        // returns the hour format, possible values 12hr and 24 hr
        getTimeFormat: function (hoursFormat) {
            if (hoursFormat == "h:mm a" || hoursFormat == "a h:mm" || hoursFormat == "ah:mm" || hoursFormat == "a hh:mm") {
                hoursFormat = '12';
            } else {
                hoursFormat = '24'; // if hoursFormat = H.mm or h:mm
            }

            return hoursFormat;
        },

        // TODO: This should take a date object as input
        getTimestampWithSaveFormat: function () {
            return this.macroDrivenDatetime("Now", "YYYY-MM-DD", "hh:mm:ss");
        },

        // Note that this method may be called before Ext has loaded;
        // example: The logger uses this before Ext loads.
        // NOTE: This seems to be the only method to take an actual Date object.
        dateObjFormatter: function (inDate, dateOnly) {
            if (inDate) {
                if ("Ext" in window) {
                    return Ext.Date.format(inDate, dateOnly ? 'Y-m-d' : 'Y-m-d H:i:s')
                } else {
                    var result =  inDate.getFullYear() + "-" + (1 + inDate.getMonth()) + "-" + inDate.getDate();
                    if (!dateOnly) result += " " + inDate.getHours() + ":" + inDate.getMinutes() + ":" + inDate.getSeconds();
                    return result;
                }
            } else {
                return "";
            }
        },

        //Used to build the datetime value based on macro's(yesterday, now, today, tomorrow)
        macroDrivenDatetime: function (macro, dateFormat, timeFormat, displayMode, dtValue) {

            var yesterday = this.getDateYesterday();
            var yesDtValue = this.dateObjFormatter(yesterday);

            var dt = this.getDateTimeNow(),
                value;
            var nowDtValue = this.dateObjFormatter(dt);

            var today = this.getDateToday();
            var todayDtValue = this.dateObjFormatter(today);

            var tomorrow = this.getDateTomorrow();
            var tomDtValue = this.dateObjFormatter(tomorrow);

            switch (macro) {
            case "Yesterday":
                value = yesDtValue;
                break;
            case "Now":
                value = nowDtValue;
                break;
            case "Today":
                value = todayDtValue;
                break;
            case "Tomorrow":
                value = tomDtValue;
                break;
            }

            timeFormat = this.getTimeFormat(timeFormat);
            //For fields which are not on screen displayMode is null
            //hence use the value's length to differentiate
            if (displayMode != null && displayMode != undefined) {
                if (displayMode == "datetime") {
                    value = this.datetimeRenderer(value, dateFormat, timeFormat);
                } else if (displayMode == "date") {
                    value = this.dateRenderer(value, dateFormat);
                }
            } else if (dtValue != null && dtValue != undefined) {
                if (dtValue.length > 12) {
                    value = this.datetimeRenderer(value, dateFormat, timeFormat);
                } else {
                    value = this.dateRenderer(value, dateFormat);
                }
            }

            return value;
        },

        /* We ignore any settings the browser and OS may provide on the current timezone and use the salesforce timezone setting */
        __convertTimeToSalesforceTimezone : function(d) {
            if (datetimeutil.DatetimeUtil.timeZone) {

                d.setMinutes(d.getMinutes() + d.getTimezoneOffset()); // Remove the browser's timezone offset to reset to GMT
                var isNegative = datetimeutil.DatetimeUtil.timeZone.match(/^-/);
                var hours = Number(datetimeutil.DatetimeUtil.timeZone.match(/^-?\+?(\d+)/)[1]);
                var minutes = Number(datetimeutil.DatetimeUtil.timeZone.match(/:(\d+)/)[1]);
                if (isNegative) {
                    d.setHours(d.getHours() - hours, d.getMinutes() - minutes);
                } else {
                    d.setHours(d.getHours() + hours, d.getMinutes() + minutes);
                }
            }
        },

        getDateToday: function () {
            var d = new Date();
            this.__convertTimeToSalesforceTimezone(d);
            d.setHours(0, 0, 0, 0);
            return d;
        },

        getDateYesterday: function () {
            var d = new Date();
            this.__convertTimeToSalesforceTimezone(d);
            d.setDate(d.getDate() - 1);
            d.setHours(0, 0, 0, 0);
            return d;
        },

        getDateTomorrow: function () {
            var d = new Date();
            this.__convertTimeToSalesforceTimezone(d);
            d.setDate(d.getDate() + 1);
            d.setHours(0, 0, 0, 0);
            return d;
        },

        getDateTimeNow: function () {
            var d = new Date();
            this.__convertTimeToSalesforceTimezone(d);
            return d;
        },

        /* There are two datetime formats used in the data model:
         * "2013-04-17T23:38:18.000+0000"
         * "2013-04-01 00:00:00"
         * It may also be possible to have just "2013-04-01"
         * Determine which format is being used and return a Date object
         * TODO: Does not handle the +-xxxx (in the case of all data I've seen +0000)
         */
        getDateObjFromDataModel: function (inDateString) {
            if (inDateString instanceof Date) return inDateString;
            var d = new Date();
            d.setHours(0, 0, 0, 0);

            var dateSubstr = inDateString.substring(0, 10);

            var indexOfT = inDateString.indexOf("T");
            var timeSubstr = indexOfT == -1 ? inDateString.substring(11) : inDateString.substr(11, 8);

            var parts = dateSubstr.split(/-/);
            d.setFullYear(parts[0]);
            d.setMonth(parts[1] - 1);
            d.setDate(parts[2]);

            if (timeSubstr) {
                timeSubstr = timeSubstr.replace(/\..*$/, "");
                parts = timeSubstr.split(/:/);
                d.setHours(parts[0], parts[1], parts[2], 0);
            }
            return d;
        }
    });
})();
// end of file

