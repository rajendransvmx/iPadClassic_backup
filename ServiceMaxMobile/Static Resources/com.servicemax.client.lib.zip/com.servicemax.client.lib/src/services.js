(function ($) {

    var libServices = SVMX.Package("com.servicemax.client.lib.services");

    ////////////////////////////////// LOGGING /////////////////////////////

    /**
     * The central logging service.  Note that logTargetSettings are not available while loading modules; they only become available once Client.__run is called.
     *
     * @class           com.servicemax.client.lib.services.LoggingService
     * @extends         com.servicemax.client.lib.api.Object
     *
     */
    libServices.Class("LoggingService", com.servicemax.client.lib.api.Object, {
        __loggers: null,
        __uncreatedLoggers: null,
        __logTargetSettings: null,

        __constructor: function () {
            if (libServices.LoggingService.__instance != null)
                return libServices.LoggingService.__instance;

        // There should only be a single LoggingService class; set this static property to insure that this instance is that one.
            libServices.LoggingService.__instance = this;

            // no special characters allowed for the logger source
            this.__loggers = {};
        },

        setTargetSettings: function(targetSettings) {
            libServices.LoggingService.clearTargets();
            this.generateLogTargets(targetSettings.targets);

            var settings;
            this.__logTargetSettings = targetSettings.loggers;
            for (var source in this.__loggers) {
                var targetSettings = this.getLoggerSettings(source);
                this.__loggers[source].setTargetSettings(targetSettings);
            }
        },

        generateMissingLogTargets : function(targets) {
            if (this.__uncreatedLoggers) this.generateLogTargets(this.__uncreatedLoggers);
        },

        generateLogTargets: function(targets) {
            this.__uncreatedLoggers = {};
            var hasError = false;
            var sTargets = libServices.LoggingService.__targets;
            SVMX.forEachProperty(targets, function(targetName, targetDef) {
                if (!SVMX.array.contains(this.__targets, function(target) {
                    return target.targetName == targetName;
                })) {
                    var className = targetDef["class-name"];
                    var cls = SVMX.getClass(className, true);
                    if (!cls) {
                        this.__uncreatedLoggers[targetName] = targetDef;
                        hasError = true;
                    } else {
                        targetDef.options.targetName = targetName;
                        SVMX.create(className, targetDef.options);
                    }
                }
            }, this);
            if (!hasError) this.__uncreatedLoggers = null;
        },


        // Settings for this source take precedence
        // settings for DEFAULT take secondary precedence
        // "BrowserConsoleLogTarget": "DEBUG" is the default if no other setting is provided for BrowserConsoleLogTarget
            getLoggerSettings: function(source) {
                if (this.__logTargetSettings) {
                    return $.extend({}, this.__logTargetSettings.DEFAULT || {}, this.__logTargetSettings[source] || {});
                } else {
                    var targets = this.getTargets();
                    var result = {};
                    for (var i = 0; i < targets.length; i++) {
                        result[targets[i].targetName] = targets[i].defaultLogLevel;
                    }
                    return result;
                }
            },

        // Find or create the named Logger
            getLogger: function(source) {
                var ret = null;

                if (source == undefined || source == null) source = "SVMXCONSOLECORE";

                if (this.__loggers[source] == undefined) {
                    var targetSettings = this.getLoggerSettings(source);
                    ret = new libServices.Logger(this, source, targetSettings);
                    this.__loggers[source] = ret;
                } else {
                    ret = this.__loggers[source];
                }
                return ret;
            },


            getTargets: function(optionalTargetNames) {
                var ret = [];
                var targets = libServices.LoggingService.__targets;
                if (optionalTargetNames) {
                    for (var i = 0; i < targets.length; i++) {
                        if (optionalTargetNames[targets[i].targetName]) {
                            ret.push(targets[i]);
                        }
                    }
                } else {
                    for (var i = 0; i < targets.length; i++) {
                        if (targets[i].isDefaultTarget) {
                            ret.push(targets[i]);
                        }
                    }
                }
                return ret;
            }

        }, {
            __targets: [],
            __instance: null,
            getInstance: function (optionalLogSettings) {
                var ret = null;
                if (libServices.LoggingService.__instance == null) {
                    ret = new libServices.LoggingService(optionalLogSettings);
                } else {
                    ret = libServices.LoggingService.__instance;
                }
                return ret;
            },

            // Register a new log target
            registerTarget: function (target, options) {
                // Do not allow multiple log targets of the same name; only allow the last one created to exist
                SVMX.array.remove(libServices.LoggingService.__targets, function(tmptarget) {return target.targetName == tmptarget.targetName;}, true);

                libServices.LoggingService.__targets.push(target);
                SVMX.timer.job("generateMissingLogTargets", 10, function() {
                    libServices.LoggingService.getInstance().generateMissingLogTargets();
                });
            },
            clearTargets: function() {
                libServices.LoggingService.__targets = [];
            }
        }
    );


    /**
     * Log target API
     *
     * @class           com.servicemax.client.lib.services.AbstractLogTarget
     * @extends         com.servicemax.client.lib.api.Object
     *
     * @param   {Object}    options
     *
     */
    libServices.Class("AbstractLogTarget", com.servicemax.client.lib.api.Object, {
        /**
         * @property {string}
         * Name of the log target, "Browser", "Database", etc...
         * If svmx-logging-preferences is in use then all targetNames come from that setting.
         * Otherwise, target names can be assigned as part of the subclass definition.
         * The target name simply identifies this logger instance.
         */
        targetName: "",

        /**
         * @property {boolean}
         * If true, then this logging target will be used to log if there is no svmx-logging-preferences setting
         * ANY use of svmx-logging-preferences will cause those settings and not this property to determine who
         * logs what.
         */
        isDefaultTarget: false,

        /**
         * @property {string}
         * One of ERROR, DEBUG, INFO, WARNING or NONE.
         * This value is only used if isDefaultTarget is true AND there is no svmx-logging-preferences setting.
         * Indicates the log level that will be logged.
         */
        defaultLogLevel: "ERROR",
        __constructor: function (options) {
            if (!options) options = {};
            this.targetName = options.targetName;

            // register with the logging service
            libServices.LoggingService.registerTarget(this);
        },

        log: function (message, options) {}

    }, {});


    /**
     * Default logging target. Logs to the browser console.
     *
     * @class           com.servicemax.client.lib.services.BrowserConsoleLogTarget
     * @extends         com.servicemax.client.lib.services.AbstractLogTarget
     *
     */
    libServices.Class("BrowserConsoleLogTarget", libServices.AbstractLogTarget, {
        isDefaultTarget: true,
        defaultLogLevel: "DEBUG",

        __constructor: function (options) {
            if (!options) options = {targetName: "Browser"};
            this.__base(options);
        },

        log: function (message, options) {
            var console = window.console;
            if (!console) return;

            var type = options.type;

            if (message instanceof Error) {
                message = message.stack ? message.stack.toString() : message.toString();
            }

            var msg = options.timeStamp + ": " + options.source + " " + message;

            if (type == "INFO" || type == "CRITICAL") console.info(msg);
            else if (type == "ERROR") console.error(msg);
            else if (type == "WARNING") console.warn(msg);
            else if (type == "DEBUG") {
                if (console.debug) {
                    console.debug(msg);
                } else {
                    console.info("DEBUG=>INFO " + msg);
                }
            } else console.log(msg);
        }
    }, {});

    // As this is our Default Log Target until svmx-logging-preferences has specified otherwise, we need to create an instance of it.
    // Normally, Log Targets are created by the svmx-logging-preferences settings.
    new libServices.BrowserConsoleLogTarget({targetName: "Browser"});



    /**
     * The AlertLogTarget will present logged messages in the form of an obnoxious alert dialog.
     * Useful for really glaring errors that you want to be notified of without having to insert
     * alert code that might get checked in and irritate the rest of the developers (and perhaps users).
     * This log target was primarily added as an easy way of testing the Logging Targets, and
     * is not expected to receive much use.
     *
     * @class           com.servicemax.client.lib.services.AlertLogTarget
     * @extends         com.servicemax.client.lib.services.AbstractLogTarget
     *
     */
    libServices.Class("AlertLogTarget", libServices.AbstractLogTarget, {

        __constructor: function (options) {
            this.__base(options);
        },

        log: function (message, options) {
            var console = window.console;
            if (!console) return;

            var type = options.type;

            if (message instanceof Error) {
                message = message.stack ? message.stack.toString() : message.toString();
            }

            var msg = options.timeStamp + ": " + options.source + " " + message;
        alert(type + ": "+ msg);
        }

    }, {});



    /**
     * The logger API;
     *
     * This Logger class is really a Log Dispatcher that routes messages to the proper AbstractLogTarget subclass
     *
     * @class           com.servicemax.client.lib.services.Logger
     * @extends         com.servicemax.client.lib.api.Object
     *
     */
    libServices.Class("Logger", com.servicemax.client.lib.api.Object, {

    // LoggingService instance
        __parent: null,

    // Name of this logger "sfm-expressions"
        __source: "",

    // {targetName1: "ERROR", targetName2: "INFO", etc...}
    __targetSettings: null,

        __constructor: function (parent, source, targetSettings) {
            this.__parent = parent;
            this.__source = source;
        this.setTargetSettings(targetSettings);
        },

    /**
     * This method is currently called from core.js's run method, and is not expected to be
     * called from any other external point.
     *
     * @param {Object} A hash of settings: {targetName1: "ERROR", targetName2: "INFO", etc...}
     */
    setTargetSettings: function(targetSettings) {
        this.__targetSettings = targetSettings;
    },

        __shouldSkipLogging: function (type, target) {
            var ret = false,
                preferenceMap = {
                    "DEBUG": 5,
                    "INFO": 4,
                    "WARNING": 3,
                    "ERROR": 2,
            "CRITICAL": 1,
            "NONE": 0
                };
        var targetSetting = this.__targetSettings[target];
        if (!targetSetting) return true;

        var targetLevel = preferenceMap[targetSetting];
        var requestLevel = preferenceMap[type];

            if (targetLevel < requestLevel) {
                ret = true;
            }

            return ret;
        },

        getTimestamp: function () {
            return com.servicemax.client.lib.datetimeutils ? com.servicemax.client.lib.datetimeutils.DatetimeUtil.macroDrivenDatetime("Now") : new Date().toString();
        },

    /**
     * Logs the specified message at the "info" log level
     */
        info: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("INFO", t[i].targetName)) {
                    t[i].log(message, {
            type: "INFO",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        },

    /**
     * Logs the specified message at the "debug" log level
     */
        debug: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("DEBUG", t[i].targetName)) {
                    t[i].log(message, {
            type: "DEBUG",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        },

    /**
     * Logs the specified message at the "error" log level
     */
        error: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("ERROR", t[i].targetName)) {
                    t[i].log(message, {
            type: "ERROR",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        },

    /**
     * Logs the specified message at the "warning" log level
     */
        warning: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("WARNING", t[i].targetName)) {
                    t[i].log(message, {
            type: "WARNING",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        },

    /**
     * Same as warning
     */
        warn: function (message) {
            this.warning(message);
        },

    /**
     * Logs the specified message at the "critical" log level (not sure how well supported this is, and does not appear to get much use)
     */
        critical: function (message) {
            var t = this.__parent.getTargets(this.__targetSettings),
                stringObj = this.getTimestamp();

            for (var i = 0; i < t.length; i++) {
        if (!this.__shouldSkipLogging("CRITICAL", t[i].targetName)) {
                    t[i].log(message, {
            type: "CRITICAL",
            source: this.__source,
            timeStamp: stringObj
                    });
        }
            }
        }

    }, {});

    ////////////////////////////////// END - LOGGING /////////////////////////////

    ////////////////////////////////// RESOURCE LOADING //////////////////////////

    /**
     *
     * @class           com.servicemax.client.lib.services.ResourceLoaderEvent
     * @extends         com.servicemax.client.lib.api.Event
     */
    libServices.Class("ResourceLoaderEvent", com.servicemax.client.lib.api.Event, {
        __constructor: function (type, target, data) {
            this.__base(type, target, data);
        }
    }, {});

    /**
     *
     * @class           com.servicemax.client.lib.services.ResourceLoader
     * @extends         com.servicemax.client.lib.api.EventDispatcher
     *
     * @note
     * Supported events
     *<br> 01. LOAD_COMPLETE
     *<br> 02. LOAD_ERROR
     */
    libServices.Class("ResourceLoader", com.servicemax.client.lib.api.EventDispatcher, {

        __constructor: function () {
            this.__base();
        },

        loadAsync: function (options) {
            $.ajax({
                type: "GET",
                dataType: options.responseType,
                data: options.data,
                cache: options.cache,
                url: options.url,
                context: this,
                async: true,
                success: function (data, status, jqXhr) {
                    this._loadSuccess(data, status);
                },
                error: function (jqXhr, status, e) {
                    this._loadError(jqXhr, status, e);
                }
            });
        },

        _loadSuccess: function (data, status) {
            var rle = new libServices.ResourceLoaderEvent("LOAD_COMPLETE", this, data);
            this.triggerEvent(rle);
        },

        _loadError: function (jqXhr, status, e) {
            var rle = new libServices.ResourceLoaderEvent("LOAD_ERROR", this);
            this.triggerEvent(rle);
        }
    }, {});

    /**
     *
     * @class           com.servicemax.client.lib.services.ResourceLoaderService
     * @extends         com.servicemax.client.lib.api.Object
     *
     */
    libServices.Class("ResourceLoaderService", com.servicemax.client.lib.api.Object, {

        __constructor: function () {
            if (libServices.ResourceLoaderService.__instance != null)
                return libServices.ResourceLoaderService.__instance;

            libServices.ResourceLoaderService.__instance = this;
        },

        createResourceLoader: function () {
            // TODO: should create appropriate loader types -> local (for devices), remote (http for PCs)
            return new libServices.ResourceLoader();
        }

    }, {
        __instance: null,

        getInstance: function () {
            var ret = null;
            if (libServices.ResourceLoaderService.__instance == null) {
                ret = new libServices.ResourceLoaderService();
            } else {
                ret = libServices.ResourceLoaderService.__instance;
            }
            return ret;
        }
    });

    ////////////////////////////////// END - RESOURCE LOADING ////////////////////

})(jQuery);

// end of file