/**
 * This file needs a description
 * @class com.servicemax.client.sfmconsole.impl
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */
(function(){

	var consoleImpl = SVMX.Package("com.servicemax.client.sfmconsole.impl");
	var TS;
	consoleImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {

		__runMode : null,

		__constructor : function(){
			this.__base();
			this._logger = SVMX.getLoggingService().getLogger("CONSOLE-IMPL");

			// set up a static variable for global access
			consoleImpl.Module.instance = this;

			// set up the org namespace
			var ons = SVMX.getClient().getApplicationParameter("org-name-space");
			if(!ons || ons === "") ons = "SVMXC";

			SVMX.OrgNamespace = ons;
			// end set up namespace

			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
		},

		beforeInitialize : function(){
			com.servicemax.client.sfmconsole.utils.init();
			com.servicemax.client.sfmconsole.commands.init();
			com.servicemax.client.sfmconsole.expressionbridge.init();
			com.servicemax.client.sfmconsole.constants.init();
            com.servicemax.client.sfmconsole.engine.init();
		},

		initialize : function(){
            // Gets an empty dictionary so that TS is never null/undefined.
		    TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("IPAD");
			//if(this.__runMode == "CONSOLE") com.servicemax.client.sfmconsole.ui.api.init();
		},

		afterInitialize : function(){
			var serv = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.preferences").getInstance();
			serv.addPreferenceKey(com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING);
		}

	}, {

		instance : null
	});


	/**
	 * The Console Application; while the class name is "Application", this is just one possible
	 * instance of AbstractApplication which exists in the sfmconsole namespace.
	 *
	 * This application manages a set of "console applications" which are really just applets designed
	 * to run within this container.
	 * @class com.servicemax.client.sfmconsole.impl.Application
	 * @super com.servicemax.client.lib.api.AbstractApplication
	 */
	consoleImpl.Class("Application", com.servicemax.client.lib.api.AbstractApplication,{

		// Module instance
		__parent : null,
		__logger : null,
		__namedInstanceService  : null,

        //handle for to menu processor
        __menuProcessor: null,
        __menuflag: null,

		// State Handler; Currently manages turning on/off the busy indicator/spinning icon
		__applicationStateHandler : null,

		// Error Handler; Shows error messages
		__applicationErrorHandler : null,

		// Message Handler; Shows messages such as alerts
		__applicationMessageUIHandler : null,

		// Quick Message Handler; Shows a popup/toast message
		__applicationQuickMessageHandler : null,

		// Root container for showing all console applications; note that this is NOT the root container for sfmconsole itself.
		__consoleAppContainer : null,

		// Contains the configurations for each type of console app as specified in manifest.json
		// Hash indexed by Application Id.  Access this using getAppConfig method; do not access directly.
		__consoleAppConfigs : null,

		// Hash of running console apps indexed by Application Id (specified in manifest.json)
		// As there can be multiple apps of the same id, this hash may not contain ALL open console apps.
		// This is used primarily to determine if a Singleton console app of the specified Id has already been created
		// so we know whether to show it or create it.
		__runningConsoleAppsByAppId : null,

		// Hash of running console apps indexed by the Window Id (which is the Id of their Root Container).
		// Unlike __runningConsoleAppsByAppId this should always contain ALL running console apps.
		__runningConsoleAppsByWindowId : null,

		// The UserInfo structure used to identify the current user.  Only access this using getUserInfo().
		// TODO: Create a UserInfo class to represent this that makes all user info properties private
		__userInfo: null,

		// The Spinner widget for indicating something is loading
		// TODO: Hook this into the __applicationStateHandler unless sorting out the difference between this loader and "showLoadMask" suggests
		// that a different TODO item is needed.
		__initialLoader : null,

		// Hash used to insure that every window title and menu text is unique
		__windowTitles  : null,

        // Whatever notifications the UI Library has provided
        __notificationService : null,

        //USED TEMP FOR THE SWITCH TO UI MODULES - Tim
        __view : null,

		__constructor : function(){
			this.__parent = consoleImpl.Module.instance;
			this.__logger = this.__parent.getLogger();
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
            this.__notificationService = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.notifications");

			this.__windowTitles = {};
			this.__consoleAppConfigs = {};
			this.__runningConsoleAppsByAppId = {};
			this.__runningConsoleAppsByWindowId = {};
		},

		triggerEvent : function(e) {
			SVMX.getLoggingService().getLogger("SFMConsoleApplication").warn("SFMConsole event triggered: " + e.type);
			return this.__base(e);
		},

		beforeRun : function(options){
			// create the named default controller
			var ni = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance();

			// create the named default controller
			ni.createNamedInstanceAsync("CONTROLLER",{ handler : function(controller){
				// now create the named default model
				ni.createNamedInstanceAsync("MODEL",{ handler : function(model){
					controller.setModel(model);
					options.handler.call(options.context);
				}, context : this});

			}, context : this, additionalParams : { eventBus : this }});


			 ni.createNamedInstanceAsync("SFMCONSOLE.VIEW",{ handler : function(view){
				 this.__view = view;
			 }, context: this, additionalParams: {}});
		},

		run : function(){
			this.__logger.info("Application runMode is " + this.__runMode);
			this.__logger.info("Great to be standing on my own legs!");
			this.__logger.info("Caching is => " + SVMX.isCachingEnabled());

            this.__loadTags(SVMX.proxy(this, function() {
			    if(this.__runMode == "CONSOLE"){
                    this.__runConsole();
                } else {
    				this.__runEngine();
                }
			}));

            this.__discoverConsoleUserMenuItems();
		},

		__runConsole : function () {
				this.__runSync();
		},

        // WARNING: This call to loadTags, as currently implemented, needs to be able to access dictionary's for all modules.
        // TODO: Each module should localize its tooltip before sfmconsole ever sees it.
        __loadTags : function(callback){
            var client = SVMX.getClient();
            var declaration = client.getDeclaration("com.servicemax.client.sfmconsole.translation-tags");
            var definitions = client.getDefinitionsFor(declaration) || [];
            var configs = SVMX.array.map(definitions, function(d) {return d.config;});

            var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                        "SFMCONSOLE.RETRIEVE_DISPLAY_TAGS", this, {
                            request : {moduleIds : configs},
                            responder: SVMX.create("com.servicemax.client.sfmconsole.commands.RetrieveDisplayTagsResponder", this, callback)
                        }
            );
            this.triggerEvent(evt);
        },

        onRetrieveDisplayTags: function(translationService, errorMsg, callback) {
            TS = translationService.getDictionary("IPAD");

            var evt = SVMX.create("com.servicemax.client.lib.api.Event", "DISPLAY_TAGS_LOADED", this);
            SVMX.getClient().triggerEvent(evt);

            callback.call();
        },

        /*
         * Creates the User Context Menu NamedInstance;
         * on the callback it sorts the config menu items
         * then process the handler class
         */
        __discoverConsoleUserMenuItems: function() {
            var nis = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance();
            var that = this;

			// create the named default controller
			nis.createNamedInstanceAsync("CONSOLE_MENUITEMS", {
                handler : function(toolbar){
                    var config = toolbar.getMenuConfigItems();
                    //1 order
                    config.sort(function(a, b){
                        var ap = (a.priority) ? parseInt(a.priority):0;
                        var bp = (b.priority) ? parseInt(b.priority):0;
                        return (ap - bp);
                    });

                    that.__menuProcessor = config;
			    },
                context : this,
                additionalParams : {
                    application : this
                }
            });

            return this;
        },

        /*
         * Support to call the menu items in order; both sync and async
         *
         */
        __asyncForEach: function(array, fn, callback) {
            array = array.slice(0);

            function processOne() {
                var item = array.pop();

                fn(item, function(result) {
                    if(array.length > 0) {
                        setTimeout(processOne, 0); // schedule immediately
                    } else {
                        callback(); // Done!
                    }
                });
            }

            if(array.length > 0) {
                setTimeout(processOne, 0); // schedule immediately
            } else {
                callback(); // Done!
            }
        },

        /*
         *
         process menu as needed
         *
         */
        __processMenu: function(){
            var sfmconsole = this.__root;
            var config = this.__menuProcessor;

            /*sfmconsole.sfmconsoleusermenupanel.menu.items.each(function(item){
                item.destroy();
            });*/

            //2 process
            this.__asyncForEach(config,
                function(item, callback) {
                    item.processor.processMenuItem(sfmconsole, item, callback);
                },
                function() {
                    //alert("Done!");
                }
            );
        },

        /*
         * Load all configurations for all console apps from the manifest.json files.
         */
		__discoverConsoleApps : function(){
			var declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.consoleapp");
			var definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length === 0){
				this.__logger.error("No console apps defined.");
				return;
			}

			var discovered = [];
			for(var i=0;i<definitions.length;i++){
                var key = definitions[i].config.app.id;
                this.__consoleAppConfigs[key] = definitions[i].config;
                // If config tooltip is an array, then 0 is tag id and 1 is default text
                var tag = this.__consoleAppConfigs[key].tooltip;
                var tagId = (typeof tag === 'object') ? tag[0] : tag;
                var tagDefault = (typeof tag === 'object') ? tag[1] : tag;
                if(this.__consoleAppConfigs[key].discover) {
                    discovered.push(
                        {   weight : definitions[i].config.positionWeight,
                            context : this,"key":key,
                            iconClass : this.__consoleAppConfigs[key].icon['large-css-class'],
                            tooltip : TS.T(tagId, tagDefault)
                        });
                }
            }
			discovered.sort(function(a, b){return a.weight-b.weight;});
			for(var t=0;t<discovered.length;t++){
				if (discovered[t]) {
				    this.__root.addConsoleNavLaunchButton(
						discovered[t].context,
						discovered[t].key,
						discovered[t].iconClass,
						discovered[t].tooltip);
				}
			}
		},

		__buildRootContainer : function(){
			this.__root = this.__view.createComponent("ROOTCONTAINER", {
				renderTo : SVMX.getDisplayRootId(),
				console  : this
			});
		},

		/**
		 * Get the config data for the specified application id; config data is set via module.json file
		 * @param {string} appId
		 * @returns {Object} Application config data
		 */
		getAppConfig : function(appId) {
		    return this.__consoleAppConfigs[appId];
		},

       /**
        * Get the root container component for sfmconsole; this should contain everything within the application.
        */
		getRoot : function(){
			return this.__root;
		},

		/**
		 * Iterate over the console apps
		 * @param callback Your iterator function
		 * @param {AbstractConsoleApp} callback.consoleApp An AbstractConsoleApp instance
		 * @TODO: Might be handy to have an optional parameter of appId, and only call the callback on apps
		 * with that appId.
		 */
        forEachConsoleApp : function(callback) {
            SVMX.forEachProperty(this.__runningConsoleAppsByWindowId, function(inKey, inValue) {
                callback(inValue);
            });
        },

        /**
         * Returns the ConsoleApp that is currently showing
         * If we fail to find a current app, just return the configured start/home app.
         */
		getCurrentConsoleApp : function() {
			var result;
			this.forEachConsoleApp(function(consoleApp) {
				if (consoleApp.isShowing()) result = consoleApp;
			});
			if(!result){
				var startAppId = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start");
				result = this.findConsoleAppByAppId(startAppId);
			}
			return result;
		},

		/**
		 * Returns any console apps that have been instantiated with the specified appId (appId specified in module.json)
		 * @returns {Object} result
		 * @returns {Console} result.consoleAppInstance Instance of a console app
		 * @returns {Panel} result.consoleAppContainer Instance of the console app's Root Container
		 */
		findConsoleAppByAppId : function(appId) {
		    return this.__runningConsoleAppsByAppId[appId];
		},

		/**
		 * Returns any console apps that have been instantiated with the specified ComponentId/upi
		 * @returns {Object} result
		 * @returns {Console} result.consoleAppInstance Instance of a console app
		 * @returns {Panel} result.consoleAppContainer Instance of the console app's Root Container
		 */
		findConsoleAppByWindowId : function(appId) {
		    return this.__runningConsoleAppsByWindowId[appId];
		},

		/**
		 * Use this to show a console app that has previously been created.
		 * While launchConsoleApp can detect if a given console app has already been created and show it,
		 * this only works well for cases where a given console app can have only a single instance.
		 * @param {Console} windowId ID of the window/console app instance to be shown
		 */
		showConsoleApp : function(windowId) {
		    this.hideSpinner();
		    this.__hideAllAppWindows();
		    var consoleAppInstance = this.findConsoleAppByWindowId(windowId);
		    consoleAppInstance.show();
		},

		/**
		 * Use this to instantiate a console app if needed and then show it.
		 * If needed means that it can detect if a Singleton console app has previously been created
		 * or not and instantiate it when needed.  If the app is NOT a singleton console app (sfmdelivery)
		 * this will not detect if its already been created, and will always create a new one.
		 * @param {String} consoleAppId Id specified for the app in its manifest.json file
		 * @param {Object} [Options] Not sure if this should ever be used.
		 */
		launchConsoleApp : function (consoleAppId, options) {
			options = options || {};
			// The lastOpener lets us determine which console app to show if/when the new console app is closed.
			// Only used when creating a new console app.
			var lastOpenerApp = this.getCurrentConsoleApp();
			var lastOpener = lastOpenerApp ? lastOpenerApp.getId() : null;

			// Clean up the UI prior to showing a new app.
			this.hideSpinner();
			this.__hideAllAppWindows();

            // Get the configuration for the requested application (module.json)
            var appConfig = this.getAppConfig(consoleAppId);
            var isSingleton = appConfig ? !appConfig.multiple : false;

            // Find out if that app has already been created (not too useful if its not a singleton)
			var consoleAppInstance = this.findConsoleAppByAppId(consoleAppId);

            // If the appConfig doesn't exist, then the consoleAppId is invalid.
            if (!appConfig) {
                this.__logger.error("Console App Not Defined: " + consoleAppId);
            }

            // If its a singleton and previously created, just show it.
			else if(isSingleton && consoleAppInstance) {
                this.__logger.info("Instance of App '" + consoleAppId + "' already running, showing...");
                this.showConsoleApp(consoleAppInstance.getId());
			}

			// Else create a new console app
			else {
				options.isClosable = !isSingleton;

				try {

					var consoleAppInstance = SVMX.create(
					    this.getAppConfig(consoleAppId).app["class-name"],
					    {
					        parent: this,
						    rootContainer: this.__root,
						    appConfig: this.getAppConfig(consoleAppId),
						    opener: lastOpener,
						    options: options
						}
					);

					// Index console app instance
					this.__runningConsoleAppsByAppId[consoleAppInstance.getAppTypeId()] = consoleAppInstance;
					this.__runningConsoleAppsByWindowId[consoleAppInstance.getId()] = consoleAppInstance;

					options.context = this;
					consoleAppInstance.show();
					consoleAppInstance.start(options);
				} catch (err) {
					this.__logger.error(err);
					return false;
				}
			}
		},

		closeClosableApps : function() {
			var me = this;
			this.forEachConsoleApp(function(consoleApp){
				if(consoleApp.__appConfig.multiple) me.destroyConsoleApp (consoleApp);
			});
		},

        applyAppInfo : function(consoleAppInstance) {
            this.__deregisterWindowTitle(consoleAppInstance);
		    var titleText = this.__getWindowTitle(consoleAppInstance, consoleAppInstance.getWindowTitle());
			consoleAppInstance.setTitle(titleText);
			var appConfig = consoleAppInstance.getAppConfig();
			var isSingleton = consoleAppInstance.isSingleton();

			// TODO: In theory, we should use something like appConfig.discover, and any
			// console app that is not discoverable gets shown in the process menu.
			// But before we do that, we'd need to be able to handle exceptions such as the SyncApp,
			// which is not discoverable, but which isn't intended to be shown in the menu.
			if(!isSingleton) {
				this.__addProcessToMenu(consoleAppInstance);
			}
        },

		__addProcessToMenu	: function (consoleAppInstance) {
			this.__root.addProcessMenuItem(consoleAppInstance);
		},

		__deregisterWindowTitle : function(consoleAppInstance) {
		     var id = consoleAppInstance.getId();
		     SVMX.forEachProperty(this.__windowTitles, SVMX.proxy(this, function(inKey, inValue) {
		         if (inValue == id) delete this.__windowTitles[inKey];
		     }));
		},

		__getWindowTitle : function(consoleAppInstance, text) {
		    var menuText = text;
		    for (var i = 0; i < 100; i++) {
			    if (!this.__windowTitles[menuText]) break;
			    menuText = text + " (" + (i+1) +")";
			}
			this.__windowTitles[menuText] = consoleAppInstance.getId();
			return menuText;
		},

		__getSyncImpl : function() {
			if(!this.__syncImpl){
				var declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.synchronizer");
				var definitions = SVMX.getClient().getDefinitionsFor(declaration);
				if(definitions.length === 0){
					this.__logger.error('Unable to load console synchronizer');
					return;
				}

				var className = definitions[0].config.impl['class-name'];
				this.__syncImpl = SVMX.create(className, this);
			}
			return this.__syncImpl;
		},

		getSyncImpl : function(){
			return this.__syncImpl;
		},

		__runSync : function(){

			if(SVMX.getClient().getApplicationParameter("sfmconsole-skip-sync")){
				return this.__syncCompleted();
			}

			this.showSpinner();

			this.__getSyncImpl().run({
				handler : this.__syncCompleted, context : this
			});
		},


        changeApplicationState : function(request) {
            switch(request.state) {
                case "BLOCK":
                    this.showSpinner();
                    break;
                case "UNBLOCK":
                    this.hideSpinner();
                    break;
            }
        },

		/**
		 * Shows a spinner over the page
		 */
		showSpinner : function(optionalTarget) {
		    if (this.__notificationService) {
                this.__notificationService.waitingMessage(optionalTarget);
            } else {
                this.__logger.error("showSpinner failed because there is no notification service");
            }
		},

		/**
		 * Hides the spinner shown with showSpinner
		 */
		hideSpinner : function() {
		    if (this.__notificationService) {
                this.__notificationService.endWaitingMessage();
            }
		},
		runManualSyncBackground : function () {
			this.__getSyncImpl().performSync("INCREMENTAL");
		},

		// TODO: Dependencies on Ext should be moved to ui/api.js
		showSyncUI : function () {
			if(Ext.getCmp("syncWindow")){
				Ext.getCmp("syncWindow").show();
				Ext.getCmp("subPanel").hide();
			}
		},

        /*
         * Boon: added  __discoverConsoleUserMenuItems
         */
		__syncCompleted : function(lastSync){
            var that = this;

            var f = SVMX.proxy(this, function() {
               	this.__userInfo = lastSync.user;
    			this.__buildRootContainer();
    			this.__root.setUserInfo(this.getUserInfo());
    			this.__discoverConsoleApps();
    			this.__openFirstConsoleApp();
    			this.__startIncrementalReSync();

                var menutoolbar = this.__root.sfmconsoleusermenupanel;

                this.__menuflag = true;
                //bind a click event to the console
                menutoolbar.on({
                    mouseover: function(){
                        if (that.__menuflag) {
                            that.__processMenu();
                            that.__menuflag = false;
                        }
                    }
                });

                menutoolbar.menu.on({
                    click: function(menu){
                        //remove
                        //1) remove the menu items
                        menu.items.each(function(item){
                            item.destroy();
                        });

                        menu.hide();
                        that.__menuflag = true;

                    }
                });

    		});

            if (TS.isEmpty()) {
    			this.__loadTags(SVMX.proxy(this, function() {
                    f();
        		}));
        	} else {
        	    f();
        	}
       },

		/**
		 * @method getUserInfo
		 * Returns the userInfo object as a readonly object
		 * Insures readonly by returning a clone of the object rather than the original object
		 */
	    getUserInfo : function() {
	       return SVMX.cloneObject(this.__userInfo) || {};
	    },

	    setUserInfo : function(userInfo) {
	    	this.__userInfo = userInfo;

			//check the data structure for TimeZone attribute
            if (this.__userInfo.TimezoneOffset === undefined) {
                //set to local timezone
                var timeZoneDate = new Date();
                this.__userInfo.TimezoneOffset =  (timeZoneDate.getTimezoneOffset() / 60) * -1;
            }

            // Setup the datetimeutils constants
	    	var DatetimeUtils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
	    	DatetimeUtils.setTimezoneOffset(userInfo.TimezoneOffset);
            DatetimeUtils.setDateFormat(userInfo.DateFormat);
            DatetimeUtils.setTimeFormat(userInfo.TimeFormat);

            var evtUserInfo = SVMX.create("com.servicemax.client.lib.api.Event",
	         							  "GLOBAL.HANDLE_USER_INFO", this, userInfo);
	        SVMX.getClient().triggerEvent(evtUserInfo);
	    },

	    /**
	     * Close a console app.  This represents a request from someone other than the app itself to close the console
	     * app, which must first be passed by the console app itself to verify that it can safely be closed.
	     * @param {Object} options
	     * TODO: Document what the options are
	     */
		closeConsoleApp : function(consoleAppInstance){
			if(consoleAppInstance){
				consoleAppInstance.onCanClose(SVMX.proxy(this, function(canClose){
					if(canClose === true) this.destroyConsoleApp(consoleAppInstance);
				}));
			}
		},

		// TODO: If this is a public method, document what are the options
		destroyConsoleApp : function(consoleAppInstance) {
		    if (consoleAppInstance) {
			   consoleAppInstance.onClose();
			   delete this.__windowTitles[consoleAppInstance.getTitle()];
			   delete this.__runningConsoleAppsByWindowId[consoleAppInstance.getId()];
			   if (this.__runningConsoleAppsByAppId[consoleAppInstance.getAppTypeId()] == this) {
			       delete this.__runningConsoleAppsByWindowId[consoleAppInstance.getAppTypeId()];
			   }
               this.__root.manageConsoleAppContainerClose(consoleAppInstance);
               consoleAppInstance.destroy();
            }
		},

		__openFirstConsoleApp : function () {
			var consoleAppId = (SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start") || null);
			if(!consoleAppId || consoleAppId === ""){
				this.__logger.error("sfmconsole-runtime-start is not set in application config.");
				return false;
			}
			this.launchConsoleApp(consoleAppId,{});
		},

		__hideConsoleApp : function(consoleAppInstance) {
			consoleAppInstance.hide();
		},

		__hideAllAppWindows : function () {
		    var currentConsoleApp = this.getCurrentConsoleApp();
		    if (currentConsoleApp && currentConsoleApp.isShowing()) {
				this.__hideConsoleApp(currentConsoleApp);
			}
		},

		__startIncrementalReSync : function(){
			if(this.__userInfo && this.__userInfo.reSync){
				this.runManualSyncBackground();
			}
		},

		// TODO: What is difference between this and __initialLoader?
		showLoadMask : function(loadMaskTarget){
			this.__root.showLoading(loadMaskTarget);
		},

		hideLoadMask : function() {
			this.__root.hideLoading();
		},


		__appShow : function(consoleAppInstance) {
			this.__root.showApp(this.__consoleAppContainer);
		},

		__appHide : function(consoleAppInstance) {
			this.__root.hideApp(this.__consoleAppContainer);
		},

		// TODO: This does not appear to be called; clean this up.
		consoleResizeApp : function(consoleAppInstance) {
			this.__root.resizeApp(this.__consoleAppContainer);
		},

		__runEngine : function(){
			var client = SVMX.getClient();

			// set up the application title
			SVMX.setWindowTitle(client.getApplicationTitle());

			// look for the content providers
			// right now, only sfm delivery engine
			var declaration = client.getDeclaration("com.servicemax.client.sfmconsole.deliveryengine");
			var definitions = client.getDefinitionsFor(declaration);

			var sfmdefinition = null;
			var preferEngineId = SVMX.getClient().getApplicationParameter('sfmconsole-engine-id');
			if(preferEngineId){
				for(var i = 0; i < definitions.length; i++){
					if(preferEngineId == definitions[i].config.engine.id){
						sfmdefinition = definitions[i];
						break;
					}
				}
			}else{
				sfmdefinition = definitions[0];
			}
			if(sfmdefinition === null){
				this.__logger.error("Cannot find any delivery engines." + (preferEngineId && "("+preferEngineId+")"));
				return;
			}

			var engineConfig = sfmdefinition.config.engine;
			var engineClassName = engineConfig["class-name"];

			sfmdefinition.createInstanceAsync(engineClassName, {handler : function(engine){

				// initialize the engine
				engine.initAsync({handler : function(){
					// start the engine
					engine.run({});

				}, context : this});

			}, context : this});
		},

		setApplicationStateHandler : function(stateHandler){

			// set up the application state handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application UI state will
			// be managed by SFMConsole itself.
			this.__applicationStateHandler = stateHandler;
		},

		getApplicationStateHandler : function(){
			return this.__applicationStateHandler || this;
		},

		setApplicationErrorHandler : function(errorHandler){

			// set up the application error handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application errors will
			// be managed by SFMConsole itself.
			this.__applicationErrorHandler = errorHandler;
		},

		getApplicationErrorHandler : function(){
			return this.__applicationErrorHandler || this;
		},

		setApplicationMessageUIHandler : function(messageUIHandler){

			// set up the application message UI handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application message UI will
			// be managed by SFMConsole itself.
			this.__applicationMessageUIHandler = messageUIHandler;
		},

		getApplicationMessageUIHandler : function(){
			return this.__applicationMessageUIHandler || this;
		},

		setApplicationQuickMessageHandler : function(quickMessageUIHandler){

			// set up the application quick message handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application quick messages will
			// be managed by SFMConsole itself.
			this.__applicationQuickMessageHandler = quickMessageUIHandler;
		},

		getApplicationQuickMessageHandler : function(){
			return this.__applicationQuickMessageHandler || this;
		},


		showQuickMessage : function(message, duration, type){
			if (this.__notificationService) {
                this.__notificationService.quickMessage(message, duration, type);
            } else {
                this.__logger.error("showQuickMessage failed because there is no notification service");
            }
		},

		notifyApplicationError : function(error){
			if (this.__notificationService) {
                var title = TS.T("IPAD018_TAG007","Error Message");
                this.__notificationService.errorMessage(error, title);
            } else {
                this.__logger.error("notifyApplicationError failed because there is no notification service");
            }
		},

		/**
		 * Supports default and custom messages
		 *
		 * @param {Object} options
		 * options.type: QUESTION, WARN, ERROR, INFO, CUSTOM
		 * options.text
		 * options.buttons Array of ["OK", "CANCEL", "YES", "NO"]
		 */
		showMessage : function(options){
			if (this.__notificationService) {
                if (!options.title) {
                    options.title = TS.T("SFMDELIVERY.SFM002_TAG099", "Information");
                }
                this.__notificationService.showMessage(options);
            } else {
                this.__logger.error("showMessage failed because there is no notification service");
            }
		}
	},{});

	consoleImpl.Class("CompositionEngine", com.servicemax.client.lib.api.Object,{
		__metamodel : null, __parent : null,

		__constructor : function(metamodel, parent){
			this.__metamodel = metamodel;
			this.__parent = parent;
		},

		compose : function(){
			var composition = this.__parent.__self.composition;
			return this.__composeInternal(this.__metamodel, composition, this.__parent);
		},

		__composeInternal : function(metamodel, composition, parent){
			var length = composition.length, i;
			for(i = 0; i < length; i++){
				var compositionItem = composition[i];
				var compositionMetamodel = metamodel.getChildNode(compositionItem.name);

				if(compositionMetamodel){
					var compositionItemObj = null,
						compositionItemClass = compositionItem.className;

					if(compositionMetamodel instanceof Array === false){
						compositionMetamodel = [compositionMetamodel];
					}
					var compositionMetamodelLength = compositionMetamodel.length, j, compositionMetamodelItem;
					for(j = 0; j < compositionMetamodelLength; j++){
						compositionMetamodelItem = compositionMetamodel[j];
						compositionItemObj = SVMX.create(compositionItemClass, {compositionMetamodel : compositionMetamodelItem});
						if(compositionItemObj.__self.composition !== undefined){
							this.__composeInternal(compositionMetamodelItem, compositionItemObj.__self.composition, compositionItemObj);
						}
						parent.onCompositionChildCreate(compositionItemObj, compositionItem.name);
					}
				}
			}
		}
	}, {});

})();