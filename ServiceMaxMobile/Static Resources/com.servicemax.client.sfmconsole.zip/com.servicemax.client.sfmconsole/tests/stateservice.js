
var stateService;

QUnit.module("StateManager", {
    setup: function() {
        stateService = SVMX.create('com.servicemax.client.sfmconsole.utils.StateService');
    },
    teardown: function() {
        stateService = null;
    }
});

test("__constructor()", function() {
    equal(stateService.getState(), undefined, 'State stack');
    equal(stateService.getIndex(), 0, 'State index');
});

test("pushState()", function() {
    var state = stateService.pushState({
        title: "test",
        subtitle: "subtest"
    });
    equal(state && state.title, "test", 'State property');
});

test("replaceState()", function() {
    stateService.pushState({
        title: "test1"
    });
    var state = stateService.replaceState({
        title: "test2"
    });
    equal(state && state.title, "test2", 'State property');
    equal(state && state.index, 0, 'State index');
});

test("modifyState()", function() {
    stateService.pushState({
        title: "test1"
    });
    var state = stateService.modifyState({
        title: "test2"
    });
    equal(state && state.title, "test2", 'State property');
    equal(state && state.index, 0, 'State index');
});

test("getState()", function() {
    stateService.pushState({
        title: "test",
        subtitle: "subtest"
    });
    var state = stateService.getState();
    equal(state && state.title, "test", 'State property');
});

test("getIndex()", function() {
    stateService.pushState({
        title: "test",
        subtitle: "subtest"
    });
    var state = stateService.getState();
    equal(stateService.getIndex(), 0, 'State index');
    equal(state && state.index, 0, 'State index property');
});

test("back()", function() {
    stateService.pushState({
        title: "test"
    });
    stateService.pushState({
        title: "test2"
    });
    stateService.back();
    equal(stateService.getIndex(), 0, 'State index');
});

test("forward()", function() {
    stateService.pushState({
        title: "test"
    });
    stateService.pushState({
        title: "test2"
    });
    stateService.back();
    stateService.forward();
    equal(stateService.getIndex(), 1, 'State index');
});

test("go()", function() {
    stateService.pushState({
        title: "test"
    });
    stateService.pushState({
        title: "test2"
    });
    stateService.go(-1);
    equal(stateService.getIndex(), 0, 'State index');
});

/* This test has problems
asyncTest("triggerStateChange()", function() {
    expect(2);
    stateService.bind("STATE_CHANGE", function(evt){
        var state = evt && evt.data || {};
        equal(state && state.index, 0, 'State index property');
        equal(state && state.title, "test", 'State title property');
        start();
    });
    stateService.pushState({
        title: "test"
    });
});
*/