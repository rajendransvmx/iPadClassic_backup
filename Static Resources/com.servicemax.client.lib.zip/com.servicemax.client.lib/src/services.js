(function($){
	
	var libServices = SVMX.Package("com.servicemax.client.lib.services");
	
	////////////////////////////////// LOGGING /////////////////////////////
	
	/**
	 * Log target API
	 */
	libServices.Class("AbsractLogTarget", com.servicemax.client.lib.api.Object, {
		
		__constructor : function(options){
			
			// register with the logging service
			libServices.LoggingService.getInstance().registerTarget(this, options);
		},
		
		log : function(message, options){}
		
	}, {});
	
	/**
	 * default logging target. logs to the browser console
	 */
	libServices.Class("BrowserConsoleLogTarget", libServices.AbsractLogTarget, {
		
		__constructor : function(options){
			this.__base(options);
		},
		
		log : function(message, options){
			var console = window.console;
			if(!console) return;
			
			var type = options.type;
			
			if(message instanceof Error){
				message = message.stack ? message.stack.toString() : message.toString();
			}
			
			var msg = options.timeStamp + ": " + options.source + " " + message;
			
			if(type == "INFO" || type == "CRITICAL") console.info(msg);
			else if(type == "ERROR") console.error(msg);
			else if(type == "WARNING") console.warn(msg);
			else if(type == "DEBUG") { 
				if(console.debug) {
					console.debug(msg);
				}else{
					console.info("DEBUG=>INFO " + msg);
				}
			}
			else console.log(msg);
		}
		
	}, {});
	
	/**
	 * The central logging service
	 */
	libServices.Class("LoggingService", com.servicemax.client.lib.api.Object, {
		__loggers : null, __targets : null, __filter : null, __isFilterAplied : false,
		__filterPreference : null,
		
		__constructor : function(){
			if(libServices.LoggingService.__instance != null) 
				return libServices.LoggingService.__instance;
			
			libServices.LoggingService.__instance = this;
			
			// no special characters allowed for the logger source
			this.__loggers = {};
			
			//targets
			this.__targets = [];
			
			// set up the filter
			this.__filter = 'all';
			this.__filterPreference = {enabled : true, constraint : "DEBUG"};
			
			this__isFilterAplied = false;
		},
		
		setFilter : function(filter){
			if(this.__isFilterAplied){
				this.getLogger().critical("Error! Attempt to set up the logging filter more than once!");
				return;
			}
			
			this.__isFilterAplied = true;
			if(!filter.enabled){
				this.__filter = 'none';
				
				// update all loggers
				for(var source in this.__loggers)
					this.__loggers[source].setFilter(filter);
			}
		},
		
		setFilterPreference : function(filterPref){
			this.__filterPreference = filterPref;
			
			// update all loggers
			for(var source in this.__loggers)
				this.__loggers[source].setFilterPreference(filterPref);
		},
		
		getLogger : function(source){
			var ret = null;
			
			if(source == undefined || source == null) source = "SVMXCONSOLECORE";
			
			if(this.__loggers[source] == undefined){
				ret = new libServices.Logger(this, source, this.__filter, this.__filterPreference);
				this.__loggers[source] = ret;
			}else{
				ret = this.__loggers[source];
			}
			return ret;
		},
		
		registerTarget : function(target, options){
			this.__targets[this.__targets.length] = {target : target, options : options};
		},
		
		getTargets : function(){
			var ret = [];
			
			//TODO : apply filters
			for(var i = 0; i < this.__targets.length; i++){
				ret[i] = this.__targets[i].target;
			}
			return ret;
		}
		
	}, {
		__instance : null,
		
		getInstance : function(){
			var ret = null;
			if(libServices.LoggingService.__instance == null){
				ret = new libServices.LoggingService();
			}else{
				ret = libServices.LoggingService.__instance;
			}
			return ret;	
		}
	});
	
	/**
	 * The logger API
	 */
	libServices.Class("Logger", com.servicemax.client.lib.api.Object, {
		
		__parent : null, __source : "", __filter : "", __isFilterAplied : false,
		__filterPreference : null,
		
		__constructor : function(parent, source, filter, filterPref){
			this.__parent = parent;
			this.__source = source;
			this.__filter = filter;
			this.__isFilterAplied = false;
			this.__filterPreference = filterPref;
		},
		
		setFilter : function(filter){
			if(this.__isFilterAplied){
				this.critical("Error! Attempt to set up the logging filter more than once!");
				return;
			}
			
			this.__isFilterAplied = true;
			if(!filter.enabled){
				this.info("Disbaling logging on => " + this.__source);
				this.__filter = 'none';
			}
		},
		
		setFilterPreference : function(filter){
			this.critical("Setting logging preference on => " + this.__source + ", pref => " + SVMX.toJSON(filter));
			this.__filterPreference = filter;
		},
		
		__shouldSkipLogging : function(type){
			var ret = false, preferenceMap = {"DEBUG" : 4, "INFO" : 3, "WARNING" : 2, "ERROR" : 1};
			if(this.__filter == 'none' || !this.__filterPreference.enabled){
				ret = true;
			}else{
				if(preferenceMap[type] > preferenceMap[this.__filterPreference.constraint]){
					ret = true;
				}
			}
			
			return ret;
		},
		
		getTimestamp : function() {
			return com.servicemax.client.lib.datetimeutils.DatetimeUtil.macroDrivenDatetime("Now");
		},

		info    : function(message){
			if(this.__shouldSkipLogging("INFO")) return;
			
			var t = this.__parent.getTargets(), stringObj = this.getTimestamp();
			
			for(var i = 0; i < t.length; i++){
				t[i].log(message, {type : "INFO", source : this.__source, timeStamp :  stringObj});
			}
		},
		
		debug   : function(message){
			if(this.__shouldSkipLogging("DEBUG")) return;
			
			var t = this.__parent.getTargets(), stringObj = this.getTimestamp();
			
			for(var i = 0; i < t.length; i++){
				t[i].log(message, {type : "DEBUG", source : this.__source, timeStamp :  stringObj});
			}
		},
		
		error   : function(message){
			if(this.__shouldSkipLogging("ERROR")) return;
			
			var t = this.__parent.getTargets(), stringObj = this.getTimestamp();
			
			for(var i = 0; i < t.length; i++){
				t[i].log(message, {type : "ERROR", source : this.__source, timeStamp :  stringObj});
			}
		},
		
		warning : function(message){
			if(this.__shouldSkipLogging("WARNING")) return;
			
			var t = this.__parent.getTargets(), stringObj = this.getTimestamp();
			
			for(var i = 0; i < t.length; i++){
				t[i].log(message, {type : "WARNING", source : this.__source, timeStamp :  stringObj});
			}
		},
		
		warn : function(message){
			this.warning(message);
		},
		
		critical : function(message){
			var t = this.__parent.getTargets(), stringObj = this.getTimestamp();
			
			for(var i = 0; i < t.length; i++){
				t[i].log(message, {type : "CRITICAL", source : this.__source, timeStamp :  stringObj});
			}
		}
		
	}, {});
	
    ////////////////////////////////// END - LOGGING /////////////////////////////
	
	////////////////////////////////// RESOURCE LOADING //////////////////////////
	
	
	libServices.Class("ResourceLoaderEvent", com.servicemax.client.lib.api.Event, {
		__constructor : function(type, target, data) { this.__base(type, target, data); }
	}, {});
	
	/**
	 * Supported events
	 * 01. LOAD_COMPLETE
	 * 02. LOAD_ERROR
	 */
	libServices.Class("ResourceLoader", com.servicemax.client.lib.api.EventDispatcher, {
		
		__constructor : function(){
			this.__base();
		},
		
		loadAsync : function(options){
			$.ajax({type: "GET", 
					dataType: options.responseType, data: options.data, cache : options.cache,
					url: options.url, context: this, async: true,
					success: function(data, status, jqXhr) { this._loadSuccess(data, status); }, 
					error : function(jqXhr, status, e){this._loadError(jqXhr, status, e);} } );
		},
		
		_loadSuccess : function(data, status){
			var rle = new libServices.ResourceLoaderEvent("LOAD_COMPLETE", this, data);
			this.triggerEvent(rle);
		},
		
		_loadError : function(jqXhr, status, e){
			var rle = new libServices.ResourceLoaderEvent("LOAD_ERROR", this);
			this.triggerEvent(rle);
		}
	}, {});
	
	libServices.Class("ResourceLoaderService", com.servicemax.client.lib.api.Object, {

		__constructor : function(){
			if(libServices.ResourceLoaderService.__instance != null) 
				return libServices.ResourceLoaderService.__instance;
			
			libServices.ResourceLoaderService.__instance = this;
		},
		
		createResourceLoader : function(){
			// TODO: should create appropriate loader types -> local (for devices), remote (http for PCs)
			return new libServices.ResourceLoader();
		}
		
	}, {
		__instance : null,
		
		getInstance : function(){
			var ret = null;
			if(libServices.ResourceLoaderService.__instance == null){
				ret = new libServices.ResourceLoaderService();
			}else{
				ret = libServices.ResourceLoaderService.__instance;
			}
			return ret;	
		}
	});
	
	////////////////////////////////// END - RESOURCE LOADING ////////////////////
	
})(jQuery);

// end of file