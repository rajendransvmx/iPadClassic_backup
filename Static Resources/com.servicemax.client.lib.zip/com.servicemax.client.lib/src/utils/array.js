/**
 * @author: Michael Kantor
 * @copyright: ServiceMax, Inc
 * @since: The minimum version where this file is supported
 * @description: Array utilities support the following code:
 var arr = [{firstName: "Michael", lastName: "Kantor"}, {firstName: "Timothy", lastName: "Ashton"}, {firstName: "Eric", lastName: "Ingram"}, {firstName: "Vinod", lastName: "Kumar"}]

SVMX.array.indexOf(arr, arr[3]) -> 3
SVMX.array.indexOf(arr, function(inItem) {return inItem.firstName == "Michael"}) -> 0

if (SVMX.array.contains(arr, arr[3])) {
    ...
}

var firstNames = SVMX.array.map(arr, function(inItem) {return inItem.firstName}); -> ["Michael", "Timothy", "Eric", "Vinod"]

var haveLongNames = SVMX.array.filter(arr, function(inItem) {return inItem.firstName.length > 5}) -> 
[{firstName: "Michael", lastName: "Kantor"}, {firstName: "Timothy", lastName: "Ashton"}]

if (SVMX.array.every(arr, function(inItem) {return inItem.firstName.length > 5;})) {
    ....
}

SVMX.array.forEach(arr, function(inItem) {
    console.log(inItem.firstName);
})

SVMX.array.insert(arr, {firstName: "Indresh", lastname: ""}, 0) -> Indresh is first element in list

SVMX.array.removeElementAt(arr,0)  -> Indresh is removed

SVMX.array.remove(arr, arr[0]) -> Michael is removed

SVMX.array.remove(arr, function(inItem) {return inItem.firstName.length > 5;}, true) -> Removes all elements where first name is longer than 5 characters
 */

(function($){
	
	SVMX.array = {
			
			/* @param {Object[]|Value[]} inArray Array of objects or literals to search
			 * @param {Object|Value|Function} inValue Value to search for.  If value is a function, its treated as a callback 
			 *  							  that is used to evaluate whether an item is a match. Callback is function(inItem, inIndex)
			 * @param {Object} [inContext] If inValue is a function, can provide the function's "this" value.
			 * @returns {Number} -1 if not found, or the index of the element found. 
			 */
			indexOf: function(inArray, inValue, inContext) {
				if (!inArray || !inArray.length) return -1;
				var isFunc = typeof inValue === "function"
				if (isFunc && inContext) inValue = SVMX.proxy(inContext, inValue);

				if (Array.prototype.indexOf && !isFunc) {
					return inArray.indexOf(inValue);
				} else {
					for (var i = 0; i < inArray.length; i++) {
						if (isFunc) {
							if (inValue(inArray[i], i)) return i;
						} else if (inValue === inArray[i]) return i;
					}					
				}
				return -1;				
			},
			
			/* Useful for simple boolean if statements where indexOf is more clutter;
			 * @returns {Boolean} Returns true if inValue exists in inArray.
			 * If inValue is a function, returns true if the function evaluates to true for any item
			 * in the array.
			 */
			contains: function(inArray, inValue, inContext) {return SVMX.array.indexOf(inArray, inValue, inContext) != -1;},
			
			/* Maps one array to a second array.  Useful for transposing values, or extracting a field from every object
			 * in an array and storing it in a new array.  Callbacks are of the form function(inItem, inIndex)
			 * @param {Object[]|Value[]} inArray Array of objects or values
			 * @param {Function} inCallback Callback that takes as input an array element and returns a value for the new array
			 * @param {Object} [inContext] Optional context for inCallback
			 * @returns {Object[]|Value[]} a new array
			 */
			map: function(inArray, inCallback, inContext) {
				if (inContext) inCallback = SVMX.proxy(inContext, inCallback);
				return $.map(inArray, inCallback);
			},


			filter: function(inArray, inCallback, inContext) {
				if (inContext) inCallback = SVMX.proxy(inContext, inCallback);
				return $.grep(inArray, inCallback);
			},

			
			/* Used to test if something is true for every element of an array.  Callbacks are of the form function(inItem, inIndex)
			 * @param {Object[]|Value[]} inArray Array of objects or values
			 * @param {Function} inCallback Callback that takes as input an array element and returns a boolean
			 * @param {Object} [inContext] Optional context for inCallback
			 * @returns {Boolean} If inCallback returns false for any element of inArray, returns false, else returns true
			 */
			every: function(inArray, inCallback, inContext){
				if (!inArray || !inArray.length) return false;
				if (inContext) inCallback = SVMX.proxy(inContext, inCallback);
				for (var i = 0; i < inArray.length; i++) if (!inCallback(inArray[i], i)) return false;
				return true;
			},
			
			/* Used to iterate over every element of an array and call a function on each element.
			 * Its a good way to localize the scope for handling of each item.  Callbacks are of the form function(inItem, inIndex)
			 * @param {Array} inArray The array to iterate over
			 * @param {Function} inCallback Function to call on each item; of the forum function(inItem, inIndex)
			 * @param {Object} [inContext] Optional context for inCallback			 
			 * @param {null|Object} inContext Execute inCallback with inContext as the "this" value.
			 *
			 * NOTE: If callback returns false, forEach exits.  Treat this as your loop s"break".
			 */
			forEach: function(inArray, inCallback, inContext) {
				if (inContext) inCallback = SVMX.proxy(inContext, inCallback);
				for (var i = 0; i < inArray.length; i++) {
					var result = inCallback(inArray[i], i);
					if (result === false) return;
				}
			},

			/* I find this easier to remember than splice...
			* @param {Array} inArray Array to modify
			* @param {Value} inElement Value to insert
			* @param {Number} inIndex Position to insert the new value
			*/
			insert: function(inArray, inElement, inIndex) {
				inArray.splice(inIndex, 0, inElement);
			},

			/* I find this easier to remember than splice...
			* @param {Array} inArray Array to modify
			* @param {Number} inIndex Position to remove the value from
			*/
			removeElementAt: function(inArray, inIndex) {
				inArray.splice(inIndex,1);
			},

			/* More general remove method
			* @param {Array} inArray Array to modify
			* @param {Function|Value} inValue If its a function, then its treated a 
			*                         callback of the form function(inItem, inIndex) 
			*                         and if it returns a truthy value, element is removed.
			*                         If its a value, remove the first occurance of that value
			* @param {Boolean} removeAll Defaults to false; if true then will iterate over every 
			*                  item in your very long array and find and remove all matches.
			*                
			*/			
			remove: function(inArray, inValue, removeAll) {
				var isFunc = typeof inValue === "function"
				for (var i = inArray.length - 1; i >= 0; i--) {
					var value = inArray[i];
					var isMatch = isFunc ? inValue(value,i) : value === inValue;
					if (isMatch) {
						SVMX.array.removeElementAt(inArray, i);
						if (!removeAll) return value;
					}
				}								
			}			
	};
})(jQuery);
