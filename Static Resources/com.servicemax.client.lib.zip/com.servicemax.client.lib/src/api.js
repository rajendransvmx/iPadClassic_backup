(function($){
	
	var libApi = SVMX.Package("com.servicemax.client.lib.api");
	
	/**
	 * Base class for all the client side classes
	 */
	libApi.Class("Object", {
		__constructor : function() {},
		
		/**
		 * The toString() method overrides the native toString method, and allows us to represent objects
		 * within the debugger for easy interpretation.  Main use case: Identifying the type of an object
		 * and especially, managing an array or hash of objects and knowing what the contents are.
		 * NOTE: While FireFox automatically represents all objects in its debugger using toString(), WebKit
		 * does not; use instead the watch panel and add "this.toString()".
		 * 
		 * Individual classes can override toString and pass a description up to the parent method.
		 * 
		 * toString method for Sencha objects is set in com.servicemax.client.ui.components.impl
		 */
		getClassName : function() {return this.constructor.__className || "unknown";},
		toString : function(description) {
			var shortClassName = this.getClassName().replace(/^com\.servicemax\.client\./, "client.");
			description = description ? " " + description : "";
			return shortClassName +  (description ? " (" + description + ")" : "");
		}
	}, {});
	
	/**
	 * The event base class
	 */
	libApi.Class("Event", com.servicemax.client.lib.api.Object, {
		
		type : null, target : null, data : null,
		__constructor : function(type, target, data){
			this.type = type; this.target = target; this.data = data;
		}
	
	}, {});

	/**
	 * Base classes for all those classes which want to be an event source
	 */
	libApi.Class("EventDispatcher", libApi.Object, {
		
		eventHandlers : [], 
		
		__constructor : function() { this.eventHandlers = []; },
		
		bind : function (type, handler, context) {
			this.eventHandlers[this.eventHandlers.length] = { type:type, handler:handler, context:context };
		},
			
		unbind : function(type, handler, context) {
			for (var i = 0; i < this.eventHandlers.length; i++) {
				if(this.eventHandlers[i].handler == handler && this.eventHandlers[i].type == type){
					this.eventHandlers.splice(i, 1);
				}
			}
		},
			
		triggerEvent : function(e) {
			for(var i = 0; i < this.eventHandlers.length; i++){
				if(this.eventHandlers[i].type == e.type) {
					if(this.eventHandlers[i].context){
						this.eventHandlers[i].handler.call(this.eventHandlers[i].context, e);
					}else{
						this.eventHandlers[i].handler(e);
					}
				}
			}
		}
		
	}, {});
	
	/**
	 * The base module API, which is an entry point to all the modules. All the modules should implement
	 * a class by deriving from this class.
	 */
	libApi.Class("ModuleActivator", libApi.Object, {
		_logger : null, _module : null,
		__constructor : function() {},
		
		beforeInitialize : function(){},
		initialize : function(){},
		afterInitialize : function(){},
		
		setModule : function(value){ this._module = value; },
		getModule : function() { return this._module; },
		getLogger : function(){ return this._logger; },
		getResourceUrl : function(path){ return this._module.getResourceUrl(path); }
	}, {});
	
	/**
	 * The application API
	 */
	libApi.Class("AbstractApplication", libApi.EventDispatcher, {
		
		__constructor : function() { this.__base(); },
		
		beforeRun : function(options){ options.handler.call(options.context); },
		run : function(){}
		
	}, {
		currentApp : null
	});
	
	//////////////////////////////////////////
	
	// Set of utility classes which helps in inter-class communication (based on design patterns). 
	// The candidate who can use these classes include;
	//     01. MVC implementations
	//     02. Call back handlers
	
	/**
	 * The command class
	 */
	libApi.Class("AbstractCommand", libApi.Object, {
		
		__constructor : function(){ },
		executeAsync : function(request, responder) { }
	
	}, {});
	
	/**
	 * The operation class
	 */
	libApi.Class("AbstractOperation", libApi.Object, {
		
		__constructor : function() { },
		performAsync : function(request, responder) { }
		
	}, {});
	
	/**
	 * The responder class
	 */
	libApi.Class("AbstractResponder", libApi.Object, {
		
		__constructor : function() { },
		result : function(data) { },
		fault : function(data) { }
	}, {});


	/**
	 * Generic extension class
	 */
	libApi.Class("AbstractExtension", com.servicemax.client.lib.api.Object, {
		perform : function(caller, onComplete){}
	}, {});

	/* Create an instance of this to quickly/easily run all extensions of the given
	 * name.  NOTE: Will execute extensions serially.  TODO: some extensions that
	 * make web reqeusts may want to specify execution in parallel.
	 * TODO: Any extension that does not depend upon other extensions shoul be run
	 * in parallel instead of serially.
	 */	
	libApi.Class("ExtensionRunner", com.servicemax.client.lib.api.Object, {
		__caller: null, 
		__extensionName: null,
		__onComplete: null,
		__constructor : function(caller, extensionName) {
			this.__caller = caller;
			this.__extensionName = extensionName
		},
		perform : function(onComplete) {
			var client = SVMX.getClient();
			// TODO: should extensions only be called after a particular sync type is called?
			var declaration = client.getDeclaration("com.servicemax.client.extension");
			if (!declaration) return onComplete ? onComplete() : null;
			var definitions = client.getDefinitionsFor(declaration);
			var extensionName = this.__extensionName;
			definitions = SVMX.array.filter(definitions, function(def) {return def.config["event"] === extensionName;});
			var remainingCount = definitions.length;
			if (remainingCount === 0) return onComplete ? onComplete() : null;

			var onDone = SVMX.proxy(this, function() {
				remainingCount--;
				if (remainingCount === 0 && onComplete) onComplete();
			});

			for (var i = 0; i < definitions.length; i++) {
				var definition = definitions[i];
				var extClassName = definition.config['class-name'];
				var extClass = SVMX.create(extClassName);

				// NOTE: try/catch block can't catch async errors;
				// The Extension must use its callback in an error handler!
				try {
					extClass.perform(this.__caller, onDone);
				} catch(e) {					
				}
			}
		}
	},
	// STATIC METHODS
	{
		run : function(inCaller, inName, onDone) {
			var extensionRunner = new com.servicemax.client.lib.api.ExtensionRunner(inCaller, inName);
			extensionRunner.perform(onDone);
		}
	});
	//////////////// end of utility classes ////////////////
	
})(jQuery);

// end of file