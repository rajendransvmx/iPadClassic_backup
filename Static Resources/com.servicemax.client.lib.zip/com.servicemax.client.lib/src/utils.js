
/**
 * Contains utility methods
 */

(function($){
	var packageCount = 0, classCount = 0;
	
	var SVMX = {
			
		// to create package
		Package : function(name){
			var arr = name.split(".");
			var fn = (window || this);
			for (var i = 0, len = arr.length; i < len; i++) {
				if(!fn[arr[i]]) fn[arr[i]] = {};
				
				fn =fn[arr[i]];
			}
			
			fn.name = name;
			
			// to create class declaration
			fn.Class = function(name, baseCls, instanceProps, staticProps){
				
				var cls = $.inherit(baseCls, instanceProps, staticProps);
				cls.__className = name;
				this[name] = cls;
				cls.name = this.name + ":" + name;
				classCount++;
				return cls;
			};
			
			packageCount++;
			
			return fn; 
		}
	};
	
	SVMX.getPackageCount = function(){
		return packageCount;
	};
	
	SVMX.getClassCount = function(){
		return classCount;
	};
	
	SVMX.stringEndsWith = function(str, suffix){
		var ret = false;
		if(str && str.length > 0){
			ret = ( str.indexOf(suffix, str.length - suffix.length) !== -1 );
		}
		return ret;
	};
	
	SVMX.string = {};
	SVMX.string.capitalize = function(str) {
		return str[0].toUpperCase() + str.substring(1);
	};
	
	SVMX.string.camelCase = function(str) {
  		return str.replace(/_[a-zA-Z]/g, function(inStr) {return inStr.substring(1).toUpperCase();});
 	};
	
	// "Showing message {{current}} of {{total}}"
	SVMX.string.substitute = function(inString, inObject) {
		if (!inObject) inObject = {};
		return String(inString).replace(/\{\{.*?\}\}/g, function(inTerm) {
			inTerm = inTerm.substring(2, inTerm.length-2);
			return inObject[inTerm] || "";
		});
	};

	SVMX.forEachProperty = function(inObject, inFunc, inContext) {
		if (inContext) inFunc = SVMX.proxy(inContext, inFunc);
		for (key in inObject) {
			if (inObject.hasOwnProperty(key)) {
				inFunc(key, inObject[key]);
			}
		}
	};

	SVMX.isPlatform = function(plaformName){
		var ret = true;
		try{
			ret = navigator.platform.slice(0, plaformName.length) == plaformName;
		}catch(e){
			SVMX.getLoggingService().getLogger().error("Cannot detect the platform! " + e);
		}
		return ret;
	};
	
	SVMX.cloneObject = function(obj){
		return SVMX.toObject(SVMX.toJSON(obj));
	};
	
	SVMX.write = function(content) {
        document.write(content);
    };

	SVMX.meta = function(name, content) {
		SVMX.write('<meta name="' + name + '" content="' + content + '">');
    };
    
	SVMX.getLoggingService = function(){
		return com.servicemax.client.lib.services.LoggingService.getInstance();
	};
	
	SVMX.getClient = function(){
		return com.servicemax.client.lib.core.Client.getInstance();
	};
	
	SVMX.getCurrentApplication = function(){
		return com.servicemax.client.lib.api.AbstractApplication.currentApp;
	};
	
	var __GUID__ = 0;
	SVMX.generateGUID = function(){
		// TODO: need a better way to generate GUIDs.
		return ++__GUID__;
	};
	
	var __SVMX_CREATE_HELPERS__ = [];
	SVMX.registerCreateHelper = function(forPackage, helper, context, options){
		__SVMX_CREATE_HELPERS__[__SVMX_CREATE_HELPERS__.length] = 
				{forPackage : forPackage, helper : helper, context : context, options : options};
	};
	
	SVMX.getCreateHepler = function(fullClassName){
		var pkgEndIndex = fullClassName.lastIndexOf(".");
		
		if(pkgEndIndex < 0) return null;
		
		var pkg = fullClassName.substring(0, pkgEndIndex);
		var i, l = __SVMX_CREATE_HELPERS__.length;
		for(i = 0; i < l; i++){
			var helper = __SVMX_CREATE_HELPERS__[i];
			if(helper.forPackage.indexOf(pkg) == 0){
				return helper;
			}
		}
		
		return null;
	};
	
	SVMX.getClass = function(className, failSilently){
		try{
			var arr = className.split(".");
			var fn = window;
			for (var i = 0, len = arr.length; i < len; i++) {
				if (failSilently && !fn) return;
				fn = fn[arr[i]];
			}
	
			if (typeof fn !== "function" && !failSilently) {
				SVMX.getLoggingService().getLogger().error("Cannot find definition for class : " + className);
			}
			return  fn;
		}catch(e){
			if (!failSilently) {
				SVMX.getLoggingService().getLogger().error("Error while resolving class <" + className + "> :" + e);
				throw e;
			}
		}
	};
	
	SVMX.create = function(){
		var fullClassName = '';
		try{
			if(arguments.length < 1) return null; // TODO log error
			
			fullClassName = arguments[0];
			
			var helper = SVMX.getCreateHepler(fullClassName);
			if(helper != null){
				return helper.helper.apply(helper.context, arguments);
			}else{
				var i, l = arguments.length, argsStr = "";
				for(i = 1; i < l; i++){
					argsStr += "arguments[" + i + "],";
				}
				
				if(argsStr.length > 0)
					argsStr = argsStr.substring(0, argsStr.length - 1);
				
				var cls = SVMX.getClass(fullClassName);
				var clsObj = eval("new cls(" + argsStr + ")");
				
				return clsObj;
			}
		}catch(e){
			SVMX.getLoggingService().getLogger().error("Error while creating class <" + fullClassName + " > : " + e);
			throw e;
		}
	};
	
	/***	 
	 * @param {Object} inScope Object that will be "this" within the function
	 * @param {Function|String} inFunction A function or the name of a function that exists within inScope
	 * @param [arg1,arg2,arg3] Zero or more arguments that will be passed in when the function is called
	 * @returns function that when called will have inScope as the "this" object.
	 * @description Calls jQuery.proxy which is documented at http://api.jquery.com/jQuery.proxy/ but changes the arguments
	 * so that the arguments do not vary in order
	 */
	SVMX.proxy = function() {
		var context = arguments[0];
		var func = arguments[1];
		if (typeof(func) !== "string") {			
			var tmp = arguments[0];
			arguments[0] = arguments[1];
			arguments[1] = tmp;			
		}
		return jQuery.proxy.apply(window, arguments);
	};

	// Move this into utils/timer.js when it becomes big enough
	SVMX.timer = {
		doLater : function(inFunc, inContext) {
			var f = inContext ? SVMX.proxy(inContext, inFunc) : inFunc;
			window.setTimeout(f, 1);
		},		

		/* Invokation:
		 * SVMX.timer.job("myTimer", 100, this, function() {...}); // function executes with this as context
		 * SVMX.timer.job("myTimer", 50, function() {}); // cancels previous timer and runs function with window context
		*/
		job : function(inName, inDelay, inJob1, inJob2) {
		    var inJob;
		    if (inJob1 && inJob2) {
		        inJob = SVMX.proxy(inJob1, inJob2);
		    } else if (inJob2) {
		        inJob = inJob2;
		    } else {
		        inJob = inJob1;
		    }
    		SVMX.timer.cancelJob(inName);
		    var job = function() {
	            delete SVMX.timer._jobs[inName];
	            inJob();
	        }
    		SVMX.timer._jobs[inName] = setTimeout(job, inDelay);
		},
		cancelJob : function(inName) {
    		clearTimeout(SVMX.timer._jobs[inName]);
    		delete SVMX.timer._jobs[inName];
		},
		hasJob : function(inName) {
		    return Boolean(SVMX,timer._jobs[inName]);
		},
		_jobs: {}
	};
	SVMX.doLater = SVMX.timer.doLater; // shortcut
	
	SVMX.ajax = function(options){
		return $.ajax(options);
	};
	
	SVMX.openInBrowserWindow = function(url){
		window.open(url, "_blank");
	};
	
	SVMX.setWindowTitle = function(title){
		window.document.title = title || "";
	};
	
	SVMX.reloadPage = function(){
		window.location.reload();
	};
	
	SVMX.navigateTo = function(url){
		window.location.href = url;
	};
	
	SVMX.onWindowResize = function(callback, context){
		SVMX.timer.job("windowResize", 1, function() {
	  		callback.call(context);
	  	});
	}
	
	var bCachingEnabled = null;
	SVMX.isCachingEnabled = function(){
		
		if(bCachingEnabled === null){
			var isEnabled = SVMX.getClient().getApplicationParameter("enable-cache");
			
			// configuration takes the highest precedence. if it is enabled in the configuration,
			// only then check is it is disabled/enabled via URL
			
			if(isEnabled != undefined && isEnabled != null && isEnabled === true){
				isEnabled = SVMX.getUrlParameter("enable-cache");
				if(isEnabled != undefined && isEnabled != null && isEnabled === "false"){
					isEnabled = false;
				}else{
					isEnabled = true;
				}
			}else{
				isEnabled = false;
			}
			
			bCachingEnabled = isEnabled;
		}
		
		return bCachingEnabled;
	};
	
	var bLoggingEnabled = null;
	SVMX.isLoggingEnabled = function(){
		
		if(bLoggingEnabled === null){
			var isEnabled = SVMX.getClient().getApplicationParameter("enable-log");
			
			// configuration takes the highest precedence. if it is enabled in the configuration,
			// only then check is it is disabled/enabled via URL
			
			if(isEnabled != undefined && isEnabled != null && isEnabled === true){
				isEnabled = SVMX.getUrlParameter("enable-log");
				if(isEnabled != undefined && isEnabled != null && isEnabled === "false"){
					isEnabled = false;
				}else{
					isEnabled = true;
				}
			}else{
				isEnabled = false;
			}
			
			bLoggingEnabled = isEnabled;
		}
		
		return bLoggingEnabled;
	};
	
	var __SVMX_URL_PARAMS__ = null;
	SVMX.getUrlParameter = function(name){
		if(__SVMX_URL_PARAMS__ == null){
			__SVMX_URL_PARAMS__ = {};
			var Url = document.URL;
			var paramValues = Url.slice(Url.indexOf("?") + 1).split("&");
			
			for (var i = 0; i < paramValues.length; i++) {
				var val = paramValues[i].split("=");
				__SVMX_URL_PARAMS__[val[0]] = val[1]; 
			}
		}
		var ret = __SVMX_URL_PARAMS__[name];
		if(ret != null){
			ret = decodeURIComponent(ret);
			
			// decodeURIComponent does not decode +!
			ret = ret.split("+").join(" ");
		}
		return ret;
	}; 
	
	SVMX.toJSON = function(data){
		if(data){
			return $.toJSON(data);
		}
		return null;
	};

	// do not call with indent; just SVMX.prettyPrint(myObj)
	SVMX.prettyPrint = function(data, indent) {
		indent = indent || 0;
		function doIndent(indent) {
			return new Array(indent).join("    ");
		}
		var result = "";
		if ($.isArray(data)) {
			result += "[\n"
			for (var i = 0; i < data.length; i++) {
				result +=  doIndent(indent+1) + i + ". " + SVMX.prettyPrint(data[i], indent+1);
				if (i < data.length-1) result += ",";
				result += "\n";
			}
			result += doIndent(indent) + "]"
		} else if (typeof data === "object" && data !== null) {
			result += "{\n";
			SVMX.forEachProperty(data, function(inKey, inValue) {
				result += doIndent(indent+1) + inKey + ": " + SVMX.prettyPrint(inValue, indent+1) + ",\n";
			});
			result += doIndent(indent) + "}";
		} else {
			result += data;
		}
		return result;
	};
	
	SVMX.dump = function(data) {
		console.log(SVMX.prettyPrint(data));
	};

	SVMX.toObject = function(data){
        var ret = data;

        if(typeof(data) == 'string'){
            try { ret = $.secureEvalJSON(data); } catch(e) { SVMX.getLoggingService().getLogger().error("SVMX.toObject() failed!"); }
        }

        return ret;
    };
    
	SVMX.toggleClass = function(selector, cssClass){
		$(selector).toggleClass(cssClass);
	};
	
	SVMX.sort = function(items, fieldOrFunc){
		// right now, only field name is supported
		if(typeof(fieldOrFunc) != 'string') return;
		
		var i, l = items.length;
		
		if(l < 2) return items;
		
		for(i = 0; i < (l - 1);){
			var k = 0;
			for(; k < (l - 1); k++){
				if(items[k][fieldOrFunc] > items[k+1][fieldOrFunc]){
					var temp   = items[k];
					items[k]   = items[k+1];
					items[k+1] = temp; 
				}
			}
			l--;
		}
		return items;
	};
	
	////////////////// jQuery.Deffered Utilities ////////////	
	// Utility for turning an array of deferreds into a single
	// deferred that evaluates when all deferreds are complete
	SVMX.when = function(arrayOfDeferred) {
		var args = "";
		for (var i = 0; i < arrayOfDeferred.length; i++) {
			if (i > 0) args += ",";
			args += "arrayOfDeferred[" + i + "]"
		}
		return eval("$.when(" + args + ")");
	};

	
	// !!!!!! DEPRECATED !!!!
	SVMX.loadCss = function(path){
		
		$.ajax({ type : 'GET', url : path, dataType : 'css', async : false,
			success  : function() {},
			error : function(jqXhr, status, e){ }
		});
		
		if (document.createStyleSheet){
            document.createStyleSheet(path);
        }
        else {
            $("head").append($("<link rel='stylesheet' href='" + path +"' type='text/css' media='screen' />"));
        }
	};
	
	SVMX.requireStyleSheet = function(url, callback, context, options){
		if(!$.isArray(url)) {
			url = [url];
		}
		
		var counter = 0;
		var prefix = options.prefix ? options.prefix : "";
		$.each(url, function() {
			
			var head = document.getElementsByTagName( 'head' )[0], link = document.createElement( 'link' );           
			link.setAttribute( 'href', prefix + this );
			link.setAttribute( 'rel', 'stylesheet' );
			link.setAttribute( 'type', 'text/css' );
			
			var sheet, cssRules, interval_id = 0, attempt = 0;
			if ( 'sheet' in link ) { sheet = 'sheet'; cssRules = 'cssRules'; }
			else { sheet = 'styleSheet'; cssRules = 'rules'; }
			
			interval_id = setInterval( function() {
				SVMX.getLoggingService().getLogger().info("requireStyleSheet::setInterval()");
				attempt++;
				if(attempt > 200){
					
					// could not load...
					clearInterval( interval_id );
					SVMX.getLoggingService().getLogger().info("Timeout! clearing interval with id => " + interval_id);
					head.removeChild( link ); 
					if(++counter == url.length) {
						callback.apply(context);
					}
				}else{
				
					try {
						if ( link[sheet] && link[sheet][cssRules].length ) {
						
							clearInterval( interval_id );
							SVMX.getLoggingService().getLogger().info("clearing interval with id => " + interval_id);
							if(++counter == url.length) {
								callback.apply(context);
							}
						}
					} catch( e ) {
						// !!! Important to note that loading style sheets is the last call before the application starts
						// any un-caught errors in the application may end up here.
						SVMX.getLoggingService().getLogger().error("There was an error! =>" + e);
					}
				}
			}, 100 );

			head.appendChild( link );
		});
	};
	
	SVMX.requireScript = function(url, callback, errback, context, options){
		
		if(!$.isArray(url)) {
			url = [url];
		}
		
		var loadVersion = SVMX.getClient().getLoadVersion();
		
		// some JS files have only one version. For example language files from ExtJS
		if(options && options.ignoreLoadVersion){
			loadVersion = "debug";	
		}
		
		if(loadVersion == "micro") url = ["__all__-min.js"];
		
		var counter = 0, cache = SVMX.isCachingEnabled();
		var prefix = options.prefix ? options.prefix : "";
		$.each(url, function() {
			var async = ( options.async != undefined ) ? options.async : true;
			
			var scriptToLoad = this;
			if(loadVersion == "min"){
				scriptToLoad = scriptToLoad.substring(0,scriptToLoad.length - 3) + "-min.js";
			}
			
			$.ajax({ cache : cache, type : 'GET', url : prefix + scriptToLoad, dataType : 'script', async : async,
				success  : function() {
					if(++counter == url.length) {
						callback.apply(context);
					}
				},
				error : function(jqXhr, status, e){ 
					SVMX.getLoggingService().getLogger().error("Error while loading => " + prefix + scriptToLoad + " =>" + e);
					if (errback) errback(new Error(scriptToLoad + " Failed to load"));
					throw e;
					//debugger; 
				}
			});
		});
	};
	
	SVMX.requireTemplate = function(url, callback, context, options){
		
		if(!$.isArray(url)) {
			url = [url];
		}
		
		var counter = 0;
		var prefix = options.prefix ? options.prefix : "";
		var templateList = [];
		
		$.each(url, function() {
			var async = ( options.async != undefined ) ? options.async : true;
			var name = this.toString();
			$.ajax({ type : 'GET', url : prefix + this, dataType : 'text', async : async,
				success  : function(data, status, jqXhr) {
					templateList[templateList.length] = {name : name, data : data};
					if(++counter == url.length) {
						callback.call(context, templateList);
					}
				},
				error : function(jqXhr, status, e){ 
					// YUI Compressor cribs
					//debugger; 
				}
			});
		});
	};
	
	SVMX.getDisplayRootId = function(){
		
		// TODO : Could be in application definition??
		return "client_display_root";
	};
	
	var __allClientProperties = {};
	SVMX.getClientProperty = function(name){
		return __allClientProperties[name];
	};
	
	SVMX.setClientProperty = function(name, value){
		__allClientProperties[name] = value;
	};
	
	////////////////// XML handling ////////////
	SVMX.toXML = function(data, rootElementName){
		
		function format(){
			if(arguments.length == 0 ) return "";
			
			var formatted = arguments[0];
			
		    for (var i = 1; i < arguments.length; i++) {
		        var regexp = new RegExp('\\{'+ (i - 1) +'\\}', 'gi');
		        formatted = formatted.replace(regexp, arguments[i]);
		    }
		    return formatted;
		}
		
		function getElement(name, value){
			var ret = "";
			if(value != null && value != undefined){
				if(value instanceof Array){
					ret +=  getArrayElement(name, value);
				}else if(typeof(value) == 'object'){
					ret += getObjectElement(name, value);
				}else{
					ret += getSimpleElement(name, value);
				}
			}
			return ret;
		}
		
		function getArrayElement(name, value){
			var ret = "", i, l = value.length, xml;
			for(var i = 0; i < l; i++){
				var arrayItem = value[i];
				ret += getElement(name, arrayItem);
			}
			return ret;	
		}
		
		function getSimpleElement(name, value){
			// escape all the special characters
			if(value && typeof(value) == 'string'){
				value = value.split("&").join("&amp;");
				value = value.split("<").join("&lt;");
				value = value.split(">").join("&gt;");
				value = value.split('"').join("&quot;");
				value = value.split("'").join("&#39;");
			}
			// end escape special characters
			
			return format("<{0}>{1}</{0}>", name, value);
		}
		
		function getObjectElement(name, value){
			var ret = "";
			for(var itemName in value){
				var itemValue = value[itemName];
				ret += getElement(itemName, itemValue);
			}
			
			if(name)
				ret = format("<{0}>{1}</{0}>", name, ret);
			return ret;
		}
		
		if(typeof(data) == 'string') return data;
		
		var xml = getObjectElement(rootElementName, data); 
		return xml;
	};
	
	SVMX.xmlToJson = function(xml) {
		var attr, child, attrs = xml.attributes, children = xml.childNodes, key = xml.nodeType, obj = {}, i = -1;

	    if (key == 1 && attrs.length) {
	    	i = -1;
	    } else if (key == 3) {
	    	obj = xml.nodeValue;
	    }

		while (child = children.item(++i)) {
			key = child.nodeName;
			key  = key.indexOf(":") != -1 ? key.split(":")[1] : key;
			
			if (obj.hasOwnProperty(key)) {
				if (obj.toString.call(obj[key]) != '[object Array]') {
  					obj[key] = [obj[key]];
				}
				obj[key].push(SVMX.xmlToJson(child));
			}else {
				obj[key] = SVMX.xmlToJson(child);
			}
		}
		
		// correct all text nodes
		for(var name in obj){
			var objItem = obj[name];
			if(objItem && typeof(objItem) == 'object'){
				if(objItem.hasOwnProperty("#text")){
					obj[name] = objItem["#text"];
					
					// also correct the boolean values
					if(obj[name] === "false") obj[name] = false;
					else if(obj[name] === "true") obj[name] = true;
					// end boolean correction
				}
			}
		}
		// end correction
		
		return obj;
  	}
	////////////////// End - XML handling /////
	window["SVMX"] = SVMX;
})(jQuery);

// end of file