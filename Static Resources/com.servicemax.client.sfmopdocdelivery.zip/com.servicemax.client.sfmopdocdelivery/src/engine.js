
(function(){
	var engine = SVMX.Package("com.servicemax.client.sfmopdocdelivery.engine");
	
engine.init = function(){
	//imports
	var CONSTANTS = com.servicemax.client.sfmopdocdelivery.constants.Constants;
	//end imports
	
	engine.Class("DeliveryEngineImpl", com.servicemax.client.sfmconsole.api.AbstractDeliveryEngine, {
		__nodeProcessor : null, __orgNamespace : null, styleNodeValue : null, __timeFormat : null, __dateFormat : null, __uniqueObjects : null,
		__depthCount : 2, __uniqueObjects : null, __jsee : null, __pendingNodeItems : null, __metadata : null, __data : null,
		__processedMetadata : null, __recsInfo : null, __aliasObjectName : null, __aliasDescribeInfo : null, __imageIds : null,
		__eventBus : null, __signaturesPending : null, __allowSignatures : null, __allowDraft : null,
		initAsync : function(options){
			// nothing to initialize, return
			//options.handler.call(options.context);
			var ni = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance(); 
			this.__eventBus = SVMX.create("com.servicemax.client.sfmopdocdelivery.impl.SFMOPDOCDeliveryEngineEventBus", {});
			
			// create the named default controller
			ni.createNamedInstanceAsync("CONTROLLER",{ handler : function(controller){
				
				// now create the named default model
				ni.createNamedInstanceAsync("MODEL",{ handler : function(model){
					controller.setModel(model);
					options.handler.call(options.context);
				}, context : this});
				
			}, context : this, additionalParams : { eventBus : this.__eventBus }});
		},
		
		run : function(options){
			var serv = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance();
			serv.createNamedInstanceAsync("NODE_PROCESSOR",{ handler : function(processor){
				this.__nodeProcessor = processor; 
				this.__orgNamespace = SVMX.getClient().getApplicationParameter("org-namespace");
				this.__allowSignatures = SVMX.getClient().getApplicationParameter("allow-signatures");
				this.__allowDraft = SVMX.getClient().getApplicationParameter("allow-draft");
				this.__runInternal();
			}, context : this });
		},
		
		__runInternal : function(){
				
			var platformSpecifics = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.platformspecifics").getInstance();
			var qInfo = platformSpecifics.getQualificationInfo();			
			this.returnUrl  = SVMX.getUrlParameter("SVMX_retURL");
			if(!qInfo.isQualified){
								
				platformSpecifics.alert(qInfo.errorMessage);
				platformSpecifics.navigateBack(this.returnUrl);					
			}
			else{
				
				this.__jsee = new com.servicemax.client.sfmopdocdelivery.jsel.JSExpressionEngine(this);
				this.__pendingNodeItems = new com.servicemax.client.sfmopdocdelivery.engine.PendingNodeProcessCollection();
				this.__signaturesPending = new com.servicemax.client.sfmopdocdelivery.engine.PendingSignatures();
				
				//special handling for image processing
				SVMX.getClient().triggerEvent(new com.servicemax.client.lib.api.Event("SFMOPDOCDELIVERY.JSEE_CREATED", this, {jsee : this.__jsee}));			
				this.__jsee.initialize({ contextRoots : ["$D","$M"] });
				
				//invoking events for getTemplate, Userinfo, Metadata, and Data
				var currentApp = this.getEventBus();
				var ec = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollection",currentApp,
						[							
							SVMX.create("com.servicemax.client.lib.api.Event",
								"SFMOPDOCDELIVERY.GET_USERINFO", this, {request : { context : this }}),
							SVMX.create("com.servicemax.client.lib.api.Event",
								"SFMOPDOCDELIVERY.GET_TEMPLATE", this, {request : { context : this, processId : SVMX.getUrlParameter("SVMX_processId") }}),
							SVMX.create("com.servicemax.client.lib.api.Event", 
								"SFMOPDOCDELIVERY.GET_DOCUMENT_METADATA", this, {request : { context : this, processId : SVMX.getUrlParameter("SVMX_processId") }}),
							SVMX.create("com.servicemax.client.lib.api.Event", 
								"SFMOPDOCDELIVERY.GET_DOCUMENT_DATA", this, {request : { context : this, returnUrl : this.returnUrl, processId : SVMX.getUrlParameter("SVMX_processId"), recordId : SVMX.getUrlParameter("SVMX_recordId") }})						
						 ]);
						 	 
				ec.triggerAll(function(evtCol){
					var items = evtCol.items(), size = items.length, i;
					for(i = 0; i < size; i++){
						var item = items[i];
						if(item.type() == "SFMOPDOCDELIVERY.GET_DOCUMENT_METADATA"){
							this.__metadata = item.response;
						}else if(item.type() == "SFMOPDOCDELIVERY.GET_DOCUMENT_DATA"){
							this.__data = item.response;
						}else if(item.type() == "SFMOPDOCDELIVERY.GET_USERINFO"){
							this.__onGetUserInfoComplete(item.response);
						}else if(item.type() == "SFMOPDOCDELIVERY.GET_TEMPLATE"){
							this.__onGetTemplateComplete(item.response);
						}
					}
					this.__getObjectDescribeInfo();
					
				},this)		
			}
				
						
		},
		
		__getObjectDescribeInfo : function(){
			this.__uniqueObjects = {};
			//parse through metadata
			this.__processMetaDataCollection();			
			//create events for all the objects
			this.__parseForImageIds();		
			var describeList = [];
			var intCount = 0;
			for(var i in this.__uniqueObjects){
				var evt = SVMX.create("com.servicemax.client.lib.api.Event", 
						"SFMOPDOCDELIVERY.DESCRIBE_OBJECT", this, {request : {objectName : this.__uniqueObjects[i]}});
				describeList[intCount] = evt;
				intCount++;
			}
			if(intCount > 0){
				var currentApp = this.getEventBus();
				var ec = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollection", currentApp, describeList);			
				ec.triggerAll(this.onDescribeObjectsComplete, this);
			//invoke all			
			}
			else{
				//then process the template
				this.__processTemplate();
			}
			
		},
		
		onDescribeObjectsComplete : function(evtCol){
			
			this.__aliasDescribeInfo = {};
			//add all labels to the context
			var items = evtCol.items(), size = items.length, i;
			var objMetadataMap = {};
			//process and assign the fields to object 
			for(i = 0; i < size; i++){
				var item = items[i], objectName = item.getEventObj().data.request.objectName;
				var objMetadataFields = item.response.fields;
				objMetadataMap[objectName] = this.__processObjectDescribe(objMetadataFields);				
			}
			
			//loop through all alias information and assign reference fields
			var depthCount = this.__depthCount;
			for(var alias in this.__aliasObjectName){
				var objName = this.__aliasObjectName[alias];
				if (objMetadataMap[objName]) {					
					var context = {};
					context[alias] = this.__processRefFieldsObjectDescribe(objName,objMetadataMap,depthCount);
					this.__aliasDescribeInfo[alias] = context[alias];
					this.__jsee.addContext(context, "$M");
				}				
			}			
			//then process the template
			this.__processTemplate();			
		},
		
		__processRefFieldsObjectDescribe : function(objName,objMetadataMap, depthCount){
			var objMetadata = objMetadataMap[objName];
			for(var name in objMetadata){
				if(objMetadata[name].dataType && objMetadata[name].dataType === "reference" && 
							objMetadata[name].referenceTo && objMetadataMap[objMetadata[name].referenceTo]){
					if(depthCount > 0){						
						this.__processRefFieldsObjectDescribe(objMetadata[name].referenceTo, objMetadataMap, depthCount - 1);						
					}
					this.__assignFields(objMetadata[name], objMetadataMap[objMetadata[name].referenceTo]);										
				}				
			}
			return objMetadata;		
		},
		
		__assignFields : function(refFieldInfo, objMetadata){
			
			var refField = refFieldInfo;
			for(var field in objMetadata){
				refField[field] = objMetadata[field];
			}
			return refField;			
		},		
		
		__processObjectDescribe : function(objectFields){
			
			var objectMetadata = {};
			for(var i in objectFields){
				objectMetadata[objectFields[i].name] = objectFields[i];
			}
			return objectMetadata;
				
		},
						
		__processTemplate : function(){			
			
			this.__processDataCollection();
			this.__processReferenceData();
			this.__onDataFetchComplete();			
		},
		
		getEventBus : function(){
			//return SVMX.getCurrentApplication();
			return this.__eventBus;
		},
		
		__onDataFetchComplete : function(){
			
			// process svmx-data bound attributes
			var nodesToProcess = $("[svmx-data]"), node;								
			var i = 0, l = nodesToProcess.length;
			for (i = 0; i < l; i++) {
				node = nodesToProcess[i];
				this.__nodeProcessor.process(
					{engine : this, node : node, jsee : this.__jsee, pendingNodeItems : this.__pendingNodeItems});
			}
			// end svmx-data processing
			//debugger;
			// inline expression processing
			var allInlineNodeTypes = [	{type : "div", 		name: "ILDIV"},
										{type : "strong", 	name: "ILSTRONG"},
										{type : "u", 		name: "ILU"},
										{type : "i", 		name: "ILI"},
										{type : "p", 		name: "ILP"}, 
										{type : "pre", 		name: "ILPRE"},
										{type : "h1", 		name: "ILH"},
										{type : "h2", 		name: "ILH"},
										{type : "h3", 		name: "ILH"},
										{type : "h4", 		name: "ILH"},
										{type : "h5", 		name: "ILH"},
										{type : "h6", 		name: "ILH"},
										{type : "style", 	name: "ILS"},
										{type : "span", 	name: "ILSP"},
										{type : "em", 		name: "ILEM"},
										{type : "strike", 	name: "ILSTRIKE"},
										{type : "sub", 		name: "ILSUB"},
										{type : "sup", 		name: "ILSUP"},
										{type : "ol ", 		name: "ILOL"},
										{type : "li", 		name: "ILLI"},
										{type : "ul", 		name: "ILUL"},
										{type : "b", 		name: "ILB"},
										{type : "td", 		name: "ILTD"},
										{type : "th", 		name: "ILTH"}], j, k = allInlineNodeTypes.length;
			for(j = 0; j < k; j++){
				nodesToProcess = $(allInlineNodeTypes[j].type); l = nodesToProcess.length;
				
				for(i = 0; i < l; i++){
					node = nodesToProcess[i];
					this.__nodeProcessor.process(
						{engine : this, node : node, jsee : this.__jsee, name : allInlineNodeTypes[j].name});
				}
			}			
			// end inline expression processing
			//if there are mandatory signatures then stay in HTML view(stop processing here)
			if(!this.__signaturesPending.isPending()){
				this.__checkForPendingNodeItems();
			}			
		},
		
		__checkForPendingNodeItems : function(){
			var me = this;
			if(this.__pendingNodeItems.isPending()){				
				setTimeout(function(){
					me.__checkForPendingNodeItems();
				},100)
			}else{
				//debugger;
				var outputString = $( "#" + CONSTANTS.DOCUMENT_PAGE ).html();
				outputString = outputString.replace(this.__processedStyleNodeValue,"");
				if(this.__processedStyleNodeValue !== null && 
				this.__processedStyleNodeValue !== undefined &&
				this.__processedStyleNodeValue.length > 0){
					outputString = this.__processedStyleNodeValue + outputString;
				}
				//trigger submit document
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
							"SFMOPDOCDELIVERY.SUBMIT_DOCUMENT", me, {request : { context : me, document : outputString }});
				
				me.getEventBus().triggerEvent(evt); 
			}
		},
		
		__onGetUserInfoComplete : function(userInfo){
			
			this.__jsee.setProperty(CONSTANTS.TODAY, userInfo.Today);
			this.__jsee.setProperty(CONSTANTS.TOMORROW, userInfo.Tomorrow);
			this.__jsee.setProperty(CONSTANTS.YESTERDAY, userInfo.Yesterday);
			this.__jsee.setProperty(CONSTANTS.NOW, userInfo.Now);
			this.__jsee.setProperty(CONSTANTS.USERNAME, userInfo.UserName);
			this.__jsee.setProperty(CONSTANTS.ADDRESS, userInfo.Address);
			this.__jsee.setProperty(CONSTANTS.LOCALE, userInfo.Locale);	
			this.__timeFormat = userInfo.TimeFormat;
			this.__dateFormat = userInfo.DateFormat;
			SVMX.setClientProperty("amText", userInfo.amText);
			SVMX.setClientProperty("pmText", userInfo.pmText);
							
		},
		
		__onGetTemplateComplete : function(template){
			//debugger;
			if(this.__allowDraft != null && this.__allowDraft === true){
				this.__createDraftButton();
			}
			else{
				this.__createFinalizeButton();
			}
			this.styleNodeValue = this.__parseforStyle(template.Template);
			$("#" + SVMX.getDisplayRootId()).append("<div style='border-radius:5px; border: 1px solid #72b3d5;margin-top: 5px;padding: 5px' id='" + CONSTANTS.DOCUMENT_PAGE + "'></div>");
			$("#" + CONSTANTS.DOCUMENT_PAGE).append(template.Template);
						
		},
		
		__createFinalizeButton : function(){
			var me = this;
			SVMX.handleFinalizeButtonClick = function(){
				//remove all the buttons
				debugger;
				var docPageNode = $("#" + CONSTANTS.DOCUMENT_PAGE);
				var buttons = $(docPageNode).find("button");
				if(buttons && buttons.length > 0){
					for(var i = 0;i < buttons.length; i++){
						var isSignatureButton = $(buttons[0]).attr("signature-name") != undefined ? true : false;
						if(isSignatureButton === true){
							$(buttons[i]).remove();
						}
					}
				}
				
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
					"SFMOPDOCDELIVERY.FINALIZE", me,{
						request : { 
							processId 		 : SVMX.getUrlParameter("SVMX_processId"),
							recordId 		 : SVMX.getUrlParameter("SVMX_recordId"),
							htmlContent		 : $( "#" + CONSTANTS.DOCUMENT_PAGE ).html()
						}
					});
		
				me.getEventBus().triggerEvent(evt);					
			};
			var finalizeBtn = "<input style='background:#f16138; -moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px; font: normal 13px tahoma,arial,verdana,sans-serif; border: 1px solid #db3202; color:#FFFFFF; font-weight:bold; padding:3px 15px; cursor:pointer' type='button' id='svmx_finalize' onClick='SVMX.handleFinalizeButtonClick();' value='"+ CONSTANTS.FINALIZE +"'>";
			$("#" + SVMX.getDisplayRootId()).append("<div style='background:#a4d0e7; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; border: 1px solid #72b3d5;padding: 5px' id='" + CONSTANTS.FINALIZE_DIV + "'></div>");
			$("#" + CONSTANTS.FINALIZE_DIV).append(finalizeBtn);			
		},
		
		__createDraftButton : function(){
			var me = this;
			SVMX.handleDraftButtonClick = function(){
				me.__checkForPendingNodeItems();
			}
			var draftBtn = "<input style='background:#f16138; -moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px; font: normal 13px tahoma,arial,verdana,sans-serif; border: 1px solid #db3202; color:#FFFFFF; font-weight:bold; padding:3px 15px; cursor:pointer' type='button' id='svmx_draft' onClick='SVMX.handleDraftButtonClick();' value='"+ CONSTANTS.DRAFT +"'>";
			$("#" + SVMX.getDisplayRootId()).append("<div hidden style='background:#a4d0e7; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; border: 1px solid #72b3d5;padding: 5px' id='" + CONSTANTS.DRAFT_DIV + "'></div>");
			$("#" + CONSTANTS.DRAFT_DIV).append(draftBtn);		
		},
		
		__parseforStyle : function(template){
			var startIndex, endIndex;
			var ret;
			if(!template) return ret;
			
			startIndex = template.indexOf("<style");
			endIndex = template.indexOf("</style>");
			
			if(startIndex != -1 && endIndex != -1){
				ret = template.substring(startIndex, endIndex);									 
			}		
			ret = ret + "</style>";	
			return ret;
		},
		
		onSubmitDocumentComplete : function(document){
			
			var docId = document.DocumentId;	
			var evt = SVMX.create("com.servicemax.client.lib.api.Event",
						"SFMOPDOCDELIVERY.CREATE_PDF", this, 
						{request : { context : this, returnUrl : this.returnUrl, documentId : docId, recordId : SVMX.getUrlParameter("SVMX_recordId")}});
			
			this.getEventBus().triggerEvent(evt);
		},
		
		onCreatePDFComplete : function(pdf){
			
			if (!this.__signaturesPending.isPending()) {
				var evt = SVMX.create("com.servicemax.client.lib.api.Event", "SFMOPDOCDELIVERY.TARGET_UPDATES", this, {
					request: {
						context : this,
						processId: SVMX.getUrlParameter("SVMX_processId"),
						recordId: SVMX.getUrlParameter("SVMX_recordId"),
						pdf: pdf 
					}
				});
				
				this.getEventBus().triggerEvent(evt);
			}
			else{
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
						"SFMOPDOCDELIVERY.VIEW_DOCUMENT", this, {request : { context : this, attachmentId : pdf.PDFAttachmentId, recordId : SVMX.getUrlParameter("SVMX_recordId")}});
			
				this.getEventBus().triggerEvent(evt);
			}	
						
		},
		
		onTargetUpdatesComplete : function(pdf){
			
			var evt = SVMX.create("com.servicemax.client.lib.api.Event",
			"SFMOPDOCDELIVERY.VIEW_DOCUMENT", this, {request : { context : this, attachmentId : pdf.PDFAttachmentId, recordId : SVMX.getUrlParameter("SVMX_recordId")}});
			
			this.getEventBus().triggerEvent(evt);	
					
		},
		
		//processing metadata
		__processMetaDataCollection : function(){
			
			var metadata = this.__metadata.AllObjectInfo;
			this.__processedMetadata = {};
			this.__recsInfo = {};
			this.__aliasObjectName = {};
			var sortedArray;
			var i, count = metadata.length;
			for (i = 0; i < count; i++) {
				sortedArray = [];
				var fields = metadata[i][this.__orgNamespace + "__Fields__c"]
				if(!fields || fields.length === 0) continue;
				sortedArray = this.__sortFieldsInformation(metadata[i][this.__orgNamespace + "__Fields__c"])
				this.__processedMetadata[metadata[i][this.__orgNamespace + "__Alias__c"]] = sortedArray;
				this.__recsInfo[metadata[i][this.__orgNamespace + "__Alias__c"]] = metadata[i][this.__orgNamespace + "__Type__c"];
				this.__aliasObjectName[metadata[i][this.__orgNamespace + "__Alias__c"]] = metadata[i][this.__orgNamespace + "__Object_Name__c"]				
			}			
		},
		
		//process Image metadata
		__parseForImageIds : function(){
			this.__imageIds = {};
			var templareRec = this.__metadata.TemplateRecord;
			if(templareRec != null && templareRec){
				var imageInfo = templareRec[0][this.__orgNamespace + "__Media_Resources__c"];
				if(imageInfo != null && imageInfo.length > 0){
					var imageInfoObject = SVMX.toObject(imageInfo);
					for(i = 0; i < imageInfoObject.length ; i++){
						this.__imageIds[imageInfoObject[i]["DeveloperName"]] = imageInfoObject[i]["Id"];	
					}					 
				} 
			}
			this.__jsee.setProperty(CONSTANTS.IMAGENAMEID, this.__imageIds);
			
		},
		
		//processing the data
		__processDataCollection : function() {
			
			if(this.__data.DocumentData === undefined) return;
			//process the data and build the required object
			var i, count = this.__data.DocumentData.length;
			var documentData = this.__data.DocumentData;
			this.__processedData = {};
			this.__specialFieldsData = {};
			for (i = 0; i < count; i++) {
				this.__processedData[this.__data.DocumentData[i]["Key"]] = this.__data.DocumentData[i]["Records"];
				this.__specialFieldsData[this.__data.DocumentData[i]["Key"]] = this.__data.DocumentData[i]["SpecialFields"];
			}						
		},
		
		//prcessing metadata
		__processReferenceData : function(){
			var metadata = this.__processedMetadata;
			var data = this.__processedData;
			var specData = this.__specialFieldsData;
			for(var key in metadata){
				
				//for the current metadata alias get the data
				var Recs = data[key];
				var RecSpecData = {};
				for(var idKey in specData[key]){
					RecSpecData[specData[key][idKey].Key] = specData[key][idKey].Value;
				}
				if (Recs !== undefined && Recs !== null) {
					var fields = metadata[key];
					var descInfo = this.__aliasDescribeInfo[key];
					var i, count = fields.length;
					var j, recCount = Recs.length;
					//now loop through the fields
					for (i = 0; i < count; i++) {
						//now loop the recs
						for (j = 0; j < recCount; j++) {
							//handling reference fields
							if (fields[i][CONSTANTS.REF_OBJ_NAME_2]) {
								if(Recs[j][fields[i][CONSTANTS.RLN_NAME]] !== null && Recs[j][fields[i][CONSTANTS.RLN_NAME]][fields[i][CONSTANTS.RLN_NAME_2]] !== null){									
									
									//process each metadata field that have the refernce update the value to actual field 
									Recs[j][fields[i][CONSTANTS.RLN_NAME]][fields[i][CONSTANTS.REF_FLD_NAME]] 
																= Recs[j][fields[i][CONSTANTS.RLN_NAME]][fields[i][CONSTANTS.RLN_NAME_2]][fields[i][CONSTANTS.REF_FLD_NAME_2]];
									
								}															
							}
							
							if (fields[i][CONSTANTS.REF_OBJ_NAME]) {
								var idValue = '';
								if(Recs[j][fields[i][CONSTANTS.FLD_NAME]] && Recs[j][fields[i][CONSTANTS.FLD_NAME]].Id){
									idValue = Recs[j][fields[i][CONSTANTS.FLD_NAME]].Id;
								}
								else{
									idValue = Recs[j][fields[i][CONSTANTS.FLD_NAME]];
								}
								Recs[j][fields[i][CONSTANTS.FLD_NAME]] = Recs[j][fields[i][CONSTANTS.RLN_NAME]];
								if(Recs[j][fields[i][CONSTANTS.FLD_NAME]])
									Recs[j][fields[i][CONSTANTS.FLD_NAME]].Id = idValue;
															
							}																					
						}
					}
					
					//now handling for special fields
					for (j = 0; j < recCount; j++) {
						Recs[j] = this.__processSpecialFields(RecSpecData, Recs[j]);
						//now process security check
						Recs[j] = this.__processFieldSecurity(Recs[j],descInfo)
					}
				}
				var context = {};
				context[key] = Recs;
				if (this.__recsInfo[key] === CONSTANTS.TYPE_HEADER) {					
					context[key] = Recs[0];
				}				
				this.__jsee.addContext(context, "$D");					
			}			
			
		},
		
		__processFieldSecurity : function(record, descInfo){
			for (var fieldName in record) {				
				if (typeof record[fieldName] === 'object' && descInfo[fieldName] !== undefined 
					&& descInfo[fieldName].accessible === true) {
					this.__processFieldSecurity(record[fieldName],descInfo[fieldName])								
				}
				else if(descInfo[fieldName] != null && descInfo[fieldName].accessible === false){
					record[fieldName] = '';
				}
			}
			return record;			
		},
		
		__processSpecialFields : function(RecSpecData, record){
			
			var recId = record["Id"];
			var recData = RecSpecData[recId];
			if(!recData) return record;
			var hrsFormat = com.servicemax.client.lib.datetimeutils.DatetimeUtil.getTimeFormat(this.__timeFormat);
			for(var i = 0; i < recData.length; i++){
				var arrFlds = recData[i].Key.split(".");
				var formattedValue = "";
				if (recData[i].Info && recData[i].Info === 'datetime') {
					formattedValue = com.servicemax.client.lib.datetimeutils.DatetimeUtil.datetimeRenderer(recData[i].Value,this.__dateFormat,hrsFormat,this.__timeFormat)
				}
				else if (recData[i].Info && recData[i].Info === 'date') {
					formattedValue = com.servicemax.client.lib.datetimeutils.DatetimeUtil.dateRenderer(recData[i].Value,this.__dateFormat)
				}
				if(arrFlds.length == 2 ){
					record[arrFlds[0]][arrFlds[1]] = formattedValue;					
				}
				else{
					record[recData[i].Key] = formattedValue;
				}				
			}
			return record;
			
		},
		
		__sortFieldsInformation : function(fields){
			
			var level2 = [], level1 = [], level0 = [];
			var l2_Index = 0, l1_Index = 0, l0_Index = 0;
			var allFields = SVMX.toObject(fields);
			var metadata = allFields.Metadata;
			if (metadata.length > 0) {
				for (var index in metadata) {
					if(metadata[index][CONSTANTS.REF_OBJ_NAME_2]){
						level2[l2_Index] = metadata[index];
						this.__addToUniqueObjects(metadata[index][CONSTANTS.REF_OBJ_NAME_2]);
						this.__addToUniqueObjects(metadata[index][CONSTANTS.REF_OBJ_NAME]);
						this.__addToUniqueObjects(metadata[index][CONSTANTS.OBJ_NAME]);
						l2_Index++;
					}else if(metadata[index][CONSTANTS.REF_OBJ_NAME]) {
						level1[l1_Index] = metadata[index];
						this.__addToUniqueObjects(metadata[index][CONSTANTS.REF_OBJ_NAME]);
						this.__addToUniqueObjects(metadata[index][CONSTANTS.OBJ_NAME]);
						l1_Index++;
					}else if(metadata[index][CONSTANTS.OBJ_NAME]) {
						level0[l0_Index] = metadata[index];
						this.__addToUniqueObjects(metadata[index][CONSTANTS.OBJ_NAME]);
						l0_Index++;
					}
				}
				//combining all the arrays				
			}
			return level2.concat(level1, level0);		
		},		
		__addToUniqueObjects : function(objName){
			if(objName != undefined && objName && objName.length > 0)
				this.__uniqueObjects[objName] = objName;
		},
		__processNode : function(node, targetAttribute){
			var result = this.__jsee.evalExpression($(node).attr(targetAttribute));
			$(node).html(result);
		}
		
	}, {});
	
	engine.Class("AbstractNodeProcessor", com.servicemax.client.lib.api.Object, {
		__constructor : function(){},
		/**
		 * 
		 * @param {Object} params
		 * {
		 * 		jsee : expression engine,
		 * 		node : htmlelement
		 * 
		 */
		process : function(params){ return null; },
		
		_removeControlCharacters : function(value){
			return value.replace(/[\n\r\t]/g,'');
		},
		
		_removeSVMXCharacters : function(value){
			return value.substring(2,value.length - 2);
		},
		
		format : function(str, argsArray){
			var i = 0, l = argsArray.length;
			for (var i = 0; i < l; i++) {
		        var regexp = new RegExp('\\{'+ i +'\\}', 'gi');
		        str = str.replace(regexp, argsArray[i]);
		    }
		    
		    return str;
		},
		
		replaceExpressions : function(expressionData, params, handleSpecialCharacters){
			var i , items = expressionData.items, l = items.length, item, result;
			for(i = 0; i < l; i++){
				item = items[i];
				
				// strip of the start and end delimiters
				item = item.substring(2, item.length - 2);
				item = this._removeControlCharacters(item);
				result = params.jsee.evalExpression(item, params);
				if(handleSpecialCharacters){
					if(result === undefined || result === null || result === ''){
						result = "";
					}
				}
				items[i] = result != undefined && result != null ? result : '';
			}
			return this.format(expressionData.expression, items);
		},
		
		parseforExpressions : function(inlineExpression){
			var ret = {expression : inlineExpression, found : false, items : []};
			var startIndex, endIndex, expression, temp, i;
			
			if(!inlineExpression) return ret;
			
			i = 0;
			while(true){
				startIndex = inlineExpression.indexOf("{{");
				endIndex = inlineExpression.indexOf("}}");
				
				if(startIndex != -1 && endIndex != -1){
					expression = inlineExpression.substring(startIndex, endIndex + 2);
					temp = inlineExpression.substring(0, startIndex) 
									+ "{" + i + "}";
					
					if(endIndex + 2 < inlineExpression.length){
						temp += inlineExpression.substring(endIndex + 2);
					}
					
					inlineExpression = temp;
					
					ret.found = true;
					ret.expression = inlineExpression;
					ret.items[i] = expression;
					i++;				 
				}else{
					//no more expressions
					break;
				}
			}
			return ret;
		},	
		
		parseandreplaceExpressions : function(inlineExpression, params){
			
			res = this.parseforExpressions(inlineExpression);
			var processData = this.replaceExpressions(res, params);
			return processData;
		}
		
	}, {});
	
	engine.Class("NodeProcessor", com.servicemax.client.runtime.api.AbstractNamedInstance, {
		__nodeTypeToProcessor : {},
		__constructor : function(){
			
		},
		
		initialize: function(name, data, params){
			
			var i, count = data.length;
			for (i = 0; i < count; i++) {
				var d = data[i];
				var nodeTypeMap = d.data, nodeTypeMapCount = nodeTypeMap.length, j;
				for (j = 0; j < nodeTypeMapCount; j++) {
					var mapping = nodeTypeMap[j];
					this.__nodeTypeToProcessor[mapping.nodeType] = {processor : mapping.processor, inst : null};
				}
			}
		},
		
		process : function(params){
			var name = params.name || $(params.node)[0].nodeName;
			var processorInfo = this.__nodeTypeToProcessor[name], processor = null, ret = false;
			if(processorInfo){				
				if(!processorInfo.inst){
					var cls = SVMX.getClass(processorInfo.processor);
					var clsObj = new cls();
					processorInfo.inst = clsObj;
				}
				processor = processorInfo.inst;
			}
			
			if(processor){
				ret = processor.process(
					{engine : params.engine, jsee : params.jsee, node : params.node, pendingNodeItems : params.pendingNodeItems});
			}
			
			return ret;
		}
		
	}, {});
	
	engine.Class("DivNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		process : function(params){
			
			var expression = $(params.node).attr("svmx-data");
			expression = this._removeControlCharacters(expression);			
			var result = this.parseandreplaceExpressions(expression, params);
			$(params.node).html(result);
			return true;
		}
		
	}, {});
	
	engine.Class("TableNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		process : function(params){			
			var expression = $(params.node).attr("svmx-data");
			expression = this._removeSVMXCharacters(expression);
			var result = params.jsee.evalExpression(expression);
			if (result != null && result.length > 0) {
				var l = result.length, i;
				var tbody = $("tbody", $(params.node));
				
				if(tbody.length == 0){
					$(params.node).append(document.createElement('tbody'));
				}
				tbody = $("tbody", $(params.node))[0];
				
				var thead = $("thead", $(params.node));
				
				var columns = $($(thead[0]).children()[0]).children(), colCount = columns.length, j;
				for (i = 0; i < l; i++) {
					var curRowData = result[i];
					var row = tbody.insertRow(i);
					//for supporting expressions in line items
					var key = expression.substring(3);
					this.assignContext(params.jsee, key, curRowData);
														
					for (j = 0; j < colCount; j++) {
						var actualCellField = $(columns[j]).attr("svmx-data");
						var cellField = this._removeSVMXCharacters(actualCellField);
						var cellData = row.insertCell(j);
						var path = cellField.split("."), pathElementCount = path.length, k;
						var value = curRowData;
						for (k = 0; k < pathElementCount; k++) {
							if (value[path[k]] && typeof(value[path[k]]) === 'object' 
														&& value[path[k]].Id && pathElementCount === 1) 
								value = value[path[k]].Id;
							else if(value[path[k]] !== undefined && value[path[k]] !== null)
								value = value[path[k]];
							else
								value = '';
						}
						//code to support expressions
						if(value.length == 0){
							var childExp = this._removeControlCharacters(actualCellField);			
							value = this.parseandreplaceExpressions(childExp, params);
						}
						
						try { value = value.toString(); }catch(e){}
						
						$(cellData).html(value);
						cellData.align = "center";
					}
				}
				this.assignContext(params.jsee, key, result);
			}
			return true;
		},
		
		assignContext : function(jsee, key, rowData){
			
			var context = {};
			context[key] = rowData;										
			jsee.addContext(context, "$D");
		}
		
	}, {});
	
	engine.Class("ImageNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		process : function(params){
								
			var expression = $(params.node).attr("svmx-data");
			expression = this._removeSVMXCharacters(expression);
			var result = params.jsee.evalExpression(expression, {node : params.node, pendingNodeItems : params.pendingNodeItems});
			return true;
		}
		
	}, {});
	
	engine.Class("TdNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		process : function(params){
			
			var expression = $(params.node).attr("svmx-data");
			expression = this._removeControlCharacters(expression);
			var result = this.parseandreplaceExpressions(expression, params);
			params.node.innerText = result;
			return true;
		}
				
	}, {});	
	
	engine.Class("AbstractInlineNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		processChildNodes : function(params){
			var node = params.node, children = node.childNodes, i, l = children.length, child, inlineExpression, res;
			for(i = 0; i < l; i++){
				child = children[i];
				if(child.nodeType == 3){
					// text node
					inlineExpression = child.nodeValue;
					res = this.parseforExpressions(inlineExpression);
					var processData = this.replaceExpressions(res, params, params.handleSpecialCharacters);
					var isNodeProcessed = this.processSignatureNodes(processData, child);
					if(!isNodeProcessed)
						child.nodeValue = processData;
				}
			}
		},
		
		processSignatureNodes : function(data, childNode){
			var textArr = [], i, l;			
			var isNodeProcessed = false;
			var spanNode = $("<span></span>");
			textArr = this.processTextWithDelimiters(data, "svmx-signature-start", "svmx-signature-end", 20, 18);
			
			if(textArr && textArr.length > 0){
				l = textArr.length;
				//insert before node				
				$(spanNode).insertBefore(childNode);				
				isNodeProcessed = true;
				for(i = 0; i < l; i++){
					var currNode = $("<span></span>").html(textArr[i]); 
					$(spanNode).append(currNode);
				}				
				//remove existing node
				$(childNode).remove();
				
			}
			return isNodeProcessed;
		},
		
		processTextWithDelimiters : function(text, delimiterStart, delimiterEnd, 
													numOfCharSkippedStart, numOfCharSkippedEnd){
			var textData = text;
			var textArr = [];
			var startIndex, endIndex;
			while(true){
				var temp = "";
				startIndex = textData.indexOf(delimiterStart);
				endIndex = textData.indexOf(delimiterEnd);
				if(startIndex != -1 && endIndex != -1){
					textArr.push(textData.substring(0, startIndex));
					textArr.push(textData.substring(startIndex + numOfCharSkippedStart, endIndex));
							
					if(endIndex + numOfCharSkippedEnd < textData.length){
						temp = textData.substring(endIndex + numOfCharSkippedEnd);
					}			
					textData = temp;
				}else{
					//no more signatures
					break;
				}
			}
			return textArr;										
		}
		
	}, {});
	
	engine.Class("InlineDivNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineStrongNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineUnderlineNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineItalicNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineParaNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlinePreNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineHeadingNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineStyleNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
			this.processChildNodes(params);
			return true;
		},
		
		processChildNodes : function(params){
			if(params.engine.styleNodeValue == null) return;
			
			var node = params.node, children = node.childNodes, i, l = children.length, child, inlineExpression, res;
			inlineExpression = params.engine.styleNodeValue;
			res = this.parseforExpressions(inlineExpression);
			processData = this.replaceExpressions(res, params);
			params.engine.__processedStyleNodeValue = processData;	
			if(l > 0){
				child = children[0];
				child.nodeValue = processData;
			}else{
				node.nodeValue = processData;
			}
		}
		
	}, {});
	
	engine.Class("InlineSpanNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineEMNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineStrikeNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineSubNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineSupNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineOlNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineLiNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
			params.handleSpecialCharacters = true;					
			this.processChildNodes(params);
			return true;
		}
				
	}, {});
	
	engine.Class("InlineUlNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineBoldNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineTDNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("InlineTHNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },
		
		process : function(params){
								
			this.processChildNodes(params);
			return true;
		}
	}, {});
	
	engine.Class("PendingNodeProcessCollection",  com.servicemax.client.lib.api.Object, {
		__constructor : function(){ },
		__pendingNodeItems : {},
		addItem : function(key, value){
			this.__pendingNodeItems[key] = value;
		},
		
		removeItem : function(key){
			delete this.__pendingNodeItems[key];
		},
		
		isPending : function(){
			for(key in this.__pendingNodeItems){
				return true;
			}
			return false;
		}		
	}, {});
	
	engine.Class("PendingSignatures",  com.servicemax.client.lib.api.Object, {
		__constructor : function(){ },
		__pendingSignatures : {},
		__finBtnName : 'svmx_finalize',
		__draBtnDiv : CONSTANTS.DRAFT_DIV,
		addItem : function(key, value){
			this.__pendingSignatures[key] = value;
			$("#" + this.__draBtnDiv).removeAttr("hidden");
			$("#" + this.__finBtnName).prop("disabled","true");
		},
		
		removeItem : function(key){
			if(this.__pendingSignatures[key]){
				delete this.__pendingSignatures[key];
			}
			if(!this.isPending()){
				$("#" + this.__finBtnName).removeAttr("disabled");
			}	
		},
		
		isPending : function(){
			for(key in this.__pendingSignatures){
				return true;
			}
			return false;
		}		
	}, {});
	
};
})();

// end of file