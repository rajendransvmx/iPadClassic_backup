// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.mvc\src\api.js

(function(){
	
	var mvcApi = SVMX.Package("com.servicemax.client.mvc.api");
	
	mvcApi.Class("Command", com.servicemax.client.lib.api.AbstractCommand, {
		__controller : null, __eventBus : null,
		
		__constructor : function(){ this.__base(); },
		setController : function(value){ this.__controller = value; },
		setEventBus : function(value){ this.__eventBus = value; },
		executeAsync : function(request, responder) { },
		
		_executeOperationAsync : function(request, responder, options){
			this.__controller.getModel().executeOperationAsync(
				request, responder, options, this.getEventBus());
		},
		
		getController : function(){ return this.__controller; },
		getEventBus : function(){ return this.__eventBus; }
	}, {});
	
	mvcApi.Class("Operation", com.servicemax.client.lib.api.AbstractOperation, {
		__eventBus : null,
		__constructor : function(){ this.__base(); },
		performAsync : function(request, responder) { },
		
		setEventBus : function(value){ this.__eventBus = value; },
		getEventBus : function(){ return this.__eventBus; }
	}, {});
	
	mvcApi.Class("Responder", com.servicemax.client.lib.api.AbstractResponder, {
		__constructor : function() { this.__base(); },
		result : function(data) { },
		fault : function(data) { }
	}, {});
	
	mvcApi.Class("CommandWithResponder", mvcApi.Command, {
		__constructor : function() { this.__base(); },
		
		// responder
		result : function(data) { },
		fault : function(data) { }
		// end responder
		
	}, {});
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.mvc\src\impl.js

(function(){
	
	var mvcImpl = SVMX.Package("com.servicemax.client.mvc.impl");
	
	mvcImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
		__constructor : function(){
			this.__base();
		},
		
		beforeInitialize : function(){
			mvcImpl.init();
		},
		
		initialize : function(){
			
		},
		
		afterInitialize : function(){
			
		}
	}, {});

mvcImpl.init = function(){
	
	mvcImpl.Class("Controller", com.servicemax.client.runtime.api.AbstractNamedInstance, {
		__eventId2EventMap : null, _model : null, __logger : null, __eventBus : null,
		
		__constructor : function(){
			
		},
		
		initialize : function(name, data, params){
			this.__logger = SVMX.getLoggingService().getLogger("MVC-CONTROLLER(" + name +")");
			this.__eventId2EventMap = {};
			var eventBus = params.eventBus; this.__eventBus = params.eventBus;
			var i, count = data.length;
			for(i = 0; i < count; i++){
				var d = data[i];
				var eventMap = d.data, eventCount = eventMap.length, j;
				for(j = 0; j < eventCount; j++){
					var mapping = eventMap[j];
					this.__eventId2EventMap[mapping.event] = { data : d, mapping : mapping };
					eventBus.bind(mapping.event, this.eventHandler, this);
				}
			}
		},
		
		/**
		 * 
		 * @param evt
		 */
		eventHandler : function(evt){
			try{
				var eventInfo = this.__eventId2EventMap[evt.type];
				var commandClassName = eventInfo.mapping.command;
				
				//TODO : Load the module if it is already not loaded
				
				var commandClass = SVMX.getClass(commandClassName);
				var cmd = new commandClass();
				cmd.setController(this);
				cmd.setEventBus(this.__eventBus);
				
				var request = evt.data.request;
				var responder = evt.data.responder;
				this.__logger.info("Executing command => " + evt.type);
				cmd.executeAsync(request, responder);
			}catch(e){
				this.__logger.error(e);
				throw e;
			}
		},
		
		setModel : function(value){
			this._model = value;
		},
		
		getModel : function(){ return this._model; }
		
	}, {});
	
	mvcImpl.Class("Model", com.servicemax.client.runtime.api.AbstractNamedInstance, {
		
		__operationId2OperationMap : null, __logger : null,
		
		__constructor : function(){},
		
		initialize : function(name, data, params){
			this.__logger = SVMX.getLoggingService().getLogger("MVC-MODEL(" + name +")");
			this.__operationId2OperationMap = {};
			var i, count = data.length;
			for(i = 0; i < count; i++){
				var d = data[i];
				var opMap = d.data, opCount = opMap.length, j;
				for(j = 0; j < opCount; j++){
					var mapping = opMap[j];
					this.__operationId2OperationMap[mapping.operationId] = { data : d, mapping : mapping };
				}
			}
		},
		
		/**
		 * 
		 * @param request
		 * @param responder
		 * @param options = { operationId : "" }
		 */
		executeOperationAsync : function(request, responder, options, eventBus){
			try{
			var operationInfo = this.__operationId2OperationMap[options.operationId];

			// Operation is not supported for the current application.  See LookupItemSelected operation for offline sal model vs online model for example.
			if (!operationInfo) return; 
			
			var operationClassName = operationInfo.mapping.operation;
			
			//TODO : Load the module if it is already not loaded
			
			var operationClass = SVMX.getClass(operationClassName);
			var op = new operationClass();
			op.setEventBus(eventBus);
			op.performAsync(request, responder);
			}catch(e){
				this.__logger.error(e);
				throw e;
			}
		}
		
	}, {});
};
})();

// end of file

