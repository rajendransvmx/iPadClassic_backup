
(function(){
	
	var mvcApi = SVMX.Package("com.servicemax.client.mvc.api");
	
	mvcApi.Class("Command", com.servicemax.client.lib.api.AbstractCommand, {
		__controller : null, __eventBus : null,
		
		__constructor : function(){ this.__base(); },
		setController : function(value){ this.__controller = value; },
		setEventBus : function(value){ this.__eventBus = value; },
		executeAsync : function(request, responder) { },
		
		_executeOperationAsync : function(request, responder, options){
			this.__controller.getModel().executeOperationAsync(
				request, responder, options, this.getEventBus());
		},
		
		getController : function(){ return this.__controller; },
		getEventBus : function(){ return this.__eventBus; }
	}, {});
	
	mvcApi.Class("Operation", com.servicemax.client.lib.api.AbstractOperation, {
		__eventBus : null,
		__constructor : function(){ this.__base(); },
		performAsync : function(request, responder) { },
		
		setEventBus : function(value){ this.__eventBus = value; },
		getEventBus : function(){ return this.__eventBus; }
	}, {});
	
	mvcApi.Class("Responder", com.servicemax.client.lib.api.AbstractResponder, {
		__constructor : function() { this.__base(); },
		result : function(data) { },
		fault : function(data) { }
	}, {});
	
	mvcApi.Class("CommandWithResponder", mvcApi.Command, {
		__constructor : function() { this.__base(); },
		
		// responder
		result : function(data) { },
		fault : function(data) { }
		// end responder
		
	}, {});
})();

// end of file