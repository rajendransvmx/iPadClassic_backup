// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\api.js
(function(){
	
	var clientConsoleApi = SVMX.Package("com.servicemax.client.sfmconsole.api");
	
	clientConsoleApi.Class("AbstractConsoleApp", com.servicemax.client.lib.api.Object, {
		__parent 			: null,
		__container 		: null,
		__size 				: [],
		__visibilty 		: null,
		__group 			: null,
		__windowTitle 		: null,
		__closeCallBack 	: null,
		__callbackContext 	: null,
		
		__constructor : function(parent,container,options){
			this.__parent = parent;
			this.__container = container;
			this.__size.width = options.size.width;
			this.__size.height = options.size.height;
		},
		
		start : function() {

		},
		
		onCanClose : function (callback) {
			callback(false);
		},
		
		onClose : function (options) {

		},
				
		showLoadMask : function(target) {
			this.__parent.showLoadMask(target || this.__container);
		},
		
		hideLoadMask : function(target) {
			this.__parent.hideLoadMask(target || this.__container);
		},
		
		getGroup : function () {
			return this.__group;
		},
		
		setWindowTitle : function(title){
			this.__windowTitle = title;
			this.__container.setTitle(this.__windowTitle);
		},
		
		getWindowTitle : function () {
			return this.__windowTitle;
		},
		
		getCloseCallBack : function () {
			return this.__closeCallBack;
		},
				
		getCallBackContext : function() {
			return this.__callbackContext;
		},
		
		setAppInfo : function (options) {
			options = options || {};
			
			this.__group = options.groupName;
			this.__windowTitle = options.windowTitle;
			this.__closeCallBack = options.closeCallback;
			this.__callbackContext = options.context;
		},
				
		getConsoleAppContainer : function() {
			return this.__container;
		},
		
		setRootContainer : function (container) {
			this.getConsoleAppContainer().add(container);

			// TODO: better way to size console app container!
			this.onAppResize(this.getSize());
		},
		
		getSize : function() {
			return this.__size;
		},
		
		setSize : function() {
			
		},
		
		getVisibility : function(){
			return this.visibility;
		},
		
		setVisibility : function (){
			
		},
		
		closeConsoleApp : function (){
			alert("This gets called onClose, use it to clean up.");
		}
	}, {});
	
	clientConsoleApi.Class("AbstractSync", com.servicemax.client.lib.api.Object, {
		__syncManager : null,
		__constructor : function(){},
		run : function() {},
		getSyncManager : function(){
			return this.__syncManager;
		}
	}, {});
		
	clientConsoleApi.Class("AbstractDeliveryEngine", com.servicemax.client.lib.api.Object, {
		
		__constructor : function(){
			
		},
		
		initAsync : function(options){},
		
		run : function(options){},
		
		getInterface : function(){
			return this;
		}
		
	}, {});
	
	clientConsoleApi.Class("CompositionMetaModel", com.servicemax.client.lib.api.EventDispatcher, {
		_data : null, _parent : null, _children : null, isDisplayOnly : false,
		
		__constructor : function(data, parent, isDisplayOnly){
			this.__base();
			this._data = data;
			this._parent = parent;
			this._children = {};
			if(parent){
				this.isDisplayOnly = parent.isDisplayOnly;
			}else{
				this.isDisplayOnly = false;
			}
		},
		
		getChildNode : function(name){
			return this._children[name];
		},
		
		getData : function(){
			return this._data;
		},
		
		getRoot : function(){
			if(this._parent == null) 
				return this;
			else
				return this._parent.getRoot();
		},
		
		resolveDependencies : function(){}
		
	}, {});

})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\commands.js

(function(){
	var sfmconsolecommands = SVMX.Package("com.servicemax.client.sfmconsole.commands");
	
sfmconsolecommands.init = function(){
	// moved all the commands to delivery engines




     sfmconsolecommands.Class("GetUserInfo", com.servicemax.client.mvc.api.Command, {
        
        __constructor : function(){ this.__base(); },
        
        /**
         * 
         * @param request
         * @param responder
         */
        executeAsync : function(request, responder){
            this._executeOperationAsync(request, responder, {operationId : "SFMCONSOLE.GET_USERINFO"});
        }
    }, {});

     // TODO: Move this to responders.js
    sfmconsolecommands.Class("GetUserInfoResponder", com.servicemax.client.mvc.api.Responder, {
            __parent : null,
            __constructor : function(parent) { 
                this.__base(); 
                this.__parent = parent;
            },
            
            result : function(data) { 
                    this.__parent.onGetUserInfoCompleted(data);
            },
            
            fault : function(data) { 
                // TODO:
            }
            
        }, {});

};

})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\constants.js

(function(){
	
	var constantsImpl = SVMX.Package("com.servicemax.client.sfmconsole.constants");

constantsImpl.init = function(){
	constantsImpl.Class("Constants", com.servicemax.client.lib.api.Object, {
		__constructor : function(){}
	}, {
		PREF_LOGGING					: "LOGGING"
	});
}	
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\expressionbridge.js
/**
 * @description This file acts as a bridge between the snippet and the jsee.
 * 
 * @author Indresh MS
 */

(function(){
	
	var bridgeImpl = SVMX.Package("com.servicemax.client.sfmconsole.expressionbridge");
	var escapeDuringFormat = true;
bridgeImpl.init = function(){

	if(window.$EXPR == undefined || window.$EXPR == null) window.$EXPR = {};
	
	/////////////////////////////// CORE ///////////////////////////
	var orgNameSpace = SVMX.OrgNamespace;
	
	/**
	 * The core API method to evaluate the JS expression
	 * 
	 * @param expression String the expression that needs to be evaluated
	 * @param context Object the contextual data that this expression works on
	 * @param callId String the unique identifier assigned to a particular call. This serves as a index to the call back function
	 */
	$EXPR.SVMXEvalExpression = function(expression, context, callbackHandler, callBackContext){
		// simulate the asynchronous nature by executing the rest of the method on a timeout
		setTimeout(function(){
			var callbackContext = {
					callbackHandler : callbackHandler,
					callBackContext : callBackContext,
					handler : function(result){
						this.callbackHandler.call(this.callBackContext, result);		
					}
			};
			
			try{
			// trigger the evaluation
			$EXPR.executeExpression(
				expression, context, callbackContext.handler, callbackContext, true);
			}catch(e){
				$EXPR.Logger.error("Error while performing EVAL! Please check for syntax error in the JS snippet! =>" + e);
				callbackContext.handler(context);
			}
		}, 0);
	};
	
	$EXPR.showMessage = function(options){
		SVMX.getCurrentApplication().getApplicationMessageUIHandler().showMessage(options);
	};
	
	/////////////////////////// END CORE ///////////////////////////
	
	////////////////////// GET PRICE SPECIFIC CODING ///////////////
	$EXPR.getOrgNamespace = function(){
		var ons = getOrgNameSpace(orgNameSpace);
		// strip off the trailing /
		if(ons != "") ons = ons.substring(0, ons.length - 1);
		return ons;
	};
	
	$EXPR.getPricingDefinition = function(context, callback){
		var i, detailRecords = context.detailRecords, l = detailRecords.length, 
				allParts = new ListOfValueMap("PARTS"), allLabor = new ListOfValueMap("LABOR"), allLaborParts = new ListOfValueMap("LABORPARTS");
		for(var i = 0; i < l; i++){
			var records = detailRecords[i].records, j, recordslength = records.length;
			for(j = 0; j < recordslength; j++){
				var record = records[j].targetRecordAsKeyValue, length = record.length, k;
				var lineType = getItemForDetailRecordKey("Line_Type__c", record);
				if(lineType != null && lineType.value != null){
					if(lineType.value == "Parts"){
						var product = getItemForDetailRecordKey("Product__c", record);
						allParts.addToValues(product.value);
					}else if (lineType.value == "Labor"){
						var laborItem = getItemForDetailRecordKey("Activity_Type__c", record);
						allLabor.addToValues(laborItem.value);
						
						var laborPartItem = getItemForDetailRecordKey("Product__c", record);
						if(laborPartItem) allLaborParts.addToValues(laborPartItem.value);
					}
				}
			}
		}

		var recordIdItem = context.headerRecord.records[0].targetRecordId;
		var recordId = new SingleValueMap("WORKORDER", recordIdItem);
		
		var reqData = recordId.getStringAsXML() + allParts.getStringAsXML() + allLabor.getStringAsXML() + allLaborParts.getStringAsXML();
		
		var currencyIsoCodeItem = getItemForDetailRecordKey("CurrencyIsoCode", context.headerRecord.records[0].targetRecordAsKeyValue);
		if(currencyIsoCodeItem != ""){
			var currencyIsoCode = new SingleValueMap("WORKORDERCURRENCYISO", currencyIsoCodeItem.value);
			reqData += currencyIsoCode.getStringAsXML();
		}

		// get the sal service factory
		var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.sal.service.factory");
		servDef.getInstanceAsync({handler : function(service){
			var p = {type : "SOAP", endPoint : "INTF_WebServicesDef", nameSpace : $EXPR.getOrgNamespace()};
			var sm = service.createServiceManager(p);
			var plRequest = sm.createService();
			
			plRequest.bind("REQUEST_COMPLETED", function(evt){ 
				var xml = $.parseXml(evt.data, true);
		        var messageXML = xml.getFirstElementByTagName(
		            "message", "http://soap.sforce.com/schemas/class/"+ getOrgNameSpace(orgNameSpace) + "INTF_WebServicesDef");
		        var message = "";
		        
		        // FF Bug https://bugzilla.mozilla.org/show_bug.cgi?id=194231
		        if(messageXML.firstChild.textContent && messageXML.normalize) {
		        	messageXML.normalize(messageXML.firstChild);
		        	message = messageXML.firstChild.textContent;
		        } else if(messageXML.firstChild.nodeValue) {
		        	message = messageXML.firstChild.nodeValue;
		        }
		        // end FF bug
		        
		        var messageObj = $EXPR.toObject(message);
		        callback(messageObj);
			}, this);
			
			plRequest.callMethodAsync({methodName : "PCAL_getPricingDefinition_WS", data : reqData});
		}, context : {}});
	}
	
	//case get price
	$EXPR.getCasePricingDefinition = function(context, callback){
		var i, detailRecords = context.detailRecords, l = detailRecords.length, 
				allActivities = new ListOfValueMap("ACTIVITY");
		for(var i = 0; i < l; i++){
			var records = detailRecords[i].records, j, recordslength = records.length;
			for(j = 0; j < recordslength; j++){
				var record = records[j].targetRecordAsKeyValue, length = record.length, k;
				var lineType = getItemForDetailRecordKey("Type__c", record);
				if(lineType != null && lineType.value != null){
					if(lineType.value == "Activity"){
						var activityItem = getItemForDetailRecordKey("Activity_Type__c", record);
						allActivities.addToValues(activityItem.value);						
					}
				}
			}
		}

		var recordIdItem = context.headerRecord.records[0].targetRecordId;
		var recordId = new SingleValueMap("CASE", recordIdItem);
		
		var reqData = recordId.getStringAsXML() + allActivities.getStringAsXML();
		
		var currencyIsoCodeItem = getItemForDetailRecordKey("CurrencyIsoCode", context.headerRecord.records[0].targetRecordAsKeyValue);
		if(currencyIsoCodeItem != ""){
			var currencyIsoCode = new SingleValueMap("CASECURRENCYISO", currencyIsoCodeItem.value);
			reqData += currencyIsoCode.getStringAsXML();
		}

		// get the sal service factory
		var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.sal.service.factory");
		servDef.getInstanceAsync({handler : function(service){
			var p = {type : "SOAP", endPoint : "INTF_WebServicesDef", nameSpace : $EXPR.getOrgNamespace()};
			var sm = service.createServiceManager(p);
			var plRequest = sm.createService();
			
			plRequest.bind("REQUEST_COMPLETED", function(evt){ 
				var xml = $.parseXml(evt.data, true);
		        var messageXML = xml.getFirstElementByTagName(
		            "message", "http://soap.sforce.com/schemas/class/"+ getOrgNameSpace(orgNameSpace) + "INTF_WebServicesDef");
		        var message = "";
		        
		        // FF Bug https://bugzilla.mozilla.org/show_bug.cgi?id=194231
		        if(messageXML.firstChild && messageXML.firstChild.textContent && messageXML.normalize) {
		        	messageXML.normalize(messageXML.firstChild);
		        	message = messageXML.firstChild.textContent;
		        } else if(messageXML.firstChild && messageXML.firstChild.nodeValue) {
		        	message = messageXML.firstChild.nodeValue;
		        }
		        // end FF bug
		        
		        var messageObj = $EXPR.toObject(message);
		        callback(messageObj);
			}, this);
			
			plRequest.callMethodAsync({methodName : "PCAL_getCasePricingDefinition_WS", data : reqData});
		}, context : {}});
	}
	
	function ListOfValueMap(key){
		this.key = key;
		this.allValues = {};
		this.addToValues = function(value){ 
			if(!value) return;
			
			this.allValues[value] = value; 
		}
		
		this.getStringAsXML = function(){
			var template = "<valueMap><key>{0}</key>{1}</valueMap>";
			var valuesTemplate = "<values>{0}</values>";
			var i, values = "", ret = "";
			for(i in this.allValues){
				values += format(valuesTemplate, this.allValues[i]);
			}
			escapeDuringFormat = false;
			ret = format(template, this.key, values);
			escapeDuringFormat = true;
			return ret;
		}
	}
	
	function SingleValueMap(key, value){
		this.key = key;
		this.value = value;
		
		this.getStringAsXML = function(){
			var template = "<valueMap><key>{0}</key><value>{1}</value></valueMap>";
			ret = format(template, this.key, this.value);
			return ret;
		}
	}
	
	function updateSpecialCharacter(value)
	{
		if( value != undefined && value != null)
		{
			value = value.split("&").join("&amp;");
			value = value.split("<").join("&lt;");
		}	

		return value;
	}
	
	function format(){
		if(arguments.length == 0 ) return "";
		
		var formatted = arguments[0];	// first parameter is the string to be formated
		var splCharsReplacedStr;
		
	    for (var i = 1; i < arguments.length; i++) {
	        var regexp = new RegExp('\\{'+ (i - 1) +'\\}', 'gi');
	        
	        splCharsReplacedStr = arguments[i];
	        
	        if(escapeDuringFormat){
		        //check and update for any special characters.
		        splCharsReplacedStr = updateSpecialCharacter(arguments[i]);
	        }
	        
	        formatted = formatted.replace(regexp, splCharsReplacedStr);
	    }
	    return formatted;
	}
	
	function getItemForDetailRecordKey(key, record){
		
		//add ORGNAMESPACE__ only if the key ends with __c
		if(key.indexOf("__c", key.length - "__c".length) !== -1)
			key = orgNameSpace + "__" + key;
		
		var length = record.length, k, ret = "";
		for(k = 0; k < length; k++){
			var fld = record[k];
			if(fld.key == key){
				ret = fld;
				break;
			}
		}
		return ret;
	}
	
	function getOrgNameSpace(orgNameSpace){
		if(orgNameSpace != null && orgNameSpace != '') return orgNameSpace + "/";
		else return "";
	}
	////////////////// END GET PRICE SPECIFIC CODING ///////////////
};

})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\impl.js
(function(){
	
	var consoleImpl = SVMX.Package("com.servicemax.client.sfmconsole.impl");
	
	consoleImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
		
		__runMode : null,
		
		__constructor : function(){
			this.__base();
			this._logger = SVMX.getLoggingService().getLogger("CONSOLE-IMPL");
			
			// set up a static variable for global access
			consoleImpl.Module.instance = this;
			
			// set up the org namespace
			var ons = SVMX.getClient().getApplicationParameter("org-name-space");
			if(!ons || ons == "") ons = "SVMXC";
			
			SVMX.OrgNamespace = ons;
			// end set up namespace
			
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
		},
		
		beforeInitialize : function(){
			com.servicemax.client.sfmconsole.utils.init();
			com.servicemax.client.sfmconsole.commands.init();
			com.servicemax.client.sfmconsole.expressionbridge.init();
			com.servicemax.client.sfmconsole.constants.init();
		},
		
		initialize : function(){
			if(this.__runMode == "CONSOLE") com.servicemax.client.sfmconsole.ui.api.init();
		},
		
		afterInitialize : function(){
			var serv = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.preferences").getInstance();
			serv.addPreferenceKey(com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING);
		}
		
	}, {
		instance : null
	});
	
	consoleImpl.Class("Application", com.servicemax.client.lib.api.AbstractApplication,{
		
		__parent : null, __logger : null, __namedInstanceService  : null,
		__applicationStateHandler : null, __applicationErrorHandler : null,
		__applicationMessageUIHandler : null, __applicationQuickMessageHandler : null,
		 __consoleAppContainer : null, 
		 __eventBus: null,
		__processGroups : null,
		consoleAppConfigs : null,
		runningConsoleApps : null,
		processCount : 0,
		userData: null,

		__constructor : function(){
			this.__parent = consoleImpl.Module.instance;
			this.__logger = this.__parent.getLogger();
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
			
			this.__processGroups = [];
			this.consoleAppConfigs = {};
			this.runningConsoleApps = {};
		},
		
		triggerEvent : function(e) {
			SVMX.getLoggingService().getLogger("SFMConsoleApplication").warn("Trigger event : " + e.type);
			return this.__base(e);
		},
		
		beforeRun : function(options){ 
			// get the named instance service
			/*
			var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice")
			servDef.getInstanceAsync({
				handler : function(service){
					this.__namedInstanceService= service;
					options.handler.call(options.context); 
					
				}, 
				context:this
			});
*/
			// create the named default controller
			var ni = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance(); 
			//this.__eventBus = SVMX.create("com.servicemax.client.sfmdelivery.impl.SFMDeliveryEngineEventBus", {});
			
			// create the named default controller
			ni.createNamedInstanceAsync("CONTROLLER",{ handler : function(controller){
				// now create the named default model
				ni.createNamedInstanceAsync("MODEL",{ handler : function(model){
					controller.setModel(model);
					options.handler.call(options.context);
				}, context : this});
				
			}, context : this, additionalParams : { eventBus : this }});			
		},
		
		run : function(){
			this.__logger.info("Application runMode is " + this.__runMode);
			this.__logger.info("Great to be standing on my own legs!");
			this.__logger.info("Caching is => " + SVMX.isCachingEnabled());
			// log preference
			var serv = SVMX.getClient().getServiceRegistry()
						.getService("com.servicemax.client.preferences").getInstance(),
				key = com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING;
			
			var pref = serv.getPreference(key) || {enabled : true, constraint : "DEBUG"};
			SVMX.getLoggingService().setFilterPreference(pref);
			// end log preference
						
			if(this.__runMode == "CONSOLE"){
				this.__runConsole();
				var evt = SVMX.create(	"com.servicemax.client.lib.api.Event", 
					"SFMCONSOLE.GET_USERINFO", 
					this, {
						request : {}, 
						responder : SVMX.create("com.servicemax.client.sfmconsole.commands.GetUserInfoResponder", this)
					}
				);
				this.triggerEvent(evt);
			} 
			else {this.__runEngine();}
		},
		
		onGetUserInfoCompleted : function(inUserInfo) {
			this.setUserData(inUserInfo);
		},


		getRoot : function(){
			return this.__root;
		},

		__runConsole : function () {
			this.__runSync();
		},

		__discoverConsoleApps : function(){
			declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.consoleapp");
			definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length == 0){
				this.__logger.error("No console apps defined.");
				return;
			}
								
			var discovered = [];
			for(var i=0;i<definitions.length;i++){
				var key = definitions[i].config.app["id"];	
				this.consoleAppConfigs[key] = definitions[i].config;
				if(this.consoleAppConfigs[key].discover) {
					discovered.push(
						{	weight : definitions[i].config.positionWeight,
							context : this,"key":key,
							iconClass : this.consoleAppConfigs[key].icon['large-css-class'],
							tooltip : this.consoleAppConfigs[key]["tooltip"]
						});
				}
			}
			discovered.sort(function(a, b){return a.weight-b.weight;});
			for(var t=0;t<discovered.length;t++){
				discovered[t] && this.__root.addConsoleNavLaunchButton(
						discovered[t].context,discovered[t].key,discovered[t].iconClass, discovered[t].tooltip);
			}
		},
					
		launchConsoleApp : function (consoleAppId, options) {
			options = options || {};

			if(!this.__root){
				this.__root = SVMX.create("com.servicemax.client.sfmconsole.ui.api.RootContainer",{
					renderTo : SVMX.getDisplayRootId(), console : this
				});
				this.__discoverConsoleApps();
			}

			this.__hideAllAppWindows();
			
			var isAppBooted = false;
			if(this.runningConsoleApps[consoleAppId]) isAppBooted = true;

			if(isAppBooted && (consoleAppId != "sfmdelivery" && consoleAppId != "sfmtestapp")){
				this.runningConsoleApps[consoleAppId].consoleAppInstance.__container.show();
				this.__logger.info("Instance of App '" + consoleAppId + "' already running, showing...");				
			}
			else {
				if(!this.consoleAppConfigs[consoleAppId]) {
					this.__logger.error("Console App Not Defined: " + consoleAppId);
				}else {
					options.isClosable = false;
					if(this.consoleAppConfigs[consoleAppId].multiple)options.isClosable = true;
					var consoleAppContainer = this.__root.createConsoleAppContainer(consoleAppId,options);
					
					try {
						var consoleAppInstance = SVMX.create(this.consoleAppConfigs[consoleAppId].app["class-name"],this,
								consoleAppContainer,{size :{height : this.__root.getContentAreaMaxHeight()}});
						
						options.handler = function () {
							uniqueProcessIdentifier = this.consoleAppConfigs[consoleAppId].app["id"]+this.processCount;
							consoleAppContainer.setTitle(consoleAppInstance.getWindowTitle());
							if(consoleAppId == "sfmdelivery" || consoleAppId == "sfmtestapp") {
								options.uniqueProcessIdentifier = uniqueProcessIdentifier;
								options.group = consoleAppInstance.getGroup();
								options.text = consoleAppInstance.getWindowTitle();
								
								this.__manageProcessMenus(options);
							}else {
								uniqueProcessIdentifier = this.consoleAppConfigs[consoleAppId].app["id"];
							}
								
							this.runningConsoleApps[uniqueProcessIdentifier] = {"consoleAppInstance" : consoleAppInstance, "consoleAppContainer" : consoleAppContainer};
						};
						
						options.context = this;
						consoleAppInstance.start(options);
					} catch (err) {
						this.__logger.error(err);	
						return false;
					}
				}				
			}
		},
						
		__manageProcessMenus : function (options) {
			requestedGroup = options.group;
			newGroup = 1;
			for(var e = 0; e<=10; e++){
				if(this.__processGroups[e] == requestedGroup){
					newGroup = 0;
					break;
				}
			}
			
			if(newGroup == 1){
				this.__addProcessMenuGroup(requestedGroup,options);
				this.__processGroups.push(requestedGroup);
			}
			
			this.__addProcessToMenu(requestedGroup,options);
			this.processCount++;
		},
				
		__addProcessToMenu	: function (groupId,options) {
			this.__root.addProcessMenuItem(groupId,options);
		},
		
		__removeProcessFromMenu : function () {
			
		},
		
		__addProcessMenuGroup : function (groupName){
			this.__root.addProcessMenuGroup(groupName);
		},
		
		__removeProcessGroup : function () {
			
		},
		
		__runSync : function(){
			declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.synchronizer");
			definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length == 0 || SVMX.getClient().getApplicationParameter("sfmconsole-skip-sync")){
				return this.__syncCompleted();
			}
			
			var className = definitions[0].config.impl['class-name'];
			var syncImpl = SVMX.create(className, this);
			
			syncImpl.run({
				handler : this.__syncCompleted, context : this
			});
		},
		
		__syncCompleted : function(){
			this.__openFirstConsoleApp();
		},		
		
		addOverallProgressBar : function(){
		
		},
		
		closeConsoleApp : function(appWindowId,options){
			appInstance = this.runningConsoleApps[options.uniqueProcessIdentifier].consoleAppInstance;
			appInstance.__closeCallBack();
			// debugger;
		},
		
		__openFirstConsoleApp : function () {
			var consoleAppId = (SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start") || null);
			if(!consoleAppId || consoleAppId == ""){
				this.__logger.error("sfmconsole-runtime-start is not set in application config.");
				return false;
			}
			this.launchConsoleApp(consoleAppId,{}); // TODO :: Think about what to do with options, param.			
		},
						
		__hideConsoleApp : function(target) {
			target.hide();
		},
		
		__hideAllAppWindows : function () {
			for(container in this.runningConsoleApps){
				this.__hideConsoleApp(this.runningConsoleApps[container].consoleAppContainer);
			}			
		},		
		
		__destroyAppWindow : function () {
			
		},
		
		getUserData : function () {
			return this.userData;
		},
		
		setUserData : function (inData) {
			this.userData = inData;
			if (this.__root && this.__root.setUserData) this.__root.setUserData(inData);
		},
		
		showLoadMask : function(loadMaskTarget){
			this.__root.showLoading(loadMaskTarget);
		},
		
		hideLoadMask : function() {
			this.__root.hideLoading();
		},
		
		showAppWindow : function(appWindowId){
			this.__hideAllAppWindows();
			appInstance = this.runningConsoleApps[appWindowId].consoleAppInstance;
			appInstance.__container.show();
		},
		
		__appShow : function(consoleAppInstance) {
			this.__root.showApp(this.__consoleAppContainer);// call hide on container
			// consoleAppInstance.onShowApp();					
		},
		
		__appHide : function(consoleAppInstance) {
			this.__root.hideApp(this.__consoleAppContainer);
			// consoleAppInstance.onHideApp();
		},
		
		consoleResizeApp : function(consoleAppInstance) {
			this.__root.resizeApp(this.__consoleAppContainer);
			// consoleAppInstance.onResizeApp();			
		},
		
		
		
		
		
		
		
				
		__runEngine : function(){
			var client = SVMX.getClient();
			
			// set up the application title
			SVMX.setWindowTitle(client.getApplicationTitle());
			
			// look for the content providers
			// right now, only sfm delivery engine
			var declaration = client.getDeclaration("com.servicemax.client.sfmconsole.deliveryengine");
			var definitions = client.getDefinitionsFor(declaration);

			var sfmdefinition = null;
			var preferEngineId = SVMX.getClient().getApplicationParameter('sfmconsole-engine-id');
			if(preferEngineId){
				for(var i = 0; i < definitions.length; i++){
					if(preferEngineId == definitions[i].config.engine.id){
						sfmdefinition = definitions[i];
						break;
					}
				}
			}else{
				var sfmdefinition = definitions[0];
			}
			if(sfmdefinition == null){
				this.__logger.error("Cannot find any delivery engines."
					+ (preferEngineId && "("+preferEngineId+")"));
				return;
			}
			
			var sfmdefinition = definitions[0], engineConfig = sfmdefinition.config.engine;
			var engineClassName = engineConfig["class-name"];
			
			sfmdefinition.createInstanceAsnc(engineClassName, {handler : function(engine){
				
				// initialize the engine
				engine.initAsync({handler : function(){
					// start the engine
					engine.run({});
					
				}, context : this});
				
			}, context : this});
		},
		
		setApplicationStateHandler : function(stateHandler){
			
			// set up the application state handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application UI state will
			// be managed by SFMConsole itself.
			this.__applicationStateHandler = stateHandler;
		},
		
		getApplicationStateHandler : function(){
			return this.__applicationStateHandler;
		},
		
		setApplicationErrorHandler : function(errorHandler){
			
			// set up the application error handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application errors will
			// be managed by SFMConsole itself.
			this.__applicationErrorHandler = errorHandler;
		},
		
		getApplicationErrorHandler : function(){
			return this.__applicationErrorHandler;
		},
		
		setApplicationMessageUIHandler : function(messageUIHandler){
			
			// set up the application message UI handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application message UI will
			// be managed by SFMConsole itself.
			this.__applicationMessageUIHandler = messageUIHandler;
		},
		
		getApplicationMessageUIHandler : function(){
			return this.__applicationMessageUIHandler;
		},
		
		setApplicationQuickMessageHandler : function(quickMessageUIHandler){
			
			// set up the application quick message handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application quick messages will
			// be managed by SFMConsole itself.
			this.__applicationQuickMessageHandler = quickMessageUIHandler;
		},
		
		getApplicationQuickMessageHandler : function(){
			return this.__applicationQuickMessageHandler;
		}
	},{});
	
	consoleImpl.Class("CompositionEngine", com.servicemax.client.lib.api.Object,{
		__metamodel : null, __parent : null,
		
		__constructor : function(metamodel, parent){
			this.__metamodel = metamodel;
			this.__parent = parent;
		},
		
		compose : function(){
			var composition = this.__parent.__self.composition;
			return this.__composeInternal(this.__metamodel, composition, this.__parent);
		},
		
		__composeInternal : function(metamodel, composition, parent){
			var length = composition.length, i;
			for(i = 0; i < length; i++){
				var compositionItem = composition[i];
				var compositionMetamodel = metamodel.getChildNode(compositionItem.name);
				
				if(compositionMetamodel){
					var compositionItemObj = null,
						compositionItemClass = compositionItem.className;
					
					if(compositionMetamodel instanceof Array === false){
						compositionMetamodel = [compositionMetamodel];
					}
					var compositionMetamodelLength = compositionMetamodel.length, j, compositionMetamodelItem;
					for(j = 0; j < compositionMetamodelLength; j++){
						compositionMetamodelItem = compositionMetamodel[j];
						compositionItemObj = SVMX.create(compositionItemClass, {compositionMetamodel : compositionMetamodelItem});
						if(compositionItemObj.__self.composition != undefined){
							this.__composeInternal(compositionMetamodelItem, compositionItemObj.__self.composition, compositionItemObj);
						}
						parent.onCompositionChildCreate(compositionItemObj, compositionItem.name);
					}
				}
			}
		}
	}, {});
	
})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\patterns\api.js

(function(){
	
	var compsApi = SVMX.Package("com.servicemax.client.sfmconsole.ui.components.api");
	
	compsApi.Class("ViewComposite", com.servicemax.client.lib.api.EventDispatcher, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	compsApi.Class("ViewContainer", compsApi.ViewComposite, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	compsApi.Class("ViewPlan", compsApi.ViewContainer, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	compsApi.Class("ViewModel", com.servicemax.client.lib.api.EventDispatcher, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	compsApi.Class("ViewModelNode", com.servicemax.client.lib.api.EventDispatcher, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	
	compsApi.Class("ViewEngine", com.servicemax.client.lib.api.Object, {
		__constructor : function(){
			this.__base();
		}
	}, {});
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\ui\api.js
(function(){
	var _apiImpl = SVMX.Package("com.servicemax.client.sfmconsole.ui.api");
		
	_apiImpl.init = function(){
				
		Ext.define(
				"com.servicemax.client.sfmconsole.ui.api.RootContainer",{
				extend : "com.servicemax.client.ui.components.composites.impl.SVMXSection",
				alias: 'widget.sfmconsolecontainer',
				__logger : null,
				__console : null, __contentAreaMargin : 0,
				
				constructor : function(config){
					this.__logger = SVMX.getLoggingService().getLogger("SFMCONSOLE-ROOT");	
					this.__console = config.console;		
					
					config = Ext.apply({
	    	    	    closable	: false,
	    	    	    collapsible	: false,
	    	    	    id			: 'consoleMain',
	    	    	    height		: this.__getBodyHeight(),
	    	    	    layout		: "border",
	    	    	    autoScroll	: false
					}, config || {});
					
					this.__contentAreaMargin = 5;
					
					this.callParent([config]);
					this.run();

					this.onResize();
					SVMX.onWindowResize(this.onResize, this);
				},

				onResize : function(){
					var size = this.getAppViewSize();
					size.width = size.width - (this.__contentAreaMargin * 2);
					this.setWidth(size.width);
					this.setHeight(size.height);
					
					size.width = size.width - (this.__contentAreaMargin * 2);
					size.height = this.getContentAreaMaxHeight();
					if(this.consoleAppContentArea){
						this.consoleAppContentArea.setHeight(size.height);
						this.consoleAppContentArea.setWidth(size.width);
						this.consoleAppContentArea.doLayout();
					}
					
					if(this.__console && this.__console.runningConsoleApps){
						var apps = this.__console.runningConsoleApps;
						for(var i in apps){
							if(apps[i].consoleAppInstance){
								apps[i].consoleAppInstance.onAppResize(size);
							}
						}
					}
				},
				
				getContentAreaMaxHeight : function(){
					var size = this.getAppViewSize();
					size.height = size.height - this.consoleNavBar.getHeight() 
					- (this.__contentAreaMargin * 8);
					
					return size.height;
				},
				
				getAppViewSize : function(){
					var size = Ext.getBody().getViewSize();
					return size;
				},
				
				run : function () {
					this.consoleNavBar = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						region		: 'south',
			    		layout		: 'column', 
			    		collapsible	: false,
			    		dockedItems	: [
			    		    {
			    		    	xtype: 'toolbar',
			    		    	id : 'toolbar',
			    		    	ui:'sfm-console-toolbar',
			    		    	dock: 'bottom',
			    		    	items: [
			    		    	        {
			    		    	        	xtype	: "box",
			    	    	        		autoEl	: {tag: 'img', src:'modules/com.servicemax.client.sfmconsole/resources/themes/images/sfm-console-toolbar-blue/toolbar/servicemax_logo_sm.png'},
			    	    	        		width	: 55,
					    	        		height	: 52,
					    	        		margin	: 10
			    	    				},
			    	    				{xtype : 'tbfill'},
			    	    				{
			    	    					xtype	: 'buttongroup',
			    	    					id		: 'navbarButtonGroup'
			    	    				},
			    	    				{
			    	    					xtype	: "buttongroup",
			    	    					autoScroll:true,
			    	    					id		:"navbar"
			    	    				},
			    	    				{xtype	: 'tbfill'},
			    	    				{
			    	    					text	: '',
			    	    					id: "sfmconsoleusermenupanel",
			    	    					cls		: 'sfm-console-settings-menu-btn',
			    	    					menu	: {
			    	    						xtype: 'menu',
			    	    						plain: true,
			    	    						iconAlign: 'left',
			    	    						cls: 'sfm-console-settings-menu-items',
			    	    						items: [
				    	    						{
														text: 'Settings',
														displayText: 'Settings',
														tooltip: 'Settings',
														iconCls: 'sfm-console-setting-icon'
													}
												]
			    	    					}
			    	    				},
			    	    				{
			    		    	        	xtype	: "box",
			    		    	        	id :"syncIcon",
			    	    	        		autoEl	: {
			    	    	        			tag: 'img', 
			    	    	        			src:'modules/com.servicemax.client.sfmconsole/resources/themes/images/sfm-console-toolbar-classic/toolbar/syncAni.gif', 
			    	    	        			
			    	    	        		},
			    	    	        		width	: 20,
					    	        		height	: 10,
					    	        		margin	: 10,
					    	        	    listeners: {
					    	        	        el: {
					    	        	            click: function() {
					    	        	                alert("Firing Aggressive Sync.");
					    	        	            }
					    	        	        }
					    	        	    },
			    	    				},
			    	    			]
			    		    	}
			    		   ]	
						}
					);					
					
					Ext.getCmp('consoleMain').add(this.consoleNavBar);
				},
				
				setUserData: function(inUserData) {
                    if (!inUserData) return;
                    var panel = Ext.getCmp("sfmconsoleusermenupanel");
                    if (panel) panel.setText(inUserData.UserName);
                },

				addProcessMenuGroup : function (groupId) {
					this.btnObj = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton",{
							id		: groupId,
							margin	: 5,
							text	: groupId,
							scale   : "large",
							width   : 120,
							ui		: "sfm-console-toolbar-btn",
							menu    : {cls: "sfm-console-toolbar-btn-menu"}
					});
					Ext.getCmp('navbar').insert(0,this.btnObj);
					
					var processGroupWidth = Ext.getCmp('navbar').getWidth();
					var navbarWidth = Ext.getCmp('toolbar').getWidth();
					var allowedProcessGroupWidth = navbarWidth*.3;
					//alert(processGroupWidth);
					//alert(navbarWidth);
					//alert(allowedProcessGroupWidth);
					
					if(processGroupWidth > allowedProcessGroupWidth){
						Ext.getCmp('navbar').setWidth(allowedProcessGroupWidth);
						Ext.getCmp('navbar').setHeight(80);
					}
				},
				
				addProcessMenuItem : function (groupId,options) {
					var appWindowId = options.uniqueProcessIdentifier;
					var menuItem = {
							text	: options.text,
							id		: options.uniqueProcessIdentifier,
							handler	: function () {
								SVMX.getCurrentApplication().showAppWindow(appWindowId);
							}
					};
					
					if(Ext.getCmp(groupId)) Ext.getCmp(groupId).menu.add(menuItem);
				},
				
				removeProcessMenuItem : function (options) {
					Ext.getCmp(options.uniqueProcessIdentifier).hide();
					
				},
				
				addConsoleNavLaunchButton : function (parentObj, consoleAppId, btnCssClass, tooltip) { // TODO :: btnCssClass is a hack because I cannot get the ocnfigs array from partent Obj					
					tooltip = tooltip || "";
					this.toolbarButton = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton", {
						handler	: function() {
							parentObj.launchConsoleApp(consoleAppId,{});
						},
						iconCls : btnCssClass,
						margin	: 5,
						scale	: "large",
						ui		: "sfm-console-toolbar-btn",
						tooltip	: tooltip,
						style	: "overflow:hidden"
					});
					Ext.getCmp('navbarButtonGroup').add(this.toolbarButton);
					// alert(btnCssClass);
				},
				
				createConsoleAppContainer : function (consoleAppId,options) {
					var consoleAppContainer = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						collapsible : false,
						frame 		: true,
	    	    	    title		: options.windowTitle,
	    	    	    closable	: options.isClosable,
	    	    		region		: 'center',
	    	    		margin		: this.__contentAreaMargin
					});
					consoleAppContainer.on('close',function(){
						SVMX.getCurrentApplication().closeConsoleApp(consoleAppId,options);
						consoleAppContainer.hide();
						
						//SVMX.getCurrentApplication().consoleAppInstance.getCloseCallBack();
						
						Ext.getCmp(options.uniqueProcessIdentifier).destroy();
						
						groupLength = Ext.getCmp(options.group).menu.items.length;
						if(groupLength == 0)Ext.getCmp(options.group).destroy();
							
						var appId = (SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start") || null);
						SVMX.getCurrentApplication().launchConsoleApp(appId,{});
					});
					this.add(consoleAppContainer);
					
					return consoleAppContainer;
				},
				
				showLoading : function(loadMaskTarget) {
					if(!this.__loadMask) this.__loadMask = new com.servicemax.client.ui.components.utils.LoadMask({parent : this}); // TODO :: wrong parent, but works.
					this.__loadMask.show();
					this.__loadMask.setZIndex(50000);
				},
				
				hideLoading : function() {
					if(this.__loadMask != null) this.__loadMask.hide();				
				},				
				
				createConsoleAppContentArea : function () {
					this.consoleAppContentArea = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						alias		: 'widget.consoleAppContentArea',
						collapsible : false,
						id			: 'consoleAppContentArea',
						frame		: false,						
						header		: false,
						autoScroll	: false
					});
					this.add(this.consoleAppContentArea);
				},
				
				showApp : function(targetContainer) {
					
				},
				
				hideApp : function(targetContainer) {

				},
				
				resizeApp : function(targetContainer) {
			
				},					
				
				__getBodyHeight : function(){
					return Ext.getBody().getViewSize().height;
				}
			});
	};
})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\utils.js

(function(){
	var sfmconsoleutil = SVMX.Package("com.servicemax.client.sfmconsole.utils");
	
sfmconsoleutil.init = function(){
	
	/**
	 * Use this class when want to batch a series of MVC events. All the events are processed
	 * simultaneously. The result of all the calls are made available on the callback handler.
	 */
	sfmconsoleutil.Class("EventCollection", com.servicemax.client.lib.api.Object,{
		__eventBus : null, __eventItems : null, __stackIndex : 0, __handler : null, __context : null,
		__constructor : function(eventBus, items){
			this.__eventBus = eventBus;
			this.__eventItems = [];
			this.__stackIndex = 0;
			
			for(var i = 0; i < items.length; i++){
				var ei = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollectionItem", items[i]);
				
				this.__eventItems[i] = ei;
				this.__eventItems[i].itemParent = this;
			}
		},
		
		addEvent : function(evt){
			var ei = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollectionItem", evt);
				
			this.__eventItems[this.__eventItems.length] = ei;
			this.__eventItems[this.__eventItems.length - 1].itemParent = this;
		},
		
		triggerAll : function(handler, context){
			this.__handler = handler;
			this.__context = context;
			
			for(var i = 0; i < this.__eventItems.length; i++){
				this.__stackIndex++;
				this.__eventItems[i].trigger();
			}
		},
		
		handleResponse : function(eventItem){
			this.__stackIndex--;
			if(this.__stackIndex == 0){
				this.__handler.call(this.__context, this);
			}
		},
		
		getEventBus : function(){
			return this.__eventBus;
		},
		
		items : function(){
			return this.__eventItems;
		}
	},{});
	
	sfmconsoleutil.Class("EventCollectionItem", com.servicemax.client.mvc.api.Responder,{
		__event : null, response : null, itemParent : null,
		__constructor : function(event){
			this.__event = event;
			this.__event.data.responder = this;
		},
		
		trigger : function(){
			this.itemParent.getEventBus().triggerEvent(this.__event);
		},
		
		type : function(){
			return this.__event.type;
		},
		
		getEventObj : function(){
			return this.__event;
		},
		
		result : function(data) { 
			this.response = data;
			this.itemParent.handleResponse(this);
		},
		
		fault : function(data) { 
			var err = "Error during event <" + this.__event.type + ">";
			SVMX.getLoggingService().getLogger().error(err);
			throw new Error(err);
		}
	},{});
	
	/**
	 * This class is responsible for managing the translation related activities
	 * Right now, it looks at the structure from SVMXC.COMM_TagsDefinition
	 */
	sfmconsoleutil.Class("Translation", com.servicemax.client.lib.api.Object, {
		__data : null,
		__constructor : function(data){
			this.__data = {};
			if ($.isArray(data)) {
				var i, l = data.length;
				for(i = 0; i < l; i++){
					this.__data[data[i].Key] = data[i].Value;
				}
			} else {
				this.__data = data;
			}
		},
		
		T : function(key){
			return this.__data[key];
		}
	
	}, {});
	
	sfmconsoleutil.Class("TranslationService", com.servicemax.client.lib.api.Object, {
		__data : null,
		__constructor : function(){},
		
		setTranslationData : function(data){
			this.__data = data;
		},
		
		T : function(key){
			var ret = key;
			
			// There are cases when translation is accessed (ex, during load errors) before it is initialized.
			// So if translation is not available, return the key itself.
			if(this.__data){
				ret = this.__data.T(key);
			}
			
			return ret;
		}
	}, {});
};

})();

// end of file

