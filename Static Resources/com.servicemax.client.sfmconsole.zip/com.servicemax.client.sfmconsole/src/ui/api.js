(function(){
	var _apiImpl = SVMX.Package("com.servicemax.client.sfmconsole.ui.api");
		
	_apiImpl.init = function(){
				
		Ext.define(
				"com.servicemax.client.sfmconsole.ui.api.RootContainer",{
				extend : "com.servicemax.client.ui.components.composites.impl.SVMXSection",
				alias: 'widget.sfmconsolecontainer',
				__logger : null,
				__console : null, __contentAreaMargin : 0,
				
				constructor : function(config){
					this.__logger = SVMX.getLoggingService().getLogger("SFMCONSOLE-ROOT");	
					this.__console = config.console;		
					
					config = Ext.apply({
	    	    	    closable	: false,
	    	    	    collapsible	: false,
	    	    	    id			: 'consoleMain',
	    	    	    height		: this.__getBodyHeight(),
	    	    	    layout		: "border",
	    	    	    autoScroll	: false
					}, config || {});
					
					this.__contentAreaMargin = 5;
					
					this.callParent([config]);
					this.run();

					this.onResize();
					SVMX.onWindowResize(this.onResize, this);
				},

				onResize : function(){
					var size = this.getAppViewSize();
					size.width = size.width - (this.__contentAreaMargin * 2);
					this.setWidth(size.width);
					this.setHeight(size.height);
					
					size.width = size.width - (this.__contentAreaMargin * 2);
					size.height = this.getContentAreaMaxHeight();
					if(this.consoleAppContentArea){
						this.consoleAppContentArea.setHeight(size.height);
						this.consoleAppContentArea.setWidth(size.width);
						this.consoleAppContentArea.doLayout();
					}
					
					if(this.__console && this.__console.runningConsoleApps){
						var apps = this.__console.runningConsoleApps;
						for(var i in apps){
							if(apps[i].consoleAppInstance){
								apps[i].consoleAppInstance.onAppResize(size);
							}
						}
					}
				},
				
				getContentAreaMaxHeight : function(){
					var size = this.getAppViewSize();
					size.height = size.height - this.consoleNavBar.getHeight() 
					- (this.__contentAreaMargin * 8);
					
					return size.height;
				},
				
				getAppViewSize : function(){
					var size = Ext.getBody().getViewSize();
					return size;
				},
				
				run : function () {
					this.consoleNavBar = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						region		: 'south',
			    		layout		: 'column', 
			    		collapsible	: false,
			    		dockedItems	: [
			    		    {
			    		    	xtype: 'toolbar',
			    		    	id : 'toolbar',
			    		    	ui:'sfm-console-toolbar',
			    		    	dock: 'bottom',
			    		    	items: [
			    		    	        {
			    		    	        	xtype	: "box",
			    	    	        		autoEl	: {tag: 'img', src:'modules/com.servicemax.client.sfmconsole/resources/themes/images/sfm-console-toolbar-blue/toolbar/servicemax_logo_sm.png'},
			    	    	        		width	: 55,
					    	        		height	: 52,
					    	        		margin	: 10
			    	    				},
			    	    				{xtype : 'tbfill'},
			    	    				{
			    	    					xtype	: 'buttongroup',
			    	    					id		: 'navbarButtonGroup'
			    	    				},
			    	    				{
			    	    					xtype	: "buttongroup",
			    	    					autoScroll:true,
			    	    					id		:"navbar"
			    	    				},
			    	    				{xtype	: 'tbfill'},
			    	    				{
			    	    					text	: '',
			    	    					id: "sfmconsoleusermenupanel",
			    	    					cls		: 'sfm-console-settings-menu-btn',
			    	    					menu	: {
			    	    						xtype: 'menu',
			    	    						plain: true,
			    	    						iconAlign: 'left',
			    	    						cls: 'sfm-console-settings-menu-items',
			    	    						items: [
				    	    						{
														text: 'Settings',
														displayText: 'Settings',
														tooltip: 'Settings',
														iconCls: 'sfm-console-setting-icon'
													}
												]
			    	    					}
			    	    				},
			    	    				{
			    		    	        	xtype	: "box",
			    		    	        	id :"syncIcon",
			    	    	        		autoEl	: {
			    	    	        			tag: 'img', 
			    	    	        			src:'modules/com.servicemax.client.sfmconsole/resources/themes/images/sfm-console-toolbar-classic/toolbar/syncAni.gif', 
			    	    	        			
			    	    	        		},
			    	    	        		width	: 20,
					    	        		height	: 10,
					    	        		margin	: 10,
					    	        	    listeners: {
					    	        	        el: {
					    	        	            click: function() {
					    	        	                alert("Firing Aggressive Sync.");
					    	        	            }
					    	        	        }
					    	        	    },
			    	    				},
			    	    			]
			    		    	}
			    		   ]	
						}
					);					
					
					Ext.getCmp('consoleMain').add(this.consoleNavBar);
				},
				
				setUserData: function(inUserData) {
                    if (!inUserData) return;
                    var panel = Ext.getCmp("sfmconsoleusermenupanel");
                    if (panel) panel.setText(inUserData.UserName);
                },

				addProcessMenuGroup : function (groupId) {
					this.btnObj = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton",{
							id		: groupId,
							margin	: 5,
							text	: groupId,
							scale   : "large",
							width   : 120,
							ui		: "sfm-console-toolbar-btn",
							menu    : {cls: "sfm-console-toolbar-btn-menu"}
					});
					Ext.getCmp('navbar').insert(0,this.btnObj);
					
					var processGroupWidth = Ext.getCmp('navbar').getWidth();
					var navbarWidth = Ext.getCmp('toolbar').getWidth();
					var allowedProcessGroupWidth = navbarWidth*.3;
					//alert(processGroupWidth);
					//alert(navbarWidth);
					//alert(allowedProcessGroupWidth);
					
					if(processGroupWidth > allowedProcessGroupWidth){
						Ext.getCmp('navbar').setWidth(allowedProcessGroupWidth);
						Ext.getCmp('navbar').setHeight(80);
					}
				},
				
				addProcessMenuItem : function (groupId,options) {
					var appWindowId = options.uniqueProcessIdentifier;
					var menuItem = {
							text	: options.text,
							id		: options.uniqueProcessIdentifier,
							handler	: function () {
								SVMX.getCurrentApplication().showAppWindow(appWindowId);
							}
					};
					
					if(Ext.getCmp(groupId)) Ext.getCmp(groupId).menu.add(menuItem);
				},
				
				removeProcessMenuItem : function (options) {
					Ext.getCmp(options.uniqueProcessIdentifier).hide();
					
				},
				
				addConsoleNavLaunchButton : function (parentObj, consoleAppId, btnCssClass, tooltip) { // TODO :: btnCssClass is a hack because I cannot get the ocnfigs array from partent Obj					
					tooltip = tooltip || "";
					this.toolbarButton = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton", {
						handler	: function() {
							parentObj.launchConsoleApp(consoleAppId,{});
						},
						iconCls : btnCssClass,
						margin	: 5,
						scale	: "large",
						ui		: "sfm-console-toolbar-btn",
						tooltip	: tooltip,
						style	: "overflow:hidden"
					});
					Ext.getCmp('navbarButtonGroup').add(this.toolbarButton);
					// alert(btnCssClass);
				},
				
				createConsoleAppContainer : function (consoleAppId,options) {
					var consoleAppContainer = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						collapsible : false,
						frame 		: true,
	    	    	    title		: options.windowTitle,
	    	    	    closable	: options.isClosable,
	    	    		region		: 'center',
	    	    		margin		: this.__contentAreaMargin
					});
					consoleAppContainer.on('close',function(){
						SVMX.getCurrentApplication().closeConsoleApp(consoleAppId,options);
						consoleAppContainer.hide();
						
						//SVMX.getCurrentApplication().consoleAppInstance.getCloseCallBack();
						
						Ext.getCmp(options.uniqueProcessIdentifier).destroy();
						
						groupLength = Ext.getCmp(options.group).menu.items.length;
						if(groupLength == 0)Ext.getCmp(options.group).destroy();
							
						var appId = (SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start") || null);
						SVMX.getCurrentApplication().launchConsoleApp(appId,{});
					});
					this.add(consoleAppContainer);
					
					return consoleAppContainer;
				},
				
				showLoading : function(loadMaskTarget) {
					if(!this.__loadMask) this.__loadMask = new com.servicemax.client.ui.components.utils.LoadMask({parent : this}); // TODO :: wrong parent, but works.
					this.__loadMask.show();
					this.__loadMask.setZIndex(50000);
				},
				
				hideLoading : function() {
					if(this.__loadMask != null) this.__loadMask.hide();				
				},				
				
				createConsoleAppContentArea : function () {
					this.consoleAppContentArea = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						alias		: 'widget.consoleAppContentArea',
						collapsible : false,
						id			: 'consoleAppContentArea',
						frame		: false,						
						header		: false,
						autoScroll	: false
					});
					this.add(this.consoleAppContentArea);
				},
				
				showApp : function(targetContainer) {
					
				},
				
				hideApp : function(targetContainer) {

				},
				
				resizeApp : function(targetContainer) {
			
				},					
				
				__getBodyHeight : function(){
					return Ext.getBody().getViewSize().height;
				}
			});
	};
})();