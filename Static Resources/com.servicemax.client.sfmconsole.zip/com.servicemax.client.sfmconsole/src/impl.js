(function(){
	
	var consoleImpl = SVMX.Package("com.servicemax.client.sfmconsole.impl");
	
	consoleImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
		
		__runMode : null,
		
		__constructor : function(){
			this.__base();
			this._logger = SVMX.getLoggingService().getLogger("CONSOLE-IMPL");
			
			// set up a static variable for global access
			consoleImpl.Module.instance = this;
			
			// set up the org namespace
			var ons = SVMX.getClient().getApplicationParameter("org-name-space");
			if(!ons || ons == "") ons = "SVMXC";
			
			SVMX.OrgNamespace = ons;
			// end set up namespace
			
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
		},
		
		beforeInitialize : function(){
			com.servicemax.client.sfmconsole.utils.init();
			com.servicemax.client.sfmconsole.commands.init();
			com.servicemax.client.sfmconsole.expressionbridge.init();
			com.servicemax.client.sfmconsole.constants.init();
		},
		
		initialize : function(){
			if(this.__runMode == "CONSOLE") com.servicemax.client.sfmconsole.ui.api.init();
		},
		
		afterInitialize : function(){
			var serv = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.preferences").getInstance();
			serv.addPreferenceKey(com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING);
		}
		
	}, {
		instance : null
	});
	
	consoleImpl.Class("Application", com.servicemax.client.lib.api.AbstractApplication,{
		
		__parent : null, __logger : null, __namedInstanceService  : null,
		__applicationStateHandler : null, __applicationErrorHandler : null,
		__applicationMessageUIHandler : null, __applicationQuickMessageHandler : null,
		 __consoleAppContainer : null, 
		 __eventBus: null,
		__processGroups : null,
		consoleAppConfigs : null,
		runningConsoleApps : null,
		processCount : 0,
		userData: null,

		__constructor : function(){
			this.__parent = consoleImpl.Module.instance;
			this.__logger = this.__parent.getLogger();
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
			
			this.__processGroups = [];
			this.consoleAppConfigs = {};
			this.runningConsoleApps = {};
		},
		
		triggerEvent : function(e) {
			SVMX.getLoggingService().getLogger("SFMConsoleApplication").warn("Trigger event : " + e.type);
			return this.__base(e);
		},
		
		beforeRun : function(options){ 
			// get the named instance service
			/*
			var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice")
			servDef.getInstanceAsync({
				handler : function(service){
					this.__namedInstanceService= service;
					options.handler.call(options.context); 
					
				}, 
				context:this
			});
*/
			// create the named default controller
			var ni = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance(); 
			//this.__eventBus = SVMX.create("com.servicemax.client.sfmdelivery.impl.SFMDeliveryEngineEventBus", {});
			
			// create the named default controller
			ni.createNamedInstanceAsync("CONTROLLER",{ handler : function(controller){
				// now create the named default model
				ni.createNamedInstanceAsync("MODEL",{ handler : function(model){
					controller.setModel(model);
					options.handler.call(options.context);
				}, context : this});
				
			}, context : this, additionalParams : { eventBus : this }});			
		},
		
		run : function(){
			this.__logger.info("Application runMode is " + this.__runMode);
			this.__logger.info("Great to be standing on my own legs!");
			this.__logger.info("Caching is => " + SVMX.isCachingEnabled());
			// log preference
			var serv = SVMX.getClient().getServiceRegistry()
						.getService("com.servicemax.client.preferences").getInstance(),
				key = com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING;
			
			var pref = serv.getPreference(key) || {enabled : true, constraint : "DEBUG"};
			SVMX.getLoggingService().setFilterPreference(pref);
			// end log preference
						
			if(this.__runMode == "CONSOLE"){
				this.__runConsole();
				var evt = SVMX.create(	"com.servicemax.client.lib.api.Event", 
					"SFMCONSOLE.GET_USERINFO", 
					this, {
						request : {}, 
						responder : SVMX.create("com.servicemax.client.sfmconsole.commands.GetUserInfoResponder", this)
					}
				);
				this.triggerEvent(evt);
			} 
			else {this.__runEngine();}
		},
		
		onGetUserInfoCompleted : function(inUserInfo) {
			this.setUserData(inUserInfo);
		},


		getRoot : function(){
			return this.__root;
		},

		__runConsole : function () {
			this.__runSync();
		},

		__discoverConsoleApps : function(){
			declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.consoleapp");
			definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length == 0){
				this.__logger.error("No console apps defined.");
				return;
			}
								
			var discovered = [];
			for(var i=0;i<definitions.length;i++){
				var key = definitions[i].config.app["id"];	
				this.consoleAppConfigs[key] = definitions[i].config;
				if(this.consoleAppConfigs[key].discover) {
					discovered.push(
						{	weight : definitions[i].config.positionWeight,
							context : this,"key":key,
							iconClass : this.consoleAppConfigs[key].icon['large-css-class'],
							tooltip : this.consoleAppConfigs[key]["tooltip"]
						});
				}
			}
			discovered.sort(function(a, b){return a.weight-b.weight;});
			for(var t=0;t<discovered.length;t++){
				discovered[t] && this.__root.addConsoleNavLaunchButton(
						discovered[t].context,discovered[t].key,discovered[t].iconClass, discovered[t].tooltip);
			}
		},
					
		launchConsoleApp : function (consoleAppId, options) {
			options = options || {};

			if(!this.__root){
				this.__root = SVMX.create("com.servicemax.client.sfmconsole.ui.api.RootContainer",{
					renderTo : SVMX.getDisplayRootId(), console : this
				});
				this.__discoverConsoleApps();
			}

			this.__hideAllAppWindows();
			
			var isAppBooted = false;
			if(this.runningConsoleApps[consoleAppId]) isAppBooted = true;

			if(isAppBooted && (consoleAppId != "sfmdelivery" && consoleAppId != "sfmtestapp")){
				this.runningConsoleApps[consoleAppId].consoleAppInstance.__container.show();
				this.__logger.info("Instance of App '" + consoleAppId + "' already running, showing...");				
			}
			else {
				if(!this.consoleAppConfigs[consoleAppId]) {
					this.__logger.error("Console App Not Defined: " + consoleAppId);
				}else {
					options.isClosable = false;
					if(this.consoleAppConfigs[consoleAppId].multiple)options.isClosable = true;
					var consoleAppContainer = this.__root.createConsoleAppContainer(consoleAppId,options);
					
					try {
						var consoleAppInstance = SVMX.create(this.consoleAppConfigs[consoleAppId].app["class-name"],this,
								consoleAppContainer,{size :{height : this.__root.getContentAreaMaxHeight()}});
						
						options.handler = function () {
							uniqueProcessIdentifier = this.consoleAppConfigs[consoleAppId].app["id"]+this.processCount;
							consoleAppContainer.setTitle(consoleAppInstance.getWindowTitle());
							if(consoleAppId == "sfmdelivery" || consoleAppId == "sfmtestapp") {
								options.uniqueProcessIdentifier = uniqueProcessIdentifier;
								options.group = consoleAppInstance.getGroup();
								options.text = consoleAppInstance.getWindowTitle();
								
								this.__manageProcessMenus(options);
							}else {
								uniqueProcessIdentifier = this.consoleAppConfigs[consoleAppId].app["id"];
							}
								
							this.runningConsoleApps[uniqueProcessIdentifier] = {"consoleAppInstance" : consoleAppInstance, "consoleAppContainer" : consoleAppContainer};
						};
						
						options.context = this;
						consoleAppInstance.start(options);
					} catch (err) {
						this.__logger.error(err);	
						return false;
					}
				}				
			}
		},
						
		__manageProcessMenus : function (options) {
			requestedGroup = options.group;
			newGroup = 1;
			for(var e = 0; e<=10; e++){
				if(this.__processGroups[e] == requestedGroup){
					newGroup = 0;
					break;
				}
			}
			
			if(newGroup == 1){
				this.__addProcessMenuGroup(requestedGroup,options);
				this.__processGroups.push(requestedGroup);
			}
			
			this.__addProcessToMenu(requestedGroup,options);
			this.processCount++;
		},
				
		__addProcessToMenu	: function (groupId,options) {
			this.__root.addProcessMenuItem(groupId,options);
		},
		
		__removeProcessFromMenu : function () {
			
		},
		
		__addProcessMenuGroup : function (groupName){
			this.__root.addProcessMenuGroup(groupName);
		},
		
		__removeProcessGroup : function () {
			
		},
		
		__runSync : function(){
			declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.synchronizer");
			definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length == 0 || SVMX.getClient().getApplicationParameter("sfmconsole-skip-sync")){
				return this.__syncCompleted();
			}
			
			var className = definitions[0].config.impl['class-name'];
			var syncImpl = SVMX.create(className, this);
			
			syncImpl.run({
				handler : this.__syncCompleted, context : this
			});
		},
		
		__syncCompleted : function(){
			this.__openFirstConsoleApp();
		},		
		
		addOverallProgressBar : function(){
		
		},
		
		closeConsoleApp : function(appWindowId,options){
			appInstance = this.runningConsoleApps[options.uniqueProcessIdentifier].consoleAppInstance;
			appInstance.__closeCallBack();
			// debugger;
		},
		
		__openFirstConsoleApp : function () {
			var consoleAppId = (SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start") || null);
			if(!consoleAppId || consoleAppId == ""){
				this.__logger.error("sfmconsole-runtime-start is not set in application config.");
				return false;
			}
			this.launchConsoleApp(consoleAppId,{}); // TODO :: Think about what to do with options, param.			
		},
						
		__hideConsoleApp : function(target) {
			target.hide();
		},
		
		__hideAllAppWindows : function () {
			for(container in this.runningConsoleApps){
				this.__hideConsoleApp(this.runningConsoleApps[container].consoleAppContainer);
			}			
		},		
		
		__destroyAppWindow : function () {
			
		},
		
		getUserData : function () {
			return this.userData;
		},
		
		setUserData : function (inData) {
			this.userData = inData;
			if (this.__root && this.__root.setUserData) this.__root.setUserData(inData);
		},
		
		showLoadMask : function(loadMaskTarget){
			this.__root.showLoading(loadMaskTarget);
		},
		
		hideLoadMask : function() {
			this.__root.hideLoading();
		},
		
		showAppWindow : function(appWindowId){
			this.__hideAllAppWindows();
			appInstance = this.runningConsoleApps[appWindowId].consoleAppInstance;
			appInstance.__container.show();
		},
		
		__appShow : function(consoleAppInstance) {
			this.__root.showApp(this.__consoleAppContainer);// call hide on container
			// consoleAppInstance.onShowApp();					
		},
		
		__appHide : function(consoleAppInstance) {
			this.__root.hideApp(this.__consoleAppContainer);
			// consoleAppInstance.onHideApp();
		},
		
		consoleResizeApp : function(consoleAppInstance) {
			this.__root.resizeApp(this.__consoleAppContainer);
			// consoleAppInstance.onResizeApp();			
		},
		
		
		
		
		
		
		
				
		__runEngine : function(){
			var client = SVMX.getClient();
			
			// set up the application title
			SVMX.setWindowTitle(client.getApplicationTitle());
			
			// look for the content providers
			// right now, only sfm delivery engine
			var declaration = client.getDeclaration("com.servicemax.client.sfmconsole.deliveryengine");
			var definitions = client.getDefinitionsFor(declaration);

			var sfmdefinition = null;
			var preferEngineId = SVMX.getClient().getApplicationParameter('sfmconsole-engine-id');
			if(preferEngineId){
				for(var i = 0; i < definitions.length; i++){
					if(preferEngineId == definitions[i].config.engine.id){
						sfmdefinition = definitions[i];
						break;
					}
				}
			}else{
				var sfmdefinition = definitions[0];
			}
			if(sfmdefinition == null){
				this.__logger.error("Cannot find any delivery engines."
					+ (preferEngineId && "("+preferEngineId+")"));
				return;
			}
			
			var sfmdefinition = definitions[0], engineConfig = sfmdefinition.config.engine;
			var engineClassName = engineConfig["class-name"];
			
			sfmdefinition.createInstanceAsnc(engineClassName, {handler : function(engine){
				
				// initialize the engine
				engine.initAsync({handler : function(){
					// start the engine
					engine.run({});
					
				}, context : this});
				
			}, context : this});
		},
		
		setApplicationStateHandler : function(stateHandler){
			
			// set up the application state handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application UI state will
			// be managed by SFMConsole itself.
			this.__applicationStateHandler = stateHandler;
		},
		
		getApplicationStateHandler : function(){
			return this.__applicationStateHandler;
		},
		
		setApplicationErrorHandler : function(errorHandler){
			
			// set up the application error handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application errors will
			// be managed by SFMConsole itself.
			this.__applicationErrorHandler = errorHandler;
		},
		
		getApplicationErrorHandler : function(){
			return this.__applicationErrorHandler;
		},
		
		setApplicationMessageUIHandler : function(messageUIHandler){
			
			// set up the application message UI handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application message UI will
			// be managed by SFMConsole itself.
			this.__applicationMessageUIHandler = messageUIHandler;
		},
		
		getApplicationMessageUIHandler : function(){
			return this.__applicationMessageUIHandler;
		},
		
		setApplicationQuickMessageHandler : function(quickMessageUIHandler){
			
			// set up the application quick message handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application quick messages will
			// be managed by SFMConsole itself.
			this.__applicationQuickMessageHandler = quickMessageUIHandler;
		},
		
		getApplicationQuickMessageHandler : function(){
			return this.__applicationQuickMessageHandler;
		}
	},{});
	
	consoleImpl.Class("CompositionEngine", com.servicemax.client.lib.api.Object,{
		__metamodel : null, __parent : null,
		
		__constructor : function(metamodel, parent){
			this.__metamodel = metamodel;
			this.__parent = parent;
		},
		
		compose : function(){
			var composition = this.__parent.__self.composition;
			return this.__composeInternal(this.__metamodel, composition, this.__parent);
		},
		
		__composeInternal : function(metamodel, composition, parent){
			var length = composition.length, i;
			for(i = 0; i < length; i++){
				var compositionItem = composition[i];
				var compositionMetamodel = metamodel.getChildNode(compositionItem.name);
				
				if(compositionMetamodel){
					var compositionItemObj = null,
						compositionItemClass = compositionItem.className;
					
					if(compositionMetamodel instanceof Array === false){
						compositionMetamodel = [compositionMetamodel];
					}
					var compositionMetamodelLength = compositionMetamodel.length, j, compositionMetamodelItem;
					for(j = 0; j < compositionMetamodelLength; j++){
						compositionMetamodelItem = compositionMetamodel[j];
						compositionItemObj = SVMX.create(compositionItemClass, {compositionMetamodel : compositionMetamodelItem});
						if(compositionItemObj.__self.composition != undefined){
							this.__composeInternal(compositionMetamodelItem, compositionItemObj.__self.composition, compositionItemObj);
						}
						parent.onCompositionChildCreate(compositionItemObj, compositionItem.name);
					}
				}
			}
		}
	}, {});
	
})();