(function(){
	
	var clientConsoleApi = SVMX.Package("com.servicemax.client.sfmconsole.api");
	
	clientConsoleApi.Class("AbstractConsoleApp", com.servicemax.client.lib.api.Object, {
		__parent 			: null,
		__container 		: null,
		__size 				: [],
		__visibilty 		: null,
		__group 			: null,
		__windowTitle 		: null,
		__closeCallBack 	: null,
		__callbackContext 	: null,
		
		__constructor : function(parent,container,options){
			this.__parent = parent;
			this.__container = container;
			this.__size.width = options.size.width;
			this.__size.height = options.size.height;
		},
		
		start : function() {

		},
		
		onCanClose : function (callback) {
			callback(false);
		},
		
		onClose : function (options) {

		},
				
		showLoadMask : function(target) {
			this.__parent.showLoadMask(target || this.__container);
		},
		
		hideLoadMask : function(target) {
			this.__parent.hideLoadMask(target || this.__container);
		},
		
		getGroup : function () {
			return this.__group;
		},
		
		setWindowTitle : function(title){
			this.__windowTitle = title;
			this.__container.setTitle(this.__windowTitle);
		},
		
		getWindowTitle : function () {
			return this.__windowTitle;
		},
		
		getCloseCallBack : function () {
			return this.__closeCallBack;
		},
				
		getCallBackContext : function() {
			return this.__callbackContext;
		},
		
		setAppInfo : function (options) {
			options = options || {};
			
			this.__group = options.groupName;
			this.__windowTitle = options.windowTitle;
			this.__closeCallBack = options.closeCallback;
			this.__callbackContext = options.context;
		},
				
		getConsoleAppContainer : function() {
			return this.__container;
		},
		
		setRootContainer : function (container) {
			this.getConsoleAppContainer().add(container);

			// TODO: better way to size console app container!
			this.onAppResize(this.getSize());
		},
		
		getSize : function() {
			return this.__size;
		},
		
		setSize : function() {
			
		},
		
		getVisibility : function(){
			return this.visibility;
		},
		
		setVisibility : function (){
			
		},
		
		closeConsoleApp : function (){
			alert("This gets called onClose, use it to clean up.");
		}
	}, {});
	
	clientConsoleApi.Class("AbstractSync", com.servicemax.client.lib.api.Object, {
		__syncManager : null,
		__constructor : function(){},
		run : function() {},
		getSyncManager : function(){
			return this.__syncManager;
		}
	}, {});
		
	clientConsoleApi.Class("AbstractDeliveryEngine", com.servicemax.client.lib.api.Object, {
		
		__constructor : function(){
			
		},
		
		initAsync : function(options){},
		
		run : function(options){},
		
		getInterface : function(){
			return this;
		}
		
	}, {});
	
	clientConsoleApi.Class("CompositionMetaModel", com.servicemax.client.lib.api.EventDispatcher, {
		_data : null, _parent : null, _children : null, isDisplayOnly : false,
		
		__constructor : function(data, parent, isDisplayOnly){
			this.__base();
			this._data = data;
			this._parent = parent;
			this._children = {};
			if(parent){
				this.isDisplayOnly = parent.isDisplayOnly;
			}else{
				this.isDisplayOnly = false;
			}
		},
		
		getChildNode : function(name){
			return this._children[name];
		},
		
		getData : function(){
			return this._data;
		},
		
		getRoot : function(){
			if(this._parent == null) 
				return this;
			else
				return this._parent.getRoot();
		},
		
		resolveDependencies : function(){}
		
	}, {});

})();

// end of file