/**
 * ServiceMax UIControl/Component Library for SFMDelivery.
 * @class com.servicemax.client.sfmdelivery.ui.desktop.api
 * @author Vinod Kumar V
 * @since       : 1.0
 * @copyright 2013 ServiceMax, Inc.
 */
(function(){
    var appImpl = SVMX.Package("com.servicemax.client.sfmconsole.ui.web.api");
appImpl.init = function(){


    /**
     * The Console Application; while the class name is "Application", this is just one possible
     * instance of AbstractApplication which exists in the sfmconsole namespace.
     *
     * This application manages a set of "console applications" which are really just applets designed
     * to run within this container.
     * @class com.servicemax.client.sfmconsole.impl.Application
     * @super com.servicemax.client.lib.api.AbstractApplication
     */
    appImpl.Class("Application", com.servicemax.client.sfmconsole.impl.Application,{


        run : function(){
            this.__logger.info("Caching is => " + SVMX.isCachingEnabled());

            this.__loadTags(SVMX.proxy(this, function() {
                this.__runEngine();
            }));
        },

        __runEngine : function(){
            var client = SVMX.getClient();

            // set up the application title
            SVMX.setWindowTitle(client.getApplicationTitle());

            // look for the content providers
            // right now, only sfm delivery engine
            var declaration = client.getDeclaration("com.servicemax.client.sfmconsole.deliveryengine");
            var definitions = client.getDefinitionsFor(declaration);

            var sfmdefinition = null;
            var preferEngineId = SVMX.getClient().getApplicationParameter('sfmconsole-engine-id');
            if(preferEngineId){
                for(var i = 0; i < definitions.length; i++){
                    if(preferEngineId == definitions[i].config.engine.id){
                        sfmdefinition = definitions[i];
                        break;
                    }
                }
            }else{
                sfmdefinition = definitions[0];
            }
            if(sfmdefinition === null){
                this.__logger.error("Cannot find any delivery engines." + (preferEngineId && "("+preferEngineId+")"));
                return;
            }

            var engineConfig = sfmdefinition.config.engine;
            var engineClassName = engineConfig["class-name"];

            sfmdefinition.createInstanceAsync(engineClassName, {handler : function(engine){

                // initialize the engine
                engine.initAsync({handler : function(){
                    // start the engine
                    engine.run({});

                }, context : this});

            }, context : this});
        }

    },{});
};

})();
