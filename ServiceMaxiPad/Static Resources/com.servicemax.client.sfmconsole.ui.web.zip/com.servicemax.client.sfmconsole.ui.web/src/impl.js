/**
 * This file needs a description
 * @class com.servicemax.client.sfmconsole.ui.web.impl
 * @singleton
 * @author Michael
 *
 * @copyright 2013 ServiceMax, Inc.
 */
(function(){

    var consoleImpl = SVMX.Package("com.servicemax.client.sfmconsole.ui.web.impl");
    var TS;

    consoleImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
        __constructor : function(){
            this.__base();
            this._logger = SVMX.getLoggingService().getLogger("CONSOLE-IMPL");

            // set up a static variable for global access
            consoleImpl.Module.instance = this;

            // set up the org namespace
            var ons = SVMX.getClient().getApplicationParameter("org-name-space");
            if(!ons || ons === "") ons = "SVMXC";

            SVMX.OrgNamespace = ons;
            // end set up namespace
        },

        beforeInitialize : function(){
            com.servicemax.client.sfmconsole.ui.web.api.init();
        },

        initialize : function(){

        },

        afterInitialize : function(){
            var serv = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.preferences").getInstance();
            serv.addPreferenceKey(com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING);
        }

    }, {

        instance : null
    });


    var hackyPackage = SVMX.Package("com.servicemax.client.sfmconsole.ui.desktop.console");

    hackyPackage.Class("AbstractConsoleApp", com.servicemax.client.lib.api.Object, {});

})();