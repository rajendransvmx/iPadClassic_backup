/**
 * 
 */

(function(){
	
	var instUtils = SVMX.Package("com.servicemax.client.installigence.utils.impl");
	
	instUtils.Class("Util", com.servicemax.client.lib.api.Object, {}, {
		
		/*
			Method Description : this method will generate 32 character random string. 
			We will use this string for localId or transient Id for ProductIQ.
		*/
		getLocalId : function(){ 
			var ramdomString = this.getRandomString();
			var lengh = 16;
		    return ramdomString.replace(/[ab]/g, function(character) {
		        var randomNumber = Math.random()*lengh|0, value = character === 'a' ? randomNumber : (randomNumber&0x3|0x8);
		        return value.toString(lengh);
		    });
		},

		/*
			Method Description : this method will return 32 character string.
		*/
		getRandomString :function() { 
			return 'aaaaaaaa-aaaa-4aaa-baaa-aaaaaaaaaaaa';
		}
	});
	
})();

// end of file