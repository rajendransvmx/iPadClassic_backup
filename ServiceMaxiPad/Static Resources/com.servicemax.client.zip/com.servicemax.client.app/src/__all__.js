// Code: C:\var\lib\jenkins\workspace\SVMX_UIFW_BASEORG\src\modules\com.servicemax.client.app\src\impl.js
/**
 * This file needs a description 
 * @class com.servicemax.client.app.impl
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */
(function(){
	
	var appImpl = SVMX.Package("com.servicemax.client.app.impl");
	
	appImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
		
		__constructor : function(){
			this.__base();
			this._logger = SVMX.getLoggingService().getLogger("APP-IMPL");
			
			// set up the org namespace
			var ons = SVMX.getClient().getApplicationParameter("org-name-space");
			if(!ons || ons == "") ons = "SVMXC";

			SVMX.OrgNamespace = ons;
			// end set up namespace
			
			// set up a static variable for global access
			appImpl.Module.instance = this;
		},
		
		beforeInitialize : function(){
			
		},
		
		initialize : function(){
			
		},
		
		afterInitialize : function(){
			
		}
		
	}, {
		instance : null
	});
	
	appImpl.Class("Application", com.servicemax.client.lib.api.AbstractApplication,{
		
		__parent : null, __logger : null, __namedInstanceService : null, __controller : null,
		__constructor : function(){
			this.__parent = appImpl.Module.instance;
			this.__logger = this.__parent.getLogger();
		},
		
		run : function(){
			this.__logger.info("Default application is running");
			
			// inform the hooks
			var apploadhandler = SVMX.getClient().getApplicationParameter("onappload-handler");
			if(apploadhandler){
				if(apploadhandler.context) apploadhandler.handler.call(apploadhandler.context);
				else apploadhandler.handler();
			}
		}
		
	},{});
})();

