/**
 *  Technical Attributes.
 * @class com.servicemax.client.insralligence.admin.technicalAttributes.js
 * @author Madhusudhan HK
 *
 * @copyright 2016 ServiceMax, Inc.
 **/
 (function(){

	var technicalAttributes = SVMX.Package("com.servicemax.client.installigence.admin.technicalAttributes");
	technicalAttributes.init = function() {

// TechnicalAttributes class start.
			Ext.define("com.servicemax.client.installigence.admin.TechnicalAttributes", {
			extend: "com.servicemax.client.installigence.ui.components.SVMXPanel",

	         __root: null,
	         constructor: function(config) {
	        	var me = this;
	        	this.__root = config.root;
	        	config = config || {};
				config.title = $TR.TECHNICAL_ATTRIBUTES;
				config.id = "technicalAttributes";

				me.technicalAttributesList = SVMX.create('com.servicemax.client.installigence.admin.ListAllTechnicalAttributes',{
					metadata: config.metadata,hidden:false,id:'technicalAttributesListPanel',
					root: config.root, parentContext:this
				});

				me.createNewTATemplate = SVMX.create('com.servicemax.client.installigence.admin.CreateNewTechnicalAttributesTemplate',{
					metadata: config.metadata,hidden:true,id:'createNewTATemplatePanel', autoScroll:true,layout: 'fit',
					root: config.root,  parentContext:this
				});
				config.items = [me.technicalAttributesList,me.createNewTATemplate];

	        	 this.callParent([config]);
	         },

	        getTAtemplateConfigurationDetails: function(){
	        	
	        	var templateConfiguration = {};
	        	var createNewTATemplateElt = Ext.getCmp("createNewTATemplatePanel");
	        	if(createNewTATemplateElt.isVisible() == false) return templateConfiguration;	
	        	
				
				var isInValideTemplate = (this.createNewTATemplate.productReferenceField.selectedProduct == null && this.createNewTATemplate.productFamilyComboBox.getSelectedRecord().data.fieldLabel === "--None--" && this.createNewTATemplate.productLineComboBox.getSelectedRecord().data.fieldLabel === "--None--" );
				
 
				if(!createNewTATemplateElt.isVisible() == false && isInValideTemplate == false){
					if(this.createNewTATemplate.__currentTemplateRecord.data === undefined){
						
					}else{
						templateConfiguration.templateId = this.createNewTATemplate.__currentTemplateRecord.data.Id;
					}
					
					templateConfiguration.templateTitle = this.createNewTATemplate.titleTextFields.value;
					templateConfiguration.templateDescription = Ext.getCmp("taTemplateDescriptionField").getValue();
					templateConfiguration.templateApplicationCriteria = this.__getApplicationCriteriaForTemplate();
					templateConfiguration.templateAttributesDetails = this.__getTemplateAttributesDetails();
					 
					templateConfiguration.templateAttributesType = 'TECHNICAL';
					templateConfiguration.templateIsActive = 'true';
				}
				console.log('templateConfiguration:' + templateConfiguration);
				return templateConfiguration;
	        	
	        },

	        __getApplicationCriteriaForTemplate: function(){
	        	
	        	var allApplicationCriteria = [];
	        	

	        	//if(this.createNewTATemplate.__currentApplicationCriteriaRecords.length > 0){
				//		applicationCriteria.criteriaId = this.createNewTATemplate.__currentApplicationCriteriaRecords[0].Id;
				//	}
					if(this.createNewTATemplate.productReferenceField.selectedProduct !== null){
						 
	        			var applicationCriteriaForProduct = {};
	        			
						
						applicationCriteriaForProduct.productId = this.createNewTATemplate.productReferenceField.selectedProduct.Id;		
						
						if(this.createNewTATemplate.productReferenceField.recordIndex)
							applicationCriteriaForProduct.criteriaId = this.createNewTATemplate.productReferenceField.recordIndex;
						
						allApplicationCriteria.push(applicationCriteriaForProduct);
						applicationCriteriaForProduct = null;
						
					}else{

						if(this.createNewTATemplate.productReferenceField.recordIndex)
							this.createNewTATemplate.deletedTACriteriaIds.push(this.createNewTATemplate.productReferenceField.recordIndex);

					}
	        	
	        		if(this.createNewTATemplate.productFamilyComboBox.getSelectedRecord().data.fieldLabel !== "--None--"){
	        			var applicationCriteriaForFamily = {};
	        			
	        			
	        			applicationCriteriaForFamily.productFamily = this.createNewTATemplate.productFamilyComboBox.getSelectedRecord().data.fieldLabel;		
	        			
	        			if(this.createNewTATemplate.productFamilyComboBox.recordIndex)
							applicationCriteriaForFamily.criteriaId = this.createNewTATemplate.productFamilyComboBox.recordIndex;
	        			
	        			allApplicationCriteria.push(applicationCriteriaForFamily);
	        			applicationCriteriaForFamily = null;
	        			
	        		}else{

						if(this.createNewTATemplate.productFamilyComboBox.recordIndex)
							this.createNewTATemplate.deletedTACriteriaIds.push(this.createNewTATemplate.productFamilyComboBox.recordIndex);

					}
	        	
	        		if(this.createNewTATemplate.productLineComboBox.getSelectedRecord().data.fieldLabel !== "--None--"){
	        			var applicationCriteriaLine = {};
	        			
	        			
	        			applicationCriteriaLine.productLine   = this.createNewTATemplate.productLineComboBox.getSelectedRecord().data.fieldLabel;		
	        			
	        			if(this.createNewTATemplate.productLineComboBox.recordIndex)
							applicationCriteriaLine.criteriaId = this.createNewTATemplate.productLineComboBox.recordIndex;
	        			
	        			allApplicationCriteria.push(applicationCriteriaLine);
	        			applicationCriteriaLine = null;
	        			
	        		}else{

						if(this.createNewTATemplate.productLineComboBox.recordIndex)
							this.createNewTATemplate.deletedTACriteriaIds.push(this.createNewTATemplate.productLineComboBox.recordIndex);

					}
	        	
	        	//applicationCriteria.productCode   = '';

	        	return allApplicationCriteria;

	        },
	        __getTemplateAttributesDetails: function(){
	        	var attributesDetails ;
	        	attributesDetails = {};
	        	attributesDetails.picklist = {};
	        	attributesDetails.fields   = this.__getCategoryDetails();

	        	var attributesDetailsInString = JSON.stringify(attributesDetails);
	        	return attributesDetailsInString;
	        },

	        __getCategoryDetails: function(){

	        	var categoryDetails = [];
	        	var l = this.createNewTATemplate.__sections.length, filedDetails, currentSection;
	        	var allSections = this.createNewTATemplate.__sections;

	        	for(var i = 0; i<l; i++){
	        		filedDetails = {};
	        		currentSection = allSections[i];
	        		filedDetails.title = currentSection.titleTextFields.value;
	        		filedDetails.description = Ext.getCmp('textareafield'+currentSection.id).getValue();
	        		filedDetails.technicalAttributes = this.__getAllTechnicalAttributesDetailsInCategory(currentSection);
	        		
	        		categoryDetails.push(filedDetails);

	        	}


	        	return categoryDetails;
	        },

	        __getAllTechnicalAttributesDetailsInCategory: function(section){
	        	var items = section.attributesGrid.store.data.items;
	        	var l = items.length, field = {}, allFields = [];
	        	for(var i=0; i<l; i++){
	        		field = {};
	        		field.label = items[i].data.label;
	        		//field.value = items[i].data.value;
	        		field.type = items[i].data.type;
	        		field.sequence = i
	        		field.defaultValue = items[i].data.defaultValue;
	        		field.unit  = items[i].data.unit;
	        		field.readOnly = items[i].data.readOnly;
	        		//field.format = items[i].data.format;
	        		field.format = section.attributesGrid.formatTypeStore.findRecord("label", items[i].data.format).get("value");
	        		allFields.push(field);
	        	}
	        	
	        	return allFields;
	        },
	        
	        refreshView: function(){

						this.technicalAttributesList.setVisible(true);
						this.createNewTATemplate.setVisible(false);
						this.createNewTATemplate.resetPage();
						//this.technicalAttributesList.updateTemplateList();
	        },

	       loadTemplatePage: function(record){
	        			this.technicalAttributesList.setVisible(false);
						this.createNewTATemplate.setVisible(true);
						this.createNewTATemplate.reloadTemplatePage(record);

	        },

	        shouldAllowToSaveConfigurationData: function(){

	        	if(this.createNewTATemplate.productFamilyComboBox.getSelectedRecord() == null) return true;
	        	var createNewTATemplateElt = Ext.getCmp("createNewTATemplatePanel");
				var isInValideTemplate = ((this.createNewTATemplate.productReferenceField.selectedProduct == null && this.createNewTATemplate.productFamilyComboBox.getSelectedRecord().data.fieldLabel === "--None--" && this.createNewTATemplate.productLineComboBox.getSelectedRecord().data.fieldLabel === "--None--" ) || !Boolean(this.createNewTATemplate.titleTextFields.value.length));
				if(!createNewTATemplateElt.isVisible()){
					return true;
				}else if(createNewTATemplateElt.isVisible() && isInValideTemplate == true){
					Ext.Msg.alert({
                    title : 'Error', 
                    message : 'Please fill required fields in Technical Attributes template',
                    buttonText : { ok : $TR.OK_BTN },
                    closable : false
                });
					return false;
				}else{
					return true;
				}
	        }
	        
	     });
// TechnicalAttributes class end.

// ListAllTechnicalAttributes class start.
		Ext.define("com.servicemax.client.installigence.admin.ListAllTechnicalAttributes", {
			extend: "com.servicemax.client.installigence.ui.components.SVMXPanel",

			__meta : null,
			__isTechnicalAttributesEnabled : null,
			__grid : null,
			__store : null,
			__root: null,
			__parentContext: null,
			deletedTemplateIds: null,
			constructor: function(config) {
				var me = this;
				me.deletedTemplateIds = [];
				this.__registerForDidProfileSelectCall();
				this.__root = config.root;
				this.__parentContext = config.parentContext;
				var profiles = config.metadata.svmxProfiles;
				var profilesData = [{profileId: "--None--", profileName: $TR.NONE}];
				var iProfile = 0, iProfileLength = profiles.length;
				for(iProfile = 0; iProfile < iProfileLength; iProfile++) {
					if(profiles[iProfile].profileId !== 'global'){
						profilesData.push(profiles[iProfile]);
					}
				}

				me.showProfiles = config.root.showProfiles;
				
				 me.enableTAcheckbox = SVMX.create("com.servicemax.client.installigence.ui.components.Checkbox", {
                    boxLabel : $TR.ENABLE_TECHNICAL_ATTRIBUTES,
                    scope: this,
                    handler : function(field, value){
                        this.__shouldEnableTechnicalAttributesForProfile(value,this);
                    }
                });

				  me.searchTAtemplateTextBox = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXTextSearch',{
					width: '40%',
					cls: 'search-textfield',
					emptyText : $TR.SEARCH_EMPTY_TEXT,
					listeners: {
	                    change: {
	                        fn: me.__onTextFieldChange,
	                        scope: this,
	                        buffer: 500
	                    }
	               }
				});

				  me.addTAtemplateButton = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXButton',{
					
					ui: 'svmx-toolbar-icon-btn',
					scale: 'large',
					iconCls: 'plus-icon',
					tooltip: 'Add',
					disabled: false,
					rigion:'right',
					handler : function(){

						var taListElt = Ext.getCmp("technicalAttributesListPanel");
						var createNewTATemplateElt = Ext.getCmp("createNewTATemplatePanel");


						taListElt.setVisible(false);
						createNewTATemplateElt.setVisible(true);

					}
				});
				 //Create the grid for template list.
				 var cols = [ SVMX.OrgNamespace +'__SM_Title__c', SVMX.OrgNamespace +'__SM_Description__c'], columnsDisplayLabel = [$TR.TEMPLATE_NAME,$TR.TEMPLATE_DESCRIPTION], l = cols.length, me = this;
				 var fields = [];
				 for(i = 0; i < l; i++){ fields.push(cols[i]); }
				 	var store = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', 
				 							{ fields:fields, 
				 							  data:[]
				 							});

				 var gridColumns = [];
				 gridColumns.push({
						
						xtype: 'actioncolumn',
						width: 50,
						items: [{
									iconCls: 'delet-icon',
									tooltip: 'Delete'
								}],
						handler: function(grid, rowIndex, colIndex) {
							var gridStore = grid.getStore();
		                    var rec = gridStore.getAt(rowIndex);
		                    gridStore.remove(rec);	
		                    me.deletedTemplateIds.push(rec.data.Id);

		                }		
					});
				 for (var i = 0; i < l; i++) {
                    gridColumns.push({ text : columnsDisplayLabel[i],handler : function(){
                    										},
                    							dataIndex :  cols[i], flex : 1 });
                }
                
                 me.templateGrid = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXGrid', {
        	    store: store,layout: 'fit',height:400,
        	    
        	    columns: gridColumns, flex : 1, width: "100%",viewConfig: {
                        listeners: {
                            select: function(dataview, record, item, index, e) {
                               me.__parentContext.loadTemplatePage(record); 
                            }
                        }
                    }
        	});

                 me.otherOptionsToolbar = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXToolbar',{
					style: 'border-width: 0',
					width: '100%'
				});	
                 me.otherOptionsToolbar.add(me.searchTAtemplateTextBox);
                 me.otherOptionsToolbar.add('->');
                 me.otherOptionsToolbar.add(me.addTAtemplateButton);
                /* me.otherOptionsToolbar.add({ 
									xtype: 'button', 
									text: "Previous", 
									handler : function(){
					       			
					       			}
					       		});
                 me.otherOptionsToolbar.add({ 
									xtype: 'button',
									text: "Next", 
									handler : function(){
					       		
					       			}
					       		});
				*/


				 config.items = [me.enableTAcheckbox,me.otherOptionsToolbar,me.templateGrid];

					       	me.__store = store;

				this.callParent([config]);
				//me.__reloadTemplateGrid();
				me.updateTemplateList();
				
			},
			
			__onTextFieldChange: function() {
	        	var value = this.searchTAtemplateTextBox.getValue();
	        	this.templateGrid.search(value);
	        	
	         },
			__reloadTemplateGrid: function(data){
				// Hardcoded template list.
				
				//var data = [{'templateID':'213214','templateName':'Batteries 2006','templateDescription':'Configuration for Batteries manufactured in 2006'},{'templateID':'213214','templateName':'Circute Z-cross','templateDescription':'Configuration for Z-cross'},{'templateID':'213214','templateName':'Voltage 300KV','templateDescription':'Configuration for IBs Voltage 300KV'},{'templateID':'213214','templateName':'Batteries 2006','templateDescription':'Configuration for Batteries manufactured in 2006'},{'templateID':'213214','templateName':'Circute Z-cross','templateDescription':'Configuration for Z-cross'},{'templateID':'213214','templateName':'Voltage 300KV','templateDescription':'Configuration for IBs Voltage 300KV'},{'templateID':'213214','templateName':'Batteries 2006','templateDescription':'Configuration for Batteries manufactured in 2006'},{'templateID':'213214','templateName':'Circute Z-cross','templateDescription':'Configuration for Z-cross'},{'templateID':'213214','templateName':'Voltage 300KV','templateDescription':'Configuration for IBs Voltage 300KV'},{'templateID':'213214','templateName':'Batteries 2006','templateDescription':'Configuration for Batteries manufactured in 2006'},{'templateID':'213214','templateName':'Circute Z-cross','templateDescription':'Configuration for Z-cross'},{'templateID':'213214','templateName':'Voltage 300KV','templateDescription':'Configuration for IBs Voltage 300KV'},{'templateID':'213214','templateName':'Batteries 2006','templateDescription':'Configuration for Batteries manufactured in 2006'},{'templateID':'213214','templateName':'Circute Z-cross','templateDescription':'Configuration for Z-cross'},{'templateID':'213214','templateName':'Voltage 300KV','templateDescription':'Configuration for IBs Voltage 300KV'},{'templateID':'213214','templateName':'Batteries 2006','templateDescription':'Configuration for Batteries manufactured in 2006'},{'templateID':'213214','templateName':'Circute Z-cross','templateDescription':'Configuration for Z-cross'},{'templateID':'213214','templateName':'Voltage 300KV','templateDescription':'Configuration for IBs Voltage 300KV'},{'templateID':'213214','templateName':'Batteries 2006','templateDescription':'Configuration for Batteries manufactured in 2006'},{'templateID':'213214','templateName':'Circute Z-cross','templateDescription':'Configuration for Z-cross'},{'templateID':'213214','templateName':'Voltage 300KV','templateDescription':'Configuration for IBs Voltage 300KV'}];
				this.__store.loadData(data);
				SVMX.getCurrentApplication().unblockUI();
               

			},

			__shouldEnableTechnicalAttributesForProfile: function(isEnabled,context){
				var selecetedProfile = context.showProfiles.getSelectedRecord();
				if(selecetedProfile.getData().isTechnicalAttributesEnabled == undefined){
					selecetedProfile.set("isTechnicalAttributesEnabled", "false");
				}

				selecetedProfile.set("isTechnicalAttributesEnabled", isEnabled);


			},
			__updateEnableTAcheckboxValue:function(){
				
				var selecetedProfile = this.showProfiles.getSelectedRecord();
				if(selecetedProfile.getData().isTechnicalAttributesEnabled == undefined || selecetedProfile.getData().isTechnicalAttributesEnabled === "false" ){
					this.enableTAcheckbox.setValue(false);
				}else if(selecetedProfile.getData().isTechnicalAttributesEnabled === "true"){
					this.enableTAcheckbox.setValue(true);
				}
				
			},
			__registerForDidProfileSelectCall: function(){
				var me = this;
           SVMX.getClient().bind("SELECTED_PROFILE_CALL", function(evt){

              	 var data = SVMX.toObject(evt.data);
            	 var combo = evt.target.result.combo;
            	 var record = evt.target.result.record;
          	 	this.__updateEnableTAcheckboxValue();	
				this.showProfiles.setRawValue(record.get('profileName'));

           }, this); 
			},
			updateTemplateList: function(){
				SVMX.getCurrentApplication().blockUI();
				var params = {};
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
					"INSTALLIGENCEADMIN.GET_ALL_ATTRIBUTESTEMPLATES" , this, 
					{request : { context : this, handler : this.__reloadTemplateGrid, text : params.text}});
			SVMX.getCurrentApplication().getEventBus().triggerEvent(evt);
			}



		});

// ListAllTechnicalAttributes class end.

// CreateNewTechnicalAttributesTemplate class start.
	
	Ext.define("com.servicemax.client.installigence.admin.CreateNewTechnicalAttributesTemplate", {
			extend: "com.servicemax.client.installigence.ui.components.SVMXPanel",

			__sections:null,
			__currentTemplateRecord: null,
			__currentApplicationCriteriaRecords: null,
			deletedTACriteriaIds:null,

			constructor: function(config) {
				var me = this;
				me.__sections = [];
				me.__currentTemplateRecord = {};
				me.__currentApplicationCriteriaRecords = [];
				me.deletedTACriteriaIds = [];

				//technical Attributes Template Model.
				Ext.define('technicalAttributesTemplateModel', {
						    extend: 'Ext.data.Model',
						    fields: [
						        {name: 'title',  type: 'string'},
						        {name: 'description',   type: 'string'},
						        {name: 'template_json',   type: 'string'},
						        
						    ],

						    validate: function() {
						        
						    }
					});
				
				config = config || {};
				

				 me.titleLabel = {
			        xtype: 'label',
			        forId: 'myFieldId',
			        text: $TR.TA_TEMPLATE,
			         margin:'20 0 10 10',
			       
			        
			    };

				me.titleTextFields = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXTextField',{
	    		   allowBlank : true,
	    		   editable : true,
	    		   margin:'40 0 10 10',
	    		   //width: 260,
	    		   labelStyle: 'width:110px; white-space: nowrap;', 
	    		   fieldLabel: $TR.TEMPLATE_NAME +' <span class="req" style="color:red">*</span>',
	    	   });

				me.descriptionTextAreaField = {	xtype     : 'textareafield',
			        grow      : true,
			        allowBlank: false,
			        name      : 'description',
			        fieldLabel: $TR.DESCRIPTION +' <span class="req" style="color:red">*</span>',
			         margin:'20 0 10 10',
			       // anchor    : '100%',
			        id:'taTemplateDescriptionField',
			        labelStyle: 'width:110px; white-space: nowrap;',
					height: 100
			    };


			    
			    //temp: hardcoded org name 
			   
			   // var OrgNamespace = 'SVMXDEV';
			    var OrgNamespace = SVMX.OrgNamespace;
			   	var productObjectdescribe = config.metadata['Product2'];
			    var productLines = null;
			    var productFamily = null;
			    var i=0;
			    for(i=0; i<productObjectdescribe.fields.length; i++){

			    	var field = productObjectdescribe.fields[i];
			    	if(field.type == "PICKLIST" && field.fieldAPIName == OrgNamespace + "__Product_Line__c"){

			    		productLines = field.picklistValues;

			    	}else if(field.type == "PICKLIST" && field.fieldAPIName == 'Family'){

			    		productFamily = field.picklistValues;

			    	}
			    }

			  	var productLineData = [{fieldLabel: "--None--", fieldName: $TR.NONE}];
				var pLine = 0, pLineLength = productLines.length;
				for(pLine = 0; pLine < pLineLength; pLine++) {
					
						productLineData.push(productLines[pLine]);
					
				}

				me.productLineStore = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {
			        fields: ['fieldLabel', 'fieldName'],
			        data: productLineData
			    });

			    me.productLineComboBox = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXComboBox',{
					fieldLabel: $TR.PRODUCT_LINE,
			        store: me.productLineStore,
			        labelWidth: 140,
			        width: '30%',
			        queryMode: 'local',
			        displayField: 'fieldName',
			        labelAlign: 'top',
			        editable: false,
			        region: 'center',
			        recordIndex:null, // TODO: required this variable to get rec Id from dataModel
			        listeners: {
			        	select: {
			        		
			        	},
						afterrender: function(combo) {
							var recordSelected = combo.getStore().getAt(0);                     
							combo.setValue(recordSelected.get('fieldName'));
						}
			        	
						
			        }
				});


				var productFamilyData = [{fieldLabel: "--None--", fieldName: $TR.NONE}];
				var pFamily = 0, pFamilyLength = productFamily.length;
				for(pFamily = 0; pFamily < pFamilyLength; pFamily++) {
					
						productFamilyData.push(productFamily[pFamily]);
					
				}

				me.productFamilyStore = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {
			        fields: ['fieldLabel', 'fieldName'],
			        data: productFamilyData
			    });

			    me.productFamilyComboBox = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXComboBox',{
					fieldLabel: $TR.PRODUCT_FAMILY,
			        store: me.productFamilyStore,
			        labelWidth: 140,
			        width: '30%',
			        queryMode: 'local',
			        displayField: 'fieldName',
			        labelAlign: 'top',
			        editable: false,
			        recordIndex:null, // TODO: required this variable to get rec Id from dataModel
			        listeners: {
			        	
						afterrender: function(combo) {
							var recordSelected = combo.getStore().getAt(0);                     
							combo.setValue(recordSelected.get('fieldName'));
						}
			        	
			        	
						
			        }
				});

				 me.productReferenceField = SVMX.create('com.servicemax.client.installigence.admin.productReferenceField',{
	    		   allowBlank : true,
	    		   editable : true,
	    		   cls: 'svmx-lookup-field',
	    		  	width: 200,
	    		   fieldLabel: $TR.PRODUCT,
	    		   labelAlign: 'top',
	    		    margin:'20 10 10 10',
	    		   meta: config.metadata,
	    		   recordIndex:null // TODO: required this variable to get rec Id from dataModel
	    		  
	    	   });
	    	   

	    	 
			    
			    me.criteriaToolbar = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXToolbar',{
					style: 'border-width: 0',
					width: '100%'
				});
				me.criteriaToolbar.add(me.productReferenceField);
				//me.criteriaToolbar.add(me.__lookupText);
				
				me.criteriaToolbar.add(me.productFamilyComboBox);
				me.criteriaToolbar.add(me.productLineComboBox);
				
			   

			    me.criteriaLabel = {
			        xtype: 'label',
			        forId: 'myFieldId',
			        text: $TR.APPLICATION_CRITERIA,
			         margin:'20 0 10 10'
			        
			    };

			     me.defineTemplateHeaderLabel = {
			        xtype: 'label',
			        forId: 'myFieldId',
			        text: $TR.DEFINE_TA_SECTION,
			        margin:'10 0 10 10'
			        
			    };

			    var sectionPanelObject = SVMX.create('com.servicemax.client.installigence.admin.SectionPanel',{
					metadata: config.metadata,id:'SectionPanel',
					parentContext: this,
					margin:'20 0 10 10'
				});

			    me.__sections.push(sectionPanelObject);

				if(this.__sections.length == 1)
				this.__shouldDisableDeleteSectionButtonForFirstSection(true);


			    var addNewSectionButton = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXButton',{
					cls: 'plain-btn',
					//ui: 'svmx-toolbar-icon-btn',
					//scale: 'large',
					//iconCls: 'plus-icon',
					tooltip: 'Add',
					text:$TR.ADD_SECTION,
					disabled: false,
					handler : function(){
						me.__addNewSection();
						

					}
				});

				 me.addNewSectionToolbar = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXToolbar',{
					style: 'border-width: 0',
					width: '100%'
				});
				me.addNewSectionToolbar.add(addNewSectionButton);
				me.bottomSpaceToolItems = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXToolbar',{
					style: 'border-width: 0',
					width: '100%',
					height: 150
				});

				config.items = [me.titleLabel,me.titleTextFields,me.descriptionTextAreaField,me.criteriaLabel,me.criteriaToolbar,me.defineTemplateHeaderLabel,sectionPanelObject,me.addNewSectionToolbar,me.bottomSpaceToolItems];

				
	    	   
			this.callParent([config]);
			},


			__getRandomArbitrary: function(){
				 return 'section'+Math.floor((Math.random() * 100) + 1);
			},

			__addNewSection: function(){
				var sId = this.__getRandomArbitrary();
				var sectionPanelObject = SVMX.create('com.servicemax.client.installigence.admin.SectionPanel',{
					metadata: this.config.metadata,id:sId,
					parentContext: this,
					margin:'20 0 10 10'
				});
				this.__sections.push(sectionPanelObject);

				var atIndex = this.items.indexOf(this.addNewSectionToolbar);
				this.insert(atIndex, sectionPanelObject);

				
				if(this.__sections.length >1){
					this.__shouldDisableDeleteSectionButtonForFirstSection(false);
				}else if(this.__sections.length == 1){
					this.__shouldDisableDeleteSectionButtonForFirstSection(true);
				}
				
			},

			__removeSection: function(objectId){
				
				var length = this.__sections.length;

				if(length > 1){

					for(var i =0; i<length; i++){

						var sectionObject = this.__sections[i];
						if(sectionObject.id == objectId){
						this.__sections.splice(i, 1);
						var objectToRemove = Ext.getCmp(objectId);
					    this.remove(objectToRemove);
					    if(this.__sections.length == 1)
						this.__shouldDisableDeleteSectionButtonForFirstSection(true);	
					    return;
						}

					}
					
				}
				
				
			},
			__shouldDisableDeleteSectionButtonForFirstSection: function(value){
				var firstSection = Ext.getCmp(this.__sections[0].id);
					firstSection.deleteSectionButton.setDisabled(value);
			},
			resetPage: function(){
				this.titleTextFields.setValue('');
				Ext.getCmp("taTemplateDescriptionField").setValue('');
				
				
				this.productLineComboBox.setValue(this.productLineStore.getAt(0).get('fieldName'));
				this.productFamilyComboBox.setValue(this.productFamilyStore.getAt(0).get('fieldName'));
				this.productReferenceField.lookupText.setValue('');
				this.productReferenceField.selectedProduct = null;
				//this.productReferenceField.selectedProduct = {};
				this.productReferenceField.recordIndex = null;
				this.productFamilyComboBox.recordIndex = null;
				this.productLineComboBox.recordIndex  = null;
				this.deletedTACriteriaIds = [];
				this.__currentTemplateRecord = {};


				
				var l = this.__sections.length;
				for(var i=0; i<l; i++){
					var objectToRemove = Ext.getCmp(this.__sections[i].id);
					this.remove(objectToRemove);
				}
				this.__sections.splice(0, l);
				this.__addNewSection();


			},
			reloadTemplatePage: function(record){

				
				this.__currentTemplateRecord = record;
				var templateTitle = SVMX.OrgNamespace+'__SM_Title__c';
				var templateDescription = SVMX.OrgNamespace+'__SM_Description__c';
				var templateJSON  = SVMX.OrgNamespace+'__SM_Template_Json__c';
				
				var sectionDetails = this.__parseJSONdata(record.data[templateJSON]);
				this.__loadAllSectionDetails(sectionDetails);

				this.titleTextFields.setValue(record.data[templateTitle]);
				Ext.getCmp("taTemplateDescriptionField").setValue(record.data[templateDescription]);
				this.__getTemplateCriteriaInfo(record.data.Id);

			},
			__parseJSONdata: function(jsonString){
				var obj = JSON.parse(jsonString);
				return obj;
			},
			__loadAllSectionDetails: function(sectionDetails){
				var fields = sectionDetails.fields;
				var l = fields.length;
				
				if(l > this.__sections.length){
					for(var i=1; i<l; i++){
						this.__addNewSection();
					}
				}
				this.__loadValuesForAllSections(fields);

			},

			__loadValuesForAllSections: function(sections){
				var l = this.__sections.length;
				
				for(var i=0; i<l; i++){
					var sectionPanelObject;
					sectionPanelObject = this.__sections[i];
					sectionPanelObject.titleTextFields.setValue(sections[i].title);
					Ext.getCmp('textareafield'+sectionPanelObject.id).setValue(sections[i].description);

					var attributes = sections[i].technicalAttributes;
					if(!attributes) {
	        		 attributes = [];
	        		 }
					sectionPanelObject.attributesStore.loadData(attributes);

				}
			},


			__getTemplateCriteriaInfo: function(templateId){
				SVMX.getCurrentApplication().blockUI();
				var params = {};
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
					"INSTALLIGENCEADMIN.GET_TA_TEMPLATE_CRITERIA" , this, 
					{request : { context : this,taTemplateId:templateId, handler : this.__getTemplateCriteriaInfoCompleted, text : params.text}});
			SVMX.getCurrentApplication().getEventBus().triggerEvent(evt);
			},

			__getTemplateCriteriaInfoCompleted: function(data){
				this.__currentApplicationCriteriaRecords = data;
				var l = data.length;
				var pLine   =  SVMX.OrgNamespace+'__SM_Product_Line__c';
				var pFamily =  SVMX.OrgNamespace+'__SM_Product_Family__c';
				var pId     =  SVMX.OrgNamespace+'__SM_Product__c';
				var pName   =  SVMX.OrgNamespace+'__SM_Product__r';

				for(var iCriteriaRec=0; iCriteriaRec<l; iCriteriaRec++){
						
						var criteriaObject = data[iCriteriaRec];
						if(criteriaObject[pLine] !== null){
							this.productLineComboBox.setValue(criteriaObject[pLine]);
							this.productLineComboBox.recordIndex = criteriaObject.Id;
						}
						

						if(criteriaObject[pFamily] !== null){
							this.productFamilyComboBox.setValue(criteriaObject[pFamily]);
							this.productFamilyComboBox.recordIndex = criteriaObject.Id;;
						}
						
						
						if(criteriaObject[pId] !== null)
						this.productReferenceField.lookupText.setValue(criteriaObject[pName]['Name']);

						if(criteriaObject[pId] !== null){
							this.productReferenceField.selectedProduct = {'Id':criteriaObject[pId]};
							this.productReferenceField.recordIndex = criteriaObject.Id;;
						}

						criteriaObject = null;
						
				}

				SVMX.getCurrentApplication().unblockUI();
				
			}

		});

// CreateNewTechnicalAttributesTemplate class end.


// productReferenceField class start.
   Ext.define("com.servicemax.client.installigence.admin.productReferenceField", {
	         extend: "Ext.form.FieldContainer",
	         
	         selectedProduct:null,

	         constructor: function(config) {
	        	 var me = this;
	        	 config = config || [];
	        	 selectedProduct = {};
	               
	        	 config.items = config.items || [];
	        	 config.layout = 'hbox';
	        	

	             
                 me.lookupBtn = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXButton', {
                	 iconCls: 'svmx-lookup-icon',
 					 margin: '0, 5', 
                     flex: 1,
                     handler : function(){
					       		
					       		var getAllProducts = SVMX.create("com.servicemax.client.installigence.admin.productLookup.ProductLookup", {
	                objectName : 'Product2',
	                columns : [{name : "Name"}],
	                multiSelect : false,
	                sourceComponent : this,
	                
	                mvcEvent : "GET_ALL_PRODUCTS"
			   });
			   
			   getAllProducts.find().done(function(results){
	               me.selectedProduct = results;
	               me.lookupText.setValue(results.Name);
	               
			   });
					       			}
                 });
	        	 
	        	 me.lookupText = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXTextField', {
                     minWidth: 5,
                     width: 150,
                     listeners: {
                     	change: function(field) {
								if(!field.value)
									me.selectedProduct = null;	
							}
                    	 
                     }
                 });	       	 
	        	
	        	 config.items.push(me.lookupText);
	        	 config.items.push(me.lookupBtn);
	        	 
	        	 this.callParent([config]);
	         },
	         
	        
	     });

// productReferenceField class end.

// SectionPanel class start.
		Ext.define("com.servicemax.client.installigence.admin.SectionPanel", {
			extend: "com.servicemax.client.installigence.ui.components.SVMXPanel",

	         
	         constructor: function(config) {
	        	var me = this;
	        	
	        	config = config || {};

	        	
	        	 me.deleteSectionButton = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXButton',{
					cls: 'plain-btn',
					//ui: 'svmx-toolbar-icon-btn',
					//scale: 'small',
					//iconCls: 'delet-icon',
					tooltip: 'Delete',
					text:$TR.REMOVE_SECTION,
					sectionId: config.id,
					disabled: false,
					parent:config.parentContext,
					handler : function(dButton, eventObject){
						var i = dButton.sectionId;
						dButton.parent.__removeSection(i);

					}
				});
				config.dockedItems= [{
								    xtype: 'toolbar',
								    dock: 'top',
								    items: [me.deleteSectionButton]
								}];

	        	me.titleTextFields = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXTextField',{
	    		   allowBlank : true,
	    		   editable : true,
	    		   margin:'20 0 10 10',
	    		   width: '80%',
	    		   fieldLabel: $TR.SECTION_NAME,
	    	   });

				me.descriptionTextAreaField = {	xtype     : 'textareafield',
			        grow      : true,
			        name      : 'description',
			        fieldLabel: $TR.DESCRIPTION,
			        id: 'textareafield' + config.id ,
			         margin:'20 0 10 10',
			        anchor    : '100%',
			        width: '80%',
					height: 100
			    };

	        	me.attributeTypeStore = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {
			        fields: ['value', 'label'],
			        data: [
		        		{ value: 'static', label: 'Static'}
		        		
			        ]
   	 			});
   	 			me.formatTypeStore = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {
			        fields: ['value', 'label'],
			        data: [
		        		{ value: 'Number', label: 'Number'},
		        		{ value: 'Text', label: 'Text'},
		        		{ value: 'Boolean', label: 'Boolean'}
		        		
			        ]
   	 			});

   	 			me.readOnlyTypeStore = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {
			        fields: ['value', 'label'],
			        data: [
		        		{ value: 'yes', label: 'YES'},
		        		{ value: 'no', label: 'NO'}
		        		
			        ]
   	 			});

/*
				Ext.define('attributesModel', {
				    extend: 'Ext.data.Model',
				    fields: [ {name: 'name',  type: 'string'},
				    		{name: 'attributeType',   type: 'string'},
				    		{name: 'format',   type: 'string'},
				    		{name: 'value',   type: 'string'},
				    		{name: 'unit',   type: 'string'},
				    		{name: 'readOnly',   type: 'string'},
				    		{name: 'default',   type: 'string'},

				              ]
				});

*/
				me.attributesStore = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {
				   // model: 'attributesModel',
				     fields: [ {name: 'label',  type: 'string'},
				    		{name: 'type',   type: 'string'},
				    		{name: 'format',   type: 'string'},
				    		//{name: 'value',   type: 'string'},
				    		{name: 'unit',   type: 'string'},
				    		{name: 'readOnly',   type: 'string'},
				    		{name: 'defaultValue',   type: 'string'},

				              ],
				    data: [			        
				        
				    ]
				});
				
	        	me.attributesGrid = SVMX.create('com.servicemax.client.installigence.admin.TechnicalAttributesGrid',{
					cls: 'grid-panel-borderless panel-radiusless',
					store: me.attributesStore,
					height: 300,
					width: '100%',
					autoScroll:true,
					//layout: 'fit',
				    selType: 'cellmodel',
				    attributeTypeStore: me.attributeTypeStore,	
				    formatTypeStore: me.formatTypeStore,	
				    readOnlyTypeStore: me.readOnlyTypeStore,        
				    plugins: [
				              SVMX.create('com.servicemax.client.installigence.ui.components.SVMXCellEditorPlugin', {
				                  clicksToEdit: 2
				              })
				          ],
	            });
	        	
	            config.items = [];
	            config.items.push(me.titleTextFields);
	            config.items.push(me.descriptionTextAreaField);
				config.items.push(me.attributesGrid);
	            
	          
	        	this.callParent([config]);
	         }
	        
	         
	        
	     });
// SectionPanel class end.

//TechnicalAttributesGrid class start.
	Ext.define("com.servicemax.client.installigence.admin.TechnicalAttributesGrid", {
			extend: "com.servicemax.client.installigence.ui.components.SVMXGrid",
			constructor: function(config) {
				var me = this;
				var config = config || {};


				var addAttributesButton = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXButton',{
					//cls: 'plain-btn',
					ui: 'svmx-toolbar-icon-btn',
					scale: 'large',
					iconCls: 'plus-icon',
					tooltip: 'Add',
					disabled: false,
					handler : function(){
						me.addAttributeRecord({name:''});
					}
				});
				config.dockedItems= [{
								    xtype: 'toolbar',
								    dock: 'top',
								    items: [{
								        xtype: 'tbfill'
								    },addAttributesButton]
								}];
				config.columns = [{
						menuDisabled: true,
						sortable: false,
						xtype: 'actioncolumn',
						width: 50,
						items: [{
									iconCls: 'delet-icon',
									tooltip: 'Delete'
								}],
						handler: function(grid, rowIndex, colIndex) {
							var gridStore = grid.getStore();
		                    var rec = gridStore.getAt(rowIndex);
		                    gridStore.remove(rec);                    
		                },  		                
  		                renderer: function (value, metadata, record) {
  		                	config.columns[0].items[0].iconCls = 'delet-icon';
  		                }
                }];

                var me = this;
                config.columns.push(this.createTextBoxColumn({text: $TR.ATTRIBUTE_NAME, dataIndex: 'label', flex: 1, listeners :null}));
                config.columns.push(this.createComboBoxColumn({text: $TR.TYPE, dataIndex: 'type',  flex: 1, 
		    		   store: config.attributeTypeStore}));
                config.columns.push(this.createComboBoxColumn({text: $TR.FORMATE, dataIndex: 'format',  flex: 1, 
		    		   store: config.formatTypeStore}));
               // config.columns.push(this.createTextBoxColumn({text: 'Values', dataIndex: 'value', flex: 1, listeners :null}));
                config.columns.push(this.createTextBoxColumn({text: $TR.UNIT, dataIndex: 'unit',  flex: 1, listeners :null}));
                config.columns.push(this.createComboBoxColumn({text: $TR.READY_ONLY, dataIndex: 'readOnly',  flex: 1, 
		    		   store: config.readOnlyTypeStore}));
                config.columns.push(this.createTextBoxColumnForDefaultField({text: $TR.DEFAULT_VALUES, dataIndex: 'defaultValue',  flex: 1, listeners :null}));
                this.callParent([config]);
			},			
			createTextBoxColumn: function(fieldInfo) {
	    	   var me = this;
	    	   var txtboxCol = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXTextField',{
	    		   allowBlank : true,
	    		   editable : true,
	    		   listeners : fieldInfo.listeners
	    	   });
	    	   
	    	   var fieldInfo = fieldInfo || {};
	    	   fieldInfo.sortable = false;
	    	   fieldInfo.editable = true;
	    	   fieldInfo.getEditor = function(currentRecord){
	    		   var currTypeValue = currentRecord.get('parentProfileId');
	    		   //if(currentRecord.get('isGlobal') === true && currTypeValue !== me.selectedProfileId) {
	    			 //  return "";
	    		   //}
	    		   return txtboxCol;
               };
               
	    	   return fieldInfo;
	       },
	       createTextBoxColumnForDefaultField: function(fieldInfo) {
	    	   var me = this;
	    	   
	    	   var fieldInfo = fieldInfo || {};
	    	   fieldInfo.sortable = false;
	    	   fieldInfo.editable = true;
	    	   fieldInfo.getEditor = function(currentRecord){

	    	   		var returnEditor = null;
	    	   		var currentFormate = currentRecord.get('format');
	    	   		if(currentFormate == 'Number'){
	    	   			
	    	   			returnEditor = Ext.create('Ext.grid.CellEditor', { 
						        field: Ext.create('Ext.form.field.Number', {
						            allowBlank: false
						            
						        })
						    });

	    	   		}else if(!currentFormate || currentFormate == 'Text'){
	    	   			
	    	   			returnEditor = Ext.create('Ext.grid.CellEditor', { 
						        field: Ext.create('Ext.form.field.Text', {
						            allowBlank: false
						            
						        })
						    });

	    	   		}else if(currentFormate == 'Boolean'){
	    	   			 returnEditor = Ext.create('Ext.grid.CellEditor', { 
						        field: {
			                        xtype: 'combobox',
			                        forceSelection: true,
			                        editable: false,
			                        triggerAction: 'all',
			                        allowBlank: false, 
			                        valueField:'value',
			                        displayField:'descr',
			                        store: Ext.create('Ext.data.Store',{
			                            fields:['descr','value'],
			                            data:[{
			                                descr:'YES',
			                                value:'YES'
			                            },{
			                                descr:'NO',
			                                value:'NO'
			                            }]
			                        })
			                    }
						    });

	    	   		}
	    	   	return returnEditor;

	    		   
               };
               
	    	   return fieldInfo;
	       },
	       createComboBoxColumn: function(fieldInfo) {
	    	   var me = this;
	    	   
	    	   var optionPicklist = SVMX.create('com.servicemax.client.installigence.admin.celleditors.SVMXComboBoxCellEditor',{
					displayField: 'label',
			        queryMode: 'local',
			        editable: false,
			        //valueField: 'value',
			        fieldName: fieldInfo.dataIndex,
			        store: fieldInfo.store
	    	   });	    	   
	    	   
	    	   var fieldInfo = fieldInfo || {};
	    	   fieldInfo.menuDisabled = true;
	    	   fieldInfo.sortable = false;
	    	   fieldInfo.getEditor = function(currentRecord){
	    		   var currTypeValue = currentRecord.get('parentProfileId');
	    		  // if(currentRecord.get('isGlobal') === true && currTypeValue !== me.selectedProfileId) {
	    			//   return "";
	    		   //}
	    		   optionPicklist.setRecord(currentRecord);
                   return optionPicklist;
               };
	    	   return fieldInfo;	    	   
	    	   
	       },
	       addAttributeRecord: function(records){
	       		if (!records) return;
	       		this.store.insert(this.getStore().count(), records);
	       	}
	       
		});
		

//TechnicalAttributesGrid class end.

	}
// init ends here

 })();


