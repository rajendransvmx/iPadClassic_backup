QUnit.module("UserActionsValidator", {
    setup: function() {
        //initialize code
        com.servicemax.client.installigence.admin.useractions.init();
    },
    teardown: function() {
        //cleanup code
        
    }
});

test("Standard User Actions Validator", function(){
    
});