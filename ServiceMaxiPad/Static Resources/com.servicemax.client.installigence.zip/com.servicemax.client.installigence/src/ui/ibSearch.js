/**
 * This Search IBs.
 * @class com.servicemax.client.insralligence.src.ui.ibSearch.js
 * @author Madhusudhan HK
 *
 * @copyright 2016 ServiceMax, Inc.
 **/

(function(){

	var toolBarImpl = SVMX.Package("com.servicemax.client.installigence.ibSearch");

	toolBarImpl.init = function(){
		Ext.define("com.servicemax.client.installigence.ibSearch.IBSearch",
			{
				extend: "com.servicemax.client.installigence.ui.components.SVMXPanel",
        alias: 'widget.installigence.ibSearch',
        
        //defining the class variable or private ivars.
            meta : null, 
            root: null, 
            grid : null, 
            __params : null, 
            __config: null,
            __displayFields:null,
            __searchFields:null,
            __window:null,
            __store:null,
            __grid:null,
            __objectInfo : null,
            __fieldsMap : null,

        constructor: function(searchConfig) { 
            
            
            
            this.meta = searchConfig.meta;
            this.root = searchConfig.root;
            this.__config = searchConfig;
            var me = this;
            this.__init();           
            this.meta.bind("MODEL.UPDATE", function(evt){
                
               
                this.__displayFields = this.meta.advanceSearch.displayFields;
                this.__searchFields = this.meta.advanceSearch.searchFields;
               
               this.__initComplete();
                

            }, this);
            


            searchConfig = Ext.apply({
                title: '<span class="title-text">' + 'Search' +'</span>',
                titleAlign: 'center', 
                frame: 'true',
                collapsible : false,
                style: 'margin:10px',
                height : SVMX.getWindowInnerHeight() - 40,
                toolPosition: 0,
                tools: [{
                    type:'backbtn',
                    cls: 'svmx-back-btn',
                    handler: function(e, el, owner, tool){          
                        me.__handeNavigateBack();       
                    }
                }],
                layout: "fit",
                items : this.__getUI(),
                dockedItems: [
                    {
                        dock: 'top', xtype: 'toolbar', margin: '0',
                        items : this.__getDockedUI()
                    }
                ],
            }, searchConfig || {});
            this.callParent([searchConfig]);            
        },


              
        __init : function(){

            var syncService = SVMX.getClient().getServiceRegistry()
            .getService("com.servicemax.client.installigence.sync").getInstance(), me = this;
            syncService.getSObjectInfo(SVMX.getCustomObjectName("Installed_Product"))
            .done(function(info){

                me.__objectInfo = info;
                me.__fieldsMap = {};
                var i = 0,l = info.fields.length;
                for(i = 0; i < l; i++){
                    me.__fieldsMap[info.fields[i].name] = info.fields[i]
                }

                //me.__initComplete();
            });
            
        }, 

        __initComplete : function(){
            

               var cols = this.__getDisplayFields();
              
               var  l = cols.length;
              
                // store
                var fields = [];
                for(var i = 0; i < l; i++){ 
                    fields.push(cols[i]); 
                }
                 
                
                var store = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {fields:fields, data:[]});
                
               this.__store.fields = cols;
               
                var gridColumns = [];

                for (var i = 0; i < l; i++) {
                    gridColumns.push({ text : cols[i], 
                        handler : function(){
                        this.__slectedIBS
                        },
                        dataIndex : this.__displayFields[i], 
                        flex : 1 });
                }

                //

                this.__grid.columns = gridColumns; 
                this.__grid.reconfigure(this.__store, gridColumns);



        },


        __find : function(params){
            var displayFields = this.meta.advanceSearch.displayFields;
            var searchFields = this.meta.advanceSearch.searchFields;

           

            SVMX.getCurrentApplication().blockUI();
            var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                    "INSTALLIGENCE." + this.__config.mvcEvent, this, {
                        request : { 
                            context : this, 
                            handler : this.__findComplete, 
                            //text : params.text, 
                            displayFields : this.__getFields(displayFields),
                            searchFields : searchFields 
                        }
                    });
            com.servicemax.client.installigence.impl.EventBus.getInstance().triggerEvent(evt);
            
        }, 
        
        __findComplete : function(data){
             
            this.__store.loadData(data);
            SVMX.getCurrentApplication().unblockUI();
        },

        __getDisplayFields : function(){
            var colFields = [];

            var displayColumns = this.meta.advanceSearch.displayFields && this.meta.advanceSearch.displayFields.length > 0 ? this.meta.advanceSearch.displayFields : ['Name'];
             
            this.__displayFields = displayColumns;

            if(this.__fieldsMap && this.__fieldsMap["Name"]){

                for (var i = 0; i < displayColumns.length; i++) {
                var string = displayColumns[i];

                var label = this.__fieldsMap[string].label;
                colFields.push(label);
            }
                
            }else{
                colFields.push('Name');
            }
            
            
            return colFields;
        },
        __getFields : function(fields){
            var colFields = ["Id", "Name"];

            for (var i = 0; i < fields.length; i++) {
                var string = fields[i];
                if(string && string.toLowerCase() == "id") continue;
                if(string && string.toLowerCase() == "name") continue;
                colFields.push(string);
            }
            
            return colFields;
        },
        
        __getSearchFields : function(fields){
            var colFields = [];
            for(var key in fields){             
                colFields.push(fields[key].name);
            }
            
            return colFields;
        },
        
        __slectedIBS : function(selectedRec){
            var data = {};
            data.action = "VIEW";
            data.recordIds = [selectedRec.data.Id];
            data.object = SVMX.getCustomObjectName("Installed_Product");
            var evt = SVMX.create("com.servicemax.client.lib.api.Event", "EXTERNAL_MESSAGE", this, data);
            SVMX.getClient().triggerEvent(evt); 
            this.__window.close();
        },

        __getUI:function() {

                var me = this;
                var items = [];
                
                
                var cols = me.__getDisplayFields();
                var  l = cols.length;
                // store
                var fields = [];
                for(var i = 0; i < l; i++){ 
                    fields.push(cols[i]); 
                }
                var store = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {fields:fields, this:[]});

                var gridColumns = [];

                for (var i = 0; i < l; i++) {
                    gridColumns.push({ text : cols[i], handler : function(){this.__slectedIBS},dataIndex :  this.__displayFields[i], flex : 1 });
                }

                var grid = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXGrid', {
                    store: store,
                    //selModel: {selType : 'checkboxmodel', injectCheckbox: false},
                    columns: gridColumns, flex : 1, width: "100%",
                    viewConfig: {
                        listeners: {
                            select: function(dataview, record, item, index, e) {
                                me.__slectedIBS(record);
                            }
                        }
                    }
               });


               
            
            
            this.__store = store;
            this.__grid = grid;
            items.push(this.__grid);
            return items;

            }, 
        


            find : function(){
                console.log('Reached');
            },

            __handeNavigateBack : function(){
                this.root.handleNavigateBack();
            },

            handleFocus : function(params){

                this.__displayFields = this.meta.advanceSearch.displayFields;
                this.__searchFields = this.meta.advanceSearch.searchFields;
                

                 var me = this;
                me.__grid.getStore().loadData([]);
                me.__find();


                    
            },
             __getDockedUI : function(){

                // searchText
                var searchText = SVMX.create("com.servicemax.client.installigence.ui.components.SVMXTextField", {
                    width: '80%', emptyText : 'Search', enableKeyEvents : true,
                    listeners : {
                    keyup : function(that, e, opts) {
                        if(e.getKey() == e.ENTER){
                            console.log("inside this constructor");
                          
                        }
                    }
                }

                });

                var winItems = [
                searchText,
                { xtype: 'button', text: "Search", handler : function(){
                    me.__find({ text : searchText.getValue()});
                }}
            ];
            return winItems;

             }


                
			});
	}



})();