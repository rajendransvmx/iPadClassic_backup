/**
 * This Search IBs.
 * @class com.servicemax.client.insralligence.src.ui.ibSearch.js
 * @author Madhusudhan HK
 *
 * @copyright 2016 ServiceMax, Inc.
 **/

(function(){

	var toolBarImpl = SVMX.Package("com.servicemax.client.installigence.ibSearch");

	toolBarImpl.init = function(){
		Ext.define("com.servicemax.client.installigence.ibSearch.IBSearch",
			{
				extend: "com.servicemax.client.installigence.ui.components.SVMXPanel",
        alias: 'widget.installigence.ibSearch',
        
        //defining the class variable or private ivars.
            meta : null, 
            root: null, 
            grid : null, 
            __params : null, 
            __config: null,
            __displayFields:null,
            __searchFields:null,
            __referenceFilter:null,
            __searchFilter:null,
            __window:null,
            __store:null,
            __grid:null,
            __objectInfo : null,
            __fieldsMap : null,
            __configArray : null,
            __orderBy : null,

        constructor: function(searchConfig) { 
            this.meta = searchConfig.meta;
            this.root = searchConfig.root;
            this.__config = searchConfig;
            var me = this;
            this.__init();           
            this.meta.bind("MODEL.UPDATE", function(evt){
                this.__parseConfig(this.meta.advanceSearch);
            	this.__configArray = this.meta.advanceSearch;
              	this.__initComplete();
            }, this);
            
            searchConfig = Ext.apply({
               // title: '<span class="title-text">' + 'Search' +'</span>',
               // titleAlign: 'left', 
                frame: 'true',
                collapsible : false,
                style: 'margin:1px',
                height : SVMX.getWindowInnerHeight() - 10,
                toolPosition: 0,
               /* tools: [{
                    type:'backbtn',
                    //cls: 'svmx-back-btn',
                    handler: function(e, el, owner, tool){          
                        me.__handeNavigateBack();       
                    }
                }],*/
                layout: "fit",
                items : this.__getUI(),
                dockedItems: [
                    {
                        dock: 'top', xtype: 'toolbar', margin: '0',
                        items : this.__getDockedUI()
                    }
                ],
            }, searchConfig || {});
            this.callParent([searchConfig]);            
        },
        
        __init : function(){

            var syncService = SVMX.getClient().getServiceRegistry()
            .getService("com.servicemax.client.installigence.sync").getInstance(), me = this;
            syncService.getSObjectInfo(SVMX.getCustomObjectName("Installed_Product"))
            .done(function(info){

                me.__objectInfo = info;
                me.__fieldsMap = {};
                var i = 0,l = info.fields.length;
                for(i = 0; i < l; i++){
                    me.__fieldsMap[info.fields[i].name] = info.fields[i]
                }

                //me.__initComplete();
            });
            
        }, 

        __initComplete : function(){
            

               var cols = this.__getDisplayFields();
              
               var  l = cols.length;
              
                // store
                var fields = [];
                for(var i = 0; i < l; i++){ 
                    fields.push(cols[i]); 
                }
                 
                
                var store = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {fields:fields,style : {"background-color" : "#D0CDCD","text-align":"left"},data:[]});
                
               this.__store.fields = cols;
               
                var gridColumns = [];

                for (var i = 0; i < l; i++) {
                    gridColumns.push({ text : cols[i], 
                        handler : function(){
                        this.__slectedIBS
                        },
                        dataIndex : this.__displayFields[i], 
                        flex : 1 });
                }

                //

                this.__grid.columns = gridColumns; 
                this.__grid.reconfigure(this.__store, gridColumns);



        },


        __find : function(params){
			if(params){
            	SVMX.getCurrentApplication().blockUI();
            	var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                    "INSTALLIGENCE." + this.__config.mvcEvent, this, {
                        request : { 
                            context : this, 
                            handler : this.__findComplete, 
                            text : params.text, 
                            displayFields : this.__getFields(this.__displayFields),
                            searchFields : this.__searchFields,
                            displayFilter : this.__displayFilter,
                            referenceFilter : this.__referenceFilter,
                            searchFilter : this.__searchFilter,
                            orderBy : this.__orderBy
                        }
                    });
            com.servicemax.client.installigence.impl.EventBus.getInstance().triggerEvent(evt);
            }
            else{
            	SVMX.getCurrentApplication().blockUI();
            	var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                    "INSTALLIGENCE." + this.__config.mvcEvent, this, {
                        request : { 
                            context : this, 
                            handler : this.__findComplete, 
                            //text : (params)null=null, 
                            displayFields : this.__getFields(this.__displayFields),
                            //searchFields : searchFields,
                            searchFields : this.__searchFields,
                            displayFilter : this.__displayFilter,
                            referenceFilter : this.__referenceFilter,
                            orderBy : this.__orderBy
                        }
                    });
            com.servicemax.client.installigence.impl.EventBus.getInstance().triggerEvent(evt);
            }
            
        }, 
        
        __findComplete : function(data){
             
             this.__getRefrenceFieldValue(data).done(function(){
                //Loade screen here, If there is no reference filed config field there
            });
            this.__store.loadData(data);
            SVMX.getCurrentApplication().unblockUI();
        },

        __getDisplayFields : function(){
            var colFields = [];

            //var displayColumns = this.meta.advanceSearch.displayFields && this.meta.advanceSearch.displayFields.length > 0 ? this.meta.advanceSearch.displayFields : ['Name'];
             var displayColumns = this.__displayFields && this.__displayFields.length > 0 ? this.__displayFields : ['Name'];
            this.__displayFields = displayColumns;

            if(this.__fieldsMap && this.__fieldsMap["Name"]){

                for (var i = 0; i < displayColumns.length; i++) {
                var string = displayColumns[i];

                var label = this.__fieldsMap[string].label;
                colFields.push(label);
            }
                
            }else{
                colFields.push('Name');
            }
            
            
            return colFields;
        },
        __getFields : function(fields){
            var colFields = ["Id", "Name"];

            for (var i = 0; i < fields.length; i++) {
                var string = fields[i];
                if(string && string.toLowerCase() == "id") continue;
                if(string && string.toLowerCase() == "name") continue;
                colFields.push(string);
            }
            
            return colFields;
        },
        
        __getSearchFields : function(fields){
            var colFields = [];
            for(var key in fields){             
                colFields.push(fields[key].name);
            }
            
            return colFields;
        },
        
        __slectedIBS : function(selectedRec){
            var data = {};
            data.action = "VIEW";
            data.recordIds = [selectedRec.data.Id];
            data.object = SVMX.getCustomObjectName("Installed_Product");
            var evt = SVMX.create("com.servicemax.client.lib.api.Event", "EXTERNAL_MESSAGE", this, data);
            SVMX.getClient().triggerEvent(evt); 
            //this.__window.close();
            this.root.handleNavigateBack();
        },

        __getUI:function() {

                var me = this;
                var items = [];
                
                
                var cols = me.__getDisplayFields();
                var  l = cols.length;
                // store
                var fields = [];
                for(var i = 0; i < l; i++){ 
                    fields.push(cols[i]); 
                }
                var store = SVMX.create('com.servicemax.client.ui.components.composites.impl.SVMXStore', {fields:fields,style : {"background-color" : "#D0CDCD","text-align":"left"}, this:[]});

                var gridColumns = [];

                for (var i = 0; i < l; i++) {
                    gridColumns.push({ text : cols[i], handler : function(){this.__slectedIBS},dataIndex :  this.__displayFields[i], flex : 1 });
                }

                var grid = SVMX.create('com.servicemax.client.installigence.ui.components.SVMXGrid', {
                    store: store,
                    //selModel: {selType : 'checkboxmodel', injectCheckbox: false},
                    columns: gridColumns, flex : 1, width: "100%",
                    viewConfig: {
                        listeners: {
                            select: function(dataview, record, item, index, e) {
                                me.__slectedIBS(record);
                            }
                        }
                    }
               });


               
            
            
            this.__store = store;
            this.__grid = grid;
            items.push(this.__grid);
            return items;

            }, 
        


            find : function(){
                console.log('Reached');
            },

            __handeNavigateBack : function(){
                this.root.handleNavigateBack();
            },

            handleFocus : function(params){
                var me = this;
                me.__grid.getStore().loadData([]);
                me.__find();    
            },
             __getDockedUI : function(){

                // searchText
                var me = this;
                 var searchlbl =  SVMX.create("com.servicemax.client.installigence.ui.components.Label", {
                        html : "<div></div>", width: '10%', padding : 5, height : 25, text: "Search" ,style : {"text-align":"left"}
                    });
                var searchText = SVMX.create("com.servicemax.client.installigence.ui.components.SVMXTextField", {
                    width: '40%', emptyText : 'Search', enableKeyEvents : true,
                    style: 'margin:10px',
                    listeners : {
                    keyup : function(that, e, opts) {
                        if(e.getKey() == e.ENTER){
                            console.log("inside this constructor");
                        }
                    }
                }

                });

                var winItems = [
                searchlbl,
                searchText,
                { xtype: 'button', text: "Search", handler : function(){
                    me.__find({ text : searchText.getValue()});
                }},
                { xtype: 'button', text: "Cancel", handler : function(){
                    me.__handeNavigateBack();
                }}
            ];
            return winItems;

             },

            __parseConfig:function(Config){
				var displayFields = [];
				var searchFields = [];
				var displayFilter = [];
				var referenceFilter = [];
				var searchFilter = [];
				//var searchConfigFields = Config.config;
				var searchConfigFields = Config;
				if (searchConfigFields) {
					for (var k = 0; k < searchConfigFields.length; k++) {
						var currentDictionary = searchConfigFields[k];
						var fieldType = currentDictionary.fieldType;
						var fieldName = currentDictionary.fieldName;
						if (fieldType == "Search"){
							searchFields.push(fieldName);
							if(currentDictionary.displayType != "REFERENCE"){
								searchFilter.push(currentDictionary);
							}
						}else if (fieldType == "Result"){
							displayFields.push(fieldName);
						}else if (fieldType == "OrderBy")
						{
							if(this.__orderBy){
								this.__orderBy = this.__orderBy + ", ";
							}else{
								this.__orderBy = " ";
							}
							if(currentDictionary.sortOrder == "Ascending"){
								this.__orderBy = this.__orderBy + currentDictionary.fKeyNameField + " ASC";
							}else if(currentDictionary.sortOrder =="Descending"){
								this.__orderBy = this.__orderBy + currentDictionary.fKeyNameField + " DESC";
							}
							
						}else
						{
							if(currentDictionary.displayType != "REFERENCE"){
								displayFilter.push(currentDictionary);
							}else
							{
								if(currentDictionary.fKeyNameField)
								{
									referenceFilter.push(currentDictionary);
								}
							}
						}
					}
					this.__displayFields = displayFields;
					this.__searchFields = searchFields;
					this.__displayFilter = displayFilter;
					this.__referenceFilter = referenceFilter;
					this.__searchFilter = searchFilter;
				}
       		},
			__getRefrenceFieldValue:function(data){
				var def = SVMX.Deferred();
				this.__data = data;//{};
				var idList = [];
				var me = this;
				for(var kConfig = 0; kConfig < this.__configArray.length; kConfig++ ){
					var configDict = this.__configArray[kConfig];
					if(configDict){
						if(configDict.displayType == "REFERENCE"){
							for(var k = 0; k < data.length; k++ ){
								var dataDict = data[k];
								var fieldName = configDict.fieldName;
								var value ;
								if(fieldName){  
									value = dataDict[fieldName];
									me.__data[value] = dataDict;
									if(value){
										idList.push(value);
									}
								}
							}
							this.__fetchRefValue(idList,configDict);
						}else{
							console.log("fetch value");
						}
					}
				}           
				return def;
			},
			__fetchRefValue : function (ids,configDict){
				SVMX.getCurrentApplication().blockUI();
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
						"INSTALLIGENCE." + "FETCH_VALUES_Ref", this, {
							request : { 
								context : this, 
								handler : this.__referenceComplete,
								kIds: ids,
								kConfigDict:configDict,
								referenceFilter : this.__referenceFilter
							}
						});
				com.servicemax.client.installigence.impl.EventBus.getInstance().triggerEvent(evt);
				SVMX.getCurrentApplication().unblockUI();
			},
		
			__referenceComplete: function (data){
				var me = this;
				for(var kConfig = 0; kConfig < this.__configArray.length; kConfig++ ){
					var configDict = this.__configArray[kConfig];
					if(configDict){
						if(configDict.displayType == "REFERENCE"){
							for(var k = 0; k < this.__data.length; k++ ){
								var dataDict = this.__data[k];
								var fieldName = configDict.fieldName;
								var value ;
								if(fieldName){  
									value = dataDict[fieldName];
									if(value){
										var refData = data.rData[value];
										if(refData){
											if(refData[configDict.fKeyNameField]){
												dataDict[fieldName] =  refData[configDict.fKeyNameField];
											} 
										}
									}
								}
							}
						}
					}
				}
				this.__store.loadData(this.__data);
				SVMX.getCurrentApplication().unblockUI();
			}    
		});
	}
})();