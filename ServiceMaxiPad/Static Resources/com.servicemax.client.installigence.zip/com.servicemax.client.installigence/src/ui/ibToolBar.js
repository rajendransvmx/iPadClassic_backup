/**
 * This file creates the toolbar items like search, action and filter.
 * @class com.servicemax.client.insralligence.src.ui.toolbar.js
 * @author Madhusudhan HK
 *
 * @copyright 2015 ServiceMax, Inc.
 **/

(function(){

	var toolBarImpl = SVMX.Package("com.servicemax.client.installigence.ibToolBar");

	toolBarImpl.init = function(){
		Ext.define("com.servicemax.client.installigence.ibToolBar.ToolBarItems",
			{
				extend: "com.servicemax.client.installigence.ui.components.SVMXPanel",
               alias: 'widget.installigence.ibToolBar',

               __meta: null,
               __contentarea: null,
               __installbaseSearch: null,
               
                constructor: function(config) {
						var me = this;
                        this.__contentarea = config.contentarea;
                        this.__meta = config.meta;
                        var actions = SVMX.create("com.servicemax.client.installigence.actions.Actions", {
                            region: 'east', collapsed: false, split: false, width: 170, floatable: true, meta : this.__meta,
                            contentarea : this.__contentarea,margin: '-30 0 0 795'
                        });
						
                        config = Ext.apply({
                        
                        ui: 'svmx-white-panel',
                        cls: 'filter-region',
                        layout : {type : "vbox"},
                        defaults : {padding : '0 5 0 0'},
                        titleAlign: 'center',
                        items : [ 
                        { xtype: 'button', 
                                    iconCls: 'filter-icon',
                                    margin: '9 20 20 20', //TODO. Relative margion has to be applied here
                                    handler : function(){
                                       
                                       var evt = SVMX.create("com.servicemax.client.lib.api.Event", 
                                                             "FILTER_ACTION_CALL",
                                                             this);
                                        SVMX.getClient().triggerEvent(evt);


                                    }
                                },{ xtype: 'button', 
                                    text : 'Search',
                                    width: 150,
                                    height: 30,
                                    margin: '-45 0 0 60', //TODO. Relative margion has to be applied here
                                    handler : function(){
                                        
                                        //Ext.Msg.alert('Search', 'Implement search here.');
                						me.__installbaseSearch = SVMX.create("com.servicemax.client.installigence.search.Search",{
                						config : me.__meta.advanceSearch,mvcEvent : "SEACH_INSTALLBASE"});
            							me.__installbaseSearch.find();
                                        
                                    }
                                },
                                // { xtype: 'button', 
                                //     text : 'Action',
                                //     width: 150,
                                //     height: 30,
                                //     margin: '-30 0 0 750', //TODO. Relative margion has to be applied here
                                      
                                //     handler : function(){
                                        
                                //         Ext.Msg.alert('Action', 'Implement Action here.');
                                //     }
                                // }
                                actions
                            ]
                        
                            } , config || {});

                         this.callParent([config]);

                },

                filterButtonAction : function(){

                        
                },

                searchButtonAction: function(){

                        
                }    
			});
	}



})();