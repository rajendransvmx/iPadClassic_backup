/**
 * This file needs a description
 * @class com.servicemax.client.sfmconsole.api
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */
(function(){

	var clientConsoleApi = SVMX.Package("com.servicemax.client.sfmconsole.api");
	clientConsoleApi.Class("AbstractConsoleApp", com.servicemax.client.lib.api.Object, {
		__parent                    : null,
		__container                 : null,
		__size                      : null,
		__visibility                : null,
		__group                     : null,
		__windowTitle               : null,
		__closeCallBack             : null,
		__callbackContext           : null,
		__windowId                  : null,
		__title                     : null,
		__opener                    : null,

		__constructor : function(inParams){
			this.__parent = inParams.parent;
			this.__options = inParams.options;
			this.__container = this.__createRootContainer(inParams.rootContainer, this.__options);
			this.__appConfig = inParams.appConfig;
			this.__opener = inParams.opener;
			this.__windowId = this.__generateWindowId();
			this.__size = {
			    width:  inParams.rootContainer.getContentAreaMaxHeight(),
			    height: null
			};
		},

		/*
		 * All window Ids come from this one method, which means changing this one method should redefine windowIds
		 * throughout the application
		 */
		__generateWindowId : function(consoleAppContainer, consoleAppInfo) {
		    return this.__container.getId();
		},


		__createRootContainer : function(parentContainer, options) {
		    var consoleAppContainer = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
				collapsible : false,
				frame       : true,
				title       : options.title,
				closable    : options.isClosable,
				region      : 'center',
				layout      : 'fit',
				margin      : this.__contentAreaMargin,
				hidden      : true,
				listeners   : {
					beforeClose: SVMX.proxy(this, function(){
						this.__parent.closeConsoleApp(this);
						return false;
					})
				}
			});

			parentContainer.add(consoleAppContainer);
			return consoleAppContainer;
		},

		getId : function() {return this.__windowId;},
		getRoot : function() {return this.__container;},
		getOpener : function() {return this.__opener;},

		// *** INterface to the App's configuration

		/** */
		getAppTypeId : function() {return this.__appConfig.app.id;},

		/** */
		getAppConfig : function() {return this.__appConfig;},

		/** */
		isSingleton : function() {return !this.__appConfig.multiple;},

		// *** Interface to the dom node for this console app ***

		/** */
		show : function() {
			this.__visibility = true;
		    this.getRoot().show();
	        SVMX.doLater(SVMX.proxy(this, "onShow")); // trigger an onShow event... later.
		},

		/** */
		hide : function() {
			this.__visibility = false;
		    this.getRoot().hide();
		    SVMX.doLater(SVMX.proxy(this, "onHide")); // trigger an onHide event... later.
		},

	    /** */
		isShowing : function() {return !this.getRoot().hidden;},

		/** */
		destroy : function() {
		    this.getRoot().destroy();

		    // probably more things that need destroying.
		},

		start : function() {

		},

		requestClose : function () {
			this.__parent.destroyConsoleApp(this);
		},

		onCanClose : function (callback) {
			callback(true);
		},

		/**
		 * @event
		 * Subclasses override onClose to be notified when they are being closed so that they have time to clean up
		 * all resources and call destroy on anything needing destroying.
		 * The parent method is currently empty, but may be used to clean up resources at the window level
		 */
		onClose : function () {

		},

		/**
		 * @event
		 * Called immediately after this console app is hidden. Not called if its being hidden because its being destroyed;
		 * use onClose for that event.
		 */
		onHide : function() {


		},

		/**
		 * @event
		 * Called immediately after this console app is shown. Not called when it is being created; this is intended
		 * to restore any state or function disabled via onHide.
		 */
		onShow : function() {

		},

		refreshAppView : function () {

		},

		showLoadMask : function(target) {
			this.__parent.showSpinner(target || this.__container);
		},

		hideLoadMask : function(target) {
			this.__parent.hideSpinner();
		},

		getGroup : function () {
			return this.__group;
		},

		getWindowId : function () {
			return this.__windowId;
		},

		setWindowTitle : function(title){
			this.__windowTitle = title;
			this.__container.setTitle(this.__windowTitle);
		},

		getWindowTitle : function () {
			return this.__windowTitle;
		},

		getCloseCallBack : function () {
			return this.__closeCallBack;
		},

		getCallBackContext : function() {
			return this.__callbackContext;
		},

		setAppInfo : function (options) {
			options = options || {};

			this.__group = options.groupName;
			this.__windowTitle = options.windowTitle;
			this.__closeCallBack = options.closeCallback;
			this.__callbackContext = options.context;

			this.__parent.applyAppInfo(this);
		},

		setTitle : function(inText) {
		    this.__title = inText;
		    this.getRoot().setTitle(inText);
		},
		getTitle : function() {return this.__title;},

		getConsoleAppContainer : function() {
			return this.__container;
		},

		setRootContainer : function (container) {
			this.getConsoleAppContainer().add(container);
			this.onAppResize(this.getSize());
		},

		getSize : function() {
			return this.__size;
		},

		setSize : function() {

		},

		getVisibility : function(){
			return this.__visibility;
		},

		setVisibility : function (){

		},

		closeConsoleApp : function (){

		}
	}, {});

	clientConsoleApi.Class("AbstractSync", com.servicemax.client.lib.api.Object, {
		__syncManager : null,
		__constructor : function(){},
		run : function() {},
		getSyncManager : function(){
			return this.__syncManager;
		}
	}, {});

	clientConsoleApi.Class("AbstractDeliveryEngine", com.servicemax.client.lib.api.Object, {

		__constructor : function(){

		},

		initAsync : function(options){},

		run : function(options){},

		getInterface : function(){
			return this;
		}

	}, {});

	clientConsoleApi.Class("CompositionMetaModel", com.servicemax.client.lib.api.EventDispatcher, {
		_data : null, _parent : null, _children : null, isDisplayOnly : false,

		__constructor : function(data, parent, isDisplayOnly){
			this.__base();
			this._data = data;
			this._parent = parent;
			this._children = {};
			if(parent){
				this.isDisplayOnly = parent.isDisplayOnly;
			}else{
				this.isDisplayOnly = false;
			}
		},

		getChildNode : function(name){
			return this._children[name];
		},

		getData : function(){
			return this._data;
		},

		getRoot : function(){
			if(this._parent === null)
				return this;
			else
				return this._parent.getRoot();
		},

		resolveDependencies : function(){}

	}, {});

})();