(function () {
    var impl = SVMX.Package("com.servicemax.client.usage.impl");

    impl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {

        __constructor: function () {
            this.__base();
        },

        beforeInitialize: function () {
        },

        initialize: function () {
            com.servicemax.client.usage.appdata.init();
            com.servicemax.client.usage.usagedataapi.init();
        },

        afterInitialize: function () {
            
        }

    }, {});



})();