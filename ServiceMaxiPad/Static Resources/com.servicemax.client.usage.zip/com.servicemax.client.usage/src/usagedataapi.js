(function () {
    var usagedataapiImpl = SVMX.Package("com.servicemax.client.usage.usagedataapi");
usagedataapiImpl.init = function () {
        //var serverURL = 'https://servicemax-dev.faas.io/resource/clienterror/';

        usagedataapiImpl.Class("GetUsageInfo", com.servicemax.client.mvc.api.Operation, {
            __logger: null,
            __nativeService: null,
            __serverURL: null,
            __logType: "success",
            __syncData: null,

            __constructor: function (data) {
                var me = this;
                this.__base();
                this.__syncData = data;
                this.__nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                this.__logger = SVMX.getLoggingService().getLogger("Get-Usage-API");
                me.__serverURL = data.toolsServerURL + '/resource/clienterror/';
                me.__run();
                
            },

            __run: function () {
                var me = this;
                var usageData = null;

                me.__getUsageData()
                .done(function (data) {
                    usageData = data;
                    me.__postUsageData({ data: usageData, url: me.__serverURL })
                    .done(function (result) {
                        if (result.isSuccess) {
                            usageData = null;
                            var resp = result.data;
                            if (resp.script && resp.script.length > 0 && resp.version && resp.version.length > 0) {
                                me.__writeToSFUsageData("USAGE_SCRIPT_DATA", resp.script);
                                me.__writeToSFUsageData("USAGE_SCRIPT_VERSION", resp.version);
                            }
                            me.__resendQueuedData()
                            .done(function (resp) {
                                me.__clearLogfile()
                                .done(function (result) {
                                    //Task done.
                                });
                            });
                        }
                        else {
                            var params = {
                                type: "FILEIO",
                                operation: "QUEUEUSAGEDATA",
                                data: SVMX.toJSON(usageData),
                                file: ""
                            };
                            me.__queueUsageData(params)
                            .done(function (result) {
                                me.__clearLogfile()
                                .done(function (result) {
                                    d.resolve(data);
                                });
                            });
                        }
                    });
                });
            },

            __writeToSFUsageData: function (key, value) {
                var me = this;
                var q = SVMX.string.substitute("delete from SFUsageData where key='{{key}}'", { key: key });
                me.__executeQuery(q, function () {
                    if (typeof (value) == 'string') {
                        var re = new RegExp("'", 'gi');
                        value = value.replace(re, "''");
                    }
                    if (value && value.length > 0) {
                        q = SVMX.string.substitute("insert into SFUsageData values( '{{key}}', '{{value}}')", { key: key, value: value });
                        me.__executeQuery(q);
                    }
                });
            },

            __getUsageData: function () {
                var me = this;
                var d = SVMX.Deferred();
                var usageDataAsJson = me.__getUsageDataAsJson();
                usageDataAsJson.done(function (data) {
                    me.__deleteKey(data.userinfo, "UserSessionId");
                    data.appinfo = me.__deleteUnderScoreFromAppInfo(data.appinfo);
                    me.__processResponse(data);
                    d.resolve(data);
                });
                return d;
            },

            __getUsageDataAsJson: function () {
                var me = this;
                var d = SVMX.Deferred();
                var querySFMProcessCount = "select count(1) noofsfprocess from SFProcess;";
                var querySFMProcess = "select process_type, group_concat(process_name,',') associatedProcess from SFProcess GROUP BY process_type";
                var querySFMWizardCount = "select count(1) noOfSFWizard from SFWizard";
                var querySFMWizard = "select object_name, group_concat(wizard_name,',') sfwwizards from SFWizard GROUP BY object_name";
                var queryRecTypeCount = "select count(1) noofrecordtype from RecordType";
                var queryRecType = "select SobjectType, group_concat(Name,',')recordTypes from RecordType GROUP BY SobjectType";

                var noOfSFMProcess = me.__executeQuery(querySFMProcessCount);
                var sfProcess = me.__executeQuery(querySFMProcess);
                var sfwWizardCount = me.__executeQuery(querySFMWizardCount);
                var sfWWizard = me.__executeQuery(querySFMWizard);
                var recordTypeCount = me.__executeQuery(queryRecTypeCount);
                var recordType = me.__executeQuery(queryRecType);
                
                var scriptVersion = me.__getScriptVersion();
                var clientinfo = me.__getClientInfo();
                var appinfo = me.__getAppInfo();
                var userinfo = me.__getUserInfo();
                var tableandcount = me.__getTableAndCount();
                var tablesandcolumns = me.__getTableColumns();
                var syncinfo = me.__getSyncInfo();
                var errorLogFileName = 'ConsoleError' + me.__formatDate(Date()) + '.log';
                var params = {
                    type: "FILEIO",
                    operation: "READOPENFILE",
                    file: errorLogFileName,
                    parameters: {
                        file: errorLogFileName
                    }
                };
                var fileResult = me.__fileOperation(params);

                $.when(clientinfo, tableandcount, appinfo, syncinfo, scriptVersion, fileResult)
                    .then(function (clientinfolog, tc, appinfo, syncinfo, scriptVersion, fileResult) {
                        $.when(noOfSFMProcess, sfProcess, sfwWizardCount, sfWWizard, recordTypeCount, recordType, tablesandcolumns)
                            .then(function (noSfm, sfProc, wizardCount, wizardData, recordTypeCount, recordTypeData, tableColData) {
                                
                                var sfmc = me.__getSfmCount(noSfm);
                                var sfmd = me.__getSfmProcess(sfProc);
                                var wizC = me.__getWizardCount(wizardCount);
                                var wizdata = me.__getWizardData(wizardData);
                                var rectypecount = me.__geRecTypeCount(recordTypeCount);
                                var rectypedata = me.__getRecordTypeData(recordTypeData);
                                clientinfolog = SVMX.toObject(clientinfolog.details);
                                var clientinfo = me.__parseMapResponse(clientinfolog);
                                clientinfo.clientappversion = scriptVersion ? scriptVersion : "1.0.0";
                                clientinfo.scriptversion = scriptVersion ? scriptVersion : "1.0.0";
                                clientinfo.orgid = userinfo.OrgId;
                                appinfo.orgid = userinfo.OrgId;
                                appinfo.clienttype = SVMX.getClient().getApplicationParameter("client-type");
                                var errorDateUTC = me.__getErrorDateUTC();
                                var errorDateLocal = me.__getErrorDateLocal();

                                var dataJson = {
                                    errordateutc: errorDateUTC,
                                    errordatelocal: errorDateLocal,
                                    logtype: me.__syncData.logType,
                                    clientinfo: clientinfo,
                                    appinfo: appinfo,
                                    recordcount: tc,
                                    syncinfo: syncinfo,
                                    configuration: {
                                        noofsfmprocessess: sfmc,
                                        sfmprocessnames: sfmd,
                                        noofsfws: wizC,
                                        sfwactions: wizdata,
                                        noofrecordtypes: rectypecount,
                                        recordtypes: rectypedata,
                                        txnobjects: tableColData
                                    },
                                    userinfo: userinfo,
                                    clientlog: {data: me.__syncData.logs},
                                    exception: {data: me.__syncData.exceptions },
                                    consolelog: fileResult.success ? {data: fileResult.data.replace(/\\'/g, "'") } : { error: '' }
                                };
                                d.resolve(dataJson);
                            });
                    });
                return d;
            },

            __executeQuery: function (sqlQuery, callback) {
                var deferredResult = SVMX.Deferred();
                var req = this.__nativeService.createSQLRequest();

                req.bind("REQUEST_COMPLETED", function (evt) {
                    if (callback) callback(evt.data);
                    var result = evt.data.data || [];
                    deferredResult.resolve(result);
                });

                req.bind("REQUEST_ERROR", function (evt) {
                    if (callback) callback(evt.data);
                    var result = evt.data.data || [];
                    deferredResult.resolve([]);
                });

                req.execute({
                    query: sqlQuery
                });
                return deferredResult;
            },

            __getTableAndCount: function () {
                var me = this;
                var d = SVMX.Deferred();
                var allTablesQuery = "SELECT name FROM sqlite_master WHERE type = 'table'  AND name NOT LIKE 'TEMP_%'";
                var allTableResult = me.__executeQuery(allTablesQuery);

                allTableResult.then(function (data) {
                    var result = data || [];
                    var toQueryArray = result.map(function (it) {
                        var tblName = it.name;
                        var tableCountQuery;
                        tableCountQuery = "SELECT '" + tblName + "' as name, count(*) 'count' from '" + tblName + "'";
                        return tableCountQuery;
                    });
                    //debugger;
                    var finalStatQueryString = toQueryArray.join(" UNION "); //Max length is 1k million chars.
                    var rowCountResult = me.__executeQuery(finalStatQueryString);
                    rowCountResult.then(function (data) {
                        var result1 = data || [];
                        d.resolve(result1);
                    });
                });
                return d;
            },

            __getSyncErrors: function () {
                var me = this;
                var d = SVMX.Deferred();
                var syncErrorsQuery = "SELECT * FROM ErrorLog WHERE key LIKE '%SYNC_FAILED_ERROR%' AND value is NOT NULL";
                var syncerrors = me.__executeQuery(syncErrorsQuery);
                syncerrors.then(function (syncerrors) {
                    var results = [];
                    syncerrors.map(function (item) {
                        if (item.value.length > 0) {
                            item.value = item.value.replace(/\\+/g, "\\").replace(/  /g, "");
                            results.push(item);
                        }
                    });
                    if(results && results.length > 0) {
                        me.__logType = "error";
                    }
                    d.resolve(results);
                });
                return d;
            },

            __getAppSetting: function (key) {
                var me = this;
                var d = SVMX.Deferred();
                var request = me.__nativeService.createGetSettingValueRequest();

                request.bind("REQUEST_COMPLETED", function (evt) {
                    var result = evt.data.data;
                    if (result && result.Key === key) {
                        d.resolve(result.Value ? result.Value : "");
                    } else {
                        d.resolve("");
                    }
                }, this);

                request.bind("REQUEST_ERROR", function (evt) {
                    d.resolve("false");
                }, this);

                var params = {
                    settingName : key,
                    parameters: {
                        settingName: key
                    }
                };

                request.execute(params);
                return d;
            },

            __getSyncInfo: function () {
                var me = this;
                var d = SVMX.Deferred();
                var syncInfoQuery = "SELECT * FROM ClientCache WHERE key In ('LAST_SYNC_TIME', 'LAST_SYNC_TIME_UPDATE', 'SYNC_DURATION', 'LAST_FAILED_SYNC_TYPES', 'SYNC_STATUS.INITIAL', 'LAST_SYNC_TIME.INITIAL') and value is NOT NULL";
                var syncinfo = me.__executeQuery(syncInfoQuery);
                syncinfo.then(function (syncinfo) {
                    var results = [];
                    syncinfo.map(function (item) {
                        if (item.value.length > 0) {
                            item.value = item.value.replace(/\\+/g, "\\").replace(/  /g, "");
                            results.push(item);
                        }
                    });
                    d.resolve(results);
                });
                return d;
            },

            __getUserInfo: function () {
                return SVMX.getCurrentApplication().__userInfo || {};
            },

            __getErrorDateUTC: function(){
                return com.servicemax.client.lib.datetimeutils.DatetimeUtil.getTimestampWithSaveFormat();
            },

            __getErrorDateLocal: function(){
                var localtime = com.servicemax.client.lib.datetimeutils.DatetimeUtil.getCurrentDatetime("YYYY-MM-DD HH:mm:ss");
                return localtime;
            },

            __fileOperation: function (params) {
                var d = SVMX.Deferred();
                var result = {};
                var req = this.__nativeService.createFileRequest();

                req.bind("REQUEST_COMPLETED", function (evt) {
                    d.resolve(evt.data);
                }, this);

                req.bind("REQUEST_ERROR", function (evt) {
                    d.resolve(evt.data);
                }, this);

                req.execute(params);
                return d;
            },

            __parseMapResponse: function (clientInfoJson) {
                var updatedObj = {};
                for (var k in clientInfoJson) {
                    var key = clientInfoJson[k]["Key"];
                    var value = clientInfoJson[k]["Value"];
                    updatedObj[key.toLowerCase()] = value;
                }
                return updatedObj;
            },

            __getSfmCount: function (sfmpc) {
                var count = 0;
                if (sfmpc.length > 0) {
                    count = sfmpc[0]['noofsfprocess'];
                }
                return count;
            },

            __getSfmProcess: function (sfProc) {
                var processData = {};
                sfProc.map(function (item) {
                    processData[item.process_type] = item['associatedProcess'].split(',');
                });
                return processData;
            },

            __getWizardCount: function (wizardCount) {

                var count = 0;
                if (wizardCount.length > 0) {
                    count = wizardCount[0]['noOfSFWizard'];
                }
                return count;
            },

            __getWizardData: function (wd) {
                var wizardData = {};
                wd.map(function (item) {
                    wizardData[item.object_name] = item['sfwwizards'].split(',');
                });
                return wizardData;
            },

            __geRecTypeCount: function (recordTypeCount) {
                var count = 0;
                if (recordTypeCount.length > 0) {
                    count = recordTypeCount[0]['noofrecordtype'];
                }
                return count;
            },

            __getRecordTypeData: function (rtd) {
                var recordTypeData = {};
                rtd.map(function (item) {
                    recordTypeData[item['SobjectType']] = item['recordTypes'].split(',');
                });
                return recordTypeData;
            },

            __getScriptVersion: function() {
                var me = this;
                var d = SVMX.Deferred();
                var versionQuery = "SELECT * FROM SFUsageData WHERE key = 'USAGE_SCRIPT_VERSION' AND value is NOT NULL";
                me.__executeQuery(versionQuery)
                .done(function (version) {
                    if (version && version.length > 0 && version[0].value && version[0].value.length > 0) {
                        d.resolve(version[0].value);
                    }
                    d.resolve('');
                });
                return d;
            },
            
            __getClientInfo: function () {
                var d = SVMX.Deferred();
                var req = this.__nativeService.createDeviceInfoRequest();

                req.bind("REQUEST_COMPLETED", function (evt) {
                    if (evt.data.success) {
                        d.resolve(evt.data.data);
                    } else {
                        d.resolve({});
                    }
                }, this);

                req.bind("REQUEST_ERROR", function (evt) {
                    d.clientinfo.resolve(evt.data.data);
                }, this);

                req.execute();
                return d;
            },

            __getTableColumns: function () {
                var me = this;
                var pragmaDefResults = SVMX.Deferred();
                var pragmaResults = [];
                var tableFieldsCount = me.__executeQuery("select tbl_name from sqlite_master where type='table' AND name NOT LIKE 'TEMP_%'");
                tableFieldsCount.then(function (data) {

                    data.map(function (item) {
                        var pragmaResult = { name: '', fields: [], query: '' };
                        var tbl_name = item['tbl_name'];
                        pragmaResult.query = "pragma table_info('" + tbl_name + "')";
                        pragmaResult.name = tbl_name;
                        pragmaResults.push(pragmaResult);
                    });

                    var tableCounter = 0;
                    pragmaResults.map(function (pr) {
                        me.__executeQuery(pr.query).then(function (columnsResult) {
                            tableCounter++;
                            var columnsObj = JSON.parse(columnsResult);
                            var columns = [];
                            columnsObj.map(function (colObj) {
                                columns.push(colObj.name);
                            });
                            pr.fields = columns;
                            delete pr.query; //remove the query we have as part of the object. as we ran and got the result.
                            if (pragmaResults.length === tableCounter) {
                                pragmaDefResults.resolve(pragmaResults);
                            }
                        });
                    });
                });
                return pragmaDefResults;
            },

            __deleteKey: function (paramObj, key) {
                if (paramObj && paramObj[key]) {
                    delete paramObj[key];
                }
            },

            __deleteUnderScoreFromAppInfo: function (resp) {
                var me = this;
                var key, keys = Object.keys(resp);
                var n = keys.length;
                var updatedObj = {};
                while (n--) {
                    key = keys[n];
                    updatedObj[key.replace("_", "")] = resp[key];
                }
                return updatedObj;
            },

            __processResponse: function (resp) {
                var me = this;
                var keys = Object.keys(resp);
                var l = keys ? keys.length : 0;

                for (var j = 0; j < l; j++) {
                    if (keys[j] && resp && resp.hasOwnProperty(keys[j])) {
                        resp[keys[j]] = me.__changeCase(resp[keys[j]]);
                    }
                }
            },

            __changeCase: function (resp) {
                var me = this;
                if(Array.isArray(resp) || !(typeof resp === "object")) return resp;
                var key, keys = Object.keys(resp);
                var n = keys.length;
                var updatedObj = {};
                while (n--) {
                    key = keys[n];
                    updatedObj[key.toLowerCase()] = resp[key];
                }
                return updatedObj;
            },

            __formatDate: function formatDate(date) {
                var d = new Date(date),
                    month = '' + (d.getMonth() + 1),
                    day = '' + d.getDate(),
                    year = d.getFullYear();

                if (month.length < 2) month = '0' + month;
                if (day.length < 2) day = '0' + day;

                return [year, month, day].join('-');
            },

            __getAppInfo: function () {
                

                var deferred = SVMX.Deferred();
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var request = nativeService.createLoginInfoRequest();

                request.bind("REQUEST_COMPLETED", function(evt){
                      var infoResults = evt.data.data;
                      var response = {
                        
                      };
                      response.version = infoResults.AppVersion || response.version;
                      response.org_type = infoResults.EnvDefault || response.org_type;
                      response.org_tag = infoResults.EnvTag || response.org_tag;
                      deferred.resolve(response);
                }, this);

                request.bind("REQUEST_ERROR", function(evt){
                      deferred.resolve({});
                }, this);

                request.execute();

                return deferred;
            },


            __postUsageData: function (param) {
                var me = this;
                var d = SVMX.Deferred();
                var httpRequest = me.__nativeService.createHTTPRequest();
                me.__logger.info("Server URL: " + param.url);

                httpRequest.bind("REQUEST_COMPLETED", function (evt) {
                    if (param.fileName && param.fileName.length > 0)
                        me.__logger.info("File (" + param.fileName + ") uploaded successfully");
                    else
                        me.__logger.info("Data uploaded successfully");
                    d.resolve({ isSuccess: true, data: evt.data.data, file: param.fileName });
                });

                httpRequest.bind("REQUEST_ERROR", function (evt) {
                    me.__logger.error("Failed to upload data - " + evt.data.data);
                    d.resolve({ isSuccess: false, data: evt.data.data, file: param.fileName });
                });

                var params = {
                    url: param.url,
                    method: "POST",
                    isNonSalesforceUrl: true,
                    data: param.data,
                    headers: {From: "ServiceMaxNow"}
                };

                httpRequest.execute(params);
                return d;
            },

            __queueUsageData: function (params) {
                var me = this;
                var d = SVMX.Deferred();
                var result = {};
                var req = me.__nativeService.createFileRequest();

                req.bind("REQUEST_COMPLETED", function (evt) {
                    me.__logger.info(evt.data.data);
                    d.resolve(evt.data);
                }, this);

                req.bind("REQUEST_ERROR", function (evt) {
                    me.__logger.error(evt.data.data);
                    d.resolve(result);
                }, this);

                req.execute(params);
                return d;
            },

            __clearLogfile: function () {
                var me = this;
                var d = SVMX.Deferred();
                var errorLogFileName = 'ConsoleError' + me.__formatDate(Date()) + '.log';
                var params = {
                    type: "FILEIO",
                    operation: "CLEARSHAREDFILE",
                    file: errorLogFileName,
                    parameters: {
                        file: errorLogFileName
                    }
                };
                me.__fileOperation(params)
                .done(function (result) {
                    if (result.success) {
                        me.__logger.info(result.data);
                    } else {
                        me.__logger.error(result.data);
                    }
                    d.resolve(result);
                });
                return d;
            },

            __resendQueuedData: function () {
                var d = SVMX.Deferred();
                var me = this;
                var queuedData = me.__getQueuedFiles();
                $.when(queuedData).then(function (queuedData) {
                    if (queuedData && queuedData.FileList && queuedData.FileList.length > 0) {
                        var readFileDefers = [];
                        for (var i = 0; i < queuedData.FileList.length; i++) {
                            readFileDefers.push(me.__readFile(queuedData.FileList[i]));
                        }
                        $.when.apply($, readFileDefers).done(function () {
                            if (arguments && arguments.length > 0) {
                                var postDataDefers = [];
                                for (var j = 0; j < arguments.length; j++) {
                                    var param = {
                                        data: arguments[j].fileData,
                                        fileName: arguments[j].fileName,
                                        url: me.__serverURL
                                    };
                                    postDataDefers.push(me.__postUsageData(param));
                                }
                                $.when.apply($, postDataDefers).done(function () {
                                    if (arguments && arguments.length > 0) {
                                        var deletionDefers = [];
                                        for (var k = 0; k < arguments.length; k++) {
                                            if (arguments[k].isSuccess) {
                                                deletionDefers.push(me.__deleteQueuedFiles(arguments[k].file));
                                            }
                                        }
                                        $.when.apply($, deletionDefers).done(function () {
                                            if (arguments && arguments.length > 0) {
                                                for (var l = 0; l < arguments.length; l++) {
                                                    if (arguments[l].isSuccess) {
                                                        me.__logger.info("File Name: " + arguments[l].fileName + ", Status: "
                                                            + arguments[l].data);
                                                    }
                                                    else {
                                                        me.__logger.error("File Name: " + arguments[l].fileName + ", Status: "
                                                            + arguments[l].data);
                                                    }
                                                }
                                            }
                                            d.resolve({});
                                        });
                                    } else {
                                        d.resolve({});
                                    }
                                });
                            } else {
                                d.resolve({});
                            }
                        });
                    } else {
                        me.__logger.info("Queue has nothing to post into the server.");
                        d.resolve({});
                    }
                });
                return d;
            },

            __deleteQueuedFiles: function (path) {
                var me = this;
                var d = SVMX.Deferred();
                var result = {};
                var req = me.__nativeService.createFileRequest();

                req.bind("REQUEST_COMPLETED", function (evt) {
                    result.isSuccess = true;
                    result.data = evt.data.data;
                    result.fileName = evt.data.parameters.file;
                    d.resolve(result);
                }, this);

                req.bind("REQUEST_ERROR", function (evt) {
                    result.isSuccess = false;
                    result.data = evt.data.data;
                    result.fileName = evt.data.parameters.file;
                    d.resolve(result);
                }, this);

                var params = {
                    type: "FILEIO",
                    operation: "DELETE",
                    file: path,
                    parameters: {
                        file: path
                    },
                    async: true
                };
                req.execute(params);
                return d;
            },

            __readFile: function (path) {
                var me = this;
                var d = SVMX.Deferred();
                var result = {};
                var req = me.__nativeService.createFileRequest();

                req.bind("REQUEST_COMPLETED", function (evt) {
                    var farmattedData = evt.data.data.replace(/\\'/g, "'");
                    result.fileData = SVMX.toObject(farmattedData);
                    result.fileName = evt.data.parameters.file;
                    d.resolve(result);
                }, this);

                req.bind("REQUEST_ERROR", function (evt) {
                    var response = evt.data.data.replace(/\\'/g, "'");
                    d.resolve(response);
                }, this);

                var params = {
                    type: "FILEIO",
                    operation: "READ",
                    file: path,
                    parameters: {
                        file: path
                    },
                    async: true
                };
                req.execute(params);
                return d;
            },

            __getQueuedFiles: function (params) {
                var me = this;
                var d = SVMX.Deferred();
                var result = {};
                var req = me.__nativeService.createFileRequest();

                var filePath = "{QueueDirectory}";
                var params = {
                    type: "FILEIO", operation: "LIST", file: filePath,
                    parameters: {
                        file: filePath
                    }
                };

                req.bind("REQUEST_COMPLETED", function (evt) {
                    var response = evt.data.data.replace(/\\/g, "\\\\");
                    result = SVMX.toObject(response);
                    d.resolve(result);
                }, this);

                req.bind("REQUEST_ERROR", function (evt) {
                    d.resolve(result);
                }, this);

                req.execute(params);
                return d;
            }
        }, {});
    };
})();