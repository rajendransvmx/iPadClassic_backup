(function(){
    
    var appdataImpl = SVMX.Package("com.servicemax.client.usage.appdata");

	appdataImpl.init = function(){

		appdataImpl.Class("LogTarget", com.servicemax.client.lib.services.AbstractLogTarget, {
	        __allLogs : "",
	        __captureLogs: false,
	        __constructor: function (options) {
	        	this.registerEvents();
	            this.__base(options);
	        },

	        log: function (message, options) {
	            if(this.__captureLogs){
	            	if (message instanceof Error) {
	                	message = message.stack ? message.stack.toString() : message.toString();
	            	}

		            var msg = options.timeStamp + ": " + options.source + " " + message + "\n";
		            this.__allLogs = this.__allLogs + msg;
	            }
	            
	        },

	        getAllLogs: function(){
	        	return this.__allLogs;
	        },

	        clearLogs: function(){
	        	this.__allLogs = "";
	        },

	        skipLogs: function(){
	        	this.__captureLogs = false;
	        },

	        captureLogs: function(){
	        	this.__captureLogs = true;
	        },

	        registerEvents: function(){
	        	var me = this;
	        	var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
	            var syncManager = servDef.getInstance();

	            syncManager.bind("SYNC_STARTED", function(evt){
	                me.captureLogs();
	                
	            }, this);

	            syncManager.bind("SYNC_FAILED", function(evt){
	            	me.__processErrors(evt, "SYNC_FAILED");
	                
	            }, this);

	            syncManager.bind("SYNC_COMPLETED", function(evt){
	            	me.__processErrors(evt, "SYNC_COMPLETED");
	                
	            }, this);
	        },

	        __processErrors: function(evt, evtName){
	        	var clientType = SVMX.getClient().getApplicationParameter("client-type");
	        	var logging = false, logType = "success";
	        	if(evtName == 'SYNC_FAILED'){
	        		logType = "error";
	        	}

	        	if(evt.data.usageLogging && (evt.data.usageLogging == 'always' || evt.data.usageLogging == 'error') 
	        			&& evtName == 'SYNC_FAILED'){
	        		logging = true; 
	        	}else if(evt.data.usageLogging && evt.data.usageLogging == 'always' && evtName == 'SYNC_COMPLETED'){
					logging = true;
	        	}

	        	errorToDb = { errorRecords: [] };
        		if (evt.data.allFailures && evt.data.allFailures.length > 0) {
	                var jlength = evt.data.allFailures.length;
	                for (var i = 0; i < jlength; i++) {
	                    var errorr = evt.data.allFailures[i];
	                    var errorObject = {};
	                    for (var key in errorr) {
	                        if (key === "logStoreRecord") {
	                            continue; //skip because DOM reference will cause cyclic JSON.
	                        } else {
	                            errorObject[key] = errorr[key];
	                        }
	                    }
	                    errorToDb.errorRecords.push(errorObject);
	                }
	            }


                if((clientType === 'laptop' || clientType === 'MFL') && logging){
                    var objGetData = SVMX.create('com.servicemax.client.usage.appdata.GetAppData');
                    objGetData.processErrors({
                    	syncType: evt.data.syncType, 
                    	logs: this.getAllLogs(), 
                    	logType: logType,
                    	exceptions: errorToDb,
                    	toolsServerURL: evt.data.toolsServerURL || "https://mtools-prod.servicemax-api.com"
                    });
                }
                this.skipLogs();
	            this.clearLogs();
	        }


    	}, {});					
		
	    appdataImpl.Class("GetAppData", com.servicemax.client.lib.api.Object, {
	        __nativeService: null,

	        __constructor: function () {
	            var me = this;
	            this.__base();
	            
	            this.__nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
	        },

	        processErrors: function(data){
	        	var me = this;
	        	me.getSyncUsageErrorData(data);

	        },

	        __retrieveWriteErrors: function (params, callback, context) {
	            var errorToDb = null;
	            if (params.syncErrors && params.syncErrors.allFailures) {
	                errorToDb = { errorRecords: [] };
	                for (var i = 0; i < params.syncErrors.allFailures.length; i++) {
	                    var errorr = params.syncErrors.allFailures[i];
	                    var errorObject = {};
	                    for (var key in errorr) {
	                        if (key === "logStoreRecord") {
	                            continue; //skip because DOM reference will cause cyclic JSON.
	                        } else {
	                            errorObject[key] = errorr[key];
	                        }
	                    }
	                    errorToDb.errorRecords.push(errorObject);
	                }

	                var allSyncType = ['PREINITIAL', 'INITIAL', 'INCREMENTAL', 'INCREMENTAL_AGGRESSIVE', 'ONECALLSYNC', 'AGGRESSIVE', 'CONFIG', 'PURGE', 'LOCATION', 'CONFIG_SYNC_REMINDER', 'INSERT_LOCAL_RECORDS', 'DATA'];
	                var allSyncTypeFailureKeys = [];
	                allSyncType.map(function (item) {
	                    allSyncTypeFailureKeys.push( "'" + "SYNC_FAILED_ERROR." + item + "'");
	                });

	                context.__executeQuery(SVMX.string.substitute("delete from ErrorLog where key IN ({{key}})", { key: allSyncTypeFailureKeys })).done(function (data)  {
	                    context.__writeErrorLog("SYNC_FAILED_ERROR." + params.syncType, errorToDb, callback, context);
	                });
	            }
	            else {
	                context.__writeErrorLog("SYNC_FAILED_ERROR." + params.syncType, errorToDb, callback, context);
	            }
	        },

	        __writeErrorLog : function(key, value, callback, context){
	        	value = SVMX.toJSON(value)
	            var me = this, q = SVMX.string.substitute(
	                    "delete from ErrorLog where key='{{key}}'",{key : key});
	            me.__executeQuery(q).done(function (data) {

	                if(typeof(value) == 'string'){
	                    // escape sql special characters
	                    var re = new RegExp("'", 'gi');
	                    value = value.replace(re, "''");
	                }

	                //making query as insert or replace as sometimes we see error in writing values in console
	                q = SVMX.string.substitute("insert or replace into ErrorLog values( '{{key}}', '{{value}}')",
	                        {key : key, value : value});

	                me.__executeQuery(q).done(function (data) {
	                    if(callback){
	                        callback.call(context);
	                    }
	                });
	            });
	        },

	        getSyncUsageErrorData: function (data) {
	            var me = this;
	            var snippet = me.__getUsageScriptInfo();
                snippet.done(function (snippet) {
                    if (snippet && snippet.length > 0) {
                        if (typeof snippet == 'string') {
                            try {
                                var ret = eval(snippet);
                            } catch (e) {
                                $EXPR.Logger.error('JS Snippet Error: ' + e);
                                var objUsageInfo = new com.servicemax.client.usage.usagedataapi.GetUsageInfo(data);
                            }
                        }
                    } else {
                        var objUsageInfo = new com.servicemax.client.usage.usagedataapi.GetUsageInfo(data);
                    }
                });
	        },
	       
	        __getUsageScriptInfo: function () {
	            var me = this;
	            var d = SVMX.Deferred();
	            var query = "SELECT * FROM SFUsageData WHERE key = 'USAGE_SCRIPT_DATA' AND value is NOT NULL";
	            me.__executeQuery(query)
	            .done(function (data) {
	                if (data && data.length > 0 && data[0].value) {
	                    d.resolve(data[0].value.replace(new RegExp("&#10;", "g"), "\n"));
	                }
	                d.resolve('');
	            });
	            return d;
	        },

	        __executeQuery: function (sqlQuery) {
	            var d = SVMX.Deferred();
	            var req = this.__nativeService.createSQLRequest();

	            req.bind("REQUEST_COMPLETED", function (evt) {
	                var result = evt.data.data || [];
	                d.resolve(result);
	            });

	            req.bind("REQUEST_ERROR", function (evt) {
	                var result = evt.data.data || [];
	                d.resolve([]);
	            });

	            req.execute({
	                query: sqlQuery
	            });
	            return d;
	        },

	        __getDataClientSetting: function () {
	            var me = this;
	            var deferredClientSetting = SVMX.Deferred();
	            var request = me.__nativeService.createGetSettingValueRequest();

	            request.bind("REQUEST_COMPLETED", function (evt) {
	                var result = evt.data.data;
	                if (result && result.Key === "EnableUsageTracking") {
	                    deferredClientSetting.resolve(result.Value ? result.Value : "false");
	                } else {
	                    deferredClientSetting.resolve("false");
	                }
	            }, this);

	            request.bind("REQUEST_ERROR", function (evt) {
	                deferredClientSetting.resolve("false");
	            }, this);

	            var params = {
	                settingName : "EnableUsageTracking",
	                parameters: {
	                    settingName: "EnableUsageTracking"
	                }
	            };

	            request.execute(params);
	            return deferredClientSetting;
	        },

	        __getSyncImpl : function() {
	            
	            var declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.synchronizer");
	            var definitions = SVMX.getClient().getDefinitionsFor(declaration);
	            if(definitions.length === 0){
	                this.__logger.error('Unable to load console synchronizer');
	                return;
	            }

	            var className = definitions[0].config.impl['class-name'];
	            var __syncImpl = SVMX.create(className, this);
	            

	            return __syncImpl;
	        }

	    }, {});

	}
})();