// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmopdocdelivery\src\commands.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmopdocdelivery.commands
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	var sfmopdocdeliverycommands = SVMX.Package("com.servicemax.client.sfmopdocdelivery.commands");
	
sfmopdocdeliverycommands.init = function(){
	
	sfmopdocdeliverycommands.Class("GetUserInfo", com.servicemax.client.mvc.api.CommandWithResponder, {
		__cbContext : null,
		__constructor : function(){ this.__base(); },
		
		executeAsync : function(request, responder){
			this.__cbContext = request.context;
			this._executeOperationAsync(request, responder, {operationId : "SFMOPDOCDELIVERY.GET_USERINFO"});
		}
		
	},{});
	
	sfmopdocdeliverycommands.Class("GetTemplate", com.servicemax.client.mvc.api.CommandWithResponder, {
		__cbContext : null,
		__constructor : function(){ this.__base(); },
		
		executeAsync : function(request, responder){
			this.__cbContext = request.context;
			this._executeOperationAsync(request, responder, {operationId : "SFMOPDOCDELIVERY.GET_TEMPLATE"});
		}
		
	},{});
	
	sfmopdocdeliverycommands.Class("SubmitDocument", com.servicemax.client.mvc.api.CommandWithResponder, {
		__cbContext : null,	
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this.__cbContext = request.context;
			this._executeOperationAsync(request, this, {operationId : "SFMOPDOCDELIVERY.SUBMIT_DOCUMENT"});
		},
	
		result : function(data) { 
			this.__cbContext.onSubmitDocumentComplete(data);
		},
		
		fault : function(data) { 
			// TODO:
		}
	}, {});
	
	sfmopdocdeliverycommands.Class("CreatePDF", com.servicemax.client.mvc.api.CommandWithResponder, {
		__cbContext : null,	
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this.__cbContext = request.context;
			this._executeOperationAsync(request, this, {operationId : "SFMOPDOCDELIVERY.CREATE_PDF"});
		},
	
		result : function(data) { 
			this.__cbContext.onCreatePDFComplete(data);
		},
		
		fault : function(data) { 
			// TODO:
		}
	}, {});
	
	sfmopdocdeliverycommands.Class("ViewDocument", com.servicemax.client.mvc.api.CommandWithResponder, {
		__cbContext : null,	
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this.__cbContext = request.context;
			this._executeOperationAsync(request, this, {operationId : "SFMOPDOCDELIVERY.VIEW_DOCUMENT"});
		},
	
		result : function(data) { 
			
		},
		
		fault : function(data) { 
			// TODO:
		}
	}, {});
	
	sfmopdocdeliverycommands.Class("GetDocumentMetadata", com.servicemax.client.mvc.api.Command, {
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this._executeOperationAsync(request, responder, {operationId : "SFMOPDOCDELIVERY.GET_DOCUMENT_METADATA"});
		}
	}, {});
	
	sfmopdocdeliverycommands.Class("GetDocumentData", com.servicemax.client.mvc.api.Command, {
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this._executeOperationAsync(request, responder, {operationId : "SFMOPDOCDELIVERY.GET_DOCUMENT_DATA"});
		}
	}, {});
	
	sfmopdocdeliverycommands.Class("DescribeObject", com.servicemax.client.mvc.api.Command, {
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this._executeOperationAsync(request, responder, {operationId : "SFMOPDOCDELIVERY.DESCRIBE_OBJECT"});
		}
	}, {});
	
	sfmopdocdeliverycommands.Class("CaptureSignature", com.servicemax.client.mvc.api.CommandWithResponder, {
		__cbHandler : null,	
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this.__cbHandler = request.handler;
			this._executeOperationAsync(request, this, {operationId : "SFMOPDOCDELIVERY.CAPTURE_SIGNATURE"});
		},
	
		result : function(data) { 
			this.__cbHandler(data);
		},
		
		fault : function(data) { 
			// TODO:
		}
	}, {});
	
	sfmopdocdeliverycommands.Class("Finalize", com.servicemax.client.mvc.api.Command, {
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this._executeOperationAsync(request, responder, {operationId : "SFMOPDOCDELIVERY.FINALIZE"});
		}
	}, {});
	
	sfmopdocdeliverycommands.Class("TargetUpdates", com.servicemax.client.mvc.api.CommandWithResponder, {
		__cbContext : null,
		__constructor : function(){ this.__base(); },
	
		executeAsync : function(request, responder){
			this.__cbContext = request.context;
			this._executeOperationAsync(request, this, {operationId : "SFMOPDOCDELIVERY.TARGET_UPDATES"});
		},
		
		result : function(data) { 
			this.__cbContext.onTargetUpdatesComplete(data);
		},
		
		fault : function(data) { 
		// TODO:
		}
		
	}, {});
	
	sfmopdocdeliverycommands.Class("GetDisplayTags", com.servicemax.client.mvc.api.CommandWithResponder, {
		__cbContext : null,
		__constructor : function(){ this.__base(); },
		
		executeAsync : function(request, responder){
			this.__cbContext = request.context;
			this._executeOperationAsync(request, responder, {operationId : "SFMOPDOCDELIVERY.GET_DISPLAY_TAGS"});
		}
		
	},{});
	
};
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmopdocdelivery\src\console.js
/**
 * SFM opdocconsole app
 * @class com.servicemax.client.sfmeventdelivery.console
 * @author Eric Ingram
 * @copyright 2013 ServiceMax, Inc.
 */
(function(){

	var console = SVMX.Package("com.servicemax.client.sfmopdocdelivery.console");

console.init = function(){

	console.Class("ConsoleAppImpl", com.servicemax.client.sfmconsole.api.AbstractConsoleApp, {
		engine : null,

		start : function(options){
			this.options = options || {};

			//this.showLoadMask();

			var engine = SVMX.create("com.servicemax.client.sfmopdocdelivery.engine.DeliveryEngineImpl");
			this.engine = engine.getInterface();

			this.engine.initAsync({
				handler : SVMX.proxy(this,"onEngineInit", options), // need to rename this to onEneingInit for both online/offline/standalone/sfmconsole
				context : this
			});
		},

		onEngineInit: function(options) {
            this.engine.run({
                onReady: {
                    handler: this.onEngineReady,
                    context: this
                },
                onRendered : {
					handler: this.onEngineRendered,
					context: this
				},
				requestClose : {
					handler: this.requestClose,
					context: this
				},
                container : this.getConsoleAppContainer(),
                options : options
            }, options);
        },

		onEngineReady : function(){
			this.setAppInfo({
				windowTitle: "Smart Docs"
			});
			this.hideLoadMask();
			this.__container.setTitle("Smart Docs");
			this.engine.getRoot().resize(this.getSize());
			this.setRootContainer(this.engine.getRoot());
		},

		onEngineRendered : function(objectName, processName) {
			this.hideLoadMask();
			// If the user navigates to a new process from the old process, don't rename
			// the button for their app, as that might be confusing to the user.
			this.setAppInfo({
				groupName: objectName,
				windowTitle: processName,
				closeCallback: "onClose"
			});
		},

//		onClose : function() {
//			if (this.engine) this.engine.destroy();
//			this.__base();
//		},

		onAppHide : function(event){
			// TODO: got to sleep
		},

		onAppShow : function(event){
			// TODO: wake up
		},

		onShow : function(event){
			if(this.__doReset === true && this.engine){
				this.engine.refreshData();
				this.__doReset = false;
			}
		},

		onHide : function(event) {

		},

		reset : function() {
			var isCalVisible = this.getVisibility();
			if(isCalVisible === true){
				if (this.engine) this.engine.refreshData();
			}
			else {
				this.__doReset = true;
			}
		},

		onAppResize : function(event){
			if(this.engine.getRoot()){
				try{
					this.engine.getRoot().resize(event);
				}catch(e){
					SVMX.getLoggingService().getLogger().warn("Could not resize smartdocs =>" + e);
				}
			}
		}

	}, {});

};
})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmopdocdelivery\src\constants.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmopdocdelivery.constants
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	
	var constantsImpl = SVMX.Package("com.servicemax.client.sfmopdocdelivery.constants");

constantsImpl.init = function(){
	constantsImpl.Class("Constants", com.servicemax.client.lib.api.Object, {
		__constructor : function(){}
	}, {
		FINALIZE 							: "Finalize",
		FINALIZE_DIV 						: "finalize_div",
		DRAFT	 							: "Generate Draft",
		DRAFT_DIV	 						: "draft_div",	
		DOCUMENT_PAGE 						: "document_page",
		DOCUMENT_SPINNER 					: "document_spinner",
		TODAY								: "Today",
		TOMORROW							: "Tomorrow",
		YESTERDAY							: "Yesterday",
		NOW									: "Now",
		USERNAME							: "UserName",
		ADDRESS							    : "Address",
		OBJ_NAME							: "OBJ",
		FLD_NAME							: "FN",
		FLD_TYP								: "TYP",
		RLN_NAME							: "RLN",
		REF_OBJ_NAME						: "ROBJ",
		REF_FLD_NAME						: "RFN",
		REF_FLD_TYP							: "RTYP",
		RLN_NAME_2							: "RLN2",
		REF_OBJ_NAME_2						: "ROBJ2",
		REF_FLD_NAME_2						: "RFN2",
		REF_FLD_TYP_2						: "RTYP2",
		TYPE_HEADER							: "Header_Object",
		TYPE_DETAIL							: "Detail_Object",
		LOCALE							    : "Locale",
		IMAGENAMEID							: "ImageNameId"
				
	});
}	
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmopdocdelivery\src\engine.js
/**
 * This file needs a description
 * @class com.servicemax.client.sfmopdocdelivery.engine
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){
	var engine = SVMX.Package("com.servicemax.client.sfmopdocdelivery.engine");

engine.init = function(){
	//imports
	var CONSTANTS = com.servicemax.client.sfmopdocdelivery.constants.Constants;
	//end imports

	engine.Class("DeliveryEngineImpl", com.servicemax.client.sfmconsole.api.AbstractDeliveryEngine, {
		__nodeProcessor : null, __orgNamespace : null, styleNodeValue : null, __timeFormat : null, __dateFormat : null, __uniqueObjects : null,
		__depthCount : 2, __uniqueObjects : null, __jsee : null, __pendingNodeItems : null, __metadata : null, __data : null,
		__processedMetadata : null, __recsInfo : null, __aliasObjectName : null, __aliasDescribeInfo : null, __imageIds : null,
		__eventBus : null, __signaturesPending : null, __allowSignatures : null, __allowDraft : null, __spinner : null,
		__displayTags : null, __settings : null,
		__recordId : null, __processId : null, __sourceRecord : null, __objectLabel : null,
		initAsync : function(options){
			// nothing to initialize, return
			//options.handler.call(options.context);
			var ni = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance();
			this.__eventBus = SVMX.create("com.servicemax.client.sfmopdocdelivery.impl.SFMOPDOCDeliveryEngineEventBus", {});

			// create the named default controller
			ni.createNamedInstanceAsync("CONTROLLER",{ handler : function(controller){

				// now create the named default model
				ni.createNamedInstanceAsync("MODEL",{ handler : function(model){
					controller.setModel(model);
					options.handler.call(options.context);
				}, context : this});

			}, context : this, additionalParams : { eventBus : this.__eventBus }});
		},

		run : function(options){
			if(options !== undefined && options !== null &&
					options.options !== undefined && options.options !== null) {
				this.__processId = options.options.SVMX_processId;
				this.__recordId = options.options.SVMX_recordId;

				this.onEngineRendered = options.onRendered;

				//as of now used for only laptop mobile
				this.__sourceRecord = options.options.SVMX_record;
			}

			if(this.__processId === undefined || this.__processId === null) {
				this.__processId = SVMX.getUrlParameter("SVMX_processId");
			}

			if(this.__recordId === undefined || this.__recordId === null) {
				this.__recordId = SVMX.getUrlParameter("SVMX_recordId");
			}

			var serv = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance();
			serv.createNamedInstanceAsync("NODE_PROCESSOR",{ handler : function(processor){
				this.__nodeProcessor = processor;
				this.__orgNamespace = SVMX.getClient().getApplicationParameter("org-name-space");
				this.__allowSignatures = SVMX.getClient().getApplicationParameter("allow-signatures");
				this.__allowDraft = SVMX.getClient().getApplicationParameter("allow-draft");
				this.__runInternal(options);
			}, context : this });
		},

		__runInternal : function(options){
			this.__rootNode = options.container ? options.container.body.dom : $("#" + SVMX.getDisplayRootId());
			$($("body")[0]).css('background-image', 'none');
			var platformSpecifics = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.sfmopdoc.platformspecifics").getInstance();
			this.returnUrl  = SVMX.getUrlParameter("SVMX_retURL");
			var qInfo = platformSpecifics.getQualificationInfo(this.__recordId, this.__processId, this.__process, this);
			this.__requestClose = options.requestClose;
			this.__settings = platformSpecifics.getSettingsInfo();
		},

		__process : function(qInfo){
			if(!qInfo.isQualified){
				var platformSpecifics = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.sfmopdoc.platformspecifics").getInstance();
				platformSpecifics.alert(qInfo.errorMessage, this.__requestClose);
				platformSpecifics.navigateBack(this.returnUrl);
			}
			else{
				//show the spinner
				this.__includeSpinner();
				this.__jsee = new com.servicemax.client.sfmopdocdelivery.jsel.JSExpressionEngine(this);
				this.__pendingNodeItems = new com.servicemax.client.sfmopdocdelivery.engine.PendingNodeProcessCollection();
				this.__signaturesPending = new com.servicemax.client.sfmopdocdelivery.engine.PendingSignatures(this);

				//special handling for image processing
				SVMX.getClient().triggerEvent(new com.servicemax.client.lib.api.Event("SFMOPDOCDELIVERY.JSEE_CREATED", this, {jsee : this.__jsee}));
				this.__jsee.initialize({ contextRoots : ["$D","$M"] });

				//invoking events for getTemplate, Userinfo, Metadata, and Data
				var currentApp = this.getEventBus();
				var ec = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollection",currentApp,
						[
						 	SVMX.create("com.servicemax.client.lib.api.Event",
								"SFMOPDOCDELIVERY.GET_TEMPLATE", this, {request : { context : this, processId : this.__processId }}),
							SVMX.create("com.servicemax.client.lib.api.Event",
								"SFMOPDOCDELIVERY.GET_USERINFO", this, {request : { context : this }}),
							SVMX.create("com.servicemax.client.lib.api.Event",
								"SFMOPDOCDELIVERY.GET_DOCUMENT_METADATA", this, {request : { context : this, processId : this.__processId }}),
							SVMX.create("com.servicemax.client.lib.api.Event",
								"SFMOPDOCDELIVERY.GET_DOCUMENT_DATA", this, {request : { context : this, returnUrl : this.returnUrl, processId : this.__processId, recordId : this.__recordId }}),
							SVMX.create("com.servicemax.client.lib.api.Event",
								"SFMOPDOCDELIVERY.GET_DISPLAY_TAGS", this, {request : { context : this }})

						 ]);

				ec.triggerAll(function(evtCol){
					var items = evtCol.items(), size = items.length, i, template = null;
					for(i = 0; i < size; i++){
						var item = items[i];
						if(item.type() == "SFMOPDOCDELIVERY.GET_DOCUMENT_METADATA"){
							this.__metadata = item.response;
						}else if(item.type() == "SFMOPDOCDELIVERY.GET_DOCUMENT_DATA"){
							this.__data = item.response;
						}else if(item.type() == "SFMOPDOCDELIVERY.GET_USERINFO"){
							this.__onGetUserInfoComplete(item.response);
						}else if(item.type() == "SFMOPDOCDELIVERY.GET_TEMPLATE"){
							template = item.response;
						}else if(item.type() == "SFMOPDOCDELIVERY.GET_DISPLAY_TAGS"){
							this.__displayTags = item.response;
						}
					}
					this.__onGetTemplateComplete(template);
					this.__getObjectDescribeInfo();

				},this)
			}


		},

		__getObjectDescribeInfo : function(){
			this.__uniqueObjects = {};
			//parse through metadata
			this.__processMetaDataCollection();
			//create events for all the objects
			this.__parseForImageIds();
			var describeList = [];
			var intCount = 0;
			for(var i in this.__uniqueObjects){
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
						"SFMOPDOCDELIVERY.DESCRIBE_OBJECT", this, {request : {objectName : this.__uniqueObjects[i]}});
				describeList[intCount] = evt;
				intCount++;
			}
			if(intCount > 0){
				var currentApp = this.getEventBus();
				var ec = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollection", currentApp, describeList);
				ec.triggerAll(this.onDescribeObjectsComplete, this);
			//invoke all
			}
			else{
				//then process the template
				this.__processTemplate();
			}

		},

		onDescribeObjectsComplete : function(evtCol){
			this.__aliasDescribeInfo = {};
			this.__objectLabel = "";
			//add all labels to the context
			var items = evtCol.items(), size = items.length, i;
			var objMetadataMap = {};
			var objType = "";
			if(this.__sourceRecord !== undefined && this.__sourceRecord !== null &&
					this.__sourceRecord.attributes !== undefined && this.__sourceRecord.attributes !== null
					&& this.__sourceRecord.attributes.type !== undefined && this.__sourceRecord.attributes.type !== null) {
				objType = this.__sourceRecord.attributes.type;
			}
			
			//process and assign the fields to object
			for(i = 0; i < size; i++){
				var item = items[i], objectName = item.getEventObj().data.request.objectName;
				var objMetadataFields = item.response.fields;
				objMetadataMap[objectName] = this.__processObjectDescribe(objMetadataFields);
				if(objectName === objType) {
					this.__objectLabel = item.response.label;
				}
			}
			
			//loop through all alias information and assign reference fields
			var depthCount = this.__depthCount;
			for(var alias in this.__aliasObjectName){
				var objName = this.__aliasObjectName[alias];
				if (objMetadataMap[objName]) {
					var context = {};
					context[alias] = this.__processRefFieldsObjectDescribe(objName,objMetadataMap,depthCount);
					this.__aliasDescribeInfo[alias] = context[alias];
					this.__jsee.addContext(context, "$M");
				}
			}
			//then process the template
			this.__processTemplate();
		},

		__processRefFieldsObjectDescribe : function(objName,objMetadataMap, depthCount){
			var objMetadata = objMetadataMap[objName];
			for(var name in objMetadata){
				if(((objMetadata[name].dataType && objMetadata[name].dataType === "reference") ||
						(objMetadata[name].type && objMetadata[name].type === "reference")) &&
							objMetadata[name].referenceTo && objMetadataMap[objMetadata[name].referenceTo]){
					if(depthCount > 0){
						this.__processRefFieldsObjectDescribe(objMetadata[name].referenceTo, objMetadataMap, depthCount - 1);
					}
					this.__assignFields(objMetadata[name], objMetadataMap[objMetadata[name].referenceTo]);
				}
			}
			return objMetadata;
		},

		__assignFields : function(refFieldInfo, objMetadata){

			var refField = refFieldInfo;
			for(var field in objMetadata){
				refField[field] = objMetadata[field];
			}
			return refField;
		},

		__processObjectDescribe : function(objectFields){

			var objectMetadata = {};
			for(var i in objectFields){
				objectMetadata[objectFields[i].name] = objectFields[i];
			}
			return objectMetadata;

		},

		__processTemplate : function(){

			this.__processDataCollection();
			this.__processReferenceData();
			this.__onDataFetchComplete();
		},

		getEventBus : function(){
			//return SVMX.getCurrentApplication();
			return this.__eventBus;
		},

		__onDataFetchComplete : function(){

			// process svmx-data bound attributes
			var nodesToProcess = $("[svmx-data]", $(this.__rootNode)), node;
			var i = 0, l = nodesToProcess.length;
			for (i = 0; i < l; i++) {
				node = nodesToProcess[i];
				this.__nodeProcessor.process(
					{engine : this, node : node, jsee : this.__jsee, pendingNodeItems : this.__pendingNodeItems});
			}
			// end svmx-data processing
			//debugger;
			// inline expression processing
			var allInlineNodeTypes = [	{type : "div", 		name: "ILDIV"},
										{type : "strong", 	name: "ILSTRONG"},
										{type : "u", 		name: "ILU"},
										{type : "i", 		name: "ILI"},
										{type : "p", 		name: "ILP"},
										{type : "pre", 		name: "ILPRE"},
										{type : "h1", 		name: "ILH"},
										{type : "h2", 		name: "ILH"},
										{type : "h3", 		name: "ILH"},
										{type : "h4", 		name: "ILH"},
										{type : "h5", 		name: "ILH"},
										{type : "h6", 		name: "ILH"},
										{type : "style", 	name: "ILS"},
										{type : "span", 	name: "ILSP"},
										{type : "em", 		name: "ILEM"},
										{type : "strike", 	name: "ILSTRIKE"},
										{type : "sub", 		name: "ILSUB"},
										{type : "sup", 		name: "ILSUP"},
										{type : "ol ", 		name: "ILOL"},
										{type : "li", 		name: "ILLI"},
										{type : "ul", 		name: "ILUL"},
										{type : "b", 		name: "ILB"},
										{type : "td", 		name: "ILTD"},
										{type : "th", 		name: "ILTH"}], j, k = allInlineNodeTypes.length;
			for(j = 0; j < k; j++){
				nodesToProcess = $(allInlineNodeTypes[j].type, $(this.__rootNode)); l = nodesToProcess.length;

				for(i = 0; i < l; i++){
					node = nodesToProcess[i];
					this.__nodeProcessor.process(
						{engine : this, node : node, jsee : this.__jsee, name : allInlineNodeTypes[j].name});
				}
			}
			// end inline expression processing
			//if there are mandatory signatures then stay in HTML view(stop processing here)
			//Revised: Show HTML on Click of Finalize draft then generate the report pdf

			$("#" + CONSTANTS.DOCUMENT_PAGE, $(this.__rootNode)).show();
			this.__spinner.stop();

			if (this.onEngineRendered) {
				//TODO: Sum14SP sort out proper displayObj
				//TODO: Sum14SP sort out Process name, don't use Id.
				var nameField = this.__sourceRecord._fields.getNameField().name;
				var displayObj = this.__objectLabel;
				//Display Object
				this.onEngineRendered.handler.apply(
			         this.onEngineRendered.context,
				    [displayObj, this.__sourceRecord[nameField] + ": &nbsp;&nbsp;" + this.__processId]
			    );
			}
		},

		getRoot : function(){
			return this.__rootNode;
		},

		__checkForPendingNodeItems : function(){
			var me = this;
			if(this.__pendingNodeItems.isPending()){
				setTimeout(function(){
					me.__checkForPendingNodeItems();
				},100)
			}else{
				var outputString = $( "#" + CONSTANTS.DOCUMENT_PAGE, $(this.__rootNode)).html();
				outputString = outputString.replace(this.__processedStyleNodeValue,"");
				if(this.__processedStyleNodeValue !== null &&
				this.__processedStyleNodeValue !== undefined &&
				this.__processedStyleNodeValue.length > 0){
					outputString = this.__processedStyleNodeValue + outputString;
				}
				//trigger submit document
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
							"SFMOPDOCDELIVERY.SUBMIT_DOCUMENT", me, {request : { context : me, document : outputString }});

				me.getEventBus().triggerEvent(evt);
			}
		},

		__onGetUserInfoComplete : function(userInfo){

			this.__jsee.setProperty(CONSTANTS.TODAY, userInfo.Today);
			this.__jsee.setProperty(CONSTANTS.TOMORROW, userInfo.Tomorrow);
			this.__jsee.setProperty(CONSTANTS.YESTERDAY, userInfo.Yesterday);
			this.__jsee.setProperty(CONSTANTS.NOW, userInfo.Now);
			this.__jsee.setProperty(CONSTANTS.USERNAME, userInfo.UserName);
			this.__jsee.setProperty(CONSTANTS.ADDRESS, userInfo.Address);
			this.__jsee.setProperty(CONSTANTS.LOCALE, userInfo.Locale);
			this.__timeFormat = userInfo.TimeFormat;
			this.__dateFormat = userInfo.DateFormat;
			SVMX.setClientProperty("amText", userInfo.amText);
			SVMX.setClientProperty("pmText", userInfo.pmText);

		},

		__onGetTemplateComplete : function(template){
			if(this.__allowDraft != null && this.__allowDraft === true){
				this.__createDraftButton();
			}
			else{
				this.__createFinalizeButton();
			}
			this.styleNodeValue = this.__parseforStyle(template.Template);

			$(this.__rootNode).append("<div style='border-radius:5px; border: 1px solid #72b3d5;margin-top: 5px;padding: 5px' id='" + CONSTANTS.DOCUMENT_PAGE + "'></div>");
			document.getElementById($(this.__rootNode)[0].id).style.overflow = "auto";
			$("#" + CONSTANTS.DOCUMENT_PAGE, $(this.__rootNode)).append(template.Template);
			$("#" + CONSTANTS.DOCUMENT_PAGE, $(this.__rootNode)).hide();

		},

		__includeSpinner : function(){
			var opts = {
			  lines: 17, // The number of lines to draw
			  length: 40, // The length of each line
			  width: 10, // The line thickness
			  radius: 59, // The radius of the inner circle
			  corners: 1, // Corner roundness (0..1)
			  rotate: 85, // The rotation offset
			  direction: 1, // 1: clockwise, -1: counterclockwise
			  color: '#da5e28', // #rgb or #rrggbb
			  speed: 2.2, // Rounds per second
			  trail: 60, // Afterglow percentage
			  shadow: false, // Whether to render a shadow
			  hwaccel: false, // Whether to use hardware acceleration
			  className: 'spinner', // The CSS class to assign to the spinner
			  zIndex: 2e9, // The z-index (defaults to 2000000000)
			  top: 'auto', // Top position relative to parent in px
			  left: 'auto' // Left position relative to parent in px
			};

			$(this.__rootNode).append("<div style='position:fixed;top:50%;left:50%' id='" + CONSTANTS.DOCUMENT_SPINNER + "'></div>");
			//var spinnerTarget = document.getElementById(this.__getDivId(CONSTANTS.DOCUMENT_SPINNER));
			var spinnerTarget = $('#' + CONSTANTS.DOCUMENT_SPINNER, $(this.__rootNode))[0];
			this.__spinner = new Spinner(opts).spin(spinnerTarget);
		},

		__createFinalizeButton : function(){
			var me = this;
			var handleFinalizeButtonClick = function(){
				//remove all the buttons

				var docPageNode = $("#" + CONSTANTS.DOCUMENT_PAGE, $(this.__rootNode));
				var buttons = $(docPageNode).find("button");
				if(buttons && buttons.length > 0){
					for(var i = 0;i < buttons.length; i++){
						var isSignatureButton = $(buttons[0]).attr("signature-name") != undefined ? true : false;
						if(isSignatureButton === true){
							$(buttons[i]).remove();
						}
					}
				}
				var outputString = $( "#" + CONSTANTS.DOCUMENT_PAGE, $(me.__rootNode)).html();
				outputString = outputString.replace(me.__processedStyleNodeValue,"");
				if(me.__processedStyleNodeValue !== null &&
				me.__processedStyleNodeValue !== undefined &&
				me.__processedStyleNodeValue.length > 0){
					outputString = me.__processedStyleNodeValue + outputString;
				}
				var evt = SVMX.create("com.servicemax.client.lib.api.Event",
					"SFMOPDOCDELIVERY.FINALIZE", me,{
						request : {
							processId 		 : me.__processId,
							recordId 		 : me.__recordId,
							htmlContent		 : outputString,
							sourceRecord	 : me.__sourceRecord,
							requestClose     : me.__requestClose
						}
					});

				me.getEventBus().triggerEvent(evt);
			};
			var buttonTitle = this.__getTagValue("SFM004_TAG006");
			if(buttonTitle == null){
				buttonTitle = CONSTANTS.FINALIZE;
			}
			var finalizeBtn = "<input style='background:#f16138; -moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px; font: normal 13px tahoma,arial,verdana,sans-serif; border: 1px solid #db3202; color:#FFFFFF; font-weight:bold; padding:3px 15px; cursor:pointer; width: 20%; height: 50px' type='button' id='svmx_finalize' value='"+ buttonTitle +"'>";

			$(this.__rootNode).append("<div style='background:#a4d0e7; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; border: 1px solid #72b3d5;padding: 5px' id='" + CONSTANTS.FINALIZE_DIV + "'></div>");
			$("#" + CONSTANTS.FINALIZE_DIV, $(this.__rootNode)).append(finalizeBtn);
			$('#' + 'svmx_finalize', $(this.__rootNode) ).on("click", SVMX.proxy(this, handleFinalizeButtonClick));
		},

		__createDraftButton : function(){
			var me = this;
			var platformSpecifics = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.sfmopdoc.platformspecifics").getInstance();
			var handleDraftButtonClick = function(){
				var retVal = true;
				if(me.__signaturesPending.isPending()){
					if(me.__settings["SET001"] !== undefined && me.__settings["SET001"] === "Allow"){
						retVal = true;
					}else if(me.__settings["SET001"] !== undefined && me.__settings["SET001"] === "Warn"){
						retVal = platformSpecifics.confirm(me.__getTagValue("SFM004_TAG007"));
					}else if(me.__settings["SET001"] !== undefined && me.__settings["SET001"] === "Disallow"){
						platformSpecifics.alert(me.__getTagValue("SFM004_TAG008"));
						retVal = false;
					}
				}
				if(retVal == true){
					me.__checkForPendingNodeItems();
				}

			}
			var buttonTitle = this.__getTagValue("SFM004_TAG006");
			if(buttonTitle == null){
				buttonTitle = CONSTANTS.DRAFT;
			}
			var draftBtn = "<input style='background:#f16138; -moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px; font: normal 13px tahoma,arial,verdana,sans-serif; border: 1px solid #db3202; color:#FFFFFF; font-weight:bold; padding:3px 15px; cursor:pointer' type='button' id='svmx_draft' value='"+ buttonTitle +"'>";

			$(this.__rootNode).append("<div style='background:#a4d0e7; -moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; border: 1px solid #72b3d5;padding: 5px' id='" + CONSTANTS.DRAFT_DIV + "'></div>");
			$("#" + CONSTANTS.DRAFT_DIV, $(this.__rootNode)).append(draftBtn);
			$('#' + 'svmx_draft', $(this.__rootNode) ).on("click", SVMX.proxy(this, handleDraftButtonClick));

		},

		__getTagValue : function(tagKey){
			var tagValue = null;
			if(this.__displayTags != null && this.__displayTags[tagKey] !== undefined
				&& this.__displayTags[tagKey] !== null){
					tagValue = this.__displayTags[tagKey];
				}
			return tagValue;
		},

		__parseforStyle : function(template){
			var startIndex, endIndex;
			var ret = "";
			if(!template) return ret;

			startIndex = template.indexOf("<style");
			endIndex = template.indexOf("</style>");

			if(startIndex != -1 && endIndex != -1){
				ret = template.substring(startIndex, endIndex);
			}
			if(ret !== undefined && ret !== null && ret.length > 0){
				ret = ret + "</style>";
			}
			return ret;
		},

		onSubmitDocumentComplete : function(document){

			var docId = document.DocumentId;
			var evt = SVMX.create("com.servicemax.client.lib.api.Event",
						"SFMOPDOCDELIVERY.CREATE_PDF", this,
						{request : { context : this, returnUrl : this.returnUrl, documentId : docId, recordId : SVMX.getUrlParameter("SVMX_recordId"), processId: SVMX.getUrlParameter("SVMX_processId")}});

			this.getEventBus().triggerEvent(evt);
		},

		onCreatePDFComplete : function(pdf){

			var evt = SVMX.create("com.servicemax.client.lib.api.Event", "SFMOPDOCDELIVERY.TARGET_UPDATES", this, {
				request: {
					context : this,
					processId: SVMX.getUrlParameter("SVMX_processId"),
					recordId: SVMX.getUrlParameter("SVMX_recordId"),
					pdf: pdf
				}
			});
			this.getEventBus().triggerEvent(evt);
		},

		onTargetUpdatesComplete : function(pdf){

			var evt = SVMX.create("com.servicemax.client.lib.api.Event",
			"SFMOPDOCDELIVERY.VIEW_DOCUMENT", this, {request : { context : this, attachmentId : pdf.PDFAttachmentId, recordId : SVMX.getUrlParameter("SVMX_recordId")}});

			this.getEventBus().triggerEvent(evt);

		},

		//processing metadata
		__processMetaDataCollection : function(){
			var metadata = this.__metadata.AllObjectInfo;
			this.__processedMetadata = {};
			this.__recsInfo = {};
			this.__aliasObjectName = {};
			var sortedArray;
			var i, count = metadata.length;
			for (i = 0; i < count; i++) {
				sortedArray = [];
				var fields = metadata[i][this.__orgNamespace + "__Fields__c"]
				if(!fields || fields.length === 0) continue;
				sortedArray = this.__sortFieldsInformation(metadata[i][this.__orgNamespace + "__Fields__c"])
				this.__processedMetadata[metadata[i][this.__orgNamespace + "__Alias__c"]] = sortedArray;
				this.__recsInfo[metadata[i][this.__orgNamespace + "__Alias__c"]] = metadata[i][this.__orgNamespace + "__Type__c"];
				this.__aliasObjectName[metadata[i][this.__orgNamespace + "__Alias__c"]] = metadata[i][this.__orgNamespace + "__Object_Name__c"]
			}
		},

		//process Image metadata
		__parseForImageIds : function(){
			this.__imageIds = {};
			var templareRec = this.__metadata.TemplateRecord;
			if(templareRec != null && templareRec){
				var imageInfo = templareRec[0][this.__orgNamespace + "__Media_Resources__c"];
				if(imageInfo != null && imageInfo.length > 0){
					var imageInfoObject = SVMX.toObject(imageInfo);
					for(i = 0; i < imageInfoObject.length ; i++){
						this.__imageIds[imageInfoObject[i]["DeveloperName"]] = imageInfoObject[i]["Id"];
					}
				}
			}
			this.__jsee.setProperty(CONSTANTS.IMAGENAMEID, this.__imageIds);

		},

		//processing the data
		__processDataCollection : function() {

			if(this.__data.DocumentData === undefined) return;
			//process the data and build the required object
			var i, count = this.__data.DocumentData.length;
			var documentData = this.__data.DocumentData;
			this.__processedData = {};
			this.__specialFieldsData = {};
			for (i = 0; i < count; i++) {
				this.__processedData[this.__data.DocumentData[i]["Key"]] = this.__data.DocumentData[i]["Records"];
				this.__specialFieldsData[this.__data.DocumentData[i]["Key"]] = this.__data.DocumentData[i]["SpecialFields"];
			}
		},

		//prcessing metadata
		__processReferenceData : function(){
			var metadata = this.__processedMetadata;
			var data = this.__processedData;
			var specData = this.__specialFieldsData;
			for(var key in metadata){

				//for the current metadata alias get the data
				var Recs = data[key];
				var RecSpecData = {};
				for(var idKey in specData[key]){
					RecSpecData[specData[key][idKey].Key] = specData[key][idKey].Value;
				}
				if (Recs !== undefined && Recs !== null) {
					var fields = metadata[key];
					var descInfo = this.__aliasDescribeInfo[key];
					var i, count = fields.length;
					var j, recCount = Recs.length;
					//now loop through the fields
					for (i = 0; i < count; i++) {
						//now loop the recs
						for (j = 0; j < recCount; j++) {
							//handling reference fields
							if (fields[i][CONSTANTS.REF_OBJ_NAME_2]) {
								if(Recs[j][fields[i][CONSTANTS.RLN_NAME]] !== null && Recs[j][fields[i][CONSTANTS.RLN_NAME]][fields[i][CONSTANTS.RLN_NAME_2]] !== null){

									//process each metadata field that have the refernce update the value to actual field
									Recs[j][fields[i][CONSTANTS.RLN_NAME]][fields[i][CONSTANTS.REF_FLD_NAME]]
																= Recs[j][fields[i][CONSTANTS.RLN_NAME]][fields[i][CONSTANTS.RLN_NAME_2]][fields[i][CONSTANTS.REF_FLD_NAME_2]];

								}
							}

							if (fields[i][CONSTANTS.REF_OBJ_NAME]) {
								
								//for second level picklist
								if(fields[i][CONSTANTS.REF_FLD_TYP] === "picklist" && Recs[j][fields[i][CONSTANTS.RLN_NAME]] !== null){
									Recs[j][fields[i][CONSTANTS.RLN_NAME]][fields[i][CONSTANTS.REF_FLD_NAME]] = this.__processPicklistValues(this.__aliasDescribeInfo[key][fields[i][CONSTANTS.FLD_NAME]], fields[i][CONSTANTS.REF_FLD_NAME], Recs[j][fields[i][CONSTANTS.RLN_NAME]]);									
								}
								
								var idValue = '';
								if(Recs[j][fields[i][CONSTANTS.FLD_NAME]] && Recs[j][fields[i][CONSTANTS.FLD_NAME]].Id){
									idValue = Recs[j][fields[i][CONSTANTS.FLD_NAME]].Id;
								}
								else{
									idValue = Recs[j][fields[i][CONSTANTS.FLD_NAME]];
								}
								Recs[j][fields[i][CONSTANTS.FLD_NAME]] = Recs[j][fields[i][CONSTANTS.RLN_NAME]];
								if(Recs[j][fields[i][CONSTANTS.FLD_NAME]])
									Recs[j][fields[i][CONSTANTS.FLD_NAME]].Id = idValue;
								
								

							}
							
							if(fields[i][CONSTANTS.FLD_TYP] === "picklist"){
								Recs[j][fields[i][CONSTANTS.FLD_NAME]] = this.__processPicklistValues(this.__aliasDescribeInfo[key], fields[i][CONSTANTS.FLD_NAME], Recs[j]);							 
							}
						}
					}

					//now handling for special fields
					for (j = 0; j < recCount; j++) {
						Recs[j] = this.__processSpecialFields(RecSpecData, Recs[j]);
						//now process security check
						Recs[j] = this.__processFieldSecurity(Recs[j],descInfo);
						//the below statement is used in SNUMBER function
						Recs[j].aliasName = key;
					}
				}
				var context = {};
				context[key] = Recs;
				if (this.__recsInfo[key] === CONSTANTS.TYPE_HEADER) {
					context[key] = Recs[0];
				}
				this.__jsee.addContext(context, "$D");
			}

		},
		
		__processPicklistValues : function(descInfo, fldName, rec){
			var pickValuesObjArray = descInfo[fldName].picklistValues;
			 var pickedObj = {label : '', value : ''};//if not found.. set default to empty
			 if(pickValuesObjArray.length > 0)
			 {
				  var fldValue = (rec && rec[fldName] ? rec[fldName] : '');
				  var pickedObjArray = pickValuesObjArray.filter(function(item){
						return item.value === fldValue; //"Is any pick list item matching just add to the result array"  
				  });
			   
				  //if multi picklist, the count should be more based on number of selection so handle accordingly (Currently considered single picklist)
				  if(pickedObjArray.length > 0)
				  {
					  var selectedObject = pickedObjArray[0];//get the first item (ideally the pickedObjArray size should be 1)
					  pickedObj.value = selectedObject.value;
					  pickedObj.label = selectedObject.label;//Shoud display translated label in the UI
				  }else if(fldValue.length > 0){
					  pickedObj.value = fldValue;
					  pickedObj.label = fldValue;
				  }
			 }
			 //(Set as object) jsel.js has a check to access label during evaluation
			 return pickedObj;
		},

		__processFieldSecurity : function(record, descInfo){
			for (var fieldName in record) {
				if (typeof record[fieldName] === 'object' && descInfo[fieldName] !== undefined
					&& descInfo[fieldName].accessible === true && fieldName !== "Id" && descInfo[fieldName].dataType === 'reference') {
					this.__processFieldSecurity(record[fieldName],descInfo[fieldName]);
				}
				else if(descInfo[fieldName] != null && descInfo[fieldName].accessible === false){
					record[fieldName] = '';
				}
				else if(descInfo[fieldName] === undefined || descInfo[fieldName] === null){
					record[fieldName] = '';
				}
			}
			return record;
		},

		__processSpecialFields : function(RecSpecData, record){
			var recId = record["Id"];
			var recData = RecSpecData[recId];
			if(!recData) return record;
			var hrsFormat = com.servicemax.client.lib.datetimeutils.DatetimeUtil.getTimeFormat(this.__timeFormat);
			for(var i = 0; i < recData.length; i++){
				var arrFlds = recData[i].Key.split(".");
				var formattedValue = recData[i].Value;
				if (recData[i].Info && recData[i].Info === 'datetime') {
					formattedValue = com.servicemax.client.lib.datetimeutils.DatetimeUtil.datetimeRenderer(recData[i].Value,this.__dateFormat,hrsFormat,this.__timeFormat)
				}
				else if (recData[i].Info && recData[i].Info === 'date') {
					formattedValue = com.servicemax.client.lib.datetimeutils.DatetimeUtil.dateRenderer(recData[i].Value,this.__dateFormat)
				}
				if(arrFlds.length == 2 ){
					record[arrFlds[0]][arrFlds[1]] = formattedValue;
				}
				else{
					record[recData[i].Key] = formattedValue;
				}
			}
			return record;

		},
		
		getProcessId : function() {
			return this.__processId;
		},
		
		getRecordId : function() {
			return this.__recordId;
		},

		__sortFieldsInformation : function(fields){

			var level2 = [], level1 = [], level0 = [];
			var l2_Index = 0, l1_Index = 0, l0_Index = 0;
			var allFields = SVMX.toObject(fields);
			var metadata = allFields.Metadata;
			if (metadata.length > 0) {
				for (var index in metadata) {
					if(metadata[index][CONSTANTS.REF_OBJ_NAME_2]){
						level2[l2_Index] = metadata[index];
						this.__addToUniqueObjects(metadata[index][CONSTANTS.REF_OBJ_NAME_2]);
						this.__addToUniqueObjects(metadata[index][CONSTANTS.REF_OBJ_NAME]);
						this.__addToUniqueObjects(metadata[index][CONSTANTS.OBJ_NAME]);
						l2_Index++;
					}else if(metadata[index][CONSTANTS.REF_OBJ_NAME]) {
						level1[l1_Index] = metadata[index];
						this.__addToUniqueObjects(metadata[index][CONSTANTS.REF_OBJ_NAME]);
						this.__addToUniqueObjects(metadata[index][CONSTANTS.OBJ_NAME]);
						l1_Index++;
					}else if(metadata[index][CONSTANTS.OBJ_NAME]) {
						level0[l0_Index] = metadata[index];
						this.__addToUniqueObjects(metadata[index][CONSTANTS.OBJ_NAME]);
						l0_Index++;
					}
				}
				//combining all the arrays
			}
			return level2.concat(level1, level0);
		},
		__addToUniqueObjects : function(objName){
			if(objName != undefined && objName && objName.length > 0)
				this.__uniqueObjects[objName] = objName;
		},
		__processNode : function(node, targetAttribute){
			var result = this.__jsee.evalExpression($(node).attr(targetAttribute));
			$(node, $(this.__rootNode)).html(result);
		}

	}, {});

	engine.Class("AbstractNodeProcessor", com.servicemax.client.lib.api.Object, {
		__constructor : function(){},
		/**
		 *
		 * @param {Object} params
		 * {
		 * 		jsee : expression engine,
		 * 		node : htmlelement
		 *
		 */
		process : function(params){ return null; },

		_removeControlCharacters : function(value){
			return value.replace(/[\n\r\t]/g,'');
		},

		_removeSVMXCharacters : function(value){
			return value.substring(2,value.length - 2);
		},

		format : function(str, argsArray){
			var i = 0, l = argsArray.length;
			for (var i = 0; i < l; i++) {
		        var regexp = new RegExp('\\{'+ i +'\\}', 'gi');
		        str = str.replace(regexp, argsArray[i]);
		    }

		    return str;
		},

		replaceExpressions : function(expressionData, params, handleSpecialCharacters){
			var i , items = expressionData.items, l = items.length, item, result;
			for(i = 0; i < l; i++){
				item = items[i];

				// strip of the start and end delimiters
				item = item.substring(2, item.length - 2);
				item = this._removeControlCharacters(item);
				result = params.jsee.evalExpression(item, params);
				if(handleSpecialCharacters){
					if(result === undefined || result === null || result === ''){
						result = "";
					}
				}
				items[i] = result != undefined && result != null ? result : '';
			}
			return this.format(expressionData.expression, items);
		},

		parseforExpressions : function(inlineExpression){
			var ret = {expression : inlineExpression, found : false, items : []};
			var startIndex, endIndex, expression, temp, i;

			if(!inlineExpression) return ret;

			i = 0;
			while(true){
				startIndex = inlineExpression.indexOf("{{");
				endIndex = inlineExpression.indexOf("}}");

				if(startIndex != -1 && endIndex != -1){
					expression = inlineExpression.substring(startIndex, endIndex + 2);
					temp = inlineExpression.substring(0, startIndex)
									+ "{" + i + "}";

					if(endIndex + 2 < inlineExpression.length){
						temp += inlineExpression.substring(endIndex + 2);
					}

					inlineExpression = temp;

					ret.found = true;
					ret.expression = inlineExpression;
					ret.items[i] = expression;
					i++;
				}else{
					//no more expressions
					break;
				}
			}
			return ret;
		},

		parseandreplaceExpressions : function(inlineExpression, params){

			res = this.parseforExpressions(inlineExpression);
			var processData = this.replaceExpressions(res, params);
			return processData;
		}

	}, {});

	engine.Class("NodeProcessor", com.servicemax.client.runtime.api.AbstractNamedInstance, {
		__nodeTypeToProcessor : {},
		__constructor : function(){
			this.__nodeTypeToProcessor = {};
		},

		initialize: function(name, data, params){

			var i, count = data.length;
			for (i = 0; i < count; i++) {
				var d = data[i];
				var nodeTypeMap = d.data, nodeTypeMapCount = nodeTypeMap.length, j;
				for (j = 0; j < nodeTypeMapCount; j++) {
					var mapping = nodeTypeMap[j];
					this.__nodeTypeToProcessor[mapping.nodeType] = {processor : mapping.processor, inst : null};
				}
			}
		},

		process : function(params){
			var name = params.name || $(params.node)[0].nodeName;
			var processorInfo = this.__nodeTypeToProcessor[name], processor = null, ret = false;
			if(processorInfo){
				if(!processorInfo.inst){
					var cls = SVMX.getClass(processorInfo.processor);
					var clsObj = new cls();
					processorInfo.inst = clsObj;
				}
				processor = processorInfo.inst;
			}

			if(processor){
				ret = processor.process(
					{engine : params.engine, jsee : params.jsee, node : params.node, pendingNodeItems : params.pendingNodeItems});
			}

			return ret;
		}

	}, {});

	engine.Class("DivNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		process : function(params){

			var expression = $(params.node).attr("svmx-data");
			expression = this._removeControlCharacters(expression);
			var result = this.parseandreplaceExpressions(expression, params);
			$(params.node).html(result);
			return true;
		}

	}, {});

	engine.Class("TableNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		process : function(params){
			var expression = $(params.node).attr("svmx-data");
			expression = this._removeSVMXCharacters(expression);
			var result = params.jsee.evalExpression(expression);
			if (result != null && result.length > 0) {
				var l = result.length, i;
				var tbody = $("tbody", $(params.node));

				if(tbody.length == 0){
					$(params.node).append(document.createElement('tbody'));
				}
				tbody = $("tbody", $(params.node))[0];

				var thead = $("thead", $(params.node));

				var columns = $($(thead[0]).children()[0]).children(), colCount = columns.length, j;
				for (i = 0; i < l; i++) {
					var curRowData = result[i];
					var row = tbody.insertRow(i);
					//for supporting expressions in line items
					var key = expression.substring(3);
					this.assignContext(params.jsee, key, curRowData);

					for (j = 0; j < colCount; j++) {
						var actualCellField = $(columns[j]).attr("svmx-data");
						var cellField = this._removeSVMXCharacters(actualCellField);
						var cellData = row.insertCell(j);
						var path = cellField.split("."), pathElementCount = path.length, k;
						var value = curRowData;
						for (k = 0; k < pathElementCount; k++) {
							if (value[path[k]] && typeof(value[path[k]]) === 'object'
														&& value[path[k]].Id && pathElementCount === 1)
								value = value[path[k]].Id;
							else if(value[path[k]] !== undefined && value[path[k]] !== null)
								value = value[path[k]];
							else
								value = '';
						}
						//code to support expressions
						if(value.length == 0){
							var childExp = this._removeControlCharacters(actualCellField);
							value = this.parseandreplaceExpressions(childExp, params);
						}

						try { 
							if(value && typeof(value) === 'object'){
								if(value.label !== undefined && value.label !== null
										&& value.value !== undefined && value.value !== null){
									value = value.value;
								}						
							}
							value = value.toString();				
						}catch(e){}

						$(cellData).html(value);
						cellData.align = "center";
					}
				}
				this.assignContext(params.jsee, key, result);
			}
			return true;
		},

		assignContext : function(jsee, key, rowData){

			var context = {};
			context[key] = rowData;
			jsee.addContext(context, "$D");
		}

	}, {});

	engine.Class("ImageNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		process : function(params){

			var expression = $(params.node).attr("svmx-data");
			expression = this._removeSVMXCharacters(expression);
			var result = params.jsee.evalExpression(expression, {node : params.node, pendingNodeItems : params.pendingNodeItems});
			return true;
		}

	}, {});

	engine.Class("TdNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },
		process : function(params){

			var expression = $(params.node).attr("svmx-data");
			expression = this._removeControlCharacters(expression);
			var result = this.parseandreplaceExpressions(expression, params);
			params.node.innerText = result;
			return true;
		}

	}, {});

	engine.Class("AbstractInlineNodeProcessor", engine.AbstractNodeProcessor, {
		__constructor : function(){ this.__base(); },

		processChildNodes : function(params){
			var node = params.node, children = node.childNodes, i, l = children.length, child, inlineExpression, res;
			for(i = 0; i < l; i++){
				child = children[i];
				if(child.nodeType == 3){
					// text node
					inlineExpression = child.nodeValue;
					res = this.parseforExpressions(inlineExpression);
					var processData = this.replaceExpressions(res, params, params.handleSpecialCharacters);
					var isNodeProcessed = this.processSignatureNodes(processData, child);
					if(!isNodeProcessed)
						child.nodeValue = processData;
				}
			}
		},

		processSignatureNodes : function(data, childNode){
			var textArr = [], i, l;
			var isNodeProcessed = false;
			var spanNode = $("<span></span>");
			textArr = this.processTextWithDelimiters(data, "svmx-signature-start", "svmx-signature-end", 20, 18);

			if(textArr && textArr.length > 0){
				l = textArr.length;
				//insert before node
				$(spanNode).insertBefore(childNode);
				isNodeProcessed = true;
				for(i = 0; i < l; i++){
					var currNode = $("<span></span>").html(textArr[i]);
					$(spanNode).append(currNode);
				}
				//remove existing node
				$(childNode).remove();

			}
			return isNodeProcessed;
		},

		processTextWithDelimiters : function(text, delimiterStart, delimiterEnd,
													numOfCharSkippedStart, numOfCharSkippedEnd){
			var textData = text;
			var textArr = [];
			var startIndex, endIndex;
			while(true){
				var temp = "";
				startIndex = textData.indexOf(delimiterStart);
				endIndex = textData.indexOf(delimiterEnd);
				if(startIndex != -1 && endIndex != -1){
					textArr.push(textData.substring(0, startIndex));
					textArr.push(textData.substring(startIndex + numOfCharSkippedStart, endIndex));

					if(endIndex + numOfCharSkippedEnd < textData.length){
						temp = textData.substring(endIndex + numOfCharSkippedEnd);
					}
					textData = temp;
				}else{
					//no more signatures
					break;
				}
			}
			return textArr;
		}

	}, {});

	engine.Class("InlineDivNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineStrongNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineUnderlineNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineItalicNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineParaNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlinePreNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineHeadingNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineStyleNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){
			this.processChildNodes(params);
			return true;
		},

		processChildNodes : function(params){
			if(params.engine.styleNodeValue == null) return;

			var node = params.node, children = node.childNodes, i, l = children.length, child, inlineExpression, res;
			inlineExpression = params.engine.styleNodeValue;
			res = this.parseforExpressions(inlineExpression);
			processData = this.replaceExpressions(res, params);
			params.engine.__processedStyleNodeValue = processData;

			if(l > 0){
				child = children[0];
				child.nodeValue = processData;
			}else{
				node.nodeValue = processData;
			}
		}

	}, {});

	engine.Class("InlineSpanNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineEMNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineStrikeNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineSubNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineSupNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineOlNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineLiNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){
			params.handleSpecialCharacters = true;
			this.processChildNodes(params);
			return true;
		}

	}, {});

	engine.Class("InlineUlNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineBoldNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineTDNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("InlineTHNodeProcessor", engine.AbstractInlineNodeProcessor, {
		__constructor : function(){ this.__base(); },

		process : function(params){

			this.processChildNodes(params);
			return true;
		}
	}, {});

	engine.Class("PendingNodeProcessCollection",  com.servicemax.client.lib.api.Object, {
		__constructor : function(){
			this.__pendingNodeItems = {};
		},
		__pendingNodeItems : {},
		addItem : function(key, value){
			this.__pendingNodeItems[key] = value;
		},

		removeItem : function(key){
			delete this.__pendingNodeItems[key];
		},

		isPending : function(){
			for(key in this.__pendingNodeItems){
				return true;
			}
			return false;
		}
	}, {});

	engine.Class("PendingSignatures",  com.servicemax.client.lib.api.Object, {
		__constructor : function(context){
			this.__parent = context;
			this.__pendingSignatures = {};
		},
		__parent: null,
		__pendingSignatures : {},
		__finBtnName : 'svmx_finalize',
		__draBtnDiv : CONSTANTS.DRAFT_DIV,
		addItem : function(key, value){
			this.__pendingSignatures[key] = value;
			$("#" + this.__finBtnName, $(this.__parent.__rootNode)).prop("disabled","true");
			$("#" + this.__finBtnName, $(this.__parent.__rootNode)).css({"background":"#cecece", "border": "1px solid #b1b1b1", "color" : "#a9a9a9", "text-shadow": "-1px 0px 1px #ededed", "cursor": "default", "opacity":"1" });
		},

		removeItem : function(key){
			if(this.__pendingSignatures[key]){
				delete this.__pendingSignatures[key];
			}
			if(!this.isPending()){
				$("#" + this.__finBtnName, $(this.__parent.__rootNode)).removeAttr("disabled");
				$("#" + this.__finBtnName, $(this.__parent.__rootNode)).css({"background":"#f16138", "border": "1px solid #db3202", "color" : "#FFFFFF", "text-shadow": "none","opacity":"1"});
			}
		},

		isPending : function(){
			for(key in this.__pendingSignatures){
				return true;
			}
			return false;
		}
	}, {});

};
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmopdocdelivery\src\impl.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmopdocdelivery.impl
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	var sfmopdocdeliveryImpl = SVMX.Package("com.servicemax.client.sfmopdocdelivery.impl");
	
	sfmopdocdeliveryImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
		__constructor : function(){
			this.__base();
		},
		
		beforeInitialize : function(){
			com.servicemax.client.sfmopdocdelivery.utils.init();
			com.servicemax.client.sfmopdocdelivery.constants.init();
			com.servicemax.client.sfmopdocdelivery.engine.init();
			com.servicemax.client.sfmopdocdelivery.console.init();
			com.servicemax.client.sfmopdocdelivery.commands.init();
		}
		
	}, {});	
	
	sfmopdocdeliveryImpl.Class("SFMOPDOCDeliveryEngineEventBus", com.servicemax.client.lib.api.EventDispatcher, {
		__constructor : function(){ this.__base(); },
		
		triggerEvent : function(e) {
			SVMX.getLoggingService().getLogger("SFMOPDOCDeliveryEngineEventBus").info("Trigger event : " + e.type);
			return this.__base(e);
		}
		
	}, {});
	
})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmopdocdelivery\src\jsel.js
/**
 * This file needs a description
 * @class com.servicemax.client.sfmopdocdelivery.jsel
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){

	var jseeImpl = SVMX.Package("com.servicemax.client.sfmopdocdelivery.jsel");

	jseeImpl.Class("JSExpressionEngine", com.servicemax.client.lib.api.Object, {
		__interceptors : null, __de : null,

		__constructor : function(engine) { this.__interceptors = {}; this.__de = engine;},

		addInterceptor : function(macroName, interceptor, context){
			this.__interceptors[macroName] = {interceptor : interceptor, context : context};
		},

		initialize : function(params){
			var me = this;

			// set up the context roots
			var props = {};
			var i = 0, cr = params.contextRoots, l = cr.length;
			for(i = 0; i < l; i++){
				eval("var " + cr[i] + " = {};");
			}

			this.addContext = function(context, root){
				var r = eval(root);
				for(var name in context){
					var value = context[name];
					r[name] = value;
				}
			};

			this.setProperty = function(key, value) {

				props[key] = value;
			};

			this.getProperty = function(key) {

				return props[key];
			};

			this.evalExpression = function(expr, params)
			{
				/////////////////////// MACROS //////////////////////////////////
				// !!! ALL THE MACROS MUST GO WITH IN THIS BLOCK !!!!

				function $MODIFY(value){
					return "Modified " + value;
				}

				function $BOOL(value){
					return !!value;
				}

				function $ISNULL(value){
					if(!value) return true;
					else return false;
				}

				function $ADD(){
					var ret = 0, i = 0, l = arguments.length;
					for(i = 0; i < l; i++){
						ret += arguments[i];
					}
					return ret;
				}

				function $INT(value){
					var parsedValue = parseInt(value);
					if(isNaN(parsedValue)) parsedValue = 0;
					return parsedValue;
				}

				function $FLOAT(value){
					var parsedValue = parseFloat(value);
					if(isNaN(parsedValue)) parsedValue = 0;
					return parsedValue;
				}

				function $TOUPPER(value){
					return value.toUpperCase();
				}

				function $IMAGE(value){
					if(me.__interceptors["$IMAGE"]){
						return me.__interceptors["$IMAGE"].interceptor(value, params);
					}else{
						// TODO:
						return '/servlet/servlet.FileDownload?file=' + value;
					}
				}

				function $LOGO(){
					if(me.__interceptors["$IMAGE"]){
						return me.__interceptors["$IMAGE"].interceptor("LOGO", params);
					}else{
						// TODO:
						return '/servlet/servlet.FileDownload?file=' + value;
					}
				}

				function $SIGNATURE(uniqueName, title, isMandatory, width, height){
					//TODO: Cleanup/destroy functions when done with them
					var uniqueId = $(me.__de.__rootNode).attr('id').replace(/-/g, '_');
					var handlerName = 'handleOutputDocSignatureButtonClick'+ uniqueId;
					SVMX[handlerName] = function(){
						var evtLocal = event.target;
						var uniqueNameLocal = null, imgHeight = null, imgWidth = null;
						if(evtLocal){
							uniqueNameLocal = $(event.target).attr("signature-name");
							imgHeightLocal = $(event.target).attr("imgHeight");
							imgWidthLocal = $(event.target).attr("imgWidth");
						}


						var evt = SVMX.create("com.servicemax.client.lib.api.Event",
							"SFMOPDOCDELIVERY.CAPTURE_SIGNATURE", me.__de,{
								request : {
									handler 		 : onCaptureSignature,
									processId 		 : me.__de.getProcessId(),
									recordId 		 : me.__de.getRecordId(),
									uniqueName 		 : uniqueNameLocal,
									imgHeight		 : imgHeightLocal,
									imgWidth		 : imgWidthLocal
								}
							});

						me.__de.getEventBus().triggerEvent(evt);
    				};

					var onCaptureSignature = function(data){
						var node = $("#" + data.uniqueName, $(me.__de.__rootNode));
						if(node != undefined && node && data.path != undefined && data.path.length > 0){
							var imgNode = node.find("img");
							if(imgNode){
								imgNode.remove();
							}
							var imageName = "";
                          	var url = data.path;
                          	var segements = url.split("/");
                          	imageName = segements[segements.length - 1];
							node.prepend("<img style='width:" + data.width + "; height:" + data.height + ";' svmx-data='"+ imageName +"' src='" + data.path + "'/>");
							me.__de.__signaturesPending.removeItem(data.uniqueName);
						}
					};

					var returnTag = "";
					if(me.__de.__allowSignatures != null && me.__de.__allowSignatures === true){
						title = title && title != null && title.length > 0 ? title : uniqueName;
						var defaultHeight = '186px';
                      	var defaultWidth = '350px';
                      	defaultHeight = (height != undefined && height != null && height.length > 0) ? height + 'px' : defaultHeight;
                      	defaultWidth = (width != undefined && width != null && width.length > 0) ? width + 'px' : defaultWidth;

						if(uniqueName){
							returnTag = "svmx-signature-start<div id='" + uniqueName + uniqueId +  "'>"
		                    + "<button style='min-width:50px; height:40px;' signature-name='"+ uniqueName + uniqueId + "' imgHeight='"+ defaultHeight +"' imgWidth='"+ defaultWidth +"' onclick='SVMX." + handlerName + "();'>"+ title +"</button>"
		                    + "</div>svmx-signature-end";
						}
					}
					if(isMandatory !== undefined && isMandatory.toString().toLowerCase() === "true"){
						me.__de.__signaturesPending.addItem(uniqueName+uniqueId, uniqueName+uniqueId);
					}
					return returnTag;
				}

				function $URL(value){

				}

				function $IF(condition, truthy, falsey){
					if(condition){
						return truthy;
					}else{
						return falsey;
					}
				}

				function $SUMOF(list, fieldName, options){
					var total = 0;
					var aliasName = "";

					for(i = 0; i < list.length; i++){
						total += $FLOAT(list[i][fieldName]);
						aliasName = list[i]["aliasName"];
					}
					if($M[aliasName] !== undefined && $M[aliasName] != null
								&& $M[aliasName][fieldName] !== undefined && $M[aliasName][fieldName] !== null) {
						var scale = $M[aliasName][fieldName]["scale"];
						total = total.toFixed(scale);
					}
					return total;
				}

				function $FORMAT(){
					if(arguments.length == 0 ) return "";

					var formatted = arguments[0];	// first parameter is the string to be formated

				    for (var i = 1; i < arguments.length; i++) {
				        var regexp = new RegExp('\\{'+ (i - 1) +'\\}', 'gi');
				        formatted = formatted.replace(regexp,
										arguments[i] !== undefined && arguments[i] !== null ? arguments[i] : "" );
				    }
				    return formatted;
				}

				function $TODAY(){
					if(me.getProperty('Today')) {

						return me.getProperty('Today');
					}
				}

				function $TOMORROW(){
					if(me.getProperty('Tomorrow')) {

						return me.getProperty('Tomorrow');
					}
				}

				function $NOW(){
					if(me.getProperty('Now')) {

						return me.getProperty('Now');
					}
				}

				function $YESTERDAY(){
					if(me.getProperty('Yesterday')) {

						return me.getProperty('Yesterday');
					}
				}

				function $USERNAME() {
					if(me.getProperty('UserName')) {

						return me.getProperty('UserName');
					}
				}

				function $ADDRESS() {
					if(me.getProperty('Address')) {

						return me.getProperty('Address');
					}
				}

				function $LNUMBER(value) {
					var parsedValue = parseFloat(value);
					var formattedValue = value;
					if (!isNaN(parsedValue)) {
						var locale = me.getProperty('Locale');
						var utils = com.servicemax.client.sfmopdocdelivery.utils.SFMOPDOCUtils;
						formattedValue = utils.localeFormat(locale, parsedValue);
					}
					return formattedValue;
				}

				function $ROUND(value, places){
					var multiplier = Math.pow(10, places);
    				return (Math.round(value * multiplier) / multiplier);
				}

				function $SNUMBER(record, fieldName, scale){
					var aliasName = record.aliasName;
					var scale = parseInt(scale);
					var value = $D[aliasName][fieldName];
					var parsedValue = parseFloat(value);
					if(isNaN(parsedValue)) return value;

					if(scale !== undefined && scale !== null && !isNaN(scale)) {
						parsedValue = parsedValue.toFixed(scale);
					} else if($M[aliasName] !== undefined && $M[aliasName] != null
									&& $M[aliasName][fieldName] !== undefined && $M[aliasName][fieldName] !== null){
						scale = $M[aliasName][fieldName]["scale"]
						parsedValue = parsedValue.toFixed(scale);
					}
					return parsedValue;
				}

				var $F = {	BOOL : $BOOL, 	ISNULL : $ISNULL, 	ADD : $ADD, 		INT : $INT, 		TOUPPER : $TOUPPER, 	IMAGE : $IMAGE,
								IF : $IF, 		SUMOF : $SUMOF,	FORMAT : $FORMAT, 	TODAY : $TODAY, 	TOMORROW : $TOMORROW, 	YESTERDAY : $YESTERDAY,
								NOW : $NOW , USERNAME : $USERNAME, LOGO : $LOGO, ADDRESS : $ADDRESS, LNUMBER : $LNUMBER, ROUND : $ROUND, SIGNATURE : $SIGNATURE,
								SNUMBER: $SNUMBER};
				////////////////////// END MACROS ///////////////////////////////

				try {
					var result = eval(expr);
					if(result && typeof(result) === 'object'){
						if(result.label !== undefined && result.label !== null
								&& result.value !== undefined && result.value !== null){
							result = result.value;
						}else if(result.Id){
							result = result.Id;
						}						
					}
					return result;
				} catch(e) {
					return '';
					//debugger;
				}
			};
		}

	}, {});
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmopdocdelivery\src\utils.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmopdocdelivery.utils
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	
	var sfmopdocdeliveryutil = SVMX.Package("com.servicemax.client.sfmopdocdelivery.utils");

sfmopdocdeliveryutil.init = function(){
	sfmopdocdeliveryutil.Class("SFMOPDOCUtils", com.servicemax.client.lib.api.Object, {
		__constructor : function(){}
	}, {
		localeInfo : {
			"en_US" : { "DS" : "." , "TS" : ","},
			"en_GB" : { "DS" : "." , "TS" : ","},
			"en_AU" : { "DS" : "." , "TS" : ","},
			"en_NZ" : { "DS" : "." , "TS" : ","},
			"fr" : { "DS" : "," , "TS" : " "},
			"fr_BE" : { "DS" : "," , "TS" : "."},
			"fr_CA" : { "DS" : "," , "TS" : " "},
			"fr_CH" : { "DS" : "." , "TS" : "'"},
			"fr_FR" : { "DS" : "," , "TS" : " "},
			"fr_LU" : { "DS" : "," , "TS" : " "},
			"fr_MC" : { "DS" : "," , "TS" : " "},
			"pt_BR" : { "DS" : "," , "TS" : "."},
			"pt_AO" : { "DS" : "," , "TS" : "."},
			"pt_PT" : { "DS" : "," , "TS" : "."},
			"pt" : { "DS" : "," , "TS" : "."},
			"es" : { "DS" : "," , "TS" : "."},
			"es_AR" : { "DS" : "," , "TS" : "."},
			"es_BO" : { "DS" : "," , "TS" : "."},
			"es_CL" : { "DS" : "," , "TS" : "."},
			"es_CO" : { "DS" : "," , "TS" : "."},
			"es_CR" : { "DS" : "." , "TS" : ","},
			"es_DO" : { "DS" : "." , "TS" : ","},
			"es_EC" : { "DS" : "," , "TS" : "."},
			"es_ES" : { "DS" : "," , "TS" : "."},
			"es_GT" : { "DS" : "." , "TS" : ","},
			"es_HN" : { "DS" : "." , "TS" : ","},
			"es_MX" : { "DS" : "." , "TS" : ","},
			"es_PA" : { "DS" : "." , "TS" : ","},
			"es_PE" : { "DS" : "," , "TS" : "."},
			"es_PR" : { "DS" : "." , "TS" : ","},
			"es_PY" : { "DS" : "," , "TS" : "."},
			"es_SVUS" : { "DS" : "." , "TS" : ","},
			"es_UY" : { "DS" : "," , "TS" : "."},
			"es_VE" : { "DS" : "," , "TS" : "."},
			"de" : { "DS" : "," , "TS" : "."},
			"de_AT" : { "DS" : "," , "TS" : "."},
			"de_CH" : { "DS" : "." , "TS" : "'"},
			"de_DE" : { "DS" : "," , "TS" : "."},
			"de_LU" : { "DS" : "," , "TS" : "."},
			"ja" : { "DS" : "." , "TS" : ","},
			"ja_JP" : { "DS" : "." , "TS" : ","},
			"zh" : { "DS" : "." , "TS" : ","},
			"zh_CN" : { "DS" : "." , "TS" : ","},
			"zh_SG" : { "DS" : "." , "TS" : ","},
			"zh_TW" : { "DS" : "." , "TS" : ","},
			"zh_HK" : { "DS" : "." , "TS" : ","},
			"zh_CN" : { "DS" : "." , "TS" : ","},
			"zh_MO" : { "DS" : "." , "TS" : ","},
			"ko" : { "DS" : "." , "TS" : ","},
			"ko_KR" : { "DS" : "." , "TS" : ","},
			"it" : { "DS" : "," , "TS" : "."},
			"it_CH" : { "DS" : "." , "TS" : "'"},
			"it_IT" : { "DS" : "," , "TS" : "."},
			"nl" : { "DS" : "," , "TS" : "."},
			"nl_BE" : { "DS" : "," , "TS" : "."},
			"nl_NL" : { "DS" : "," , "TS" : "."},
			"nl_SR" : { "DS" : "," , "TS" : "."}
		},	
		
		localeFormat : function(locale, value){		
			var formattedValue;
			var DS = ".", TS = ","; 
			if(this.localeInfo[locale] !== undefined && this.localeInfo[locale] !== null && this.localeInfo[locale]){
				var currLocaleInfo = this.localeInfo[locale];
				DS = currLocaleInfo.DS;
				TS = currLocaleInfo.TS;
			}
			formattedValue = this.__formatNumber(value, DS, TS);			
			return formattedValue;
		
		},
		
		__formatNumber : function(value, decimalSeparator, thousandSeparator) {
		    var parts = value.toString().split(".");
		    return parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator) + (parts[1] ? decimalSeparator + parts[1] : "");
		}		
		
	});
}	
})();

// end of file

