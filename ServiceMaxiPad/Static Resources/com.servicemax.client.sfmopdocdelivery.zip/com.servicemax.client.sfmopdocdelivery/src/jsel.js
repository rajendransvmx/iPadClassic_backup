/**
 * This file needs a description
 * @class com.servicemax.client.sfmopdocdelivery.jsel
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){

	var jseeImpl = SVMX.Package("com.servicemax.client.sfmopdocdelivery.jsel");

	jseeImpl.Class("JSExpressionEngine", com.servicemax.client.lib.api.Object, {
		__interceptors : null, __de : null,

		__constructor : function(engine) { this.__interceptors = {}; this.__de = engine;},

		addInterceptor : function(macroName, interceptor, context){
			this.__interceptors[macroName] = {interceptor : interceptor, context : context};
		},

		initialize : function(params){
			var me = this;

			// set up the context roots
			var props = {};
			var i = 0, cr = params.contextRoots, l = cr.length;
			for(i = 0; i < l; i++){
				eval("var " + cr[i] + " = {};");
			}

			this.addContext = function(context, root){
				var r = eval(root);
				for(var name in context){
					var value = context[name];
					r[name] = value;
				}
			};

			this.setProperty = function(key, value) {

				props[key] = value;
			};

			this.getProperty = function(key) {

				return props[key];
			};

			this.evalExpression = function(expr, params)
			{
				/////////////////////// MACROS //////////////////////////////////
				// !!! ALL THE MACROS MUST GO WITH IN THIS BLOCK !!!!

				function $MODIFY(value){
					return "Modified " + value;
				}

				function $BOOL(value){
					return !!value;
				}

				function $ISNULL(value){
					if(!value) return true;
					else return false;
				}

				function $ADD(){
					var ret = 0, i = 0, l = arguments.length;
					for(i = 0; i < l; i++){
						ret += arguments[i];
					}
					return ret;
				}

				function $INT(value){
					var parsedValue = parseInt(value);
					if(isNaN(parsedValue)) parsedValue = 0;
					return parsedValue;
				}

				function $FLOAT(value){
					var parsedValue = parseFloat(value);
					if(isNaN(parsedValue)) parsedValue = 0;
					return parsedValue;
				}

				function $TOUPPER(value){
					if(value && typeof(value) === 'object' && value.value){
						return value.value.toUpperCase();
					}
					return value.toUpperCase();
				}

				function $IMAGE(value){
					if(me.__interceptors["$IMAGE"]){
						return me.__interceptors["$IMAGE"].interceptor(value, params);
					}else{
						// TODO:
						return '/servlet/servlet.FileDownload?file=' + value;
					}
				}

				function $LOGO(){
					if(me.__interceptors["$IMAGE"]){
						return me.__interceptors["$IMAGE"].interceptor("LOGO", params);
					}else{
						// TODO:
						return '/servlet/servlet.FileDownload?file=' + value;
					}
				}

				function $SIGNATURE(uniqueName, title, isMandatory, width, height){
					//TODO: Cleanup/destroy functions when done with them
					var uniqueId = $(me.__de.__rootNode).attr('id').replace(/-/g, '_');
					var handlerName = 'handleOutputDocSignatureButtonClick'+ uniqueId;
					SVMX[handlerName] = function(){
						var evtLocal = event.target;
						var uniqueNameLocal = null, imgHeight = null, imgWidth = null;
						if(evtLocal){
							uniqueNameLocal = $(event.target).attr("signature-name");
							imgHeightLocal = $(event.target).attr("imgHeight");
							imgWidthLocal = $(event.target).attr("imgWidth");
						}


						var evt = SVMX.create("com.servicemax.client.lib.api.Event",
							"SFMOPDOCDELIVERY.CAPTURE_SIGNATURE", me.__de,{
								request : {
									handler 		 : onCaptureSignature,
									processId 		 : me.__de.getProcessId(),
									recordId 		 : me.__de.getRecordId(),
									uniqueName 		 : uniqueNameLocal,
									imgHeight		 : imgHeightLocal,
									imgWidth		 : imgWidthLocal
								}
							});

						me.__de.getEventBus().triggerEvent(evt);
    				};

					var onCaptureSignature = function(data){
						var node = $("#" + data.uniqueName, $(me.__de.__rootNode));
						if(node != undefined && node && data.path != undefined && data.path.length > 0){
							var imgNode = node.find("img");
							if(imgNode){
								imgNode.remove();
							}
							var imageName = "";
                          	var url = data.path;
                          	var segements = url.split("/");
                          	imageName = segements[segements.length - 1];
							node.prepend("<img style='width:" + data.width + "; height:" + data.height + ";' svmx-data='"+ imageName +"' src='" + data.path + "'/>");
							me.__de.__signaturesPending.removeItem(data.uniqueName);
						}
					};

					var returnTag = "";
					if(me.__de.__allowSignatures != null && me.__de.__allowSignatures === true){
						title = title && title != null && title.length > 0 ? title : uniqueName;
						var defaultHeight = '186px';
                      	var defaultWidth = '350px';
                      	defaultHeight = (height != undefined && height != null && height.length > 0) ? height + 'px' : defaultHeight;
                      	defaultWidth = (width != undefined && width != null && width.length > 0) ? width + 'px' : defaultWidth;

						if(uniqueName){
							returnTag = "svmx-signature-start<div id='" + uniqueName + uniqueId +  "'>"
		                    + "<button style='min-width:50px; height:40px;' signature-name='"+ uniqueName + uniqueId + "' imgHeight='"+ defaultHeight +"' imgWidth='"+ defaultWidth +"' onclick='SVMX." + handlerName + "();'>"+ title +"</button>"
		                    + "</div>svmx-signature-end";
						}
					}
					if(isMandatory !== undefined && isMandatory.toString().toLowerCase() === "true"){
						me.__de.__signaturesPending.addItem(uniqueName+uniqueId, uniqueName+uniqueId);
					}
					return returnTag;
				}

				function $URL(value){

				}

				function $IF(condition, truthy, falsey){
					if(condition){
						return truthy;
					}else{
						return falsey;
					}
				}

				function $SUMOF(list, fieldName, options){
					var total = 0;
					var aliasName = "";
					var dataType = "";
					
					if(list.length > 0){
						aliasName = list[0]["aliasName"];
					}
					if($M[aliasName] !== undefined && $M[aliasName] != null
							&& $M[aliasName][fieldName] !== undefined && $M[aliasName][fieldName] !== null
							&& $M[aliasName][fieldName]["dataType"] !== undefined && $M[aliasName][fieldName]["dataType"] !== null) {
						dataType = $M[aliasName][fieldName]["dataType"];
					}
					for(i = 0; i < list.length; i++){
						var value = list[i][fieldName];
						if(dataType === "picklist" || dataType === "multipicklist"){
							value = list[i][fieldName]["value"]; 
						}
						total += $FLOAT(value);
					}
					if($M[aliasName] !== undefined && $M[aliasName] != null
								&& $M[aliasName][fieldName] !== undefined && $M[aliasName][fieldName] !== null) {
						var scale = $M[aliasName][fieldName]["scale"];
						total = total.toFixed(scale);
					}
					return total;
				}

				function $FORMAT(){
					if(arguments.length == 0 ) return "";

					var formatted = arguments[0];	// first parameter is the string to be formated

				    for (var i = 1; i < arguments.length; i++) {
				        var regexp = new RegExp('\\{'+ (i - 1) +'\\}', 'gi');
				        formatted = formatted.replace(regexp,
										arguments[i] !== undefined && arguments[i] !== null ? arguments[i] : "" );
				    }
				    return formatted;
				}

				function $TODAY(){
					if(me.getProperty('Today')) {

						return me.getProperty('Today');
					}
				}

				function $TOMORROW(){
					if(me.getProperty('Tomorrow')) {

						return me.getProperty('Tomorrow');
					}
				}

				function $NOW(){
					if(me.getProperty('Now')) {

						return me.getProperty('Now');
					}
				}

				function $YESTERDAY(){
					if(me.getProperty('Yesterday')) {

						return me.getProperty('Yesterday');
					}
				}

				function $USERNAME() {
					if(me.getProperty('UserName')) {

						return me.getProperty('UserName');
					}
				}

				function $ADDRESS() {
					if(me.getProperty('Address')) {

						return me.getProperty('Address');
					}
				}

				function $LNUMBER(value,scale) {
					var parsedValue = parseFloat(value);
					var formattedValue = value;
					if (!isNaN(parsedValue)) {
						var locale = me.getProperty('Locale');
						var utils = com.servicemax.client.sfmopdocdelivery.utils.SFMOPDOCUtils;
						formattedValue = utils.localeFormat(locale, parsedValue,scale);
					}
					return formattedValue;
				}

				function $ROUND(value, places){
					var multiplier = Math.pow(10, places);
    				return (Math.round(value * multiplier) / multiplier);
				}

				function $SNUMBER(record, fieldName, scale){
					var aliasName = record.aliasName;
					var scale = parseInt(scale);
					var value = $D[aliasName][fieldName];
					var parsedValue = parseFloat(value);
					if(isNaN(parsedValue)) return value;

					if(scale !== undefined && scale !== null && !isNaN(scale)) {
						parsedValue = parsedValue.toFixed(scale);
					} else if($M[aliasName] !== undefined && $M[aliasName] != null
									&& $M[aliasName][fieldName] !== undefined && $M[aliasName][fieldName] !== null){
						scale = $M[aliasName][fieldName]["scale"]
						parsedValue = parsedValue.toFixed(scale);
					}
					return parsedValue;
				}

				var $F = {	BOOL : $BOOL, 	ISNULL : $ISNULL, 	ADD : $ADD, 		INT : $INT, 		TOUPPER : $TOUPPER, 	IMAGE : $IMAGE,
								IF : $IF, 		SUMOF : $SUMOF,	FORMAT : $FORMAT, 	TODAY : $TODAY, 	TOMORROW : $TOMORROW, 	YESTERDAY : $YESTERDAY,
								NOW : $NOW , USERNAME : $USERNAME, LOGO : $LOGO, ADDRESS : $ADDRESS, LNUMBER : $LNUMBER, ROUND : $ROUND, SIGNATURE : $SIGNATURE,
								SNUMBER: $SNUMBER};
				////////////////////// END MACROS ///////////////////////////////

				try {
					var result = eval(expr);
					if(result && typeof(result) === 'object'){
						if(result.label !== undefined && result.label !== null
								&& result.value !== undefined && result.value !== null){
							result = result.value;
						}else if(result.Id){
							result = result.Id;
						}						
					}
					return result;
				} catch(e) {
					return '';
					//debugger;
				}
			};
		}

	}, {});
})();

// end of file