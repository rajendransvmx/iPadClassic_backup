/*
 * QUnit Test Setup
 *
 * module:          group related unit test
 * setup/teardown:  test setup/cleanup
 */
/*********************************/
//Event Dispatcher class
var Utils = null;
QUnit.module("DateTimeUtils", {
    setup: function() {
        //initialize code
        Utils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
    },
    teardown: function() {
        //cleanup code
        Utils = null;
    }
});

test("convertToTimezone back & forth", function() {
    // Set the timezone so test results are consistent.
    Utils.setTimezone("America/Los_Angeles");

    // November 1 2015, UTC 2 hours before daylight savings time transition.
    var goodDate = "2015-11-01 07:00:00";

    //Good tests
    var newDate = Utils.convertToTimezone(goodDate, undefined, false); // convert to local
    equal(newDate, "2015-11-01 00:00:00", "Date should equal expected local time (nov 00:00)");

    var postNew = Utils.convertToTimezone(newDate, undefined, true); // convert back to UTC
    equal(postNew, "2015-11-01 07:00:00", "Date should equal expected input time (nov 07:00)");

    // November 1 2015, UTC 2 hours after daylight savings time transition.
    goodDate = "2015-11-01 10:00:00";

    //Good tests
    newDate = Utils.convertToTimezone(goodDate, undefined, false); // convert to local
    equal(newDate, "2015-11-01 02:00:00", "Date should equal expected local time (nov 02:00)");

    postNew = Utils.convertToTimezone(newDate, undefined, true); // convert back to UTC
    equal(postNew, "2015-11-01 10:00:00", "Date should equal expected input time (nov 10:00)");

    // March 8 2015, UTC 2 hours before daylight savings time transition.
    goodDate = "2015-03-08 08:00:00";

    //Good tests
    newDate = Utils.convertToTimezone(goodDate, undefined, false); // convert to local
    equal(newDate, "2015-03-08 00:00:00", "Date should equal expected local time (mar 00:00)");

    postNew = Utils.convertToTimezone(newDate, undefined, true); // convert back to UTC
    equal(postNew, "2015-03-08 08:00:00", "Date should equal expected input time (mar 08:00)");

    // November 1 2015, UTC 2 hours after daylight savings time transition.
    goodDate = "2015-03-08 10:00:00";

    //Good tests
    newDate = Utils.convertToTimezone(goodDate, undefined, false); // convert to local
    equal(newDate, "2015-03-08 03:00:00", "Date should equal expected local time (mar 03:00)");

    postNew = Utils.convertToTimezone(newDate, undefined, true); // convert back to UTC
    equal(postNew, "2015-03-08 10:00:00", "Date should equal expected input time (mar 10:00)");

});


test("manipulateDatetime Year", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    var newDate = Utils.manipulateDatetime(goodDate, "years", 2);
    equal(newDate, "2016-03-14 01:01:01", "Year should be 2016");

    newDate = Utils.manipulateDatetime(goodDate, "years", -2);
    equal(newDate, "2012-03-14 01:01:01", "Year should be 2012");

    newDate = Utils.manipulateDatetime(badDate, "years", 2);
    equal(newDate, badDate, "Year should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "years", 2);
    equal(newDate, reallYadDate, "Year should original");

    newDate = Utils.manipulateDatetime(badString, "years", 2);
    equal(newDate, badString, "Year should original");

});


test("manipulateDatetime Month", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "months", 2);
    equal(newDate, "2014-05-14 01:01:01", "Month should be 5");

    newDate = Utils.manipulateDatetime(goodDate, "months", -2);
    equal(newDate, "2014-01-14 01:01:01", "Month should be 2");

    newDate = Utils.manipulateDatetime(goodDate, "months", 13);
    equal(newDate, "2015-04-14 01:01:01", "Month should be 4 and Year should be 2015");

    newDate = Utils.manipulateDatetime(badDate, "months", 2);
    equal(newDate, badDate, "Month should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "months", 2);
    equal(newDate, reallYadDate, "Month should original");

    newDate = Utils.manipulateDatetime(badString, "months", 2);
    equal(newDate, badString, "Month should original");

});

test("manipulateDatetime Day", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "days", 2);
    equal(newDate, "2014-03-16 01:01:01", "Day should be 16");

    newDate = Utils.manipulateDatetime(goodDate, "days", -2);
    equal(newDate, "2014-03-12 01:01:01", "Day should be 12");

    newDate = Utils.manipulateDatetime(goodDate, "days", 366);
    equal(newDate, "2015-03-15 01:01:01", "Day should be 15 and Year should be 2015");

    newDate = Utils.manipulateDatetime(badDate, "days", 2);
    equal(newDate, badDate, "Day should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "days", 2);
    equal(newDate, reallYadDate, "Day should original");

    newDate = Utils.manipulateDatetime(badString, "days", 2);
    equal(newDate, badString, "Day should original");

});

test("manipulateDatetime Hour", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "hours", 2);
    equal(newDate, "2014-03-14 03:01:01", "Hour should be 3");

    newDate = Utils.manipulateDatetime(goodDate, "hours", -2);
    equal(newDate, "2014-03-13 23:01:01", "Hour should be 23 and Day 13");

    newDate = Utils.manipulateDatetime(badDate, "hours", 2);
    equal(newDate, badDate, "Hour should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "hours", 2);
    equal(newDate, reallYadDate, "Hour should original");

    newDate = Utils.manipulateDatetime(badString, "hours", 2);
    equal(newDate, badString, "Hour should original");

});

test("manipulateDatetime Minute", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "minutes", 2);
    equal(newDate, "2014-03-14 01:03:01", "Minute should be 3");

    newDate = Utils.manipulateDatetime(goodDate, "minutes", -2);
    equal(newDate, "2014-03-14 00:59:01", "Minute should be 59, Hours 23, and Day 13");

    newDate = Utils.manipulateDatetime(badDate, "minutes", 2);
    equal(newDate, badDate, "Minute should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "minutes", 2);
    equal(newDate, reallYadDate, "Minute should original");

    newDate = Utils.manipulateDatetime(badString, "minutes", 2);
    equal(newDate, badString, "Minute should original");

});

test("manipulateDatetime Second", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "seconds", 2);
    equal(newDate, "2014-03-14 01:01:03", "Second should be 3");

    newDate = Utils.manipulateDatetime(goodDate, "seconds", -2);
    equal(newDate, "2014-03-14 01:00:59", "Second should be 59, Minutes 00");

    newDate = Utils.manipulateDatetime(badDate, "seconds", 2);
    equal(newDate, badDate, "Second should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "seconds", 2);
    equal(newDate, reallYadDate, "Second should original");

    newDate = Utils.manipulateDatetime(badString, "seconds", 2);
    equal(newDate, badString, "Second should original");

});

test("manipulateDatetime invalid", function() {
    var goodDate = "2014-03-14 01:01:01";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "xxxx", 2);
    equal(newDate, goodDate, "Result should be " + goodDate);
});


test("getDurationBetween invalids", function() {
    //{ startDateTime: "", endDateTime: ""}
    var results = Utils.getDurationBetween("NaN-NaN", "2014-03-14 01:01:01");
    equal(results.isValid(), false, "Result should not be valid");

    results = Utils.getDurationBetween("2014-03-14 01:01:01", "NaN");
    equal(results.isValid(), false, "Result should not be valid");

    results = Utils.getDurationBetween(null, "NaN");
    equal(results.isValid(), false, "Result should not be valid");
});

test("getDurationBetween same day", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-03-14 15:30:01";
    var results = Utils.getDurationBetween(start, end);

    equal(results.get('years'), 0, "Resulting year duration should be 0");
    equal(results.get('months'), 0, "Resulting month duration should be 0");
    equal(results.get('days'), 0, "Resulting day duration should be 0");
    equal(results.get('hours'), 2, "Resulting hour duration should be 2");
    equal(results.get('minutes'), 29, "Resulting minute duration should be 29");
    equal(results.get('seconds'), 0, "Resulting minute duration should be 0");
    equal(results.get('milliseconds'), 0, "Resulting millisecond duration should be 0");

    equal(results.as('minutes'), 149, "Resulting total minute duration should be 149");
    equal(results.toString(), 'PT2H29M', "Resulting ISO duration should be PT2H29M");
});

test("getDurationBetween single day", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-03-15 15:30:01";
    var results = Utils.getDurationBetween(start, end);

    equal(results.get('years'), 0, "Resulting year duration should be 0");
    equal(results.get('months'), 0, "Resulting month duration should be 0");
    equal(results.get('days'), 1, "Resulting day duration should be 1");
    equal(results.get('hours'), 2, "Resulting hour duration should be 2");
    equal(results.get('minutes'), 29, "Resulting minute duration should be 29");
    equal(results.get('seconds'), 0, "Resulting minute duration should be 0");
    equal(results.get('milliseconds'), 0, "Resulting millisecond duration should be 0");

    equal(results.as('minutes'), 1589, "Resulting total minute duration should be 1589");
    equal(results.toString(), 'P1DT2H29M', "Resulting ISO duration should be P1DT2H29M");
});

test("getDurationBetween multi day", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-03-20 15:30:01";
    var results = Utils.getDurationBetween(start, end);

    equal(results.get('years'), 0, "Resulting year duration should be 0");
    equal(results.get('months'), 0, "Resulting month duration should be 0");
    equal(results.get('days'), 6, "Resulting day duration should be 6");
    equal(results.get('hours'), 2, "Resulting hour duration should be 2");
    equal(results.get('minutes'), 29, "Resulting minute duration should be 29");
    equal(results.get('seconds'), 0, "Resulting minute duration should be 0");
    equal(results.get('milliseconds'), 0, "Resulting millisecond duration should be 0");

    equal(results.as('minutes'), 8789, "Resulting total minute duration should be 8789");
    equal(results.toString(), 'P6DT2H29M', "Resulting ISO duration should be P6DT2H29M");
});

test("getDurationBetween single month", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-04-13 15:30:01";
    var results = Utils.getDurationBetween(start, end);

    // Month durations are under the assumption that the average month has 30 days.
    equal(results.get('years'), 0, "Resulting year duration should be 0");
    equal(results.get('months'), 1, "Resulting month duration should be 1");
    equal(results.get('days'), 0, "Resulting day duration should be 0");
    equal(results.get('hours'), 2, "Resulting hour duration should be 2");
    equal(results.get('minutes'), 29, "Resulting minute duration should be 29");
    equal(results.get('seconds'), 0, "Resulting minute duration should be 0");
    equal(results.get('milliseconds'), 0, "Resulting millisecond duration should be 0");

    equal(results.as('minutes'), 43349, "Resulting total minute duration should be 43349");
    equal(results.toString(), 'P1MT2H29M', "Resulting ISO duration should be P1MT2H29M");
});

test("getDurationBetween single month, multi day", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-04-24 15:30:01";
    var results = Utils.getDurationBetween(start, end);

    // Month durations are under the assumption that the average month has 30 days.
    equal(results.get('years'), 0, "Resulting year duration should be 0");
    equal(results.get('months'), 1, "Resulting month duration should be 1");
    equal(results.get('days'), 11, "Resulting day duration should be 11");
    equal(results.get('hours'), 2, "Resulting hour duration should be 2");
    equal(results.get('minutes'), 29, "Resulting minute duration should be 29");
    equal(results.get('seconds'), 0, "Resulting minute duration should be 0");
    equal(results.get('milliseconds'), 0, "Resulting millisecond duration should be 0");

    equal(results.as('minutes'), 59189, "Resulting total minute duration should be 59189");
    equal(results.toString(), 'P1M11DT2H29M', "Resulting ISO duration should be P1M11DT2H29M");
});

test("getDurationBetween multi month", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-05-13 15:30:01";
    var results = Utils.getDurationBetween(start, end);

    // Month durations are under the assumption that the average month has 30 days.
    equal(results.get('years'), 0, "Resulting year duration should be 0");
    equal(results.get('months'), 2, "Resulting month duration should be 2");
    equal(results.get('days'), 0, "Resulting day duration should be 0");
    equal(results.get('hours'), 2, "Resulting hour duration should be 2");
    equal(results.get('minutes'), 29, "Resulting minute duration should be 29");
    equal(results.get('seconds'), 0, "Resulting minute duration should be 0");
    equal(results.get('milliseconds'), 0, "Resulting millisecond duration should be 0");

    equal(results.as('minutes'), 86549, "Resulting total minute duration should be 86549");
    equal(results.toString(), 'P2MT2H29M', "Resulting ISO duration should be P2MT2H29M");
});

test("getDurationBetween multi month, multi day", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-05-24 15:30:01";
    var results = Utils.getDurationBetween(start, end);

    // Month durations are under the assumption that the average month has 30 days.
    equal(results.get('years'), 0, "Resulting year duration should be 0");
    equal(results.get('months'), 2, "Resulting month duration should be 2");
    equal(results.get('days'), 11, "Resulting day duration should be 11");
    equal(results.get('hours'), 2, "Resulting hour duration should be 2");
    equal(results.get('minutes'), 29, "Resulting minute duration should be 29");
    equal(results.get('seconds'), 0, "Resulting minute duration should be 0");
    equal(results.get('milliseconds'), 0, "Resulting millisecond duration should be 0");

    equal(results.as('minutes'), 102389, "Resulting total minute duration should be 102389");
    equal(results.toString(), 'P2M11DT2H29M', "Resulting ISO duration should be P2M11DT2H29M");
});
