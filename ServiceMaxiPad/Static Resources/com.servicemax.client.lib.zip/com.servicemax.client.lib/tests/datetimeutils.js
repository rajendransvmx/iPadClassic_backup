/*
 * QUnit Test Setup
 *
 * module:          group related unit test
 * setup/teardown:  test setup/cleanup
 */
/*********************************/
//Event Dispatcher class
var Utils = null;
QUnit.module("DateTimeUtils", {
    setup: function() {
        //initialize code
        Utils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
    },
    teardown: function() {
        //cleanup code
        Utils = null;
    }
});

test("manipulateDatetime Year", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    var newDate = Utils.manipulateDatetime(goodDate, "years", 2);
    equal(newDate, "2016-03-14 01:01:01", "Year should be 2016");

    newDate = Utils.manipulateDatetime(goodDate, "years", -2);
    equal(newDate, "2012-03-14 01:01:01", "Year should be 2012");

    newDate = Utils.manipulateDatetime(badDate, "years", 2);
    equal(newDate, badDate, "Year should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "years", 2);
    equal(newDate, reallYadDate, "Year should original");

    newDate = Utils.manipulateDatetime(badString, "years", 2);
    equal(newDate, badString, "Year should original");

});


test("manipulateDatetime Month", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "months", 2);
    equal(newDate, "2014-05-14 01:01:01", "Month should be 5");

    newDate = Utils.manipulateDatetime(goodDate, "months", -2);
    equal(newDate, "2014-01-14 01:01:01", "Month should be 2");

    newDate = Utils.manipulateDatetime(goodDate, "months", 13);
    equal(newDate, "2015-04-14 01:01:01", "Month should be 4 and Year should be 2015");

    newDate = Utils.manipulateDatetime(badDate, "months", 2);
    equal(newDate, badDate, "Month should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "months", 2);
    equal(newDate, reallYadDate, "Month should original");

    newDate = Utils.manipulateDatetime(badString, "months", 2);
    equal(newDate, badString, "Month should original");

});

test("manipulateDatetime Day", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "D", 2);
    equal(newDate, "2014-03-16 01:01:01", "Day should be 16");

    newDate = Utils.manipulateDatetime(goodDate, "D", -2);
    equal(newDate, "2014-03-12 01:01:01", "Day should be 12");

    newDate = Utils.manipulateDatetime(goodDate, "D", 366);
    equal(newDate, "2015-03-15 01:01:01", "Day should be 15 and Year should be 2015");

    newDate = Utils.manipulateDatetime(badDate, "D", 2);
    equal(newDate, badDate, "Day should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "D", 2);
    equal(newDate, reallYadDate, "Day should original");

    newDate = Utils.manipulateDatetime(badString, "D", 2);
    equal(newDate, badString, "Day should original");

});

test("manipulateDatetime Hour", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "hh", 2);
    equal(newDate, "2014-03-14 03:01:01", "Hour should be 3");

    newDate = Utils.manipulateDatetime(goodDate, "hh", -2);
    equal(newDate, "2014-03-13 23:01:01", "Hour should be 23 and Day 13");

    newDate = Utils.manipulateDatetime(badDate, "hh", 2);
    equal(newDate, badDate, "Hour should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "hh", 2);
    equal(newDate, reallYadDate, "Hour should original");

    newDate = Utils.manipulateDatetime(badString, "hh", 2);
    equal(newDate, badString, "Hour should original");

});

test("manipulateDatetime Minute", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "mm", 2);
    equal(newDate, "2014-03-14 01:03:01", "Minute should be 3");

    newDate = Utils.manipulateDatetime(goodDate, "mm", -2);
    equal(newDate, "2014-03-14 00:59:01", "Minute should be 59, Hours 23, and Day 13");

    newDate = Utils.manipulateDatetime(badDate, "mm", 2);
    equal(newDate, badDate, "Minute should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "mm", 2);
    equal(newDate, reallYadDate, "Minute should original");

    newDate = Utils.manipulateDatetime(badString, "mm", 2);
    equal(newDate, badString, "Minute should original");

});

test("manipulateDatetime Second", function() {
    var goodDate = "2014-03-14 01:01:01";
    var badDate = "NaN-NaN-NaN 00:00:00";
    var reallYadDate = "NaN-Foo 00:00";
    var badString = "Hello World";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "ss", 2);
    equal(newDate, "2014-03-14 01:01:03", "Second should be 3");

    newDate = Utils.manipulateDatetime(goodDate, "ss", -2);
    equal(newDate, "2014-03-14 01:00:59", "Second should be 59, Minutes 00");

    newDate = Utils.manipulateDatetime(badDate, "ss", 2);
    equal(newDate, badDate, "Second should original");

    newDate = Utils.manipulateDatetime(reallYadDate, "ss", 2);
    equal(newDate, reallYadDate, "Second should original");

    newDate = Utils.manipulateDatetime(badString, "ss", 2);
    equal(newDate, badString, "Second should original");

});

test("manipulateDatetime", function() {
    var goodDate = "2014-03-14 01:01:01";

    //Good tests
    newDate = Utils.manipulateDatetime(goodDate, "xx", 2);
    equal(newDate, goodDate, "Should be goodDate");
});


test("getDateIntervals invalids", function() {
    //{ startDateTime: "", endDateTime: ""}
    var results = Utils.getDateIntervals("NaN-NaN", "2014-03-14 01:01:01");
    equal(results.length, 1, "Results (1) length should be 1");
    equal(results[0].startDateTime, "NaN-NaN", "Results (1) startDateTime should be NaN-NaN");
    equal(results[0].endDateTime, "2014-03-14 01:01:01", "Results (1) endDateTime should be 2014-03-14 01:01:01");

    results = Utils.getDateIntervals("2014-03-14 01:01:01", "NaN");
    equal(results.length, 1, "Results (2) length should be 1");
    equal(results[0].endDateTime, "NaN", "Results (2) endDateTime should be NaN-NaN");
    equal(results[0].startDateTime, "2014-03-14 01:01:01", "Results (2) startDateTime should be 2014-03-14 01:01:01");

    results = Utils.getDateIntervals(null, "NaN");
    equal(results.length, 1, "Results (3) length should be 1");
    equal(results[0].endDateTime, "NaN", "Results (3) endDateTime should be NaN-NaN");
    equal(results[0].startDateTime, null, "Results (3) startDateTime should benull");
});

test("getDateIntervals single day", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-03-14 15:30:01";
    var results = Utils.getDateIntervals(start, end);
    equal(results.length, 1, "Results length should be 1");
    equal(results[0].startDateTime, start, "Results startDateTime should be " + start);
    equal(results[0].endDateTime, end, "Results endDateTime should be " + end);
});

test("getDateIntervals two day", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-03-15 15:30:01";
    var results = Utils.getDateIntervals(start, end);
    equal(results.length, 2, "Results length should be 2");

    equal(results[0].startDateTime, start, "Results[0]] startDateTime should be " + start);
    equal(results[0].endDateTime, "2014-03-14 23:59:59", "Results[0] endDateTime should be 2014-03-14 23:59:59");

    equal(results[1].startDateTime, "2014-03-15 00:00:00", "Results[1] startDateTime should be 2014-03-15 00:00:00");
    equal(results[1].endDateTime, end, "Results[1] endDateTime should be " + end);

});

test("getDateIntervals three day", function() {
    var start = "2014-03-14 13:01:01";
    var end = "2014-03-16 15:30:01";
    var results = Utils.getDateIntervals(start, end);
    equal(results.length, 3, "Results length should be 3");

    equal(results[0].startDateTime, start, "Results[0]] startDateTime should be " + start);
    equal(results[0].endDateTime, "2014-03-14 23:59:59", "Results[0] endDateTime should be 2014-03-15 23:59:59");

    equal(results[1].startDateTime, "2014-03-15 00:00:00", "Results[1]] startDateTime should be 2014-03-15 00:00:00");
    equal(results[1].endDateTime, "2014-03-15 23:59:59", "Results[1] endDateTime should be 2014-03-15 23:59:59");

    equal(results[2].startDateTime, "2014-03-16 00:00:00", "Results[1] startDateTime should be 2014-03-16 00:00:00");
    equal(results[2].endDateTime, end, "Results[2] endDateTime should be " + end);

});
