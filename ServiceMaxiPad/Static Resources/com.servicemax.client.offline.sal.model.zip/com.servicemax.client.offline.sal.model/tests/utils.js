var Utils = null;
QUnit.module("Utils.Data", {
    setup: function() {
        //initialize code
        Utils = com.servicemax.client.offline.sal.model.utils.Data;
    },
    teardown: function() {
        //cleanup code
        Utils = null;
    }
});

