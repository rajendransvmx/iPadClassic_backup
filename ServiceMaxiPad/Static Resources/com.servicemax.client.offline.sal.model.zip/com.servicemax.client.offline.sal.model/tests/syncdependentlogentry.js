QUnit.module("CreateSyncDependentLogValidator", {
    setup: function() {
        //initialize code
    },
    teardown: function() {
        //cleanup code
    }
});

test("After Save Sync Dependent Log Entry creation", function(){
	var dependentLogCreated = false;
	var f = {
		referenceTo : ['Account']
	};
	var sobjectinfo = {
		Id : 'a01sheoi23mdskdn'
	};

	sinon.stub(com.servicemax.client.offline.sal.model.utils.Data, "__createDependentEntry", function(){
		dependentLogCreated = true;
	});

	com.servicemax.client.offline.sal.model.utils.Data.__updateDependentRecords('transient-sdfbufkjnfwbf', f, 'SVMXC__Service_Order__c', sobjectinfo);
	equal(dependentLogCreated, true, "Sync Dependent Log Entry Created.");
});