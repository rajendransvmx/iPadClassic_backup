
var attachFile;
var attachService;
var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
var execQuery = com.servicemax.client.sync.api.Utils.execQuery;

QUnit.module("Attachments", {
    setup: function() {
        //initialize code
        attachFile = SVMX.create("com.servicemax.client.offline.sal.model.sfmdelivery.operations.AttachFile");
        attachService = SVMX.getClient().getService("com.servicemax.client.attachmentnotifications").getInstance();
    },
    teardown: function() {
        //cleanup code
        attachFile = null;
        attachService = null;
    }
});

test("validateFileInfo()", function() {
    var fileSizeLimit = 26214400;
    var err = attachFile.validateFileInfo({
        FileSizeInBytes: fileSizeLimit+1
    });
    equal(err && err.fileSizeExceeded, true, "File size error triggered (FileSizeInBytes > "+fileSizeLimit+")");
});

// AttachFile.onFileSelected()
asyncTest("onFileSelected()", function() {
    var fileSelect = {
        OriginalFileName: "TestFile.txt",
        FilePath: "C:/Path/To/TestFile.txt"
    };
    var fileInfo = {
        FileSizeInBytes: 100
    };
    var request = {
        recordId: "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    };
    var attachNoticeTriggered = false;
    var attachNoticeEvent = "ATTACHMENTS_CHANGED";
    // Expect 7 assertions
    expect(7);
    // TEST 3: Did the attachmentsnotification service fire?
    var test1 = function() {
        attachNoticeTriggered = true;
    };
     // TEST 2: Did the SFAttachment record get created?
    var test2 = function(callback) {
        execQuery("SELECT * FROM SFAttachments WHERE parent_id = '"+request.recordId+"'", function(result, err) {
            ok(result, "SFAttachment record created");
            if (result) {
                equal(result.parent_id, request.recordId,
                    "File parent ID matches ("+request.recordId+")");
                equal(result.name, fileSelect.OriginalFileName,
                    "File name matches ("+fileSelect.OriginalFileName+")");
                equal(result.file_path, fileSelect.FilePath,
                    "File path matches ("+fileSelect.FilePath+")");
                equal(result.content_length, new String(fileInfo.FileSizeInBytes),
                    "File size matches ("+fileInfo.FileSizeInBytes+")");
            }
            callback && callback(result && result.Id);
        });
    };
    // TEST 3: Did the ClientSyncLog record get created?
    var test3 = function(resultId, callback) {
        execQuery("SELECT * FROM ClientSyncLog WHERE Id = '"+resultId+"'", function(result, err) {
            ok(result, "ClientSyncLog record created");
            if (result) {
                // Clean up
                execQuery("DELETE FROM ClientSyncLog WHERE Id = '"+resultId+"'");
            }
            callback && callback();
        });
    };
    var attachNoticeCallback = function() {
        attachNoticeTriggered = true;
    };
    attachService.bind(attachNoticeEvent, attachNoticeCallback);
    var testCleanUp = function() {
        execQuery("DELETE FROM SFAttachments WHERE parent_id = '"+request.recordId+"'", function() {
            attachService.unbind(attachNoticeEvent, attachNoticeCallback);
            start();
        });
    };
    var responder = {
        result: function(){
            test2(function(resultId) {
                // Delay for test3 since ClientSyncLog record is inserted in a separate call
                setTimeout(function() {
                    test3(resultId, function() {
                        ok(attachNoticeTriggered, "Attachment notification triggered ("+attachNoticeEvent+")");
                        testCleanUp();
                    });
                }, 250);
            });
        },
        fault: function(data){
            testCleanUp();
        }
    };
    attachFile.onFileSelected(request, responder, fileSelect, fileInfo);
});