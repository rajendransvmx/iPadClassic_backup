
var nativeSer = com.servicemax.client.offline.sal.model.nativeservice.Facade;
var __nativeService = com.servicemax.client.nativeservice;

QUnit.module("NativeServiceTests", {
    setup: function() {
        //initialize code
         __nativeService.Client.execute = sinon.stub();
        },
       
    teardown: function() {
        //cleanup code
    }
});

test("Create SQL Request And Test the parameters passed to Native Service Class", function(){	
	
	var req = nativeSer.createSQLRequest();
	req.bind("REQUEST_COMPLETED", function(evt){
                  console.log(evt);
                }, this);

    req.bind("REQUEST_ERROR", function(evt){
		console.log(evt);
    }, this);

    req.execute({
        query : "",
        queryArray : ["CREATE TABLE DUMMY (NAME VARCHAR)", "INSERT INTO DUMMY VALUES(1)"],
        doRollBack : false
    });
   
    equal(__nativeService.Client.execute.callCount, 1, "ONCE");
    equal(__nativeService.Client.execute.args[0][0].parameters.queryArray.length, 2, "Array Length Should be 2");
    equal(__nativeService.Client.execute.args[0][0].parameters.doRollBack, false, "Rollback should be false");
    equal(__nativeService.Client.execute.args[0][0].parameters.async, true, "Async should be True");
    
});

