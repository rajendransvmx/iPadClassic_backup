/**
 * @author Ashwini R
 * @package com.servicemax.client.offline.sal.model.recents.operations
 */

(function() {
    var recentsImpl = SVMX.Package("com.servicemax.client.offline.sal.model.recents.operations");

recentsImpl.init = function(){
    var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
    var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.troubleshootdelivery.operations");

    function execQuery(inParams) {
        var d = $.Deferred();
        var req = nativeService.createSQLRequest();
        req.bind("REQUEST_COMPLETED", function(evt) {
            d.resolve(evt.data.data);
        });
        req.bind("REQUEST_ERROR", function(evt) {
            d.reject(evt.data.data);
        });
        req.execute({
            query: inParams.query,
            queryParams: inParams.queryParams
        });
        return d;
    }

    /**
     * Returns recent items
     *
     * 
     *
     * @class com.servicemax.client.offline.sal.model.recents.operations.getRecentInfo
     * @extends com.servicemax.client.mvc.api.Operation
     */
    recentsImpl.Class("GetRecents", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            var me = this;
            execQuery({
                query : "select RecentItems.RecordId,RecentItems.Type,RecentItems.LastAccessed, SFObjectDescribe.label, RecentItems.ObjectName, RecentItems.nameField From RecentItems LEFT JOIN SFObjectDescribe ON SFObjectDescribe.object_name = RecentItems.ObjectName ORDER BY LastAccessed DESC",
            }).then(function(result){                      
                var allresults,created,createdresults;
                var nameFieldResults = me.addNameFieldToRecords(result); 
                SVMX.when(nameFieldResults).then(function(){
                    allresults = me.formatData(result); 
                    created = me.getCreatedRecords(result);
                    createdresults = me.formatData(created);
                    responder.result({
                        'allRecords' : allresults,
                        'createdRecords' : createdresults
                    });
                 }); 
            });  
        },
        formatData: function(res){     
            var recordLimit = 25;      
            var output = {};
            var labelField = null;
            var tempItem;
            (res || []).forEach(function(item) {
                labelField = item.ObjectName ;
                    if(!(labelField in output)){
                        output[labelField] = [];
                        output[labelField].label = item.label;
                        output[labelField].data = [];
                    }
                //delete item.label;
                tempItem = JSON.parse(JSON.stringify(item));
                delete tempItem.label;
                delete tempItem.ObjectName;
                if(output[labelField].data.length < recordLimit){
                    output[labelField].data.push(tempItem);  
                }              
            });
            return output;
        },
        getCreatedRecords:function(res){
            var createdRecords = [];
            (res || []).forEach(function(item) {
                if(item.Type == "CREATE"){
                    createdRecords.push(item);
                }
            });
            return createdRecords;
        },
        addNameFieldToRecords: function(result){
            var me = this;
            this.__tempResult = result;
            var defers = [];            
            (result || []).forEach(function(item,i) {
                defers.push(execQuery({
                    query : "select " + "'" + item.ObjectName + "'"+ "." + item.NameField +" from "+ "'"+ item.ObjectName + "'" + " where " + "'"+item.ObjectName +"'"+ ".Id = " + "'" + item.RecordId + "'"                  
                }).then(function(res){
                    if(res && res.length>0) {
                        var obj = res[0];
                        var value = Object.keys(obj)[0];
                        item.NameField = obj[value];                    
                    }
                    else{
                        delete me.__tempResult[i]; // TODO Find a way to delete item without undefined
                    }                    
                })); 
            });
            return defers;
        }
        
    }, {});

     /**
     * Adds record to  recent items
     *
     * 
     *
     * @class com.servicemax.client.offline.sal.model.recents.operations.AddRecents
     * @extends com.servicemax.client.mvc.api.Operation
     */
    recentsImpl.Class("AddRecents", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
           var defers = [];   
           var recordLimit = 25;
            //Add to Recents
            var record = {
                RecordId : request.recordId,
                ObjectName : request.objectName,
                LastAccessed : request.lastAccessed,
                NameField : request.nameField,
                Type : request.type
            }
            if(record.Type == 'CREATE'){
                defers.push(execQuery({
                     query : "SELECT COUNT(*) as Count FROM RecentItems WHERE Type = 'Create' AND ObjectName =" + "'" + record.ObjectName + "'"
                }).then(function(res){                    
                    if(res[0] && res[0].Count >=recordLimit){
                         defers.push(execQuery({
                           query : "Delete from RecentItems where recordId = (select RecordId from  RecentItems WHERE Type IN ('CREATE) AND ObjectName = "+ "'" + record.ObjectName + "'" +  "ORDER BY LastAccessed ASC limit 1); "
                        }));
                    }
                }));
            }else{
                defers.push(execQuery({
                   query : "SELECT COUNT(*) as Count FROM RecentItems WHERE Type <> 'Create' AND ObjectName =" + "'" + record.ObjectName + "'"
                }).then(function(res){
                    if(res[0] && res[0].Count >=recordLimit){
                       defers.push(execQuery({
                           query : "Delete from RecentItems where recordId = (select RecordId from  RecentItems WHERE Type IN ('VIEW','EDIT') AND ObjectName = "+ "'" + record.ObjectName + "'" +  "ORDER BY LastAccessed ASC limit 1); "
                        }));
                    }
                }));

            }
            SVMX.when(defers).then(function(){
                execQuery({
                    query: "SELECT Count(*) AS length FROM RecentItems WHERE Type = 'Create' AND RecordId = '{{RecordId}}'",
                    queryParams: record
                }).then(function(count){
                    if(count[0].length > 0){ // if "create" already exist then modify only last accesssed for existing
                        execQuery({
                            query: "UPDATE RecentItems SET LastAccessed ='{{LastAccessed}}' WHERE RecordId = '{{RecordId}}'",
                            queryParams: record
                        }).then(function(count){
                           //Updated Last accessed for Created Element
                        });
                    } else{ // Other than create all other operations
                        execQuery({
                            query: "INSERT OR REPLACE INTO RecentItems (RecordId,ObjectName,LastAccessed,NameField,Type) SELECT * FROM (SELECT '{{RecordId}}','{{ObjectName}}','{{LastAccessed}}','{{NameField}}','{{Type}}') AS tmp WHERE NOT EXISTS (SELECT Type FROM RecentItems WHERE Type = 'Create' AND RecordId = '{{RecordId}}') LIMIT 1;",
                            queryParams: record
                        }).then(function(){
                            //Record added to recents successfully
                        });
                    }
                });
            });
            
        }
    }, {});

    
}
})();