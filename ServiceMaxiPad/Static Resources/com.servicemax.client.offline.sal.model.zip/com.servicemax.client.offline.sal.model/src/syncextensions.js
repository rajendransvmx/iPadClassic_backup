/**
 * This file needs a description
 * @class com.servicemax.client.offline.sal.model.sync.extensions
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function () {

    var impl = SVMX.Package("com.servicemax.client.offline.sal.model.sync.extensions");

    impl.init = function () {
        /*
         * @description: Populates the SFObjectField table based on the SFObjectDescribe table
         * TODO:  The following fields are not currently populated:
         * 			reference_to, calculated, dependent_picklist, unique
         */
        impl.Class("SFMObjectFieldExtension", com.servicemax.client.sync.api.AbstractExtension, {
            execQuery: function (inParams) {
                var req = this.__nativeService.createSQLRequest();
                req.bind("REQUEST_COMPLETED", SVMX.proxy(inParams.context, inParams.onSuccess || function () {}));
                req.bind("REQUEST_ERROR", SVMX.proxy(inParams.context, inParams.onError || function () {}));
                req.execute({
                    query: inParams.query,
                    queryParams: inParams.queryParams
                });
            },
            perform: function (syncService) {
                this.deferred = new $.Deferred();
                if (syncService.getSyncType() == "INITIAL" || syncService.getSyncType() == "CONFIG") {
                    this.__nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;

                    this.__logger = SVMX.getLoggingService().getLogger("SYNC-EXT-SFMObjectField");
                    this.localId = 1;

                    this.execQuery({
                        query: "DELETE FROM SFObjectField",
                        onSuccess: SVMX.proxy(this, function () {
                            this.execQuery({
                                query: "SELECT COUNT(*) as count FROM SFObjectDescribe",
                                context: this,
                                onSuccess: function (evt) {
                                    this.numDescribeEntries = SVMX.toObject(evt.data.data)[0].count;
                                    this.currentPageOfEntries = 0;
                                    this.getTenEntries();
                                },
                                onError: function (evt) {
                                    this.__logger.error("SFMObjectFieldExtension.perform has had a fatal error: " + evt.data.data);
                                }
                            });
                        })
                    });
                } else {
                    this.deferred.resolve();
                }

                return this.deferred;
            },
            getTenEntries: function () {
                if (this.currentPageOfEntries * 10 > this.numDescribeEntries) {
                    this.callLoadExtensions();
                    return;
                }
                this.execQuery({
                    query: "SELECT * FROM SFObjectDescribe LIMIT 10 OFFSET " + (this.currentPageOfEntries * 10),
                    onSuccess: "processDescribeObject",
                    context: this
                });
                this.currentPageOfEntries++;
            },
            callLoadExtensions: function () {
                com.servicemax.client.lib.api.ExtensionRunner.run(this, "com.servicemax.client.onFrameworkLoad")
                        .then(SVMX.proxy(this, function () {
                            return this.deferred.resolve(); // DONE
                        }));
            },
            processDescribeObject: function (evt) {
                var data = SVMX.toObject(evt.data.data);
                this.dataToProcess = data;
                if (data.length) {
                    this.processNext();
                } else {
                    //done
                    this.callLoadExtensions();
                }
            },
            processNext: function () {
                var values = [];
                var inObjectDefEntry = this.dataToProcess.shift();
                var json = inObjectDefEntry.object_describe;
                var inObjectDef = SVMX.toObject(inObjectDefEntry.object_describe);

                /* Work around stupid bug in database */
                if (!inObjectDef || typeof inObjectDef === "string") {
                    inObjectDefEntry.object_describe = inObjectDefEntry.object_describe.replace(/"inlineHelpText\"\:\".*?'ubmodul',/g, '');
                    inObjectDef = SVMX.toObject(inObjectDefEntry.object_describe);
                }

                if (inObjectDef && typeof inObjectDef === "object") {
                    var object_api_name = inObjectDefEntry.object_name;
                    SVMX.array.forEach(inObjectDef.fields, function (inField) {

                        var referenceTo = inField.referenceTo[inField.referenceTo.length - 1];

                        values.push(SVMX.string.substitute("({{local_id}}, '{{object_api_name}}', '{{api_name}}', '{{label}}', {{precision}}, {{scale}}, {{length}}, '{{type}}', '{{reference_to}}', '{{nillable}}', '{{unique}}', '{{restricted_picklist}}', '{{calculated}}', '{{defaulted_on_create}}', '{{name_field}}', '{{relationship_name}}', '{{dependent_picklist}}', '{{controler_field}}')",
                                {
                                    local_id: this.localId++,
                                    object_api_name: object_api_name,
                                    api_name: inField.name,
                                    label: inField.label.replace(/'/g, "&apos"),
                                    type: inField.type || inField.dataType,
                                    reference_to: inField.referenceTo[inField.referenceTo.length - 1],
                                    restricted_picklist: String(inField.restrictedPicklist || false),
                                    defaulted_on_create: String(inField.defaultedOnCreate),
                                    name_field: String(inField.nameField),
                                    relationship_name: inField.relationshipName,
                                    dependent_picklist: referenceTo ? true : false,
                                    controler_field: "",
                                    precision: String(inField.precision),
                                    scale: String(inField.scale),
                                    length: String(inField.length),
                                    nillable: String(inField.nillable),
                                    unique: String(inField.unique || false),
                                    calculated: String(inField.calculated)
                                }));
                    }, this);

                    var batchMax = 100;
                    while (values.length > 0) {
                        var batchValues = values.splice(0, batchMax);
                        this.execQuery({
                            query: "INSERT INTO SFObjectField (local_id, object_api_name, api_name, label, precision, scale, length, type, reference_to, nillable, 'unique', restricted_picklist, calculated, defaulted_on_create, name_field, relationship_name, dependent_picklist, controler_field) VALUES " +
                                    batchValues.join(", "),
                            context: this,
                            onError: function (evt) {
                                this.__logger.error("SERIOUS ERROR IN SFMObjectFieldExtension inserting into SFObjectField: " + evt.data.parameters.query + "; " + evt.data.data);
                            }
                        });
                    }
                }
                if (this.dataToProcess.length > 0) {
                    this.processNext();
                } else {
                    this.getTenEntries();
                }
            }
        }, {});

        impl.Class("InstallBaseExtension", com.servicemax.client.sync.api.AbstractExtension, {
            perform: function (syncService) {
                this.deferred = new SVMX.Deferred();

                if (syncService.getSyncType() == "INCREMENTAL") {
                    this.deferred.resolve();
                } else {
                    this.__logger = SVMX.getLoggingService().getLogger("SYNC-EXT-InstallBase");

                    // Ensure we have all the InstallBase objects.
                    // In the future we should pull these down from configuration.
                    var q = this.__dropTable('InstallBaseObject');
                    q = q.then(SVMX.proxy(this, this.__createObjectTable));
                    q = q.then(SVMX.proxy(this, this.fillObjectTable));

                    // Clear lock table ONLY if Reset Application
                    if (syncService.getSyncType() != "CONFIG") {
                        q = q.then(SVMX.proxy(this, this.__clearLocks));
                    }

                    q.always(SVMX.proxy(this, function () {
                        this.deferred.resolve();
                    }));
                }

                return this.deferred;
            },
            __dropTable: function (table) {
                return this.execQuery({
                    query: "DROP TABLE IF EXISTS '" + table + "'"
                });
            },
            __createObjectTable: function () {
                var sql = com.servicemax.client.sync.api.SQLSchema.getCreateQuery("InstallBaseObject");

                return this.execQuery({
                    query: sql
                });
            },
            fillObjectTable: function () {
                var sql = com.servicemax.client.sync.api.SQLSchema.getInsertReplaceQuery("InstallBaseObject", [
                    {Object_Name: SVMX.OrgNamespace + '__Installed_Product__c'},
                    {Object_Name: SVMX.OrgNamespace + '__Site__c'},
                    {Object_Name: SVMX.OrgNamespace + '__Sub_Location__c'}
                ], true);

                return this.execQuery({
                    query: sql
                });
            },
            __clearLocks: function (table) {
                return this.execQuery({
                    query: "DELETE FROM 'InstallBaseLock'"
                });
            },
            execQuery: function (inParams) {
                var d = new SVMX.Deferred();

                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;

                var req = nativeService.createSQLRequest();

                req.bind("REQUEST_COMPLETED", SVMX.proxy(this, function (evt) {
                    d.resolve(evt.data.data);
                }));
                req.bind("REQUEST_ERROR", SVMX.proxy(this, function (evt) {
                    d.reject(evt.data.data);
                }));
                req.execute({
                    query: inParams.query,
                    queryParams: inParams.queryParams
                });

                return d;
            }

        }, {});

        impl.Class("SFObjectFieldPopulateExtension", com.servicemax.client.sync.api.AbstractExtension, {
            execQuery: function (inParams) {
                var req = this.__nativeService.createSQLRequest();
                req.bind("REQUEST_COMPLETED", SVMX.proxy(inParams.context, inParams.onSuccess || function () {}));
                req.bind("REQUEST_ERROR", SVMX.proxy(inParams.context, inParams.onError || function () {}));
                req.execute({
                    query: inParams.query,
                    queryParams: inParams.queryParams
                });
            },
            perform: function (syncService, inData) {
                var me = this;
                me.syncService = syncService;
                me.productIqTables = inData.tables;

                this.deferred = new $.Deferred();
                if (syncService.getSyncType() == "INITIAL" || syncService.getSyncType() == "CONFIG") {

                    this.__nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;

                    this.__logger = SVMX.getLoggingService().getLogger("SYNC-EXT-SFMObjectField");
                    this.localId = 1;

                    this.execQuery({
                        query: "DELETE FROM SFObjectField",
                        onSuccess: SVMX.proxy(this, function () {

                            this.numDescribeEntries = me.productIqTables.length;
                            this.currentPageOfEntries = 0;
                            this.getTenEntries();

                        })
                    });
                } else {
                    this.deferred.resolve();
                }

                return this.deferred;
            },
            getTenEntries: function () {

                var me = this;
                var sfObjectDescribeTableName = "TEMP__SFObjectDescribe";

                if (this.currentPageOfEntries * 10 > this.numDescribeEntries) {
                    this.callLoadExtensions();
                    return;
                }

                var piQObjectsInClause = me.productIqTables.join("','");
                //IN ('" + columnNames + "')"
                this.execQuery({
                    query: "SELECT * FROM " + sfObjectDescribeTableName + " WHERE object_name IN ('" + piQObjectsInClause + "') LIMIT 10 OFFSET " + (this.currentPageOfEntries * 10),
                    onSuccess: "processDescribeObject",
                    context: this
                });
                this.currentPageOfEntries++;
            },
            callLoadExtensions: function () {
                com.servicemax.client.lib.api.ExtensionRunner.run(this, "com.servicemax.client.onFrameworkLoad")
                        .then(SVMX.proxy(this, function () {
                            return this.deferred.resolve(); // DONE
                        }));
            },
            processDescribeObject: function (evt) {
                var data = SVMX.toObject(evt.data.data);
                this.dataToProcess = data;
                if (data.length) {
                    this.processNext();
                } else {
                    //done
                    this.callLoadExtensions();
                }
            },
            processNext: function () {
                var values = [];
                var inObjectDefEntry = this.dataToProcess.shift();
                var json = inObjectDefEntry.object_describe;
                var inObjectDef = SVMX.toObject(inObjectDefEntry.object_describe);

                /* Work around stupid bug in database */
                if (!inObjectDef || typeof inObjectDef === "string") {
                    inObjectDefEntry.object_describe = inObjectDefEntry.object_describe.replace(/"inlineHelpText\"\:\".*?'ubmodul',/g, '');
                    inObjectDef = SVMX.toObject(inObjectDefEntry.object_describe);
                }

                if (inObjectDef && typeof inObjectDef === "object") {
                    var object_api_name = inObjectDefEntry.object_name;
                    SVMX.array.forEach(inObjectDef.fields, function (inField) {


                        var referenceTo = inField.referenceTo[inField.referenceTo.length - 1];
                        values.push(SVMX.string.substitute("({{local_id}}, '{{object_api_name}}', '{{api_name}}', '{{label}}', {{precision}}, {{scale}}, {{length}}, '{{type}}', '{{reference_to}}', '{{nillable}}', '{{unique}}', '{{restricted_picklist}}', '{{calculated}}', '{{defaulted_on_create}}', '{{name_field}}', '{{relationship_name}}', '{{dependent_picklist}}', '{{controler_field}}')",
                                {
                                    local_id: this.localId++,
                                    object_api_name: object_api_name,
                                    api_name: inField.name,
                                    label: inField.label.replace(/'/g, "&apos"),
                                    type: inField.type || inField.dataType,
                                    reference_to: referenceTo,
                                    restricted_picklist: String(inField.restrictedPicklist || false),
                                    defaulted_on_create: String(inField.defaultedOnCreate),
                                    name_field: String(inField.nameField),
                                    relationship_name: inField.relationshipName,
                                    dependent_picklist: referenceTo ? true : false,
                                    controler_field: "",
                                    precision: String(inField.precision),
                                    scale: String(inField.scale),
                                    length: String(inField.length),
                                    nillable: String(inField.nillable),
                                    unique: String(inField.unique || false),
                                    calculated: String(inField.calculated)
                                }));
                    }, this);

                    var batchMax = 100;
                    while (values.length > 0) {
                        var batchValues = values.splice(0, batchMax);
                        this.execQuery({
                            query: "INSERT INTO SFObjectField (local_id, object_api_name, api_name, label, precision, scale, length, type, reference_to, nillable, 'unique', restricted_picklist, calculated, defaulted_on_create, name_field, relationship_name, dependent_picklist, controler_field) VALUES " +
                                    batchValues.join(", "),
                            context: this,
                            onError: function (evt) {
                                this.__logger.error("SERIOUS ERROR IN SFMObjectFieldExtension inserting into SFObjectField: " + evt.data.parameters.query + "; " + evt.data.data);
                            }
                        });
                    }
                }
                if (this.dataToProcess.length > 0) {
                    this.processNext();
                } else {
                    this.getTenEntries();
                }
            }
        }, {});

        impl.Class("ServicemaxProcessForChecklistExtension", com.servicemax.client.sync.api.AbstractExtension, {
            perform: function (syncService, inParam) {
                this.__nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                this.__logger = SVMX.getLoggingService().getLogger("SVMXProcess-Checklist-EXT");
                this.__batchSize = 25;
                this.__tables = inParam.tables;

                this.deferred = new $.Deferred();

                this.execQuery({
                    query: "SELECT COUNT(*) as count FROM " + this.__tables[0] + " WHERE process_type = 'CHECKLIST'",
                    onSuccess: function (evt) {
                        this.numDescribeEntries = SVMX.toObject(evt.data.data)[0].count;
                        if (this.numDescribeEntries) {
                            this.__logger.info("Total number of checklist processes = " + this.numDescribeEntries);
                            this.currentPageOfEntries = 0;
                            this.getTwentyFiveEntries();
                        } else {
                            this.__logger.info("No checklist processes");
                        }
                    },
                    onError: function (evt) {
                        this.__logger.error("ServicemaxProcessForChecklistExtension.perform has had a fatal error: " + evt.data.data);
                    },
                    context: this
                });
                return this.deferred;
            },
            getTwentyFiveEntries: function () {
                if (this.currentPageOfEntries * this.__batchSize > this.numDescribeEntries) {
                    this.callLoadExtensions();
                    return;
                }
                this.execQuery({
                    query: "SELECT * FROM " + this.__tables[0] + " WHERE process_type = 'CHECKLIST' LIMIT " + this.__batchSize + " OFFSET " + (this.currentPageOfEntries * this.__batchSize),
                    onSuccess: "processChecklistProcesses",
                    context: this
                });
                this.currentPageOfEntries++;
            },
            processChecklistProcesses: function (evt) {
                var me = this;
                var checklistProcess = evt.data.data;
                var fieldMap = {
                    "process_id": "Id",
                    "process_unique_id": SVMX.getCustomObjectName("ProcessID"),
                    "process_type": SVMX.getCustomObjectName("Record_Type_Name"),
                    "process_name": SVMX.getCustomObjectName("Name"),
                    "process_description": SVMX.getCustomObjectName("Description"),
                    "page_layout_id": SVMX.getCustomObjectName("Page_Layout"),
                    "doc_template_id": SVMX.getCustomObjectName("Doc_Template")
                };
                var tableName = this.__tables[1];
                
                if (checklistProcess && checklistProcess.length > 0) {
                    var insertQuery = me.getInsertQueryForFields(fieldMap, checklistProcess, tableName);
                    
                    me.execQuery({
                        query: insertQuery,
                        onSuccess: function (evt) {
                            //callback && callback.call(this);
                            me.getTwentyFiveEntries();
                        },
                        onError: function (evt) {
                            this.__logger.error("Failed to insert into Servicemax_Process Table");
                        },
                        context: me
                    });

                } else {
                    this.__logger.info("No checklist Processes");
                }
            },
            getInsertQueryForFields: function (fieldMap, records, tablename) {
                var sourceFields = Object.keys(fieldMap);
                var destinationFields = sourceFields.map(function (ele) {
                    return fieldMap[ele];
                });
                var values = [];
                for (var i = 0; i < records.length; i++) {
                    var rec = records[i];
                    var fieldValue = "";

                    for (var j = 0; j < sourceFields.length; j++) {
                        if (fieldValue.length) {
                            fieldValue = fieldValue + "," + "'" + rec[sourceFields[j]] + "'";
                        } else {
                            fieldValue = "'" + rec[sourceFields[j]] + "'";
                        }

                    }
                    values[i] = "(" + fieldValue + ")";
                }

                var query = "INSERT OR REPLACE INTO " + tablename + " (" + destinationFields.join(",") + ") " + "VALUES " + values.join(",");

                return query;
            },
            callLoadExtensions: function () {
                com.servicemax.client.lib.api.ExtensionRunner.run(this, "com.servicemax.client.onFrameworkLoad")
                        .then(SVMX.proxy(this, function () {
                            return this.deferred.resolve(); // DONE
                        }));
            },
            execQuery: function (inParams) {
                var req = this.__nativeService.createSQLRequest();
                req.bind("REQUEST_COMPLETED", SVMX.proxy(inParams.context, inParams.onSuccess || function () {}));
                req.bind("REQUEST_ERROR", SVMX.proxy(inParams.context, inParams.onError || function () {}));
                req.execute({
                    query: inParams.query,
                    queryParams: inParams.queryParams
                });
            },
        }, {});
        impl.Class("PurgeIBRelatedRecords", com.servicemax.client.sync.api.AbstractExtension, {
            perform: function (syncService,params) {
                this.deferred = new $.Deferred();
                this.__syncService = syncService;
                this.ibRecordIds = params.ibRecordIds;
                this.context = params.context;
                this.__nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                this.__logger = SVMX.getLoggingService().getLogger("SVMXProcess-Checklist-EXT");
                this.deleteIbRelatedRecords(this.ibRecordIds,this.context);
                return this.deferred;
            },
            
            deleteIbRelatedRecords: function(ibRecordIds,context){
                var d = SVMX.Deferred();
                var me = this;
                if(ibRecordIds.length < 0)
                return;
                var historyTable = this.getIBTableName("SM_IB_Attributes_History");
                var installedProductId = this.getIBTableName("SM_Installed_Product_Id");
                var templateInstanceTable = this.getIBTableName("SM_IB_Attributes_Template_Instance");
                var ids = ibRecordIds.join("','");
                this.__logger.info("deleting IB related records from SM_IB_Attributes_History Table and SM_IB_Attributes_Template_Instance Table");
                var d1 = this.deleteSQLRequest(historyTable,installedProductId,ids,context);
                var d2 = this.deleteSQLRequest(templateInstanceTable,installedProductId,ids,context);
                $.when(d1,d2).done(function(){
                    me.__logger.info("finished deleting");
                    me.callLoadExtensions(me);
                    d.resolve();
                }).fail(function(){
                    me.__logger.error("Something went wrong while deleting records from IB Related Attributes");
                    d.resolve();
                });
            },
            
            deleteSQLRequest : function(tableName,idField,recIds,context){
                var d = SVMX.Deferred();
                var me = this;
                query = "SELECT ID FROM " + tableName + " WHERE " + idField + " IN ('" + recIds + "')";
                this.execQuery({
                    query: query,
                    onSuccess: function (evt) {
                        var data = evt.data.data;
                        var i = 0, len = data.length, res = [];
                        for(i ; i < len; i++){
                            res.push(data[i].Id);
                        }
                        me.context._deleteRecord(tableName,res); 
                        d.resolve();
                    },
                    onError: function (evt) {
                        this.__logger.error("Failed to get IB attribute template ids to purge");
                        d.resolve();
                    },
                    context: me
                });
            },
            
            getIBTableName: function(tableName){
                var ibTableName = SVMX.getCustomObjectName(tableName);
                return ibTableName;
            },
            
            callLoadExtensions: function () {
                var context = this;
                com.servicemax.client.lib.api.ExtensionRunner.run(this, "com.servicemax.client.onFrameworkLoad")
                        .then(SVMX.proxy(this, function () {
                            return this.deferred.resolve(); // DONE
                        }));
            },
            
            execQuery: function (inParams) {
                var req = this.__nativeService.createSQLRequest();
                req.bind("REQUEST_COMPLETED", SVMX.proxy(inParams.context, inParams.onSuccess || function () {}));
                req.bind("REQUEST_ERROR", SVMX.proxy(inParams.context, inParams.onError || function () {}));
                req.execute({
                    query: inParams.query,
                    queryParams: inParams.queryParams
                });
            },
        }, {});
	
        impl.Class("PurgePiqTechnicalAttributeRelatedRecords", com.servicemax.client.sync.api.AbstractExtension, {
            perform: function (syncService, inParam) {
                this.deferred = new $.Deferred();
                this.__syncEvent = inParam.syncEvent;
                this.__nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                this.__logger = SVMX.getLoggingService().getLogger("SVMXProcess-Checklist-EXT");
                this._purgeProductAttributesAndTemplateRecords();
                return this.deferred;
            },
            _purgeProductAttributesAndTemplateRecords: function () {
                var me = this;
                this.__logger.info("Start Product attribute and Attribute template Purge");
                this._getProductIdsToPurge().then(me._getAttributeTemplateIds)
                        .then(me.getPurgeAttributeTemplateIdWithNoProducts)
                        .then(me._getAttributeTemplateIdsToPurge)
                        .then(me._purgePiqAttributesAndTemplates)
                        .done(function () {
                            me.__logger.info("Purge Product attributes and Attribute template successfully");
                            me.callLoadExtensions(me);
                        })
                        .fail(function () {
                            me.__logger.error("Purge Product attributes and Attribute template failed");
                            me.callLoadExtensions();
                        });
            },
            _getProductIdsToPurge: function () {
                var d = SVMX.Deferred();
                var me = this;
                var query = "SELECT DISTINCT {{columnName}} FROM {{attrTableName}} WHERE {{columnName}} NOT IN (SELECT Id FROM {{prodTableName}}) AND SVMXDEV__SM_Product__c != ''";
                var fieldName = SVMX.getCustomFieldName("SM_Product");
                var queryParam = {
                    columnName: fieldName,
                    attrTableName: SVMX.getCustomFieldName("SM_Product_Attributes"),
                    prodTableName: "Product2"
                };
                var queryForProductIds = SVMX.string.substitute(query, queryParam);
                me.execQuery({
                    query: queryForProductIds,
                    onSuccess: function (evt) {
                        d.resolve(me._getResultIds(evt.data.data, fieldName), me);
                    },
                    onError: function (evt) {
                        this.__logger.error("Failed to get deleted product ids");
                    },
                    context: me
                });
                return d;
            },
            _getResultIds: function (data, fieldName) {
                var Ids = [];
                for (var i = 0; i < data.length; i++) {
                    var element = data[i][fieldName];
                    if (element && element.length && Ids.indexOf(element) === -1) {
                        Ids[i] = element;
                    }
                }
                return Ids;
            },
            _getQueryCondition: function (data) {
                var queryCondition = "";
                if(data.length) {
                    queryCondition = data.join("','");
                    queryCondition = "'" + queryCondition + "'";
                }
                return queryCondition;
            },
            _getAttributeTemplateIds: function (productIdsToPurge, context) {
                var d = SVMX.Deferred();
                var query = "SELECT DISTINCT Id, {{selectColumnName}} FROM {{tableName}} WHERE {{columnName}} IN ({{deletedProductIds}})";
                var fieldName = SVMX.getCustomFieldName("SM_Attribute_Template_Id");
                var queryParam = {
                    columnName: SVMX.getCustomFieldName("SM_Product"),
                    selectColumnName: fieldName,
                    tableName: SVMX.getCustomFieldName("SM_Product_Attributes"),
                    deletedProductIds: context._getQueryCondition(productIdsToPurge)
                };
                var queryForAttributeTemplateIds = SVMX.string.substitute(query, queryParam);
                context.execQuery({
                    query: queryForAttributeTemplateIds,
                    onSuccess: function (evt) {
                        context.productAttrToPurge = context._getResultIds(evt.data.data, 'Id');
                        d.resolve(context._getResultIds(evt.data.data, fieldName), productIdsToPurge, context);
                    },
                    onError: function (evt) {
                        this.__logger.error("Failed to get product attribute ids and attribute templates");
                    },
                    context: context
                });
                return d;
            },
            getPurgeAttributeTemplateIdWithNoProducts: function (attrTemplateIds, productIdsToPurge, context) {
                var d = SVMX.Deferred();
                var query = "SELECT DISTINCT {{selectColumnName}} FROM {{tableName}} WHERE {{selectColumnName}} IN ({{attrTemplateIds}}) AND {{columnName}} NOT IN ({{deletedProductIds}})";
                var fieldName = SVMX.getCustomFieldName("SM_Attribute_Template_Id");
                var queryParam = {
                    columnName: SVMX.getCustomFieldName("SM_Product"),
                    selectColumnName: fieldName,
                    tableName: SVMX.getCustomFieldName("SM_Product_Attributes"),
                    deletedProductIds: context._getQueryCondition(productIdsToPurge),
                    attrTemplateIds: context._getQueryCondition(attrTemplateIds)
                };
                var queryForDoNotPurgeAttributeTemplateIds = SVMX.string.substitute(query, queryParam);
                context.execQuery({
                    query: queryForDoNotPurgeAttributeTemplateIds,
                    onSuccess: function (evt) {
                        var doNotPurgeIds = context._getResultIds(evt.data.data, fieldName);
                        var allIds = attrTemplateIds;
                        var purgeIds = allIds.filter(function (ele) {
                            if (doNotPurgeIds.indexOf(ele) != -1)
                                return false;
                            else
                                return true;
                        })
                        d.resolve(purgeIds, context);
                    },
                    onError: function (evt) {
                        this.__logger.error("Failed to get attribute template ids that shouldnt be purged");
                    },
                    context: context
                });
                return d;
            },
            _getAttributeTemplateIdsToPurge: function (attrTemplateIds, context) {
                var d = SVMX.Deferred();
                var query = "SELECT {{selectColumnName}} FROM {{tableName}} WHERE {{selectColumnName}} IN ({{attrTemplateIds}}) AND {{productLine}} = '' AND {{productFamily}} = '' ";
                var fieldName = SVMX.getCustomFieldName("SM_Attribute_Template_Id");
                var queryParam = {
                    productLine: SVMX.getCustomFieldName("SM_Product_Line"),
                    productFamily: SVMX.getCustomFieldName("SM_Product_Family"),
                    selectColumnName: fieldName,
                    tableName: SVMX.getCustomFieldName("SM_Product_Attributes"),
                    attrTemplateIds: context._getQueryCondition(attrTemplateIds)
                };
                var queryForPurgeIds = SVMX.string.substitute(query, queryParam);
                context.execQuery({
                    query: queryForPurgeIds,
                    onSuccess: function (evt) {
                        context.attrTemplateToPurge = context._getResultIds(evt.data.data, fieldName);
                        context.__logger.info(context.attrTemplateToPurge.length + " records to be deleted from Attribute template table");
                        context.__logger.info(context.productAttrToPurge.length + " records to be deleted from Product attribute table");
                        d.resolve(context);
                    },
                    onError: function (evt) {
                        this.__logger.error("Failed to get attribute template ids to purge");
                    },
                    context: context
                });
                return d;
            },
            _purgePiqAttributesAndTemplates: function(context) {
                var d = SVMX.Deferred();
                var d1 = context.__syncEvent._deleteRecord(SVMX.getCustomFieldName("SM_Attributes_Template"), context.attrTemplateToPurge, function () {
                        this.__logger.info(context.attrTemplateToPurge.length + " Records deleted successfully from SM_Attributes_Template table");
                    });
                var d2 = context.__syncEvent._deleteRecord(SVMX.getCustomFieldName("SM_Product_Attributes"), context.productAttrToPurge, function () {
                        this.__logger.info(context.productAttrToPurge.length + " Records deleted successfully from SM_Product_Attributes table");
                    });
                $.when(d1,d2).done(function(){
                    context.__logger.info("finished deleting");
                    d.resolve();
                }).fail(function(){
                    context.__logger.error("Something went wrong while deleting records from Attribute template/Product attribute table finished deleting");
                    d.resolve();
                })
                return d;
            },
            callLoadExtensions: function () {
                var context = this;
                com.servicemax.client.lib.api.ExtensionRunner.run(this, "com.servicemax.client.onFrameworkLoad")
                        .then(SVMX.proxy(this, function () {
                            return this.deferred.resolve(); // DONE
                        }));
            },
            execQuery: function (inParams) {
                var req = this.__nativeService.createSQLRequest();
                req.bind("REQUEST_COMPLETED", SVMX.proxy(inParams.context, inParams.onSuccess || function () {}));
                req.bind("REQUEST_ERROR", SVMX.proxy(inParams.context, inParams.onError || function () {}));
                req.execute({
                    query: inParams.query,
                    queryParams: inParams.queryParams
                });
            },
        }, {});
    };
})();

// end of file