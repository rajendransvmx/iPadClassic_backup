/**
 * @author Sumit Gupta
 * @package com.servicemax.client.offline.sal.model.sfchatterfeedutils
 */

(function(){
	var utilsImpl = SVMX.Package("com.servicemax.client.offline.sal.model.sfchatterfeedutils");

utilsImpl.init = function(){

	utilsImpl.Class("FeedInfoParser", com.servicemax.client.lib.api.Object, {}, {

		parse: function(feedInfo){
			if(!(feedInfo && feedInfo.feedItems)) return;

			var result = { feedItems: [] };
      this._validateStructure(feedInfo);

		  feedInfo.feedItems.forEach(function(item){
				var feedItem = { 
					id: item.id, 
					message: {
            text: item.body.text,
            segments: item.body.messageSegments
          },
					user: { 
						id: item.actor.id, 
						displayName: item.actor.displayName 
					},
          timestamps: {
            createdDate: item.createdDate,
            modifiedDate: item.modifiedDate,
            relativeCreatedDate: item.relativeCreatedDate,
            editedDate: item.capabilities.edit.lastEditedDate,
            relativeLastEditedDate: item.capabilities.edit.relativeLastEditedDate
          },
					comments: []
				};
				item.capabilities.comments.page.items.forEach(function(comment){
					feedItem.comments.push({
						id: comment.id,
						message: {
              text: comment.body.text,
              segments: comment.body.messageSegments
            },
						user: { 
  						id: comment.user.id, 
  						displayName: comment.user.displayName 
  					},
            timestamps: {
              createdDate: comment.createdDate,
              relativeCreatedDate: comment.relativeCreatedDate,
              editedDate: comment.capabilities.edit.lastEditedDate,
              relativeLastEditedDate: comment.capabilities.edit.relativeLastEditedDate
            }
					});
				});
				result.feedItems.push(feedItem);
			});

			return result;
		},

    addComment: function(feedInfo, comment){
      if(!(feedInfo && feedInfo.feedItems && comment && comment.feedElement)) return;

      this._validateStructure(feedInfo);

      for(var i = 0, l = feedInfo.feedItems.length; i < l; i++){
        if(feedInfo.feedItems[i].id == comment.feedElement.id){
          feedInfo.feedItems[i].capabilities.comments.page.items.push(comment);
          break;
        }
      }
    },

    _validateStructure: function(feedInfo){
      feedInfo.feedItems.forEach(function(item){
        if(!item.body) item.body = {};
        if(!item.actor) item.actor = {};

        if(!item.capabilities) item.capabilities = {};
        if(!item.capabilities.edit) item.capabilities.edit = {};
        if(!item.capabilities.comments) item.capabilities.comments = {};
        if(!item.capabilities.comments.page) item.capabilities.comments.page = {};
        if(!item.capabilities.comments.page.items) item.capabilities.comments.page.items = [];

        item.capabilities.comments.page.items.forEach(function(comment){
          if(!comment.body) comment.body = {};
          if(!comment.user) comment.user = {};

          if(!comment.capabilities) comment.capabilities = {};
          if(!comment.capabilities.edit) comment.capabilities.edit = {};
        });
      });
    }
	});

}

})();