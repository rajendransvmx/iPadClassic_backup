(function() {
    var impl = SVMX.Package("com.servicemax.client.offline.sal.model.tasks.operations");
    impl.init = function() {
        var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;
        var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
        var utils = com.servicemax.client.offline.sal.model.sfwdeliveryutils.Utils;
        var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.tasks");

        /**
         *  Gets tasks list from database
         *
         *  @class      com.servicemax.client.offline.sal.model.tasks.operations.GetTasksList
         *  @extends    com.servicemax.client.mvc.api.Operation
         */
         impl.Class("GetTasksList", com.servicemax.client.mvc.api.Operation, {
            __constructor : function() {
                this.__base();
            },

            /**
             *
             * @param    {Object}    request         data request object
             * @param    {Object}    responder       responder object
             */
             performAsync : function(request, responder) {
                 var query = "SELECT * FROM Task ORDER BY ActivityDate ASC, Subject ASC;";
                 this.__executeQuery(query, function(result1) {
                     if(!result1) {
                         var query = "SELECT * FROM Task ORDER BY Subject ASC;";
                         this.__executeQuery(query, function(result2) {
                             responder.result(result2);
                         });
                     }
                     else {
                         responder.result(result1);
                     }

                 })
             },


             __executeQuery : function(query, binds, callback){

                 if(typeof binds === "function"){
                     callback = binds;
                     binds = {};
                 }

                 var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                 var request = nativeService.createSQLRequest();

                 request.bind("REQUEST_COMPLETED", function(evt){
                     callback.call(this, SVMX.toObject(evt.data.data));
                 }, this);

                 request.bind("REQUEST_ERROR", function(evt){
                     SVMX.getLoggingService().getLogger(evt.data);
                     callback.call(this, false);
                 }, this);

                 request.execute({query : query, async : true, queryBinds: binds });
             }
         });

         /**
          *  Manage a task in database and sync records
          *  Add, delete, update
          *
          *  @class      com.servicemax.client.offline.sal.model.tasks.operations.ManageTask
          *  @extends    com.servicemax.client.mvc.api.Operation
          */
          impl.Class("ManageTask", com.servicemax.client.mvc.api.Operation, {
             __constructor : function() {
                 this.__base();
             },

             /**
              *
              * @param    {Object}    request         data request object
              * @param    {Object}    responder       responder object
              */
              performAsync : function(request, responder) {
                  /**
                  *   If statement to split:
                  *   Delete
                  *   Create/Update
                  */
                  if(request.type == "delete") {
                      OfflineDataUtils.deleteRecord({
                          Id : request.recordId,
                          onSuccess : SVMX.proxy(this, function(record) {
                              //Aggressive Sync Handler 1
                              SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveStarted();

                              OfflineDataUtils.writeSyncRecords([], [], [record], function() {
                                  //Not doing responder here because this callback function is not called
                                  //when deleting "local" records

                                  //Aggressive Sync Handler 2
                                  SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveCompleted();
                              });
                              responder.result(record);
                          }),
                          onError : SVMX.proxy(this, function() {
                              alert("deleteRecord on Task failed!");
                          })
                      })
                  }
                  else {
                      var date = request.date;
                      var priority = request.priority;
                      var description = request.description;
                      var record = request.record;
                      var userId = OfflineSystemUtils.getUserInfo().UserId;
                      var data;
                      if(request.type == "edit") {
                          data = record.data;
                          data.Priority = priority;
                          data.Subject = description;
                          data.ActivityDate = date;
                          data.OwnerId = userId;
                      }
                      else {
                          data = {
                              "Subject" : description,
                              "ActivityDate" : date,
                              "Priority" : priority,
                              "OwnerId" : userId
                          }
                      }
                      OfflineDataUtils.writeRecord({
                          data: data,
                          type: "Task",
                          onSuccess: SVMX.proxy(this, function(isInsert, syncRecordData) {
                              var syncInsertRecords = [];
                              var syncUpdateRecords = [];
                              var syncDeleteRecords = [];
                              if(syncRecordData){
                                  if(isInsert) {
                                      syncInsertRecords.push(syncRecordData);
                                  }
                                  else {
                                      syncUpdateRecords.push(syncRecordData);
                                  }
                              }
                              //Aggressive Sync Handler 1
                              SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveStarted();

                              OfflineDataUtils.writeSyncRecords(syncInsertRecords, syncUpdateRecords, syncDeleteRecords, function() {
                                  //Aggressive Sync Handler 2
                                  SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveCompleted();
                                  responder.result(data);
                              });
                          }),
                          onError: SVMX.proxy(this, function(inError) {
                              alert("Create/Update Task Failed!");
                          })
                      });
                  }

              },


              __executeQuery : function(query, binds, callback){

                  if(typeof binds === "function"){
                      callback = binds;
                      binds = {};
                  }

                  var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                  var request = nativeService.createSQLRequest();

                  request.bind("REQUEST_COMPLETED", function(evt){
                      callback.call(this, SVMX.toObject(evt.data.data));
                  }, this);

                  request.bind("REQUEST_ERROR", function(evt){
                      SVMX.getLoggingService().getLogger(evt.data);
                      callback.call(this, false);
                  }, this);

                  request.execute({query : query, async : true, queryBinds: binds });
              }
          });

    }
})();
