/**
 * This file needs a description
 * @class com.servicemax.client.offline.sal.model.sfmeventdelivery.operations
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){
    var sfmeventOperations = SVMX.Package("com.servicemax.client.offline.sal.model.sfmeventdelivery.operations");

sfmeventOperations.init = function(){

    var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
    var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;
    var OfflineMetaUtils = com.servicemax.client.offline.sal.model.utils.MetaData;
    var OfflineDateUtils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
    var OfflineSyncDataUtils = com.servicemax.client.offline.sal.model.utils.SyncData;

    var executeQuery = function(query, binds){
        var d = SVMX.Deferred();

        if(binds){
            query = SVMX.string.substitute(query, binds);
        }

        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
        var request = nativeService.createSQLRequest();

        request.bind("REQUEST_COMPLETED", function(evt){
            d.resolve(evt.data);
        }, this);

        request.bind("REQUEST_ERROR", function(evt){
            d.resolve(null);
        }, this);

        request.execute({
            query : query,
            async : true
        });

        return d;
    };

    sfmeventOperations.Class("DeleteEventData", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        __executeQuery : function(query, binds, callback){
            if(typeof callback == "undefined"){
                callback = binds;
            }else if(binds){
                query = SVMX.string.substitute(query, binds);
            }

            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var request = nativeService.createSQLRequest();

            request.bind("REQUEST_COMPLETED", function(evt){
                if (callback) {
                    callback(evt.data);
                }
            }, this);

            request.bind("REQUEST_ERROR", function(evt){
                if (callback) {
                    callback(evt.data);
                }
            }, this);

            return request.execute({
                query : query,
                async : true
            });
        },

        performAsync: function(request, responder) {
            //request.data.deleteDetailRecords(request.records, request.alias);
            //responder.result({});
            var that = this;

            OfflineDataUtils.getRecord({Id: request.recordId})
            .fail(SVMX.proxy(this, function() {
                responder && responder.result();
            }))
            .done(SVMX.proxy(this, function(inRecord) {
                if (inRecord) {
                    inRecord.deleteRecord(
                        SVMX.proxy(that, that.__sync, responder),
                        SVMX.proxy(that, that.__failedUpdate, responder)
                    );
                }
            }));
        },

        __sync : function(responder, syncRecordData) {
            var isNotLocal = true;
            if (syncRecordData && syncRecordData.Id && syncRecordData.Id.indexOf('local_') != -1) {
                // Local records have a different path.
                isNotLocal = false;
            }

            // Only run if not local
            isNotLocal && SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveStarted();

            OfflineDataUtils.writeSyncRecords(null, null, [syncRecordData], SVMX.proxy(this, this.__finish, responder));

            // If all events were local above did not call callback so we just finish
            !isNotLocal && this.__localFinish(responder);
        },

        __localFinish : function(responder) {
            // Local record deleted, no need to run aggresive sync.
            responder && responder.result();
        },

        __finish : function(responder) {
            // Start Aggressive sync if applicable
            SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveCompleted();
            responder && responder.result();
        },

        __failedUpdate : function(responder) {
            responder && responder.result();
        }

    }, {});

    sfmeventOperations.Class("UpdateEventDate", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__logger = SVMX.getLoggingService().getLogger('SFM-EVENT-DATA-OP');
            this.__base();
        },


        performAsync: function(request, responder) {
            var that = this;

            if (!request || !request.recordId || !request.startDate || !request.endDate) {
                this.__logger.error("Cannot update date on event record. Missing all required request data");

                responder && responder.result();

                return;
            }

            var recordId = request.recordId;
            var startDate = request.startDate;
            var endDate = request.endDate;

            com.servicemax.client.offline.sal.model.utils.Data.getRecord({Id: recordId})
                .fail(SVMX.proxy(this, function() {
                    // Could not find Event record
                    this.__logger.error("Cannot update date on event record. Record not found for: " + recordId);

                    responder && responder.result();
                }))
                .done(SVMX.proxy(this, function(inRecord) {
                    var eventType = inRecord.getTableName(); // Will be Event if SF Event

                    // Figure out field names depending on event type
                    var allDayField = "IsAllDayEvent";
                    var startField = "StartDateTime";
                    var endField = "EndDateTime";

                    var activityDateTimeField = "ActivityDateTime";
                    var activityDateField = "ActivityDate";
                    var durationField = "DurationInMinutes";

                    if (eventType != "Event") {
                        allDayField = SVMX.OrgNamespace + "__IsAllDayEvent__c";
                        startField = SVMX.OrgNamespace + "__StartDateTime__c";
                        endField = SVMX.OrgNamespace + "__EndDateTime__c";

                        activityDateTimeField = SVMX.OrgNamespace + "__ActivityDateTime__c";
                        activityDateField = SVMX.OrgNamespace + "__ActivityDate__c";
                        durationField = SVMX.OrgNamespace + "__DurationInMinutes__c";
                    }

                    // Convert new startDate and time to be just date
                    var activityDate = startDate.split(' ')[0];

                    // Get duration
                    var duration = OfflineDateUtils.getDurationBetween(startDate, endDate).asMinutes();

                    inRecord[allDayField] = "false"; // If it was an All day event, it is now not.
                    inRecord[startField] = startDate;
                    inRecord[endField] = endDate;

                    inRecord[activityDateTimeField] = startDate;
                    inRecord[activityDateField] = activityDate;
                    inRecord[durationField] = duration;

                    inRecord.writeRecord(
                        SVMX.proxy(that, that.__sync, responder),
                        SVMX.proxy(that, that.__failedUpdate, responder)
                    );
                }));
        },


        __sync : function(responder, isInsert, syncRecordData) {
            SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveStarted();
            if (isInsert) {
                OfflineDataUtils.writeSyncRecords([syncRecordData], null, null, SVMX.proxy(this, this.__finish, responder));
            } else {
                OfflineDataUtils.writeSyncRecords(null, [syncRecordData], null, SVMX.proxy(this, this.__finish, responder));
            }
        },

        __finish : function(responder) {
            // Start Aggressive sync if applicable
            SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveCompleted();
            responder && responder.result();
        },

        __failedUpdate : function(responder) {
            responder && responder.result();
        }
    }, {});

    sfmeventOperations.Class("GetEventData", com.servicemax.client.mvc.api.Operation, {
        __constructor : function(){
            this.__logger = SVMX.getLoggingService().getLogger('SFM-EVENT-DATA-OP');
            this.__queryCounter = 0;
            this.__data = {};

            this.__base();
        },

        performAsync : function(request, responder) {
            this.responder = responder;
            this.__refereceFields = [];
            this.__ids = [];
            this.__data.userinfo = OfflineSystemUtils.getUserInfo();
            var d1 = this.__getCalendarSettings()
            .then(SVMX.proxy(this, function(settings) {
                this.__data.settings = settings;
                // Get the Event Subject Setting and get the fields from the setting.
                this.__sfEventFields = this.__getFieldsFromSubjectSetting(settings.sfEventSubjectSetting);
                this.__svmxEventFields = this.__getFieldsFromSubjectSetting(settings.svmxEventSubjetSetting);

                this.__describeObject("Event",this.__sfEventFields)
                .then(SVMX.proxy(this, function(sfEventFieldAndFieldType){
                    this.__data.sfEventFieldAndFieldType = sfEventFieldAndFieldType;
                    var objectName = SVMX.OrgNamespace + "__SVMX_Event__c";
                    this.__describeObject(objectName, this.__svmxEventFields)
                    .then(SVMX.proxy(this, function(svmxEventFieldAndFieldType){
                        this.__data.svmxEventFieldAndFieldType = svmxEventFieldAndFieldType;
                        var d2 = this.__getCalendarUsers();
                        var d3 = this.__getCalendarEvents(this.__data.userinfo);
                        SVMX.when([d2, d3]).then(SVMX.proxy(this, function(userData, eventData){
                            this.__data.users = userData.data;
                            this.__data.events = eventData;
                            for(var i = 0; i < eventData.length; i++){
                                for(var j = 0; j < this.__refereceFields.length; j++){
                                    var id = eventData[i][this.__refereceFields[j]];
                                    if(id != null && id.length > 0){
                                        this.__ids.push(id);
                                    }
                                }
                            }
                            if(this.__ids.length > 0){
                                this.__getNameForIds(this.__ids)
                                .then(SVMX.proxy(this,function(recordIdName){
                                    this.__data.recordIdName = recordIdName;
                                    this.__processResponseData();
                                  }));
                            }
                            else{
                              this.__processResponseData();
                            }
                        }));
                    }));
                }));
            }));
        },

        __getNameForIds : function(Ids){
            var query = "SELECT Id, Name FROM SFRecordName WHERE Id IN ('{{Ids}}')";
            var binds = {
              Ids : Ids.join("','")
            };
            return executeQuery(query,binds).then(SVMX.proxy(this, this.__parseRecordNameId));
        },

        __parseRecordNameId: function(recordIdNameData){
            var def = SVMX.Deferred();
            var recordIdName = {};
            var data = recordIdNameData.data || [];
            for(var i = 0; i < data.length; i++){
              recordIdName[data[i]["Id"]] = data[i]["Name"];
            }
            def.resolve(recordIdName);
            return def.promise();
        },


        __processResponseData : function(){

            // make sure current user is set
            if(this.__data.userinfo){
                this.__data.users = this.__data.users || [];
                var isUserInUsers = false;
                for(var i = 0; i < this.__data.users.length; i++){
                    if(this.__data.users[i].Id == this.__data.userinfo.UserId){
                        isUserInUsers = true;
                    }
                }
                if(!isUserInUsers && this.__data.users.push){
                    this.__data.users.push({
                        Id : this.__data.userinfo.UserId,
                        FirstName : this.__data.userinfo.UserName,
                        LastName : ""
                    });
                }
            }else{
                this.__data.userinfo = {};
            }

            this.responder.result(this.__data);
        },
        /**
         * 1) Apply time zone offset and format date fields
         * 2) Skip recurring events header record
         * 3) If it's an all-day add +1 day to the end date for it to render correctly
         */
        __processDateFields: function(inData, fieldHash){
            var formattedData = [];
            var timeOffset = this.__data.userinfo.TimezoneOffset;

            if (!timeOffset){
                this.__logger.error("User Info: missing user timezone offset; Location TimeZone");
            }

            if (timeOffset !== 0) {
                $.each(inData, function(id, record){
                    if (record.IsRecurrence != "true") {
                        if (record.IsAllDayEvent != "true") {
                            var newRecord = {};

                            $.each(record, function(idx, item){
                                if (fieldHash[idx]) {
                                    newRecord[idx] = OfflineDateUtils.convertToTimezone(item, timeOffset);
                                } else {
                                    newRecord[idx] = item;
                                }
                            });

                            // guard rail to prevent events without times being used
                            if (newRecord.StartDateTime && newRecord.EndDateTime) {
                                formattedData.push( newRecord );
                            }
                        } else {
                            if (record.EventType === SVMX.OrgNamespace + "__SVMX_Event__c") {
                                // ServiceMax Event
                                // Need to use Activity Date as start Date and then derive EndDate from duration
                                record.StartDateTime = record.ActivityDate && record.ActivityDate + " 00:00:00"; // Sometimes we get blank data
                                var duration = isNaN(record.DurationInMinutes) ? 0 : Number(record.DurationInMinutes);

                                record.EndDateTime = OfflineDateUtils.manipulateDatetime(record.StartDateTime, "minutes", duration);
                            } else {
                                // SalesForce Event
                                // we need to offset enddate to +one day
                                var orginalDate = record.EndDateTime;
                                record.EndDateTime = OfflineDateUtils.manipulateDatetime(orginalDate, "days", 1);
                            }

                            // guard rail to prevent events without times being used
                            if (record.StartDateTime && record.EndDateTime) {
                                formattedData.push( record );
                            }
                        }
                    }
                });

                return formattedData;
            } else {
                return inData;
            }
        },

        __getCalendarUsers : function(callback){
            return executeQuery("SELECT * FROM User LIMIT 10");
        },

       /*
        * fetch the calendar events
        *
        */
        __getCalendarEvents : function(userinfo){
            var settings = this.__data.settings;
            var calendarEvents = null;
            var ids = [];
            //Defect 018035: Permissions to WorkOrder fields.
            //TODO: At some point this should be abstracted out into a proper permissions system
            //      designed for reuse across modules.
            var perm = {
                // Event-level permissions
                event: {
                    hasDriveTime: false
                },
                svmxevent: {
                    hasEvent: false,
                    hasDriveTime: false,
                    hasAllDayEvent: false
                },
                // work order level permissions
                wo: {
                    hasName: false,
                    hasSLA: false,
                    hasCompany: false,
                    hasStreet: false,
                    hasCity: false,
                    hasState: false,
                    hasCountry: false,
                    hasZip: false
                },
                // case level permissions
                case: {
                    hasName: false,
                    hasSLA: false,
                    hasCompany: false
                }
            };


            // Get DescribeObject of Service_Order and verify the user has access
            //  to all the required field. The ones they do not, return as blank.
            return $.when(true)
            /*
             * work order level permissions check
             */
            .then(SVMX.proxy(this, function(){
                var defer = $.Deferred();

                com.servicemax.client.offline.sal.model.utils.MetaData.describeObject({
                    objectName: SVMX.OrgNamespace + "__Service_Order__c"
                }).done(SVMX.proxy(this, function(desc) {

                    for (var i = 0; i < desc.fields.length; i++) {
                        var f = desc.fields[i];
                        if (f.name == "Name") {
                            perm.wo.hasName = true;
                        } else if (f.name == SVMX.OrgNamespace + "__SLA_Terms__c") {
                            perm.wo.hasSLA = true;
                        } else if (f.name == SVMX.OrgNamespace + "__Company__c") {
                            perm.wo.hasCompany = true;
                        } else if (f.name == SVMX.OrgNamespace + "__Street__c") {
                            perm.wo.hasStreet = true;
                        } else if (f.name == SVMX.OrgNamespace + "__City__c") {
                            perm.wo.hasCity = true;
                        } else if (f.name == SVMX.OrgNamespace + "__State__c") {
                            perm.wo.hasState = true;
                        } else if (f.name == SVMX.OrgNamespace + "__Country__c") {
                            perm.wo.hasCountry = true;
                        } else if (f.name == SVMX.OrgNamespace + "__Zip__c") {
                            perm.wo.hasZip = true;
                        }
                    }

                    defer.resolve();
                })).fail(SVMX.proxy(this, function() {
                    // We do not have permission to WorkOrder
                    this.__logger.warn("Unable to get ObjectDescribe of Service_Order ");

                    defer.resolve();
                }));

                return defer.promise();
            }))
            /*
             * case level permissions check
             */
            .then(SVMX.proxy(this, function(){
                var defer = $.Deferred();

                com.servicemax.client.offline.sal.model.utils.MetaData.describeObject({
                    objectName: "Case"
                }).done(SVMX.proxy(this, function(desc) {

                    for (var i = 0; i < desc.fields.length; i++) {
                        var f = desc.fields[i];
                        if (f.name == "CaseNumber") {
                            // Case's "Name" descriptor is "CaseNumber"
                            perm.case.hasName = true;
                        } else if (f.name == SVMX.OrgNamespace + "__SLA_Terms__c") {
                            perm.case.hasSLA = true;
                        } else if (f.name == "AccountId") {
                            // Case's "Company" descriptor is "AccountId"
                            perm.case.hasCompany = true;
                        }
                    }

                    defer.resolve();
                })).fail(SVMX.proxy(this, function() {
                    // We do not have permission to Case
                    this.__logger.warn("Unable to get ObjectDescribe of Case ");

                    defer.resolve();
                }));

                return defer.promise();
            }))
            .then(SVMX.proxy(this, function(){
                var defer = $.Deferred();

                com.servicemax.client.offline.sal.model.utils.MetaData.describeObject({
                    objectName: "Event"
                }).done(SVMX.proxy(this, function(desc) {

                    for (var i = 0; i < desc.fields.length; i++) {
                        var f = desc.fields[i];
                        if (f.name == SVMX.OrgNamespace + "__Driving_Time__c") {
                            perm.event.hasDriveTime = true;
                        }
                    }

                    defer.resolve();
                })).fail(SVMX.proxy(this, function() {
                    // We do not have permission to WorkOrder
                    this.__logger.warn("Unable to get ObjectDescribe of Event ");

                    defer.resolve();
                }));

                return defer.promise();
            }))
            .then(SVMX.proxy(this, function(){
                var defer = $.Deferred();

                com.servicemax.client.offline.sal.model.utils.MetaData.describeObject({
                    objectName: SVMX.OrgNamespace + "__SVMX_Event__c"
                }).done(SVMX.proxy(this, function(desc) {

                    for (var i = 0; i < desc.fields.length; i++) {
                        var f = desc.fields[i];
                        if (f.name == SVMX.OrgNamespace + "__Driving_Time__c") {
                            perm.svmxevent.hasDriveTime = true;
                        }
                        if (f.name == SVMX.OrgNamespace + "__IsAllDayEvent__c") {
                            perm.svmxevent.hasAllDayEvent = true;
                        }
                    }

                    perm.svmxevent.hasEvent = true;

                    defer.resolve();
                })).fail(SVMX.proxy(this, function() {
                    // We do not have permission or object describe for ServiceMax Event does not exist.
                    this.__logger.warn("Unable to get ObjectDescribe of ServiceMax Event, this is standard behavior and can safely be ignored " +
                        "if you have the Global Setting for ServiceMax Events to behave as Salesforce Events (GLB025) or do not have permission to ServiceMax Events.");

                    defer.resolve();
                }));

                return defer.promise();
            }))
            .then(SVMX.proxy(this, function(){
                //1) fetch the calendar events
                // These queries make me cry.
                var sql = "SELECT DISTINCT R.*, A.Name As AccountName " +
                    "FROM (SELECT E.*, 'Event' AS EventType, " +
                    ((perm.event.hasDriveTime) ? "    E." + SVMX.OrgNamespace + "__Driving_Time__c As DrivingTime, " :  " '' as DrivingTime, ") +
                    // Pull in data from Case or Work Order (THESE OBJECTS ONLY)
                    "S." + "Name as WO_Name, " +
                    "S." + SVMX.OrgNamespace + "__Company__c AS WO_AccountId, " +
                    "S." + SVMX.OrgNamespace + "__SLA_Terms__c AS WO_SLA, " +
                    "S." + SVMX.OrgNamespace + "__Street__c AS WO_Street, " +
                    "S." + SVMX.OrgNamespace + "__City__c AS WO_City, " +
                    "S." + SVMX.OrgNamespace + "__State__c AS WO_State, " +
                    "S." + SVMX.OrgNamespace + "__Country__c AS WO_Country, " +
                    "S." + SVMX.OrgNamespace + "__Zip__c AS WO_Zip, " +
                    "C.error_type as isRecordInConflict FROM Event E " +
                    "LEFT JOIN ClientSyncConflict C ON C.Id = E.WhatID " +
                    // LEFT JOIN the following subquery as 'S' (Simplifies pulling from both Case and Work Order at the same time)
                    "LEFT JOIN (SELECT Id," +
                    // Big block of "x if permission or '' as x"
                    ((perm.wo.hasName) ? "Name," : "'' AS Name,") +
                    ((perm.wo.hasSLA) ? SVMX.OrgNamespace + "__SLA_Terms__c," : "'' AS " + SVMX.OrgNamespace + "__SLA_Terms__c,") +
                    ((perm.wo.hasCompany) ? SVMX.OrgNamespace + "__Company__c," : "'' AS " + SVMX.OrgNamespace + "__Company__c,") +
                    ((perm.wo.hasStreet) ? SVMX.OrgNamespace + "__Street__c," : "'' AS " + SVMX.OrgNamespace + "__Street__c,") +
                    ((perm.wo.hasState) ? SVMX.OrgNamespace + "__State__c," : "'' AS " + SVMX.OrgNamespace + "__State__c,") +
                    ((perm.wo.hasCity) ? SVMX.OrgNamespace + "__City__c," : "'' AS " + SVMX.OrgNamespace + "__City__c,") +
                    ((perm.wo.hasCountry) ? SVMX.OrgNamespace + "__Country__c," : "'' AS " + SVMX.OrgNamespace + "__Country__c,") +
                    ((perm.wo.hasZip) ? SVMX.OrgNamespace + "__Zip__c" : "'' AS " + SVMX.OrgNamespace + "__Zip__c") +
                    " FROM " + SVMX.OrgNamespace + "__Service_Order__c UNION SELECT Id, " +
                    ((perm.case.hasCompany) ? "AccountId," : "'',") +
                    ((perm.case.hasSLA) ? SVMX.OrgNamespace + "__SLA_Terms__c," : "'',") +
                    ((perm.case.hasName) ? " CaseNumber," : "'',") +
                    // empty values for street address because case doesn't have one
                    " '', '', '', '', '' FROM 'Case') " +
                    // join the subquery as 'S'
                    "AS S ON S.Id = E.WhatId " +
                    "WHERE (E.IsRecurrence != 'true' OR E.IsRecurrence IS NULL) ) R " +
                    "LEFT JOIN SFRecordName A ON A.Id = R.WO_AccountId";

                return executeQuery(sql);
            }))
            .then(SVMX.proxy(this, function(eventData) {
              calendarEvents = eventData.data;

              // No ServiceMax Events, probably because of the global setting GLOB001_GBL025
              // The global setting makes it as though ServiceMax events don't exist and breaks everything.
              if (!perm.svmxevent.hasEvent) {
                  // Hacky hack is hacky.
                  return SVMX.Deferred().resolve({}).promise();
              }

              // Run the same query against the ServiceMax Event object
              // I'm sorry for this.
              var sql2 = "SELECT R.*, A.Name As AccountName " +
                  "FROM " +
                  "(SELECT E.*,'" + SVMX.OrgNamespace + "__SVMX_Event__c' AS EventType, " +
                  "    E.Id, E.Name AS Subject, " +
                  "    E." + SVMX.OrgNamespace + "__WhoId__c, " +
                  ((perm.svmxevent.hasAllDayEvent) ? "    E." + SVMX.OrgNamespace + "__IsAllDayEvent__c AS IsAllDayEvent, " : " '' as IsAllDayEvent, ") +
                  "    E." + SVMX.OrgNamespace + "__WhatId__c AS WhatId, " +
                  "    E." + SVMX.OrgNamespace + "__Service_Order__c, " +
                  "    E." + SVMX.OrgNamespace + "__Location__c AS Location, " +
                  "    E." + SVMX.OrgNamespace + "__ActivityDateTime__c AS ActivityDateTime, " +
                  "    E." + SVMX.OrgNamespace + "__ActivityDate__c AS ActivityDate, " +
                  "    E." + SVMX.OrgNamespace + "__DurationInMinutes__c AS DurationInMinutes, " +
                  "    E." + SVMX.OrgNamespace + "__StartDateTime__c AS StartDateTime, " +
                  "    E." + SVMX.OrgNamespace + "__EndDateTime__c AS EndDateTime, " +
                  "    E." + SVMX.OrgNamespace + "__Description__c AS Description, " +
                  ((perm.svmxevent.hasDriveTime) ? "    E." + SVMX.OrgNamespace + "__Driving_Time__c As DrivingTime, " :  " '' as DrivingTime, ") +
                  "    E.OwnerId, E.IsDeleted, E.CreatedDate, E.CreatedById, E.LastModifiedDate, " +
                  "    E.LastModifiedById, E.SystemModStamp, " +
                  // Pull in data from Case or Work Order (THESE OBJECTS ONLY)
                  "S." + "Name as WO_Name, " +
                  // Don't ask me why this one is just "AccountId", the normal event query uses WO_AccountId.
                  "S." + SVMX.OrgNamespace + "__Company__c AS AccountId, " +
                  "S." + SVMX.OrgNamespace + "__SLA_Terms__c AS WO_SLA, " +
                  "S." + SVMX.OrgNamespace + "__Street__c AS WO_Street, " +
                  "S." + SVMX.OrgNamespace + "__City__c AS WO_City, " +
                  "S." + SVMX.OrgNamespace + "__State__c AS WO_State, " +
                  "S." + SVMX.OrgNamespace + "__Country__c AS WO_Country, " +
                  "S." + SVMX.OrgNamespace + "__Zip__c AS WO_Zip, " +
                  "    C.error_type as isRecordInConflict " +
                  "FROM " + SVMX.OrgNamespace + "__SVMX_Event__c E " +
                  "LEFT JOIN ClientSyncConflict C " +
                  "    ON C.Id = E." + SVMX.OrgNamespace + "__WhatId__c " +
                  // LEFT JOIN the following subquery as 'S' (Simplifies pulling from both Case and Work Order at the same time)
                  "LEFT JOIN (SELECT Id," +
                  // Big block of "x if permission or '' as x"
                  ((perm.wo.hasName) ? "Name," : "'' AS Name,") +
                  ((perm.wo.hasSLA) ? SVMX.OrgNamespace + "__SLA_Terms__c," : "'' AS " + SVMX.OrgNamespace + "__SLA_Terms__c,") +
                  ((perm.wo.hasCompany) ? SVMX.OrgNamespace + "__Company__c," : "'' AS " + SVMX.OrgNamespace + "__Company__c,") +
                  ((perm.wo.hasStreet) ? SVMX.OrgNamespace + "__Street__c," : "'' AS " + SVMX.OrgNamespace + "__Street__c,") +
                  ((perm.wo.hasState) ? SVMX.OrgNamespace + "__State__c," : "'' AS " + SVMX.OrgNamespace + "__State__c,") +
                  ((perm.wo.hasCity) ? SVMX.OrgNamespace + "__City__c," : "'' AS " + SVMX.OrgNamespace + "__City__c,") +
                  ((perm.wo.hasCountry) ? SVMX.OrgNamespace + "__Country__c," : "'' AS " + SVMX.OrgNamespace + "__Country__c,") +
                  ((perm.wo.hasZip) ? SVMX.OrgNamespace + "__Zip__c" : "'' AS " + SVMX.OrgNamespace + "__Zip__c") +
                  " FROM " + SVMX.OrgNamespace + "__Service_Order__c UNION SELECT Id, " +
                  ((perm.case.hasCompany) ? "AccountId," : "'',") +
                  ((perm.case.hasSLA) ? SVMX.OrgNamespace + "__SLA_Terms__c," : "'',") +
                  ((perm.case.hasName) ? " CaseNumber," : "'',") +
                  // empty values for street address because case doesn't have one
                  " '', '', '', '', '' FROM 'Case') " +
                  // join the subquery as 'S'
                  "AS S ON S.Id = E." + SVMX.OrgNamespace + "__WhatId__c " +
                  ") R " +
                  "LEFT JOIN SFRecordName A ON A.Id = R.AccountId";

              return executeQuery(sql2);
            }))
            .then(SVMX.proxy(this, function(eventData2) {
                  var defer = SVMX.Deferred();
                  if (eventData2.data !== undefined) {
                      for (var i = 0; i < eventData2.data.length; i++) {
                          calendarEvents.push(eventData2.data[i]);
                      }
                  }
                  defer.resolve(calendarEvents);

                  return defer.promise();
              }))
            .then(SVMX.proxy(this, function(eventData){
                //2) process calendar event data getting valid ids
                var defer = $.Deferred();

                for(var i in eventData){
                    if(eventData[i].WhatId && eventData[i].WhatId.length > 0){
                        ids.push(eventData[i].WhatId);
                    }
                }

                return this.__getRelatedRecordPriority(ids);
            }))
            .then(SVMX.proxy(this, function(allPrios){
                var defer = SVMX.Deferred();
                //3) set up the appropriate event priority color
                for(var i=0; i<calendarEvents.length; i++){
                    var wid = calendarEvents[i].WhatId;
                    var prio = null;

                    //set color to default case
                    calendarEvents[i].Color = settings.colors.Other;

                    //set the priority to low
                    calendarEvents[i].Priority = "Other";

                    for (var k=0; k<allPrios.data.length; k++){
                        if (allPrios.data[k].Id == wid){
                            prio = allPrios.data[k]["priority"];
                            calendarEvents[i].Priority = prio;

                            var color = settings.colors[prio];
                            if (color) {
                                //change colors if there is a priority match
                                calendarEvents[i].Color = color;
                            }
                            break;
                        }
                    }
                }
                // end event priority

                // format event dates
                calendarEvents = this.__processDateFields(calendarEvents, {
                    ActivityDateTime: true,
                    StartDateTime: true,
                    EndDateTime: true,
                    CreatedDate: true,
                    LastModifiedDate: true,
                    SystemModstamp: true
                });

                return this.__getDisplayNames(calendarEvents, ids);
            }));
        },

        __getDisplayNames : function(eventData, ids) {

            var tableNamesHash = {};
            var counter = 0;
            SVMX.array.forEach(eventData, function(event) {
                if (event.WhatId) {
                    try {
                        var name = OfflineMetaUtils.getTableForId(event.WhatId);
                        if (name && !tableNamesHash[name]) {
                            tableNamesHash[name] = [];
                            counter++;
                        }
                        if (name) {
                            tableNamesHash[name].push(event.WhatId);
                        }
                    } catch(e) {
                        this.__logger.error("Failed call to getTableForId from __getDisplayNames");
                    }
                }
            }, this);
            this.__logger.info("COUNT: " + counter);
            var defs = [];
            SVMX.forEachProperty(tableNamesHash, SVMX.proxy(this, function(inKey, inValue) {
                 var query = "SELECT Id, {{nameField}} as name_field FROM '{{tableName}}' WHERE Id IN ('{{Id}}')";
                 var binds = {
                   nameField: OfflineMetaUtils.getNameField(inKey),
                   tableName: inKey,
                   Id: inValue.join("','")
                 };
                 defs.push(executeQuery(query, binds));
            }));

            return SVMX.when(defs).then(SVMX.proxy(this, function() {
                var def = SVMX.Deferred();
                for (var i = 0; i < arguments.length; i++) {
                  var nameValues = arguments[i].data;
                  for (var k = 0; k < nameValues.length; k++) {
                      SVMX.array.forEach(eventData, function(item) {
                          if (item.WhatId == nameValues[k].Id && nameValues[k].name_field != item.Subject) {
                              item.RelatedName = nameValues[k].name_field;
                          }
                      });
                  }
                }
                def.resolve(eventData);
                return def.promise();
            }));
        },

        __getFieldsFromSubjectSetting : function(eventSubjectSetting){
          var fields = [],  matches = [];
          if(eventSubjectSetting != null){
              matches = eventSubjectSetting.match(/\{\w+\}/g);
              if(matches != null && matches.length > 0){
                  for (var i = 0; i < matches.length; i++){
                      fields.push(matches[i].replace(/\{*\}*/g,""));
                  }
              }
          }
          return fields;
        },

        __describeObject : function(objectName, objectFields){
            var me = this;
            var defer = SVMX.Deferred();
            var objectFields = objectFields;
            com.servicemax.client.offline.sal.model.utils.MetaData.describeObject({
                objectName: objectName
            }).done(SVMX.proxy(this, function(desc) {
                var objectFieldAndFieldType = {}
                var fields = desc.fields;
                for(var i = 0; i < objectFields.length; i++){
                    for(var j = 0; j < fields.length; j++){
                        if(objectFields[i] == fields[j].name){
                          if(objectName == SVMX.OrgNamespace+"__SVMX_Event__c" &&  objectFields[i] == SVMX.OrgNamespace+"__WhatId__c"){
                              objectFieldAndFieldType[objectFields[i]] =  "reference";
                              me.__refereceFields.push(objectFields[i]);
                          }
                          else {
                            objectFieldAndFieldType[objectFields[i]] =  fields[j].type;
                            if(fields[j].type == "reference"){
                                me.__refereceFields.push(objectFields[i]);
                            }
                            break;
                          }
                        }
                    }
                }
                defer.resolve(objectFieldAndFieldType);
            })).fail(SVMX.proxy(this, function() {
              this.__logger.warn("Unable to get ObjectDescribe of "+objectName);
              defer.resolve();
            }));
            return defer.promise();
        },

        __getCalendarSettings : function(){
            var query = "SELECT setting_id as key, value FROM MobileDeviceSettings " +
                    "where setting_id in ('IPAD006_SET001', 'IPAD006_SET002', 'IPAD006_SET003', 'IPAD006_SET004'," +
                    "'Synchronization To Get Events', 'Synchronization To Remove Events', 'IPAD006_SET005', 'IPAD006_SET006')";

            return executeQuery(query).then(SVMX.proxy(this, this.__parseCalenderSettings));
        },

        __parseCalenderSettings: function(settingData){
            var def = SVMX.Deferred();
            // map setting values to object
            var settings = {
                colors : {},
                daysToGet : null,
                daysToDelete : null,
                sfEventSubjectSetting : null,
                svmxEventSubjetSetting : null
            };
            for(var i in settingData.data){
                var key = settingData.data[i].key;
                var value = settingData.data[i].value;
                switch(key){
                    case "IPAD006_SET001":
                        settings.colors.High = value;
                        break;
                    case "IPAD006_SET002":
                        settings.colors.Medium = value;
                        break;
                    case "IPAD006_SET003":
                        settings.colors.Low = value;
                        break;
                    case "IPAD006_SET004":
                        settings.colors.Other = value;
                        break;
                    case "Synchronization To Get Events":
                        settings.daysToGet = value;
                        break;
                    case "Synchronization To Remove Events":
                        settings.daysToDelete = value;
                        break;
                    case "IPAD006_SET005":
                        settings.sfEventSubjectSetting = value;
                        break;
                    case "IPAD006_SET006":
                        settings.svmxEventSubjetSetting = value;
                        break;
                }
            }
            def.resolve(settings);
            return def.promise();
        },

        /*
        * TODO: need to revisit to account for objects that has priorities
        * for now it check the following tables: Case, SVMXC__Service_Order__c
        */
        __getRelatedRecordPriority : function(ids){
            var sqlWorkOrder = "SELECT Id, {{ns}}__Priority__c as priority FROM {{ns}}__Service_Order__c WHERE Id IN ('{{ids}}')";
            var query = sqlWorkOrder;
            //check the case
            if (OfflineMetaUtils.isTableInDatabase("Case")) {
                var sqlCase = "SELECT Id, priority FROM 'case' WHERE Id IN ('{{ids}}')";
                query += " UNION " + sqlCase;
            }

            var binds = {
                ids : ids.join("','"),
                ns: SVMX.OrgNamespace
            };

            return executeQuery(query, binds);
        }
    }, {});

    /**
     * A way to get the Event Object names that have an edit process. Not as thorough
     * as checking per individual event but much quicker
     */
    sfmeventOperations.Class("GetEditableObjectNames", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var that = this;

            var query = "SELECT DISTINCT pc.object_name AS name " +
                "FROM SFProcess AS p " +
                "JOIN SFProcessComponent AS pc ON p.process_id = pc.process_id " +
                "WHERE " +
                "pc.component_type = 'TARGET' " +
                "AND p.process_type = 'STANDALONE EDIT' " +
                "AND pc.object_name IN ('Event', '"+SVMX.OrgNamespace+"__SVMX_Event__c')";

            var d = executeQuery(query);

            d.always(SVMX.proxy(this, function(data) {
                data = data || {};
                data.data = data.data || [];
                var eventObjectNames = [];
                for (var i = 0; i < data.data.length; i++) {
                    eventObjectNames.push(data.data[i].name);
                }

                responder.result(eventObjectNames);
            }));
        }

    }, {});


    sfmeventOperations.Class("GetFirstEventProcess", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        __executeQuery : function(query){
            var d = SVMX.Deferred();

            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var request = nativeService.createSQLRequest();

            request.bind("REQUEST_COMPLETED", function(evt){
                d.resolve(evt.data);
            }, this);

            request.bind("REQUEST_ERROR", function(evt){
                d.resolve(null);
            }, this);

            request.execute({
                query : query,
                async : true
            });

            return d;
        },

        performAsync: function(request, responder) {
            var that = this;

            var d = this.getEventObjects();
            d = d.then(SVMX.proxy(this, function(data) {
                return this.getFirstEventProcess(data);
            }));

            d.always(SVMX.proxy(this, function(data) {
                responder.result(data);
            }));
        },

        /**
         * Find the event we should create
         */
        getEventObjects: function() {
            var ret = SVMX.Deferred();
            var that = this;
            var query = "SELECT value FROM MobileDeviceSettings WHERE setting_id = 'GLOB001_GBL025'";

            var d = this.__executeQuery(query);

            d.always(SVMX.proxy(this, function(data) {
                var settingValue = data.data && data.data[0] && data.data[0].value;
                var filterObjectNames = [];
                switch (settingValue) {
                    case 'ServiceMax Event':
                        filterObjectNames = [SVMX.OrgNamespace+'__SVMX_Event__c'];
                        break;
                    case 'Event':
                        filterObjectNames = ['Event'];
                        break;
                    default:
                        // Nothing set so we will look for both
                        filterObjectNames = ['Event', SVMX.OrgNamespace+'__SVMX_Event__c'];
                }

                ret.resolve(filterObjectNames);
            }));

            return ret.promise();
        },

        getFirstEventProcess: function(eventObjectNames) {
            var that = this;
            var ret = SVMX.Deferred();

            // Get first process id with prefrence to Event if looking for both.
            var query = "SELECT p.process_unique_id, pc.object_name " +
                "FROM SFProcess AS p " +
                "JOIN SFProcessComponent AS pc ON p.process_id = pc.process_id " +
                "WHERE " +
                "pc.component_type = 'TARGET' " +
                "AND p.process_type = 'STANDALONE CREATE' " +
                "AND pc.object_name IN ('" +eventObjectNames.join("','") + "') " +
                " ORDER BY pc.object_name LIMIT 1";

                var d = this.__executeQuery(query);
                d.always(SVMX.proxy(this, function(data) {
                    ret.resolve(data);
                }));

            return ret.promise();
        }

    }, {});

    sfmeventOperations.Class("GetPriorityColors", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        __executeQuery : function(query){
            var d = SVMX.Deferred();

            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var request = nativeService.createSQLRequest();

            request.bind("REQUEST_COMPLETED", function(evt){
                d.resolve(evt.data);
            }, this);

            request.bind("REQUEST_ERROR", function(evt){
                d.resolve(null);
            }, this);

            request.execute({
                query : query,
                async : true
            });

            return d;
        },

        performAsync: function(request, responder) {
            var that = this;

            var d = this.getPrioritySettings();
            d.always(SVMX.proxy(this, function(priorityMap) {
                responder.result(priorityMap);
            }));
        },

        /**
         * Find the event we should create
         */
        getPrioritySettings: function() {
            var ret = SVMX.Deferred();
            var that = this;
            var priorityMap = {
                High: '#F75D59',
                Medium: '#ADDFF',
                Low: '#C9BE62',
                Other: '#4E8975'
            };
            var query = "SELECT setting_id, value FROM MobileDeviceSettings WHERE setting_id IN ('IPAD006_SET001', 'IPAD006_SET002', 'IPAD006_SET003', 'IPAD006_SET004')";

            var d = this.__executeQuery(query);

            d.always(SVMX.proxy(this, function(data) {
                data = data.data || [];
                var i = 0;
                for (i = 0; i < data.length; i++) {
                    switch (data[i].setting_id) {
                        case 'IPAD006_SET001':
                            priorityMap.High = data[i].value;
                            break;
                        case 'IPAD006_SET002':
                            priorityMap.Medium = data[i].value;
                            break;
                        case 'IPAD006_SET003':
                            priorityMap.Low = data[i].value;
                            break;
                        case 'IPAD006_SET004':
                            priorityMap.Other = data[i].value;
                            break;
                    }
                }

                ret.resolve(priorityMap);
            }));

            return ret.promise();
        },



    }, {});


    /**
    * Retrieve mobile device settings
    */
    sfmeventOperations.Class("RetrieveMobileSettings", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync : function(request, responder) {
            var d = this.getMobileSettings(request.settingIds);
            d.always(SVMX.proxy(this, function(settingValue) {
                responder.result(settingValue);
            }));
        },

        getMobileSettings: function(settings) {
            var ret = SVMX.Deferred();
            var settingIds = [];
            settings.map(function (item) {
                settingIds.push( "'" + item + "'");
            });

            var query = "SELECT * FROM MobileDeviceSettings WHERE setting_id IN ({{settingIds}})",
            bind = {settingIds: settingIds};
            var d = executeQuery(query, bind);
            d.always(SVMX.proxy(this, function(data) {
                ret.resolve(data && data.data ? data.data : []);
            }));
            return ret.promise();
        }

    }, {});


    /**
    * This is class to save new event record. This is SFDC Event or SVMX Event created from custom view without using SFM.
    */
    sfmeventOperations.Class("SaveNewEvent", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.eventRecord = {};
            this.__base();
        },

        performAsync : function(request, responder) {
            if(request.type == "create") {
                var data = {};
                var userId = SVMX.getCurrentApplication().getUserInfo().UserId;
                var techId = SVMX.getCurrentApplication().getUserInfo().UserTechId;
                if(request.objectName === "Event") {
                    data.Subject = request.subject;
                    data.Description = request.description;
                    data.StartDateTime = request.startDateTime;
                    data.EndDateTime = request.endDateTime;
                    data.WhatId = request.whatId;
                    //Commented below line because its causing issue. Since WhoId is lookup to Contact or Lead object.
                    //data.WhoId = userId;
                } else if(request.objectName === SVMX.OrgNamespace + "__SVMX_Event__c") {
                    data.Name = request.subject;
                    data[SVMX.OrgNamespace + "__Description__c"] = request.description;
                    data[SVMX.OrgNamespace + "__EndDateTime__c"] = request.endDateTime;
                    data[SVMX.OrgNamespace + "__StartDateTime__c"] = request.startDateTime;
                    data[SVMX.OrgNamespace + "__WhatId__c"] = request.whatId;
                    //data[SVMX.OrgNamespace + "__WhoId__c"] = userId;
                    data[SVMX.OrgNamespace + "__Technician__c"] = techId;
                    data["OwnerId"] = userId;
                }

                OfflineDataUtils.writeRecord({
                    data: data,
                    type: request.objectName,
                    onSuccess: SVMX.proxy(this, this.__sync, responder),
                    onError: SVMX.proxy(this, this.__failedUpdate, responder)
                });
            }
        },

        __sync : function(responder, isInsert, syncRecordData) {
            
            // Pass this information so that it can be added in the recent items.
            this.eventRecord = {};
            this.eventRecord.recordId = syncRecordData.Id;
            this.eventRecord.objectName = syncRecordData.objectName;
            
            SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveStarted();
            if (isInsert) {
                OfflineDataUtils.writeSyncRecords([syncRecordData], null, null, SVMX.proxy(this, this.__finish, responder));
            } else {
                OfflineDataUtils.writeSyncRecords(null, [syncRecordData], null, SVMX.proxy(this, this.__finish, responder));
            }
        },

        __finish : function(responder) {
            // Start Aggressive sync if applicable
            SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveCompleted();
            responder && responder.result(this.eventRecord);
        },

        __failedUpdate : function(responder) {
            responder && responder.result();
            this.__logger.error("Cannot insert event record.");
        }

    }, {});


    /**
     * SFM Event platform specifics
     * Extends SFM Search platform specifics because they do the same thing
     */
    sfmeventOperations.Class("PlatformSpecifics",
        com.servicemax.client.offline.sal.model.sfmsearch.utils.impl.PlatformSpecifics, {


        // TODO :: combine...clean.....common private regarding obj....
        showRecord : function(info){
            var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("IPAD");
            var recId = info.key, me = this;
            var objectName = info.objectName;

            var getViewProcesses = function(recId, objectName) {
                OfflineMetaUtils.getQualifiedProcessesForRecord({
                    objectName: objectName,
                    recordId: recId,
                    processType: "VIEW RECORD",
                    considerDefaultView: true
                })
                .then(SVMX.proxy(this, function(viewProcesses, record) {
                   if (viewProcesses.length) {
                      var request = {SVMX_processId : viewProcesses[0].process_unique_id, SVMX_recordId : recId, SVMX_record: record};
                      SVMX.getCurrentApplication().launchConsoleApp("sfmdelivery", request);
                   } else {
                       var message = TS.T("TODO", "View not configured for this record. Please contact your system administrator.");

                        SVMX.getCurrentApplication()
                        .getApplicationMessageUIHandler()
                        .showMessage({
                            type: "INFO",
                            text: message
                        });
                        me.triggerNoViewProcessEvent();
    			   }
                }));
            };

            if(!objectName){
                objectName = this.__getObjectName(recId);
            }
            getViewProcesses(recId, objectName);
        },

        triggerNoViewProcessEvent : function(){
            var clientType = SVMX.getClient().getApplicationParameter("client-type");

            if(clientType && clientType.toLowerCase() === 'laptop'){
                var currentApp = SVMX.getCurrentApplication();
                var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                     "SFMDELIVERY.VIEW_LOADED", this, null);
                currentApp.triggerEvent(evt);
            }
        },

        editRecord : function(info){
            info = info || {};
            var recId = info.key, me = this;
            var objectName = info.objectName;
            var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("IPAD");

            var getEditProcess = function(recId, objectName) {
                OfflineMetaUtils.getQualifiedProcessesForRecord({
                    objectName: objectName,
                    recordId: recId,
                    processType: "STANDALONE EDIT"
                })
                .then(SVMX.proxy(this, function(editProcesses, record) {
                    if (editProcesses.length) {
                        var result,i;
                        for(i=0; i< editProcesses.length; i++)
                        {
                            if(editProcesses[i].process_unique_id == "EVT_004" || editProcesses[i].process_unique_id == "SVMXEVT_004")
                            {
                                result = editProcesses[i].process_unique_id;
                                break;
                            }
                            else
                            {
                                result = editProcesses[0].process_unique_id;
                            }
                        }
                        if(info.callback) {
                            info.callback.call(info.context || this, result, recId, record);
                        }
                    }
                    else {
                       var message = TS.T("SFMDELIVERY.TAG0020", "An edit process is not associated with this record.");

                        SVMX.getCurrentApplication()
                        .getApplicationMessageUIHandler()
                        .showMessage({
                            type: "INFO",
                            text: message
                        });
                    }
                }));
            };


            if(!objectName){
                objectName = this.__getObjectName(recId);
            }
            getEditProcess(recId, objectName);
        },

        __getObjectName : function(rid) {
            return OfflineMetaUtils.getTableForId(rid);
        }

    }, {});

};
})();

// end of file
