
(function() {
    var impl = SVMX.Package("com.servicemax.client.offline.sal.model.sync.operations");
    impl.init = function() {

        var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;
        var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
        var utils = com.servicemax.client.offline.sal.model.sfwdeliveryutils.Utils;
        var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.sync");

        /**
         *  this class provides methods to fetch the wizard contents
         *
         *  @class      com.servicemax.client.offline.sal.model.sfwdelivery.operations.GetWizardInfo
         *  @extends    com.servicemax.client.mvc.api.Operation
         */
        impl.Class("GetSyncStatus", com.servicemax.client.mvc.api.Operation, {
            __constructor: function() {
                this.__base();
            },

            /**
             *
             * @param    {Object}    request         data request object
             * @param    {Object}    responder       responder object
             */
            performAsync: function(request, responder) {

                var syncType = request.syncType;
                var statusTime = null;
                var statusToUpdate = null;
                var onCallStatus = null;
                var timeKey = null;
                var statusKey = null;

                var d = SVMX.when([
                    this.__runNativeSQLRequest({
                        query: "SELECT value FROM ClientCache where key IN(" + "'LAST_SYNC_TIME." + syncType + "'" + ") AND value is NOT NULL LIMIT 1;"
                    }),
                    this.__runNativeSQLRequest({
                        query: "SELECT value FROM ClientCache where key IN(" + "'SYNC_STATUS." + syncType + "'" + ") AND value is NOT NULL LIMIT 1;"
                    })
                ]);
                d.then(SVMX.proxy(this, function(timeResult, statusResult) {

                    if (timeResult === null ) {
                        statusTime = "-";
                    } else if (statusResult === null) {
                        statusToUpdate = "-";
                    } else {
                        statusTime = this.__getQueryColumnValueAsDate(timeResult);
                        statusToUpdate = this.__getQueryColumnValueAsString(statusResult);
                    }
                    var ret = {
                        statusTime: statusTime,
                        statusToUpdate: statusToUpdate
                    };
                    return ret;

                }))
                .done(SVMX.proxy(this, function(params) {
                    responder.result(params);
                }));

            },


            __runNativeSQLRequest: function(options) {
                var d = SVMX.Deferred();

                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var request = nativeService.createSQLRequest();
                var query = options.query;

                request.bind("REQUEST_COMPLETED", function(evt) {
                    d.resolve(SVMX.toObject(evt.data.data));
                }, this);

                request.bind("REQUEST_ERROR", function(evt) {
                    d.reject({});
                }, this);

                request.execute({
                    query: query,
                    async: true
                });

                return d.promise();
            },
            __getQueryColumnValueAsDate: function(resp) {
                var returnValue = " ";
                if (resp && resp[0]) {
                    var value = resp[0].value;
                    returnValue = com.servicemax.client.lib.datetimeutils.DatetimeUtil.parseGMTDate(value);
                }
                return returnValue;
            },
            __getQueryColumnValueAsString: function(resp) {
                var returnValue = " ";
                if (resp && resp[0]) {
                    returnValue = resp[0].value;
                }
                return returnValue;
            }


        }, {});
    };
})();
