/**
 * Operations for search
 * @author Indresh M S
 * @class com.servicemax.client.offline.sal.model.sfmsearchdelivery.operations
 * @since: The minimum version where this file is supported
 *
 * @copyright: 2013 ServiceMax, Inc
 */

/*

  Things to clarify with the iPad folks;
  01. The SFM_Search_Process does not contain the search process Id. Instead SFM_Search_Objects contain a reference
      to the process Id.
  02. The SFM_Search_Objects does not contain the corresonding SFDC Object API name. It only contains the readable name.
      Using this, one cannot identify the actual SFDC object.

  03. 'Result' field sequence is not available in SFM_Search_Field
*/
(function(){

	var operationsImpl = SVMX.Package("com.servicemax.client.offline.sal.model.sfmsearchdelivery.operations");

operationsImpl.init = function(){

	var OfflineMetaUtils = com.servicemax.client.offline.sal.model.utils.MetaData;
	var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
    var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;

    var DatetimeUtils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
    var logger = SVMX.getLoggingService().getLogger("svmxc-search-service");
	operationsImpl.Class("GetSearchInfo", com.servicemax.client.mvc.api.Operation, {

		__constructor : function(){ this.__base(); },

		performAsync : function(request, responder) {
			var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmsearch.utils.impl.Utils");
			// clear cache; this call should only be made when we are refreshing/regenerating the search models; perhaps after
			// a sync.
			utils.getSearchDefinition({clearCache: true}, function(resp){
				// extract only result fields
				var allSearchInfo = resp.lstSearchInfo || [], i, l = allSearchInfo.length, si;
				var allSearchDetails, j, c, sd;
				var allFields, k, s, fld, resultFields;

				for(i = 0; i < l; i++){
					si = allSearchInfo[i];
					allSearchDetails = si.searchDetails || []; c = allSearchDetails.length;
					for(j = 0; j < c; j++){
						sd = allSearchDetails[j];
						allFields = sd.fields || []; s = allFields.length; resultFields = [];
						for(k = 0; k < s; k++){
							fld = allFields[k];
							if(fld[SVMX.OrgNamespace + "__Search_Object_Field_Type__c"] == "Result"){
								resultFields.push(fld);
							}
						}
						sd.fields = resultFields;
					}
				}
				// end result fields

				responder.result(resp);
			}, this);
		}
	}, {});

	operationsImpl.Class("GetSearchResults", com.servicemax.client.mvc.api.Operation, {

		__constructor : function(){ this.__base(); },

		performAsync : function(request, responder) {

			var me = this,
			    objectName, searchDef;
            var userInfo = OfflineSystemUtils.getUserInfo();
			var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmsearch.utils.impl.Utils");

		     var onDescribeObject = function(describeData) {
        		   var recordTypeInfo = describeData.recordTypeInfos;
		           var recordTypeHash = {};
		           SVMX.array.forEach(recordTypeInfo, function(item) {recordTypeHash[item.name] = item.recordTypeId;});



					var fields = searchDef.fields || [], i, l = fields.length, fld, tableExists,
						ftype, fname, lookupName, sc, objectName1, objectName2, displayType, searchBaseObjectName, fldReferenceObjectName, operator, operand,
						searchColumns = [], searchJoins = [], orderColumns = [], expressions = [];
                    var advancedExpression = searchDef.objectDetails[SVMX.OrgNamespace + "__Parent_Object_Criteria__c"],
                        exprs = [],
                        exprIndex = 1,
                        fieldsHash = {};
                    var objectNameList = [objectName];
                    for(i = 0; i < l; i++){
						fld = fields[i];
						objectName1 = fld[SVMX.OrgNamespace + "__Object_Name__c"];
						objectName2 = fld[SVMX.OrgNamespace + "__Object_Name2__c"];
                        if (objectName1) {
                            objectNameList.push(objectName1);
                            fieldsHash[objectName1] = {};
                        }
                        if (objectName2) {
                            objectNameList.push(objectName2);
                            fieldsHash[objectName2] = {};
                        }
                    }


				   var query = SVMX.string.substitute("SELECT api_name, object_api_name from SFObjectField WHERE object_api_name IN ('{{object_names}}')",
				                      {object_names: objectNameList.join("','")});
				   utils.executeQuery(query, SVMX.proxy(this, function(fieldList) {
            		   SVMX.array.forEach(fieldList, function(item) {
            		       fieldsHash[item.object_api_name][item.api_name] = item;
            		   });
		               var objectName = searchDef.objectDetails.objectApiName;

						// search columns with key word
						// implicit filter criteria
						// sort columns

						// set up where clause
						var wc = "", kw = request.KeyWord || "";
						if(request.Operator === "Exact Match"){
							wc = "=";
						}else{
							wc = "like";
							if(request.Operator === "Contains"){
								kw = "%" + kw + "%";
							}else if(request.Operator === "Starts With"){
								kw = kw + "%";
							}else{
								kw = "%" + kw;
							}
						}
						// end where clause

                       searchJoins.push("LEFT JOIN `ClientSyncConflict` ON ClientSyncConflict.Id = MAIN.Id");

						// search & result columns
						var resultColumns = ["MAIN.Id", "ClientSyncConflict.error_type as isRecordInConflict"];
						for(i = 0; i < l; i++){
							fld = fields[i];
							ftype = fld[SVMX.OrgNamespace + "__Search_Object_Field_Type__c"];
							fname = fld[SVMX.OrgNamespace + "__Field_Name__c"];
							lookupName = fld[SVMX.OrgNamespace + "__Lookup_Field_API_Name__c"].replace(/__r$/,"__c");
							objectName1 = fld[SVMX.OrgNamespace + "__Object_Name__c"];
							objectName2 = fld[SVMX.OrgNamespace + "__Object_Name2__c"];
							displayType = fld[SVMX.OrgNamespace + "__Display_Type__c"];
							operator = fld[SVMX.OrgNamespace + "__Operator__c"];
							operand = fld[SVMX.OrgNamespace + "__Operand__c"];
							sc = null;


							try {
    							if (operator) {
    							    this.__addExpressionToSearchQuery(fld, i, searchJoins, searchColumns, resultColumns, exprs, exprIndex, userInfo, recordTypeHash, fieldsHash);
    							    exprIndex++;
    							} else {

        							// If its just a plain field of our base object
        							// 1. SVMX__Field_Name__c (fname) names the field of the base object to query
        							if (displayType !== "REFERENCE" && !lookupName) {
        							    this.__addPlainFieldToSearchQuery(wc, kw, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash);
        							}

        							// If its a reference field that uses the name field
        							// 1. SVMXC__Object_Name__c names the foreign table to query
        							// 2. SVMXC__Field_Name__c names the field of the base object that contains the reference we are looking up
        							// 3. SVMXC__Lookup_Field_API_Name__c: Ignored, use name field instead to retrieve value from foreign table
        							else if (displayType === "REFERENCE" && !lookupName) {
        							    this.__addReferenceFieldToSearchQuery(wc, kw, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash);

        							}

        							// If its a refence to a foreign table that points to a non-reference
        							// field of that table
        							// 1. SVMXC__Object_Name__c: Ignored
        							// 2. SVMXC__Object_Name2__c: Foreign table to retrieve data from
        							// 3. SVMXC__Lookup_Field_API_Name__c: Field name that contains the reference in our main table
        							// 4. SVMXC__Field_Name__c: Name of the field in the foreign table to retrieve
        							else if (displayType !== "REFERENCE" && lookupName) {
        								this.__addReferenceFieldWithCustomDisplayToSearchQuery(wc, kw, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash);
        							}

        							// Its a reference to a foreign table that points to a field in that foreign table
        							// contains a reference pointing to yet another table (blech!)
        							// 1. SVMXC__Lookup_Field_API_Name__c: Field name that contains the reference in our main table
        							// 2. SVMXC__Object_Name2__c: Name of the table that Lookup_Field_API_Name looks up its data from
        							// 3. SVMXC__Field_Name__c: Name of the field in Object_Name2 table that we are getting our second reference from
        							// 4. SVMXC__Object_Name__c: Name of the table to get our final value from
        							else if (displayType === "REFERENCE" && lookupName) {
        							    this.__addReferenceToReferenceToSearchQuery(wc, kw, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash);
        							}
        							if (ftype == "OrderBy") {
        								orderColumns.push("fld" + i + " " + (fld[SVMX.OrgNamespace + "__Sort_Order__c"] === "Ascending" ? "ASC" : "DESC"));
        							}
        						}
        					} catch(e) {
        					    logger.error("Major Error: " + e);
        					    var ret = {MapStringMap : [], stringMap : [], totalCount: 0};
                                responder.result(ret);
        					}
						}

						resultColumns = resultColumns.join(",\n");
						searchColumns = searchColumns.join(" OR \n") || "1\n";
						searchJoins   = searchJoins.join("\n");
						orderColumns  = orderColumns.length? "\nORDER BY " + orderColumns.join(",") : "";
                        if (exprs.length) {
                            if (!advancedExpression) {
                                // filter out empty items and then join the results with AND
                                searchColumns = "(" + searchColumns + ") AND (" + SVMX.array.filter(exprs, function(item) {return item;}).join(" AND ") + ")";
                            } else {
                                searchColumns = "(" + searchColumns + ") AND (" + advancedExpression.replace(/\d+/g, function(inStr) {
                                    return exprs[inStr];
                                }) + ")";
                            }
                        }

						var q = SVMX.string.substitute(
							"SELECT DISTINCT {{columns}} \nFROM `{{objectName}}` AS MAIN \n{{joins}} \nWHERE {{search}} {{orderBy}} LIMIT {{limit}}",
							{
								columns : resultColumns,
								joins : searchJoins,
								objectName : objectName,
							 	search : searchColumns,
							 	limit : request.RecordLimit,
							 	orderBy : orderColumns
							}
						);

                        var countQuery = SVMX.string.substitute(
                            "SELECT count(*) as count  FROM (SELECT DISTINCT {{columns}} FROM `{{objectName}}` AS MAIN \n{{joins}} \nWHERE {{search}})",
                            {
                                columns : resultColumns,
                                joins : searchJoins,
                                objectName : objectName,
                                search : searchColumns
                            }
                        );
						// end query
                        var totalCount = 0;
                        logger.debug("SEARCH QUERY: " + searchDef.objectLable + ", " +  q);
                        utils.executeQuery(countQuery, function(resp){

                              logger.debug("Processing Count " + searchDef.objectLable);

                              totalCount = resp && resp[0] && resp[0].count  ? parseInt(resp[0].count) : 0;

                              utils.executeQuery(q, function(resp){

                                  logger.debug("Processing " + searchDef.objectLable);
                                  this.__handleResponse(request, responder, resp,
                                        utils, searchDef, expressions, recordTypeHash, totalCount);
                                // TODO: Record records from SFDC when online
                            }, this);
                        }, this);
					}));
                };


            var onGetSearchDefinitionFor = function(inSearchDef){
				searchDef = inSearchDef;
				objectName = searchDef.objectDetails.objectApiName;

                OfflineMetaUtils.describeObject({
                      sync: true,
                      objectName: objectName,
                      onSuccess : SVMX.proxy(this, onDescribeObject)
                });
			};

            utils.getSearchDefinitionFor(request, SVMX.proxy(this, onGetSearchDefinitionFor));
		},

		__addExpressionToSearchQuery : function(fld, i, searchJoins, searchColumns, resultColumns, exprs, exprIndex, inUserInfo, recordTypeHash, fieldsHash) {
		    var fname = fld[SVMX.OrgNamespace + "__Field_Name__c"],
		        fQueryName = "fld" + i,
		        ftype = String(fld[SVMX.OrgNamespace + "__Display_Type__c"]).toLowerCase(),
		        operator = fld[SVMX.OrgNamespace + "__Operator__c"].toLowerCase(),
				operand = fld[SVMX.OrgNamespace + "__Operand__c"],
				 objectName1 = fld[SVMX.OrgNamespace + "__Object_Name__c"],
		    	 objectName2 = fld[SVMX.OrgNamespace + "__Object_Name2__c"];

			// should always use objectName2 (assumption)
			if (!fieldsHash[objectName2][fname]) {
               throw(fname + " does not exist; this search can not be performed without fixing either permission, search configurations, or other types of errors");
        	}

		    if (fname === "RecordTypeId") {
                if (recordTypeHash[operand]) operand = recordTypeHash[operand];
                resultColumns.push("MAIN." + fname + " as fld" + i);
            } else if (ftype == "reference") {
			    this.__addReferenceFieldToSearchQuery(null, null, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash);
            } else if (ftype == "double" || ftype == "int" || ftype == "currency" || ftype == "percent") {
                resultColumns.push("ifnull(nullif(MAIN." + fname + ", ''), 0) as fld" + i);
		    } else {
		        resultColumns.push("MAIN." + fname + " as fld" + i);
		    }



		    /* TODO: Everything in this block is untested */
		    switch(operand.toLowerCase()) {
		        case "svmx.currentuser":
		          operand = inUserInfo.UserId;
		          break;
                case "svmx.currentuserid":
                  operand = inUserInfo.UserId;
                  break;
                case "svmx.usertrunk":
                  operand = (inUserInfo.UserTrunk) ? inUserInfo.UserTrunk: '';
                  break;
		        case "yesterday":
		        case "svmx.yesterday":
					operand = this.getDateTimeAsFormat(ftype,"Yesterday");                   	          
				break;
		        case "today":
		        case "svmx.today":
					operand = this.getDateTimeAsFormat(ftype,"Today");
    				break;
		        case "tomorrow":
		        case "svmx.tomorrow":
					operand = this.getDateTimeAsFormat(ftype,"Tomorrow");
                break;
		        case "now":
		        case "svmx.now":
					operand = this.getDateTimeAsFormat(ftype,"Now");
                 break;
		    }

            if (SVMX.array.get(["eq","ne","gt","ge","lt","le"], operator) &&
                !SVMX.array.get(["double", "int", "percent", "currency"], ftype)) {
                operand = "'" + operand + "'";
            }

            var expression;
            switch (operator) {
                case "eq" :
                    expression = fQueryName + " = " + operand;
                    break;
                case "ne" :
                    if (operand) {
                        expression = "(" + fQueryName + " != " + operand + " OR " + fQueryName + " IS NULL)";
                    } else {
                        expression = fQueryName + " != " + operand;
                    }
                    break;

                case "lt" :
                    expression = fQueryName + " < " + operand;
                    break;

                case "le" :
                    expression = fQueryName + " <= " + operand;
                    break;

                case "gt" :
                    expression = fQueryName + " > " + operand;
                    break;

                case "ge" :
                    expression = fQueryName + " >= " + operand;
                    break;
		        case "isnull" :
		            expression = "(" + fQueryName + " is null OR " + fQueryName + " = '')";
		            break;

		        case "isnotnull" :
		            expression = "(" + fQueryName + " is not null AND " + fQueryName + " != '')";
		            break;

		        case "contains":
		            expression = fQueryName + "  like '%" + operand + "%'";
		            break;

		        case "notcontain":
		            if (operand) {
		                expression = "(" + fQueryName + " not like '%" + operand + "%' OR " + fQueryName + " IS NULL)";
		            } else {
		                expression = fQueryName + " not like '%" + operand + "%'";
		            }
		            break;
		        case "starts":
		            expression = fQueryName + "  like '" + operand + "%'";
		            break;

		        // IN and NOTIN are not tested
		        case "in" :
		        case "notin" :
		            var exprParts = [
		              fQueryName + " = '" + operand + "'",
		              fQueryName + " like '" + operand + ",%'",
		              fQueryName + " like '%," + operand + "'",
		              fQueryName + " like '%," + operand + ",%'"
		            ];

		            if (operator == "in") {
		                expression = "(" + exprParts.join(" OR ") + ")";
		            } else {
		                expression = "NOT (" + exprParts.join(" OR ") + ")";
		            }
		            break;
		    }
            exprs[exprIndex] = expression;
		},
		
		getDateTimeAsFormat : function(format,value){
			var operand;
			if(format == "datetime"){
				operand = DatetimeUtils.macroDrivenDatetime(value, "YYYY-MM-DD", "HH:mm:ss");
			}else if(format == "date"){
				operand = DatetimeUtils.macroDrivenDatetime(value, "YYYY-MM-DD" ,'','date');
			}
			return operand;
		},
        __addPlainFieldToSearchQuery : function(wc, kw, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash) {
		    var ftype = fld[SVMX.OrgNamespace + "__Search_Object_Field_Type__c"],
		        fname = fld[SVMX.OrgNamespace + "__Field_Name__c"],
		         objectName1 = fld[SVMX.OrgNamespace + "__Object_Name__c"],
		    	 objectName2 = fld[SVMX.OrgNamespace + "__Object_Name2__c"];

            // should always use objectName2 (assumption)
			if (!fieldsHash[objectName2][fname]) {
    		   logger.error("Minor Error: Search field " + fname + " does not exist");
               return; // just ignore it
        	}

		    resultColumns.push("MAIN." + fname + " as fld" + i);
			if (ftype == "Search" && kw !== "%%") {
				searchColumns.push(SVMX.string.substitute("{{column}} {{clause}} '{{keyword}}'",
						{column : "MAIN." + fname, clause : wc, keyword : kw}));
			}
		},
		__addReferenceFieldToSearchQuery : function(wc, kw, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash) {
		    var tableExists = false,
		    	 objectName1 = fld[SVMX.OrgNamespace + "__Object_Name__c"],
		    	 objectName2 = fld[SVMX.OrgNamespace + "__Object_Name2__c"],
		    	 fname = fld[SVMX.OrgNamespace + "__Field_Name__c"],
		    	 ftype = fld[SVMX.OrgNamespace + "__Search_Object_Field_Type__c"],
		    	 nameField;

		     // should always use objectName1 (assumption)
			if (!fieldsHash[objectName2][fname]) {
               logger.error("Minor Error: Search field " + fname + " does not exist");
               return; // just ignore it
        	}

		    OfflineMetaUtils.isTableInDatabase(objectName1, SVMX.proxy(this, function(exists) {
				tableExists = exists;
			}));
			if (!tableExists) return;
			// synchronous callback

			OfflineMetaUtils.getNameField(fld[SVMX.OrgNamespace + "__Object_Name__c"], function(tmp) {
				nameField = tmp;
			});
			if (!nameField) return;
			searchJoins.push(SVMX.string.substitute(
				"LEFT JOIN `{{table_name}}` as {{alias}} ON {{alias}}.Id = MAIN.{{source_field_name}}",
				{
					table_name: objectName1,
					alias: "tbl" + i,
					source_field_name: fname
				}
			));

			if (ftype == "Search" && kw !== null) {
				if (kw !== "%%") {
					searchColumns.push(SVMX.string.substitute("{{column}} {{clause}} '{{keyword}}'",
							{column : "tbl" + i + "." + nameField, clause : wc, keyword : kw}));
				}
			}
			resultColumns.push("tbl" + i + "." + nameField + " as fld" + i);
			resultColumns.push("MAIN." + fname + " as fld" + i + "_ref");
        },

        __addReferenceFieldWithCustomDisplayToSearchQuery : function(wc, kw, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash) {
		    var tableExists = false,
		    	 objectName1 = fld[SVMX.OrgNamespace + "__Object_Name__c"],
		    	 objectName2 = fld[SVMX.OrgNamespace + "__Object_Name2__c"],
		    	 fname = fld[SVMX.OrgNamespace + "__Field_Name__c"],
		    	 ftype = fld[SVMX.OrgNamespace + "__Search_Object_Field_Type__c"],
		    	 lookupName = fld[SVMX.OrgNamespace + "__Lookup_Field_API_Name__c"].replace(/__r$/,"__c");

		  if (!lookupName.match(/__c$/) && !lookupName.match(/Id$/)) {
			  	lookupName = lookupName+'Id';
	    }

            // should always use objectName2 (assumption)
			if (!fieldsHash[objectName2][fname]) {
			   logger.error("Minor Error: Search field " + fname + " does not exist");
               return; // just ignore it
        	}

            OfflineMetaUtils.isTableInDatabase(objectName2, SVMX.proxy(this, function(exists) {
				tableExists = exists;
			}));

			if (!tableExists) return;
			searchJoins.push(SVMX.string.substitute(
				"LEFT JOIN `{{table_name}}` as {{alias}} ON {{alias}}.Id = MAIN.{{source_field_name}}",
				{
					table_name: objectName2,
					alias: "tbl" + i,
					source_field_name: lookupName
				}
			));

			if (ftype == "Search" && kw !== "%%") {
				searchColumns.push(SVMX.string.substitute("{{column}} {{clause}} '{{keyword}}'",
						{column : "tbl" + i + "." + fname, clause : wc, keyword : kw}));
			}
			resultColumns.push("tbl" + i + "." + fname + " as fld" + i);
			resultColumns.push("MAIN." + lookupName + " as fld" + i + "_ref");
        },

        __addReferenceToReferenceToSearchQuery : function(wc, kw, fld, i, searchJoins, searchColumns, resultColumns, fieldsHash) {
		    var tableExists = false,
		    	 objectName1 = fld[SVMX.OrgNamespace + "__Object_Name__c"],
		    	 objectName2 = fld[SVMX.OrgNamespace + "__Object_Name2__c"],
		    	 fname = fld[SVMX.OrgNamespace + "__Field_Name__c"],
		    	 ftype = fld[SVMX.OrgNamespace + "__Search_Object_Field_Type__c"],
		    	 lookupName = fld[SVMX.OrgNamespace + "__Lookup_Field_API_Name__c"].replace(/__r$/,"__c"),
		    	 nameField;

					if (fname.match(/Id$/) && !lookupName.match(/__c$/) && !lookupName.match(/Id$/)) {
							lookupName = lookupName+'Id';
					}

		    	 // should always use objectName2 (assumption)
    			if (!fieldsHash[objectName2][fname]) {
    			   logger.error("Minor Error: Search field " + fname + " does not exist");
                   return; // just ignore it
            	}

    			// TODO: Insure all tables are present!
    			OfflineMetaUtils.isTableInDatabase(objectName1, SVMX.proxy(this, function(exists) {
    				tableExists = exists;
    			}));
    			if (!tableExists) return;
    			OfflineMetaUtils.isTableInDatabase(objectName2, SVMX.proxy(this, function(exists) {
    				tableExists = exists;
    			}));
    			if (!tableExists) return;

    			// synchronous callback
    			OfflineMetaUtils.getNameField(objectName1, function(tmp) {
    				nameField = tmp;
    			});
    			if (!nameField) return;
    			searchJoins.push(SVMX.string.substitute(
    				"LEFT JOIN `{{table_name}}` as {{alias}} ON {{alias}}.Id = MAIN.{{source_field_name}}",
    				{
    					table_name: objectName2,
    					alias: "tbl" + i,
    					source_field_name: lookupName
    				}
    			));
    			searchJoins.push(SVMX.string.substitute(
    				"LEFT JOIN `{{table_name}}` as {{alias}} ON {{old_alias}}.{{source_field_name}} = {{alias}}.Id",
    				{
    					table_name: objectName1,
    					alias: "tbl" + i + "_2",
    					old_alias: "tbl" + i,
    					source_field_name: fname
    				}
    			));

    			if (ftype == "Search") {
    				if (kw !== "%%") {
    					searchColumns.push(SVMX.string.substitute("{{column}} {{clause}} '{{keyword}}'",
    						{column : "tbl" + i + "_2." + nameField, clause : wc, keyword : kw}));
    				}
    			}
    			resultColumns.push("tbl" + i + "_2." + nameField + " as fld" + i);
    			resultColumns.push("tbl" + i + "." + fname + " as fld" + i + "_ref");
        },

		__handleResponse : function(request, responder, data, utils, searchDef, expressions, recordTypeHash, totalCount){

			var stringMap = [],  i,
			    fields = searchDef.fields,
			    expUtils = com.servicemax.client.offline.sal.model.utils.Expressions,
			    targetObjectName = searchDef.objectDetails[SVMX.OrgNamespace + "__Target_Object_Name__c"],
			    newdata = [],
                missingIds = [];

			stringMap.push({key : "SEARCH_OBJECT_ID", value : request.ObjectId});

			logger.info("DATA COUNT: " + data.length);

			var ret = {
                MapStringMap    : [],
                stringMap       : stringMap,
                totalCount      : totalCount
            };
			var l = data.length, record, dataItem, j, name;

	        var userInfo = OfflineSystemUtils.getUserInfo();
            var offset = userInfo.TimezoneOffset;
			for(i = 0; i < l; i++){
				dataItem = data[i];

				var record = {valueMap : []};
				record.valueMap.push({key: "Id", value: dataItem.Id});
				record.id = dataItem.Id;

				SVMX.array.forEach(fields, function(fld, fieldIndex) {
					var fname = fld[SVMX.OrgNamespace + "__Field_Name__c"];
					var parentName = fld[SVMX.OrgNamespace + "__Object_Name2__c"];
					var parentReferenceName = fld[SVMX.OrgNamespace + "__Lookup_Field_API_Name__c"];

                    // This does not change the name, but simply insures that the name used is unique.
                    if (parentName && parentName != targetObjectName) fname = parentReferenceName + "-" + fname;
					var ftype = fld[SVMX.OrgNamespace + "__Search_Object_Field_Type__c"];
					if (ftype == "Result") {
						var isRef = fld[SVMX.OrgNamespace + "__Display_Type__c"] === "REFERENCE";

						if (!isRef) {
						    var nextValue = {
						        key : fname,
						        type: fld[SVMX.OrgNamespace + "__Display_Type__c"],
						        value: dataItem["fld" + fieldIndex],
                                value1: dataItem["fld" + fieldIndex + "_ref"]};

						    // TODO: Once the server sends us a server formated date instead of locally formated date in online search, we can
							// remove this custom date handling
							/*if (nextValue.type == "DATE") {
								//nextValue.value = nextValue.value ? com.servicemax.client.lib.datetimeutils.DatetimeUtil.convertToTimezone(nextValue.value, offset, false) : nextValue.value;
								nextValue.value = DatetimeUtils.getFormattedDatetime(nextValue.value, DatetimeUtils.getDefaultDateFormat());
								nextValue.type = "STRING";
							} else if (nextValue.type == "DATETIME") {
								//nextValue.value = nextValue.value ? com.servicemax.client.lib.datetimeutils.DatetimeUtil.convertToTimezone(nextValue.value, offset, false) : nextValue.value;
								nextValue.value = DatetimeUtils.getFormattedDatetime(nextValue.value);
								nextValue.type = "STRING";
							}*/

						} else {
							nextValue = {
								key: fname,
								type: "REFERENCE",
								value: dataItem["fld" + fieldIndex],
								value1: dataItem["fld" + fieldIndex + "_ref"]
							};
						}

                        if (!nextValue.value && dataItem["fld" + fieldIndex + "_ref"] && this.__lookupRecordName(fld)) {
                            missingIds.push(dataItem["fld" + fieldIndex + "_ref"]);
                        }


                        record.valueMap.push(nextValue);
					}
				}, this);

				record.valueMap.push({
				    key: "isRecordInConflict",
				    value: (dataItem.isRecordInConflict === "conflict" || dataItem.isRecordInConflict === "error")
				});
				ret.MapStringMap.push(record);
			}

            OfflineDataUtils.getFromRecordNameTable(missingIds)
            .then(SVMX.proxy(this, function(nameIdPairs) {
                var nameIdHash = {};
                SVMX.array.forEach(nameIdPairs, function(item) {nameIdHash[item.Id] = item.Name;});

                SVMX.array.forEach(ret.MapStringMap, function(record) {
                    SVMX.array.forEach(record.valueMap, function(item) {
                        if (item.value1 && nameIdHash[item.value1]) {
                            item.value = nameIdHash[item.value1];
                            delete item.value1;
                        }
                    }, this);
                }, this);

                this.__refactorNameFields(ret, utils, searchDef);
                responder.result(ret);
            }));


		},

        __lookupRecordName: function(fld) {
            var displayType = fld[SVMX.OrgNamespace +  "__Display_Type__c"];
            var lookupName = fld[SVMX.OrgNamespace + "__Lookup_Field_API_Name__c"].replace(/__r$/,"__c");
            if (displayType !== "REFERENCE" && !lookupName) {
                return false;
            }

            else if (displayType === "REFERENCE" && !lookupName) {
                return true;
            }

            else if (displayType !== "REFERENCE" && lookupName) {
                var objectName = fld[SVMX.OrgNamespace + "__Object_Name2__c"];
                var nameField = OfflineMetaUtils.getNameField(objectName);
                var fname = fld[SVMX.OrgNamespace + "__Field_Name__c"];
                return fname == nameField;
            }


            else if (displayType === "REFERENCE" && lookupName) {
                return true;
            }


        },

		__refactorNameFields : function(data, utils, searchDef){
			var nameFieldName = searchDef.objectDetails.objectNameField;
			var i, records = data.MapStringMap, l = records.length, record, recordItems;
			for(i = 0; i < l; i++){
				record = records[i]; recordItems = record.valueMap;

				var j, c = recordItems.length;
				for(j = 0; j < c; j++){
					if(recordItems[j].key == nameFieldName){
						recordItems[j].value1 = record.id;
					}
				}
			}
		}
	}, {});
	
	operationsImpl.Class("GetUserInfo", com.servicemax.client.mvc.api.Operation, {

            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {
                responder.result(OfflineSystemUtils.getUserInfo());
            }
        }, {});

    operationsImpl.Class("GetOnlineResults", com.servicemax.client.mvc.api.Operation, {

            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {

                var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
                servDef.getInstance().getOnlineSearchResults({
                    data: request,
                    callback: SVMX.proxy(this, function(result){
                        if(result.isSuccess){
                            responder.result(result.data);
                        }else{
                            responder.result();
                        }
                    })
                });
            }
        }, {});

     operationsImpl.Class("DownloadRecordOnDemand", com.servicemax.client.mvc.api.Operation, {

            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {  

                var onSuccess = function(result){
                    /*com.servicemax.client.offline.sal.model.utils.Data
                        .getRecord( { Id: request.data.recordId } )
                            .done(SVMX.proxy(this, function(record){
                                if(record){
                                    responder.result(getRawValues(record));
                                }else{
                                    responder.fault();
                                }
                            }));*/
                    responder.result(result);
                }
                var onError = function(result){
                     responder.fault(result);
                }

                /*var getRawValues = function(record){
                   for(var key in record){
                       if(SVMX.typeOf(record[key]) === "Object"){
                           record[key] = record[key].fieldvalue && record[key].fieldvalue.key;
                       }
                   }
                   return record;
                }*/

                var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
                servDef.getInstance().downloadRecordOnDemand(request)
                    .then(SVMX.proxy(this, onSuccess),SVMX.proxy(this, onError));
            }
        }, {});

	operationsImpl.Class("GetSearchResultLimitSettings", com.servicemax.client.mvc.api.Operation, {

		__constructor: function() {
			this.__base();
		},

		getSettingValue:function(record){

		},

		performAsync: function(request, responder) {
			var me=this;
			var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmsearch.utils.impl.Utils");
			var settingValueQuery="SELECT * FROM MobileDeviceSettings WHERE setting_id IN('IPAD019_SET001')";//TODO correct Setting if introduced.

			utils.executeQuery(settingValueQuery, function(settingValueRows){

				var settingValues={maxLimit:null,defaultLimit:25};

				for(var i=0;i<settingValueRows.length;i++){

					var settingRow=settingValueRows[0];

					if(settingRow['setting_id']==="IPAD019_SET001")
					{
						settingValues.maxLimit=settingRow['value'];
					}
					/*else if(settingRow['setting_id']==="  "){//TODO correct Setting if introduced.
						settingValues.defaultLimit=settingRow['value'];
					}*/
				}
				responder.result(settingValues);

			}, this);
		}
	}, {});


};

})();

// end of file
