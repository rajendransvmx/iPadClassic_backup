/**
 *
 # Package #
 *
 * Operations for sfmdelivery
 *
 * @class com.servicemax.client.offline.sal.model.sfmdelivery.operations
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 * @since: The minimum version where this file is supported
 */

// TODO: XXX
(function() {
    var sfmdeliveryoperations = SVMX.Package("com.servicemax.client.offline.sal.model.sfmdelivery.operations");
sfmdeliveryoperations.init = function() {

        // TODO: make sfmdelivery module optional
        if (!com.servicemax.client.sfmdelivery.operationutils) return;

        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
        var logger = SVMX.getLoggingService().getLogger("sfm-offline-operations");
        var OpUtils = com.servicemax.client.sfmdelivery.operationutils.Utilities;
        var DatetimeUtils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
        var OfflineExprUtils = com.servicemax.client.offline.sal.model.utils.Expressions;
        var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;
        var OfflineMetaUtils = com.servicemax.client.offline.sal.model.utils.MetaData;
        var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
        var OfflineSyncUtils = com.servicemax.client.offline.sal.model.utils.SyncData;
        var OfflineCacheUtils = com.servicemax.client.offline.sal.model.utils.Cache;
        var RecordClass = com.servicemax.client.offline.sal.model.utils.Record;
        var VirtualRecordClass = com.servicemax.client.offline.sal.model.utils.VirtualRecord;

        var Module = com.servicemax.client.offline.sal.model.impl.Module;

        var getDataFromEvt = function(evt) {
                return SVMX.toObject(evt.data.data);
            };

        var sfNameFields = null;
        // imports
        // end imports


        // !!!!! only temporary, for testing purposes !!!!!
        var processId = null;
        // !!!!! end temporary !!!!!!!!!

        /* Utility for calling a query; a bit less wordy than our default.
         * @param {String} query
         * @param {Object} [context]
         * @param {String|Function} [onSuccess] Name of method to fire on context
         * @param {String|Function} [onError] Name of method to fire on context
         * @param {Object} [state] A hash of state parameters you want passed to the handler
         */
        function execQuery(inParams) {
            var d = $.Deferred();
            var req = nativeService.createSQLRequest();
            req.bind("REQUEST_COMPLETED", function(evt) {
                d.resolve(evt.data.data);
                if (inParams.onSuccess) {
                    if (inParams.state) {
                        SVMX.proxy(inParams.context, inParams.onSuccess)(inParams.state, evt);
                    } else {
                        SVMX.proxy(inParams.context, inParams.onSuccess)(evt);
                    }
                }
            });
            req.bind("REQUEST_ERROR", function(evt) {
                logger.error("\n" + evt.type + ": " + evt.data.data + "\nQUERY: " + evt.data.parameters.query);
                d.reject(evt.data.data);
                if (inParams.onError) {
                    if (inParams.state) {
                        SVMX.proxy(inParams.context, inParams.onError)(inParams.state, evt);
                    } else {
                        SVMX.proxy(inParams.context, inParams.onError)(evt);
                    }
                }
            });
            req.execute({
                query: inParams.query,
                queryParams: inParams.queryParams
            });
            return d;
        }


        sfmdeliveryoperations.Class("Utilities", com.servicemax.client.lib.api.Object, {}, {
            /**
             * PUBLIC METHOD getProcessComponents
             * @description
             *    Queries the SFProcessComponents to get information about each line item type for the
             *    given processId.  Results returned through the onSuccess callback.  Callback is of the form
             *    function(inStringMap, inData) {...} where the StringMap is inData converted into StringMap format
             *
             * @param {Object} inParams
             *    {string} [processId] process name/id
             *    {string} [salesforceProcessId] process id as a Salesforce reference.
             *    {Function} [onSuccess] Function to call when results are available
             *    {Function} [onError] Function to call when error is thrown
             * @returns undefined
             *
             */
            getProcessComponents : function(inParams) {
                var query;
                if (inParams.salesforceProcessId) {
                    query = SVMX.string.substitute(
                    //"SELECT * FROM SFProcessComponent WHERE process_id = '{{process_id}}' AND component_type = 'TARGETCHILD'",
                    "SELECT parent_column as parent_column, object_name as target_object_name, layout_id, object_mapping_id, value_mapping_id, expression_id, component_type, advanced_options, Id as processComponentId, parent_object, target_object_label " + "FROM SFProcessComponent WHERE process_id = '{{process_id}}'", {
                        process_id: inParams.salesforceProcessId
                    });
                } else {
                    query = SVMX.string.substitute("SELECT parent_column as parent_column, object_name as target_object_name, layout_id, object_mapping_id, value_mapping_id, expression_id, component_type, advanced_options, SFProcessComponent.Id as processComponentId, parent_object, target_object_label " + "FROM SFProcessComponent " + "LEFT JOIN  SFProcess ON SFProcess.process_id = SFProcessComponent.process_id " + "WHERE process_unique_id = '{{process_id}}'", {
                        process_id: inParams.processId
                    });
                }

                var req = nativeService.createSQLRequest();
                req.bind("REQUEST_ERROR", SVMX.proxy(this, "__getProcessComponentsError", inParams, query));
                req.bind("REQUEST_COMPLETED", SVMX.proxy(this, "__getProcessComponentsSuccess", inParams, query));
                req.execute({
                    query: query
                });
            },

            __getProcessComponentsSuccess: function(inParams, query, evt) {
                var data = getDataFromEvt(evt);
                // Result is a StringMap
                var stringMap = SVMX.array.map(data, function(inItem) {
                    return {
                        key: inItem.layout_id,
                        value: inItem.parent_column,
                        value1: inItem.advanced_options, // Advanced Options, used for sorting field
                        fieldsToNull: null // TODO: WHAT IS THIS?
                    };
                });
                SVMX.array.forEach(data, function(item) {
                    if (item.advanced_options) item.advanced_options = SVMX.toObject(item.advanced_options);
                });
                if (inParams.onSuccess) inParams.onSuccess(stringMap, data);
            },

            __getProcessComponentsError: function(inParams, query, evt) {
                logger.error("_getProcessComponentsError: " + query + " returns " + evt.data);
                if (inParams.onError) inParams.onError(evt);
            }
        });


        /* OPERATION: GetPageLayout
         * STATUS: Works;
         * @param {string} processId
         * @description Returns a JSON structure describing the page to be rendered
         * TODO:
         *    1. MICHAEL: Remove string parsing hack for accessing JSON data
         *    2. VINOD: Handle linkedProcesses
         *    3. MICHAEL: Implement a database for caching Templates instead of using recordTemplateCache
         */
        var recordTemplateCache = {};
        sfmdeliveryoperations.Class("GetPageLayout", com.servicemax.client.mvc.api.Operation, {

            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {
                var state = {
                    responder: responder,
                    processId: request.processId,
                    processType: null,
                    recordId: request.recordId
                };

                // caching will fail for now as we want to continue to test our getpagelayout.  Remove
                // the "1" when ready for caching.
                OfflineCacheUtils.readObjectFromDBCache("PURGE_ON_CONFIG_SYNC.GetPageLayout_" + state.processId)

                .then(SVMX.proxy(this, function(data) {
                    if (data) return responder.result(data);
                    execQuery({
                        query: //"SELECT process_id, page_layout_id, process_type FROM SFProcess WHERE process_unique_id='{{process_id}}'",
                        "SELECT SFProcess.process_type, SFProcess.process_name,  SFProcess.process_id, SFProcess.process_unique_id, SFProcessComponent.object_name, SFProcessComponent.enable_attachment, SFPageLayout.page_data FROM SFProcess " +
                        "LEFT JOIN SFProcessComponent ON SFProcess.process_id = SFProcessComponent.process_id " +
                        "LEFT JOIN SFPageLayout ON SFPageLayout.page_layout_id = SFProcess.page_layout_id " +
                        "WHERE process_unique_id = '{{process_id}}' AND component_type='TARGET'",
                        queryParams: {
                            process_id: state.processId
                        }
                    }).then(
                    SVMX.proxy(this, function(data) {
                        return this._onGetLayoutSuccess(state, data);
                    }),
                    SVMX.proxy(this, function(error) {
                        logger.error("GetPageLayout Failed: " + error);
                    }));
                }));
            },
            _onGetLayoutError: function(state, error) {
                logger.error(error);
                // TODO: Need to make this error recoverable
            },
            _onGetLayoutSuccess: function(state, data) {
                var d = new $.Deferred();
                data = data[0];
                if (!data) {
                    return this._onGetLayoutError(state, "Layout not found");
                }
                state.processType = data.process_type;
                state.salesforceProcessId = data.process_id;
                var pageLayoutData = SVMX.toObject(data.page_data);
                pageLayoutData.header.headerLayout[SVMX.OrgNamespace + "__Enable_Attachments__c"] = (data.enable_attachment == "true");


                execQuery({
                    query: "Select label FROM SFObjectDescribe where object_name ='{{source}}'",
                    queryParams: {
                        source: pageLayoutData.header.headerLayout[SVMX.OrgNamespace + "__Object_Name__c"]
                    },

                }).then (SVMX.proxy(this, function(evt) {
                    try {
                        pageLayoutData.header.headerLayout[SVMX.OrgNamespace + "__Page_Layout_ID__c"] = evt[0].label;
                    } catch(e) {
                        logger.error("Unexpected error in the object label THEN handler:" + e);
                    }

                    state.processName = data.process_name;
                    state.tableName = data.object_name;

                    if (!pageLayoutData.details) {
                        logger.info('Page layout data missing for process ' + data.process_id);
                        return this._onGetLayoutError(state, "No pageLayout.details found");
                    }

                    // TODO: VINOD, Get the ACTUAL linkedProcesses
                    SVMX.array.forEach(pageLayoutData.details, function(inDetail) {
                        inDetail.linkedProcesses = [];
                    });

                    this.__cacheChildRecordTemplates(state.salesforceProcessId, pageLayoutData);
                    state.fullData = {
                        response: {},
                        page: pageLayoutData
                    };
                }))
                .then(SVMX.proxy(this, function(){
                  this.__buildQuestionInfoJSON(state, data.page_data);
                }))
                .then(SVMX.proxy(this, function() {
                    this.__buildFieldMapping(state, data.page_data);
                }))

                .then(SVMX.proxy(this, function() {
                    sfmdeliveryoperations.Utilities.getProcessComponents({
                        salesforceProcessId: state.salesforceProcessId,
                        onSuccess: SVMX.proxy(this, "_onGetProcessComponents", state),
                        onError: SVMX.proxy(this, function(evt) {
                            logger.error("_onGetPageLayoutSuccess failed to get StringMap");
                        })
                    });
                   d.resolve();
                }));

                return d;
            },

          __buildQuestionInfoJSON : function(state,pageLayoutStr){
                var d = new $.Deferred();
                var SFQuestionBankTable = {
                   "Short_Name"          : "shortname",
                   "Scale"               : "scale",
                   "Response_Type"       : "responseType",
                   "QuestionJSON"        : "questionJSON",
                   "QuestionID"          : "questionID",
                   "Question"            : "question",
                   "Precision"           : "precision",
                   "Length"              : "length",
                   "Help_URL"            : "helpURL",
                   "Description"         : "description",
                   "Id"                  : "id",
                   "Name"                : "name",
                   "Response_Set_Values" : "responseSetValues",
                   "Response_Set"        : "responseSet",
                   "CreatedBy"           : "createdBy",
                   "CurrencyIsoCode"     : "currencyIsoCode",
                   "LastModifiedBy"      : "lastModifiedBy"
                }
                try{
                  var questionIds = SVMX.array.map(pageLayoutStr.match(/"SVMX(?:DEV|C)__Question__c":".*?"/g) || [],
                      function(inString) {
                        return inString.split(/":"/)[1].replace(/"/,"");
                      }
                  );
                  if (questionIds.length === 0) {
                      d.resolve();
                      return d;
                  } else {

                    execQuery({
                        query       :  "Select MAIN.*, sfqbr.Response_Set_Values FROM SFQuestionBank AS MAIN LEFT JOIN SFQBResponseSet AS sfqbr ON MAIN.Response_Set = sfqbr.Id WHERE MAIN.Id IN ('{{question_ids}}') " ,
                        queryParams : {
                            question_ids : questionIds.join("','")
                        }
                    })
                    .then(SVMX.proxy(this, function(result){
                      var questionIdQuestionJSON = {};
                      for(var i = 0; i < result.length; i++){
                          var data = result[i], questionResponse = [], questioninfo = {};
                          for(var key in data){
                              questioninfo[SFQuestionBankTable[key]] = data[key];
                              if(key === "Response_Set_Values" && questioninfo[SFQuestionBankTable[key]] != null ){
                                  var values = questioninfo[SFQuestionBankTable[key]].split(";");
                                  for(var j = 0; j < values.length; j++){
                                      if(values[j] != ""){
                                          var response = {"questionID" : questioninfo["id"],"response" : values[j], "sequence": j};
                                          questionResponse.push(response);
                                      }
                                  }
                              }
                          }

                          // Default question to active unless is "false"
                          questioninfo.active = String(questioninfo.active) !== "false";

                          var questionJSON = {"question" : questioninfo, "questionResponses" : questionResponse};
                          questionIdQuestionJSON[questioninfo["id"]] = SVMX.toJSON(questionJSON);
                      }
                      for(var i = 0; i < state.fullData.page.header.sections.length; i++){
                          var fields = state.fullData.page.header.sections[i].fields;
                          for(var j = 0; j < fields.length; j++){
                              var fieldDetail = fields[j].fieldDetail;
                              var questionId = fieldDetail[SVMX.OrgNamespace + "__Question__c"];
                              fieldDetail[SVMX.OrgNamespace + "__QuestionInfoJSON__c"] = questionIdQuestionJSON[questionId];
                          }
                      }
                      d.resolve();
                    }));
                  }
                }catch(e){
                  d.resolve();
                  return d;
                }
                return d;
            },

            __buildFieldMapping : function(state, pageLayoutStr) {
                var d = new $.Deferred();
                try {
                    var mappingIds = SVMX.array.map(pageLayoutStr.match(/"SVMXC__Field_Mapping__c":".*?"/g) || [],
                        function(inString) {
                            return inString.split(/":"/)[1].replace(/"/,"");
                        }
                    );
                    if (mappingIds.length === 0) {
                        d.resolve();
                        return d;
                    } else {
                        // A field mapping used multiple times should not be loaded multiple times
                        for (var i = mappingIds.length - 1; i >= 0; i--) {
                            var index = SVMX.array.indexOf(mappingIds, mappingIds[i]);
                            if (index > -1 && index < i) SVMX.array.removeElementAt(mappingIds, i);
                        }
                    }

                    state.fullData.page.lstObjectMapInfo = SVMX.array.map(mappingIds, function(id) {
                        return {
                            mapId: id,
                            objectMap: {
                                fields: []
                            }
                        };
                    });

                    execQuery({
                        query:  "Select object_mapping_id, source_field_name, target_field_name, mapping_value, preference_2, preference_3, " +
                                "object_mapping_id || source_field_name || target_field_name || mapping_value as myconcat " +
                                "FROM SFObjectMappingComponent WHERE object_mapping_id IN ('{{object_mapping_id}}') " +
                                "GROUP BY myconcat",
                        queryParams: {
                            object_mapping_id : mappingIds.join("','")
                        }
                    })

                    .then(SVMX.proxy(this, function(data) {
                        // Trim repeteated data


                        SVMX.array.forEach(data, function(item) {
                            var index = SVMX.array.indexOf(state.fullData.page.lstObjectMapInfo, function(arrayItem) {
                                return arrayItem.mapId == item.object_mapping_id;
                            });
                            var section = state.fullData.page.lstObjectMapInfo[index].objectMap.fields;
                            var fieldDef = {};
                            fieldDef[SVMX.OrgNamespace + "__Source_Field_Name__c"] = item.source_field_name;
                            fieldDef[SVMX.OrgNamespace + "__Target_Field_Name__c"] = item.target_field_name;
                            fieldDef[SVMX.OrgNamespace + "__Display_Value__c"] = item.mapping_value;
                            fieldDef[SVMX.OrgNamespace + "__Preference_2__c"] = item.preference_2;
                            fieldDef[SVMX.OrgNamespace + "__Preference_3__c"] = item.preference_3;
                            section.push({
                                fieldMapRecord: fieldDef
                            });
                        }, this);
                        d.resolve();
                    }));


                } catch(e) {
                    d.resolve();
                    return d;
                }

                return d;
            },

            __cacheChildRecordTemplates: function(processId, data) {
                var details = data.details;
                if (details && details.length > 0) {
                    var i, l = details.length,
                        recordTemplate, detailId, rt, key;
                    for (i = 0; i < l; i++) {
                        recordTemplate = details[i].recordTemplate;

                        if (!recordTemplate) continue;

                        detailId = details[i].dtlLayoutId;
                        rt = [{
                            sobjectinfo: recordTemplate,
                            bubbleInfo: []
                        }];
                        for (var name in recordTemplate) {
                            if (name == "attributes" || name == "attributes__key") continue;

                            rt[0].bubbleInfo.push({
                                fieldapiname: name,
                                fieldvalue: {
                                    value: recordTemplate[name],
                                    value1: recordTemplate[name]
                                }
                            });
                        }
                        key = processId + "-" + detailId;
                        recordTemplateCache[key] = rt;
                    }
                }
            },


            _onGetProcessComponents: function(state, inStringMap, processComponentList) {

                if(processComponentList){
                    var i, l = processComponentList.length;
                    for(i = 0; i < l; i++){
                        if(processComponentList[i].component_type == "TARGET"){
                            try {
                                state.fullData.page.header.headerLayout[SVMX.OrgNamespace + "__Page_Layout_ID__c"] = processComponentList[i].target_object_label;
                            } catch(e) {
                                logger.error("Unexpected error while updating Header Page Layout Id with Header Alias Name");
                            }
                        }
                    }
                }

                inStringMap.unshift({
                    "value1": null,
                    "value": state.processType,
                    "key": "PROCESSTYPE",
                    "fieldsToNull": null
                });
                state.fullData.response.stringMap = inStringMap;
                state.fullData = this.__restructureData(state.fullData);

                this.pageLayoutData = state.fullData;
                if (state.fullData.response.sfmProcessType === "VIEW RECORD") {
                    this.__onDone(state);
                } else {
                    state.processComponentList = processComponentList;
                    SVMX.doLater(SVMX.proxy(this, "getLinkedProcesses", state));
                }
            },

            __onDone: function(state) {
                var me = this;
                me.__validateReferenceObjectDefinitions(state.fullData)
                .then(function(){
                    // Build lookup display field maps for header and detail sections
                    me.__buildLookupDisplayFieldMap(state.fullData);

                    state.fullData.processTitle = state.processName;
                    // The responder may change the process type to a view process
                    // so we need to cache this as soon as possible.
                    OfflineCacheUtils.writeToDBCache("PURGE_ON_CONFIG_SYNC.GetPageLayout_" + state.processId, SVMX.toJSON(state.fullData));

                    state.responder.result(state.fullData);

                });
            },

            __validateReferenceObjectDefinitions: function(data){
                var d = new $.Deferred();
                var refObjects = [], refFields = {};

                (data.page.header.sections || []).forEach( function( section ){
                    (section.fields || []).forEach( function( field ){
                        // Question is a fake reference field which does not have related object name
                        if(field.fieldDetail[SVMX.OrgNamespace + '__DataType__c'] == 'reference' &&
                         field.fieldDetail[SVMX.OrgNamespace + "__Detail_Type__c"] != "Question"){
                            var objName = field.fieldDetail[SVMX.OrgNamespace + '__Related_Object_Name__c'];
                            if(!(objName in refFields)){
                                refFields[objName] = [];
                                refObjects.push(objName);
                            }
                            refFields[objName].push(field.fieldDetail);
                        }
                    });
                });

                (data.page.details || []).forEach( function( detail ){
                    (detail.fields || []).forEach( function( field ){
                        // Question is a fake reference field which does not have related object name
                        if(field.fieldDetail[SVMX.OrgNamespace + '__DataType__c'] == 'reference' &&
                         field.fieldDetail[SVMX.OrgNamespace + "__Detail_Type__c"] != "Question"){
                            var objName = field.fieldDetail[SVMX.OrgNamespace + '__Related_Object_Name__c'];
                            if(!(objName in refFields)){
                                refFields[objName] = [];
                                refObjects.push(objName);
                            }
                            refFields[objName].push(field.fieldDetail);
                        }
                    });
                });

                if(refObjects.length){
                    var req = nativeService.createSQLRequest();
                    req.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(result){
                        var resultSet = {};
                        (result ? result.data.data : []).forEach(function(item){
                            resultSet[item.object_name] = true;
                        });
                        for(var key in refFields){
                            if(!(key in resultSet)){
                                refFields[key].forEach(function(item){
                                    item[SVMX.OrgNamespace + '__Readonly__c'] = true;
                                });
                            }
                        }
                        d.resolve();
                    }));
                    req.bind("REQUEST_ERROR", SVMX.proxy(this, function(error){
                        d.resolve();
                    }));
                    req.execute({ query: "SELECT object_name FROM SFObjectDescribe WHERE object_name IN ('"+ refObjects.join("','") +"')" });
                }else{
                    d.resolve();
                }
                return d;
            },

            __buildLookupDisplayFieldMap: function(data){
                var refObjects = [], refFields = {};

                var lookupDisplayFieldMap = {};
                (data.page.header.sections || []).forEach( function( section ){
                    (section.fields || []).forEach( function( field ){
                        if(field.fieldDetail[SVMX.OrgNamespace + '__DataType__c'] == 'reference'){
                            var fieldName = field.fieldDetail[SVMX.OrgNamespace + "__Field_API_Name__c"];
                            lookupDisplayFieldMap[fieldName] = field.fieldDetail.SVMXC__Named_Search__r && field.fieldDetail.SVMXC__Named_Search__r.SVMXC__Default_Lookup_Column__c;
                        }
                    });
                });

                var result = {head: lookupDisplayFieldMap};
                var detailsMap = result.details = {};
                (data.page.details || []).forEach( function( detail ){
                    lookupDisplayFieldMap = {};
                    (detail.fields || []).forEach( function( field ){
                        if(field.fieldDetail[SVMX.OrgNamespace + '__DataType__c'] == 'reference'){
                            var fieldName = field.fieldDetail[SVMX.OrgNamespace + "__Field_API_Name__c"];
                            lookupDisplayFieldMap[fieldName] = field.fieldDetail.SVMXC__Named_Search__r && field.fieldDetail.SVMXC__Named_Search__r.SVMXC__Default_Lookup_Column__c;
                        }
                    });
                    detailsMap[detail.DetailLayout.Id] = lookupDisplayFieldMap;
                });

                data.lookupDisplayFieldMap = result;
            },

            __restructureData: function(data) {
                var sm = data.response.stringMap,
                    i, l = sm.length;
                for (i = 0; i < l; i++) {
                    if (sm[i].key == "PROCESSTYPE") {
                        data.response.sfmProcessType = sm[i].value;
                        break;
                    }
                }
                return data;
            },

            getLinkedProcesses: function(state) {
                var processId = state.salesforceProcessId;

                execQuery({
                    query: "Select * FROM SFLinkedProcess WHERE source_header = '{{source}}'",
                    queryParams: {
                        source: processId
                    },
                    state: state,
                    context: this,
                    onSuccess: "_getLinkedProcessesSuccess",
                    onError: "_getLinkedProcessesError"
                });
            },

            _getLinkedProcessesSuccess: function(state, evt) {
                var allProcesses = evt.data.data,
                    i, pids = [];
                allProcesses = SVMX.array.filter(allProcesses, function(item) {
                    return item.target_header;
                });
                for (i = 0; i < allProcesses.length; i++) {
                    pids.push(allProcesses[i].target_header);
                }

                state.allLinkedProcess = allProcesses;

                execQuery({
                    query: "Select * FROM SFProcess WHERE process_id in ('{{pids}}')",
                    queryParams: {
                        pids: pids.join("','")
                    },
                    state: state,
                    context: this,
                    onSuccess: "_getLinkedProcessesInfoSuccess",
                    onError: "_getLinkedProcessesError"
                });
            },

            _getLinkedProcessesInfoSuccess: function(state, evt) {
                var me = this,
                    allLinkedProcess = state.allLinkedProcess,
                    i,
                    l = allLinkedProcess.length,
                    lp, did, detail, s = 1;
                for (i = 0; i < l; i++) {
                    lp = allLinkedProcess[i];
                    did = lp.source_detail;
                    detail = getDetailFor(did);
                    if (detail) {
                        var pdef = getProcessDefFor(lp.target_header);
                        detail.linkedProcesses = detail.linkedProcesses || [];
                        detail.linkedProcesses.push({
                            title: pdef.process_name,
                            processId: pdef.process_unique_id,
                            sequence: s++ // no sequence is defined in sync metamodel
                        });
                    }
                }

                function getProcessDefFor(pid) {
                    var allProcesses = evt.data.data,
                        i, l = allProcesses.length,
                        ret = null;
                    for (i = 0; i < l; i++) {
                        if (allProcesses[i].process_id == pid) {
                            ret = allProcesses[i];
                            break;
                        }
                    }
                    return ret;
                }

                function getDetailFor(did) {
                    var details = state.processComponentList || [],
                        i, l = details.length,
                        ret = null,
                        id = null;
                    for (i = 0; i < l; i++) {
                        if (details[i].processComponentId == did) {
                            id = details[i].layout_id;

                            for (var detail in me.pageLayoutData.page.details) {
                                if (me.pageLayoutData.page.details[detail].dtlLayoutId == id) {
                                    ret = me.pageLayoutData.page.details[detail];
                                    break;
                                }
                            }

                            break;
                        }
                    }
                    return ret;
                }

                SVMX.doLater(SVMX.proxy(this, "getBusinessRules", state));
            },

            _getLinkedProcessesError: function(state, evt) {
                SVMX.doLater(SVMX.proxy(this, "getBusinessRules", state));
            },

            getBusinessRules: function(state) {
                var processId = state.salesforceProcessId;
                state.bzInfo = {};
                execQuery({
                    query: "Select * FROM SFProcessBusinessRule WHERE target_manager = '{{processId}}'",
                    queryParams: {
                        processId: processId
                    },
                    state: state,
                    context: this,
                    onSuccess: "_getProcessBusinessRuleSuccess",
                    onError: "_getBusinessRulesError"
                });
            },

            _getProcessBusinessRuleSuccess: function(state, evt) {
                var pbz = state.bzInfo.pbz = evt.data.data,
                    i, l = pbz.length,
                    ids = [],
                    temp = {};

                if (pbz.length === 0) {
                    this.__onDone(state);
                    return;
                }
                // filterout the possible duplicates
                for (i = 0; i < l; i++) {
                    temp[pbz[i].business_rule] = pbz[i].business_rule;
                }

                for (var inTemp in temp) {
                    ids.push(inTemp);
                }

                execQuery({
                    query: "Select * FROM SFBusinessRule WHERE Id in ('{{ids}}')",
                    queryParams: {
                        ids: ids.join("','")
                    },
                    state: state,
                    context: this,
                    onSuccess: "_getBusinessRuleSuccess",
                    onError: "_getBusinessRulesError"
                });
            },

            _getBusinessRuleSuccess: function(state, evt) {
                var bz = state.bzInfo.bz = evt.data.data,
                    i, l = bz.length,
                    ids = [],
                    temp = {};

                // filterout the possible duplicates
                for (i = 0; i < l; i++) {
                    temp[bz[i].Id] = bz[i].Id;
                }

                for (var inTemp in temp) {
                    ids.push(inTemp);
                }

                execQuery({
                    query: "Select * FROM SFExpressionComponent WHERE expression_id in ('{{ids}}') and expression_type IN ('Business_Rule', 'Field_Update_Rule')",
                    queryParams: {
                        ids: ids.join("','")
                    },
                    state: state,
                    context: this,
                    onSuccess: "_getBusinessRuleExpressionsSuccess",
                    onError: "_getBusinessRulesError"
                });
            },

            _getBusinessRuleExpressionsSuccess: function(state, evt) {
                state.bzInfo.bzExp = evt.data.data;

                // filter out any duplicates
                /**
                 * This may be potential issue where duplicate records are found. Sync!
                 *
                 */
                clearDuplicates();
                //

                var businessRules = this.pageLayoutData.page.businessRules = [],
                    me = this;
                for (var inProcessBusinessRule in state.bzInfo.pbz) {
                    var pno = state.bzInfo.pbz[inProcessBusinessRule].process_node_object;
                    var alias = getAliasFor(pno);
                    businessRules.push({
                        aliasName: alias,
                        sequence: state.bzInfo.pbz[inProcessBusinessRule].sequence,
                        message: state.bzInfo.pbz[inProcessBusinessRule].error_msg,
                        ruleInfo: {
                            bizRule: getBusinessRuleFor(state.bzInfo.pbz[inProcessBusinessRule].business_rule),
                            bizRuleDetails: getBusinessRuleDetailsFor(state.bzInfo.pbz[inProcessBusinessRule].business_rule)
                        }
                    });
                }

                function clearDuplicates() {
                    var exps = state.bzInfo.bzExp || [],
                        i, l = exps.length,
                        temp = {};
                    for (i = 0; i < l; i++) {
                        temp[exps[i].expression_id + "." + exps[i].sequence] = exps[i];
                    }

                    exps = state.bzInfo.bzExp = [];
                    for (var inTemp in temp) {
                        exps.push(temp[inTemp]);
                    }
                }

                function getAliasFor(pno) {
                    var details = state.processComponentList || [],
                        i, l = details.length,
                        ret = null;
                    for (i = 0; i < l; i++) {
                        if (details[i].processComponentId == pno) {
                            var dlid = details[i].layout_id;

                            for (var detail in me.pageLayoutData.page.details) {
                                if (me.pageLayoutData.page.details[detail].dtlLayoutId == dlid) {
                                    ret = me.pageLayoutData.page.details[detail]["DetailLayout"][SVMX.OrgNamespace + "__Page_Layout_ID__c"];
                                    break;
                                }
                            }

                            break;
                        }
                    }
                    return ret;
                }

                function getBusinessRuleFor(bid) {
                    var rules = state.bzInfo.bz || [],
                        i, l = rules.length,
                        ret = null;
                    for (i = 0; i < l; i++) {
                        if (rules[i].Id == bid) {
                            ret = rules[i];

                            ret["Name"] = ret.name;
                            ret[SVMX.OrgNamespace + "__ProcessID__c'"] = ret.process_ID;
                            ret[SVMX.OrgNamespace + "__Description__c"] = ret.description;
                            ret[SVMX.OrgNamespace + "__Source_Object_Name__c"] = ret.source_object_name;
                            ret[SVMX.OrgNamespace + "__Parent_Error_Msg__c"] = ret.error_msg;
                            ret[SVMX.OrgNamespace + "__Advance_Expression__c"] = ret.advanced_expression;
                            ret[SVMX.OrgNamespace + "__Message_Type__c"] = ret.message_type;
                            ret[SVMX.OrgNamespace + "__Rule_Type__c"] = ret.rule_type;

                            break;
                        }
                    }
                    return ret;
                }

                function getBusinessRuleDetailsFor(bid) {
                    var exps = state.bzInfo.bzExp || [],
                        i, l = exps.length,
                        ret = [],
                        exp;
                    for (i = 0; i < l; i++) {
                        if (exps[i].expression_id == bid) {
                            exp = exps[i];
                            ret.push(exp);

                            exp[SVMX.OrgNamespace + "__Expression_Rule__c"] = exp.expression_id;
                            exp[SVMX.OrgNamespace + "__Field_Name__c"] = exp.source_field_name;
                            exp[SVMX.OrgNamespace + "__Operator__c"] = exp.operator;
                            exp[SVMX.OrgNamespace + "__Operand__c"] = exp.value;
                            exp[SVMX.OrgNamespace + "__Display_Type__c"] = exp.field_type;
                            exp[SVMX.OrgNamespace + "__Sequence__c"] = exp.sequence;
                            exp[SVMX.OrgNamespace + "__Parameter_Type__c"] = exp.parameter_type;
                            exp[SVMX.OrgNamespace + "__Expression_Type__c"] = exp.expression_type;
                            exp[SVMX.OrgNamespace + "__Formula__c"] = exp.formula;
                            exp[SVMX.OrgNamespace + "__Action_Type__c"] = exp.action_type;
                        }
                    }
                    return ret;
                }
                this.__onDone(state);
            },

            _getBusinessRulesError: function(state, evt) {
                this.__onDone(state);
            }
        }, {});


        /* OPERATION: RetrieveSettings
         * STATUS: Works
         * @description Returns a array of Settings
         * TODO:
         *    1. ERIC: We need to get the laptop Settings
         *    2. INDRESH: We need to know if we're running this on laptop or iPad.
         *    3. MICHAEL: Remove the hardcoded in tags in _onError
         */
        sfmdeliveryoperations.Class("RetrieveSettings", com.servicemax.client.mvc.api.Operation, {

            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {
                execQuery({
                    query: "SELECT setting_id, value FROM MobileDeviceSettings",
                    state: responder,
                    context: this,
                    onSuccess: "_onSuccess",
                    onError: "_onError"
                });
            },

            _onError: function(responder, evt) {
                logger.error("RetrieveSettings failed: " + evt.data);
            },

            _onSuccess: function(responder, evt) {
                var data = getDataFromEvt(evt);

                var settings = [];
                SVMX.array.forEach(data, function(inItem) {
                    settings.push({
                        value: inItem.value,
                        key: inItem.setting_id
                    });
                });


                // TODO: See what properties from the full settings structure the online client receives we actually need
                responder.result({
                    stringMap: settings
                });

            }

        }, {});


        /* OPERATION: GetDetailMappedInfo
         * STATUS: Working.
         * @description Returns the DetailMap for the specified record type.  Called as part of adding a new record.
         * @param {string} processId ID of the process we are getting the mapping from
         * @param {string} alias Key/name for the line-item type we are adding.
         * TODO:
         *    1. Michael: Determine if performance is an issue.  Getting the entire Layout object each time this is
         *       called may be slow.
         */
        var GetDetailMappedInfoCache = {};
        sfmdeliveryoperations.Class("GetDetailMappedInfo", com.servicemax.client.mvc.api.Operation, {

            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {
                var processId = "",
                    uniqueProcessId = request.processId;
                var result = {
                    mappedLiterals: [],
                    mappedValues: []
                };
                execQuery({
                    query: "SELECT process_id FROM SFProcess where process_unique_id='{{pid}}'",
                    queryParams: {
                        pid: uniqueProcessId
                    }
                }).then(SVMX.proxy(this, function(data) {
                    if (!data || data.length == 0) {
                        responder.result(result);
                        var d = new $.Deferred();
                        d.fail(); // prevent next then clause
                        return d;
                    }
                    data = data[0];
                    return execQuery({
                        query: "SELECT object_name, object_mapping_id, value_mapping_id FROM SFProcessComponent where process_id='{{processId}}' and layout_id='{{alias}}'",
                        queryParams: {
                            processId: data.process_id,
                            alias: request.alias
                        }
                    });
                })).then(SVMX.proxy(this, function(data) {
                    if (!data || data.length == 0) {
                        responder.result(result);
                        var d = new $.Deferred();
                        d.fail(); // prevent next then clause
                        return d;
                    }
                    var d = new $.Deferred();
                    data = data[0];
                    var r = new RecordClass({}, data.object_name);
                    r.onReady(function() {
                        var ids = [];
                        if (data.value_mapping_id) ids.push(data.value_mapping_id);
                        if (data.object_mapping_id) ids.push(data.object_mapping_id);
                        execQuery({
                            query: "SELECT * FROM SFObjectMappingComponent WHERE object_mapping_id IN ('{{ids}}')",
                            queryParams: {
                                ids: ids.join("', '")
                            }
                        }).then(function(data) {
                            try {
                                d.resolve(data, r);
                            } catch(e) {
                                logger.error(e);
                                logger.error("Unexpected error in THEN handler for getDetailMappedInfo operation:" + e);
                            }
                        });
                    });
                    return d;
                })).then(SVMX.proxy(this, function(data, record) {
                    if (!data || data.length == 0) {
                        responder.result(result);
                        var d = new $.Deferred();
                        d.fail(); // prevent next then clause
                        return d;
                    }

                    var defs = [];
                    SVMX.array.forEach(data, function(d) {

                        // Source target mapping isn't part of this structure
                        if (!d.source_field_name) {
                            if (d.mapping_value.match(/^SVMX\./) || SVMX.array.indexOf(["Now", "Today", "Tomorrow", "Yesterday"], d.mapping_value) !== -1) {
                                result.mappedLiterals.push({
                                    key: d.target_field_name,
                                    value: d.mapping_value
                                });
                            } else {
                                var type = record.getFieldType(d.target_field_name);
                                if (!type) {
                                    console.error("User does not have permission to use: " + d.target_field_name);
                                    return;
                                }

                                if (type == "boolean") {
                                    d.mapping_value = String(d.mapping_value).toLowerCase();
                                }

                                if (type == "reference" && d.target_field_name != "RecordTypeId") {
                                    var value = d.mapping_value;
                                    var deferred = new $.Deferred();
                                    OfflineDataUtils.getRecord({
                                        Id: value,
                                        loadReferences: false,
                                        convertPicklists: false
                                    }).then(
                                        function(record) {
                                            result.mappedValues.push({
                                                key: d.target_field_name,
                                                //value: value,
                                                value: record.getNameValue()
                                            });
                                            deferred.resolve();
                                        },
                                        function(err) {
                                            result.mappedValues.push({
                                                key: d.target_field_name,
                                                value: value
                                            });
                                            deferred.resolve();
                                        }
                                    );
                                    defs.push(deferred);
                                } else {
                                    result.mappedValues.push({
                                        key: d.target_field_name,
                                        value: d.mapping_value
                                    });
                                }
                            }
                        }
                    }, this);

                    SVMX.when(defs).then(function() {
                        responder.result(result);
                    });
                }));

            }

        }, {});


        /* First version of GetLookupConfig operation, contains some hardcoded values required for working ahead/testing
         * Need to remove them.
         */
        sfmdeliveryoperations.Class("GetLookupConfig", com.servicemax.client.mvc.api.Operation, {

            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {
                var result = {};
                this.keyWord = request.KeyWord == null ? "" : request.KeyWord;
                this.searchOperator = request.SearchOperator;
                this.contextValue = request.LookupContext;
                this.contextMatchField = request.LookupQueryField;
                this.callType = request.callType;
                this.request = request;
                this.objectName = request.ObjectName;
                this.recordId = request.RecordId; // BubbleData only
                this.includePRIQRecords = true; // This Should always true as we want to search PRIQ DataBase
                this.searchOnlineRecord = request.searchOnlineRecord;
                this.__queryWithAFC = null;
                this.__actualLookupPreFilter = null;  //To save actual pre-filter criteria used to execute online SOQL.
                this.__actualLookupAdvFilters = [];   //To save actual adv-filter criteria used to execute online SOQL.


               // this.lookupQueryContext = request.LookupQueryContext;



                //TODO : Check usage of waitForData
                var waitForData = false,
                    lookupDef = null;

                // TODO: Build a single state object that contains this and responder and all other state
                // instead of having state vary from method to method within this class
                this.response = {
                    namesearchinfo: {
                        namedSearch: [{
                            namedSearchHdr: {},
                            namedSearchDetails: [{
                                fields: []
                            }]
                        }]
                    },
                    data: [],
                    advFilters: []
                };
                responder.__waitCounter = {
                    count: 0,
                    subRecordsStarted: false
                };

                OfflineMetaUtils.describeObject({
                    objectName: this.objectName,
                    onSuccess: SVMX.proxy(this, function(describeData) {
                        this.describeData = describeData;
                        this.fieldDefs = {};
                        SVMX.array.forEach(describeData.fields, function(f) {
                            this.fieldDefs[f.name] = f;
                        }, this);

                        if (request.LookupRecordId) {
                            key = request.LookupRecordId;
                            this.queryLookupData(responder, key, result);
                        } else {

                            // Stupid hack grabs a search completely at random!!!! TODO: FIX THIS!
                            execQuery({
                                query: "SELECT * FROM SFNamedSearch where object_name = '{{object_name}}' and is_default='true'",
                                queryParams: {
                                    object_name: this.objectName
                                }
                            }).then(SVMX.proxy(this, function(data) {
                                if (data && data.length) {
                                    key = data[0].search_sfid;
                                    this.queryLookupData(responder, key, result);
                                } else {
                                    logger.error("CONFIGURATION WARNING: There is neither a configured nor default LookupConfig for " + this.objectName);
                                    this.generateLookupData(this.objectName, responder, result);
                                }
                            }));
                            key = this.objectName;
                        }
                    }),

                    /**
                     * handles the error condition by calling the responder fault handler
                     *
                     * @event
                     * @param   {Event}         evt         event obeject
                     * @param   {String}        objectName
                     */
                    onError: SVMX.proxy(this, function(evt, objectName) {
                        // the error was logged prior to this; offline.sal.model/utils.js __onDescribeObjectError
                        responder.fault(evt, objectName);
                    })
                });
            },

            generateLookupData: function(objectName, responder, result) {
                responder.__waitCounter.count++;
                responder.__waitCounter.subRecordsStarted = true;

                var nameField = OfflineMetaUtils.getNameField(this.objectName);
                var data = [{
                    "expression_type": "SRCH_Object_Fields",
                    "field_name": nameField,
                    "search_object_field_type": "Search",
                    "field_type": "",
                    "field_relationship_name": "",
                    "sequence": "1.0000"
                }, {
                    "expression_type": "SRCH_Object_Fields",
                    "field_name": nameField,
                    "search_object_field_type": "Result",
                    "field_type": "",
                    "field_relationship_name": "",
                    "sequence": "2.0000"
                }];

                var lookupDefDetail = {
                        bubbleFields: [],
                        defaultLookupColumn: nameField,
                        displayFields: [data[1]],
                        numberOfRecs: 10,
                        preFilterCriteria: "",
                        queryColumns: "Id, Name",
                        searchFields: [data[0]]
                    };

                    var lookupDef = {
                        key: objectName,
                        advFilters: [],
                        lookupDefDetail: lookupDefDetail
                    };


                this.__prepareSearchUsingLookupDef(
                    {
                        responder: responder,
                        result: result
                    },
                    lookupDef
                );
            },

            //querying for all the lookupdata fields from SFNamedSearchComponent
            queryLookupData: function(responder, key, result) {
                responder.__waitCounter.count++;
                execQuery({
                    query: "SELECT * FROM SFNamedSearchComponent WHERE named_search = '{{key}}'",
                    queryParams: {
                        key: key
                    },
                    state: {
                        responder: responder,
                        result: result
                    },
                    context: this,
                    onSuccess: "_onQueryLookupDataSuccess",
                    onError: "_onQueryLookupDataError"
                });
            },

            //Define search and result fields
            _onQueryLookupDataSuccess: function(state, evt) {
                state.responder.__waitCounter.subRecordsStarted = true;

                var data = getDataFromEvt(evt),
                    key = data.length ? data[0].named_search : null,
                    i, l = data.length;
                if (data.length == 0) {
                    this._onGetLookupDefError(state.responder, SVMX.cloneObject(this.response), evt);
                    return;
                } else {
                    var describeData = this.describeData;
                            var fieldsHash = {};
                            SVMX.array.forEach(describeData.fields, function(f) {
                                fieldsHash[f.name] = true;
                            });
                            this.displayFields = [];
                            this.searchFields = [];
                            var displayFieldsHash = {};
                            var searchFieldsHash = {};
                            for (i = 0; i < l; i++) {
                                var fldName = data[i].field_name;

                                // TODO: Shouldn't we have a search_object_field_type == "Bubble"?  According to the Designer we should...
                                if (fieldsHash[fldName]) {
                                    if (data[i].search_object_field_type == "Result") {
                                        if (!displayFieldsHash[data[i].field_name]) {
                                            this.displayFields.push(data[i]);
                                            displayFieldsHash[data[i].field_name] = true;
                                        }
                                    }

                                    if (data[i].search_object_field_type == "Search") {
                                        if (!searchFieldsHash[data[i].field_name]) {
                                            this.searchFields.push(data[i]);
                                            searchFieldsHash[data[i].field_name] = true;
                                        }
                                    }
                                } else {
                                    logger.error("Minor Error: Lookup Config uses field '" + fldName + "' which is not available to this user");
                                }
                            }



                            this.getLookupDef(state.responder, key, state.result, displayFieldsHash);

                }
            },

            _onQueryLookupDataError: function(state, evt) {
                logger.info("No lookup data, NamedSearchComponent table might be empty");
                responder.result(state.result);
            },

            //Define the lookup definition by querying for the fields from SFNamedSearch
            getLookupDef: function(responder, key, result, displayFieldsHash) {

                execQuery({
                    query: "SELECT * FROM SFNamedSearch where search_sfid = '{{key}}'",
                    queryParams: {
                        key: key
                    },
                    state: {
                        responder: responder,
                        result: result,
                        key: key
                    },
                    context: this,
                    onSuccess: "_onGetLookupDefSuccess",
                    onError: "_onGetLookupDefError"
                });
            },

            _onGetLookupDefSuccess: function(state, evt) {
                state.result.data = getDataFromEvt(evt);
                //TODO IMP : check where the query columns info is coming from in the table
                var key = state.result.data[0].object_name, me = this,
                    displayFields1 = this.displayFields,
                    searchFields = this.searchFields,
                    numOfRecords = state.result.data[0].no_of_lookup_records;

                var d1 = this.getPreFilterCriteria(state.responder, state.key, state.result);
                var d2 = this.getAdvFilterCriteria(state.responder, state.key, state.result);
                SVMX.when([d1,d2]).then(SVMX.proxy(this, function() {
                    if (me.pfc) {
                        me.pfc = me.__convertOnlineExpressionToSQL(me.pfc);
                    }

                    var deferreds = [];
                    for (var i = 0; i < me.afc.length; i++) {
                        var filterCriteria = me.afc[i].filterCriteria;
                        if (filterCriteria.indexOf("RecordType.Name") >= 0) {
                            deferreds.push(this.__getRecordTypeId(i));
                        }
                    }
                    SVMX.when(deferreds).then(SVMX.proxy(this, function() {
                        var lookupDefDetail = {
                            bubbleFields: [],
                            defaultLookupColumn: state.result.data[0].default_lookup_column,
                            displayFields: displayFields1,
                            numberOfRecs: state.result.data[0].no_of_lookup_records,
                            preFilterCriteria: me.pfc,
                            queryColumns: "Id, Name",
                            searchFields: searchFields
                        };
                        //update queryColumns with display field
                        if(lookupDefDetail.displayFields != null && lookupDefDetail.displayFields.length > 0){
                            var fields = lookupDefDetail.displayFields, i = 0, l = fields.length, query = '';
                            var fieldSet = {"Id" : true, "Name" : true};
                            for(i = 0; i < l; i++){
                                if (!fieldSet[fields[i].field_name]) {
                                    if(query.length > 0){
                                        query += ', '+fields[i].field_name;
                                    }
                                    else{
                                      query += fields[i].field_name;
                                    }
                                }
                                fieldSet[fields[i].field_name] = true;
                            }
                            if(query.length > 0){
                              lookupDefDetail.queryColumns += ', '+query;
                            }
                        }
                        var lookupDef = {
                            key: key,
                            advFilters: me.afc,
                            lookupDefDetail: lookupDefDetail
                        };
                        return me.__prepareSearchUsingLookupDef(state, lookupDef);
                    }));

                }));
            },

            __getRecordTypeId: function(index) {
                var d = new $.Deferred();
                //Get the RecordType.Name Id from database
                //Expression matches RecordType.Name='some-name-here'
                var filterCriteria = this.afc[index].filterCriteria;
                var expr = filterCriteria.match(/RecordType.Name=['].*\S[']/g)[0];
                //Get some-name-here
                var recordTypeName = expr.substring(expr.indexOf("'") + 1, expr.length - 1);
                execQuery({
                    query : "SELECT * FROM RecordType WHERE Name='{{recordTypeName}}' AND SobjectType='{{objectType}}'",
                    queryParams : {
                        recordTypeName : recordTypeName,
                        objectType: this.afc[index].filterObject
                    }
                }).then(SVMX.proxy(this, function(data) {
                    var expr = filterCriteria.match(/RecordType.Name=['].*\S[']/g)[0];
                    this.afc[index].filterCriteria = filterCriteria.replace(expr, "RecordTypeId='" + data[0].Id + "'");
                    d.resolve();
                }));
                return d;
            },

            __convertOnlineExpressionToSQL: function(expression) {
                var subquery = expression.match(/(?:([A-z0-9_-]+ ?(?:<>|!=|=) ?[^ ()]+)(?: ?(?:AND|OR))?)+/ig);
                if (subquery) {
                    for (var j in subquery) {
                        var ex = subquery[j].match(/([A-z0-9_-]+ ?!= ?(?:NULL)+)/ig);
                        var ex1 = subquery[j].match(/([A-z0-9_-]+ ?= ?(?:NULL)+)/ig);
                        var changeBooleanTrue = subquery[j].match(/([A-z0-9_-]+ ?(?:<>|!=|=) ?(?:true)+)/ig);
                        var changeBooleanFalse = subquery[j].match(/([A-z0-9_-]+ ?(?:<>|!=|=) ?(?:false)+)/ig);
                        if (ex != null) {
                            var reg = ex[0].match(/([A-z0-9_-]+)/ig);
                            expression = expression.replace(ex[0], "(" + reg[0] + " IS NOT NULL AND " + reg[0] + " IS NOT ''" + ")");
                        }
                        if (ex1 != null) {
                            var reg1 = ex1[0].match(/([A-z0-9_-]+)/ig);
                            expression = expression.replace(ex1[0], "(" + reg1[0] + " IS NULL OR " + reg1[0] + " IS ''" + ")");
                        }
                        if (changeBooleanTrue != null) {
                            var reg2 = changeBooleanTrue[0].match(/([A-z0-9_-]+ ?(?:<>|!=|=))/ig);
                            expression = expression.replace(changeBooleanTrue[0], reg2[0] + "'true'");
                        }
                        if (changeBooleanFalse != null) {
                            var reg3 = changeBooleanFalse[0].match(/([A-z0-9_-]+ ?(?:<>|!=|=))/ig);
                            expression = expression.replace(changeBooleanFalse[0], reg3[0] + "'false'");
                        }

                    }
                }
                return expression;
            },

            __prepareSearchUsingLookupDef: function(state, lookupDef) {
                var me = this;
                var namedSearchHdr = me.response.namesearchinfo.namedSearch[0].namedSearchHdr,
                    namedSearchDetails = me.response.namesearchinfo.namedSearch[0].namedSearchDetails[0],
                    fields = namedSearchDetails.fields,
                    i, l;

                namedSearchHdr[SVMX.OrgNamespace + "__Default_Lookup_Column__c"] = lookupDef.lookupDefDetail.defaultLookupColumn;

                var displayFields = lookupDef.lookupDefDetail.displayFields,
                    l = displayFields.length,
                    fld;

                for (i = 0; i < l; i++) {
                    fld = {};
                    fld[SVMX.OrgNamespace + "__Field_Name__c"] = displayFields[i].field_name;
                    fld[SVMX.OrgNamespace + "__Sequence__c"] = displayFields[i].sequence;
                    fld[SVMX.OrgNamespace + "__Search_Object_Field_Type__c"] = "Result";
                    fld["nameField"] = null; //displayFields[i].refObjectNameField;
                    fld["dataType"] = displayFields[i].field_type;
                    fld["relationshipName"] = displayFields[i].field_relationship_name;
                    fields.push(fld);
                }
                var requestData = {};

                //TODO : Check if the following condition is required
                //TODO: Find out what we are REALLY suppose to do with META; only here
                //because without it, lookups fail.
                if (me.callType == "DATA" || me.callType == "BOTH" || me.callType == "META" || me.callType == "BUBBLE") {
                    waitForData = true;
                    requestData.lookupRequest = {
                        LookupDef: lookupDef,
                        KeyWord: me.keyWord,
                        Operator: me.searchOperator,
                        ContextValue: me.contextValue,
                        ContextMatchField: me.contextMatchField
                       // LookupQueryContext: me.lookupQueryContext
                    };
                }


                var lookupRequest = {
                    LookupDef: lookupDef,
                    KeyWord: this.keyWord,
                    Operator: this.searchOperator,
                    ContextValue: this.contextValue,
                    ContextMatchField: this.contextMatchField
                };
                this.getLUPSearchResults(state.responder, state.result, requestData.lookupRequest, fields, state.key, lookupDef.lookupDefDetail.numberOfRecs);
            },


            getPreFilterCriteria : function(responder, key, result){
                var d = new $.Deferred();
                execQuery({
                    query: "SELECT * FROM SFNamedSearchCriteria WHERE named_search = '{{key}}' AND rule_type = 'SRCH_OBJECT'",
                    queryParams: {key : key},
                    context: this,
                    state : {responder : responder, key : key, result : result, d:d},
                    onSuccess : "_onGetPFCSuccess",
                    onError: "_onGetPFCError"
                });
                return d;
            },

            getAdvFilterCriteria : function(responder, key, result){
                var d = new $.Deferred();
                execQuery({
                    query: "SELECT * FROM SFNamedSearchCriteria WHERE named_search = '{{key}}' AND rule_type = 'SRCH_CRITERIA'",
                    queryParams: {key : key},
                    context: this,
                    state : {responder : responder, key : key, result : result, d:d},
                    onSuccess : "_onGetAFCSuccess",
                    onError: "_onGetAFCError"
                });
                return d;
            },

            _onGetAFCSuccess : function(state, evt){
                this.afc  = getDataFromEvt(evt);
                var advFilters = [], afc = this.afc, l = afc.length, found = false;

                //Start => check if there are duplciate entries of the filters
                for(var i = 0; i < l; i++){
                    if(advFilters.length > 0){
                        for(var k =0; k < advFilters.length; k++){
                            if(advFilters[k].key == this.afc[i].id)
                            found = true;
                        }
                    }

                    if(!found)

                        // Store actual Advanced filters (in __actualLookupAdvFilters variable) for online lookup.
                        // No need to handle date/datetime literals (today, tomorrow, yesterday and Now).
                        // Since this will execute on Salesforce, and Salesforce supports date/ datetime literal.
                        this.__actualLookupAdvFilters.push({key: afc[i].id, filterCriteria : afc[i].parent_object_criteria});

                        advFilters.push({
                            allowOverride : afc[i].allow_override,
                            defaultOn : afc[i].default_on,
                            //Ensure TODAY, TOMORROW, YESTERDAY, NOW are handled correctly.
                            filterCriteria : this.__convertOnlineExpressionToSQL(this.sqlFixCriteria(afc[i].parent_object_criteria)),
                            filterCriteriaFields : [],
                            filterName : afc[i].name,
                            filterObject : afc[i].source_object_name,
                            key : afc[i].id,
                            lookupField : afc[i].field_name
                        });

                        found = false;
                }
                //End => check if there are duplciate entries of the filters

                this.afc = advFilters;
                state.d.resolve();
            },

            _onGetPFCSuccess : function(state, evt){
                var data  = getDataFromEvt(evt);

                // Store actual Pre filters (in __actualLookupPreFilter variable) for online lookup.
                // No need to handle date/datetime literals (today, tomorrow, yesterday and Now).
                // Since this will execute on Salesforce, and Salesforce supports date/ datetime literal.
                this.__actualLookupPreFilter = data[0].parent_object_criteria;

                //Ensure TODAY, TOMORROW, YESTERDAY, NOW are handled correctly.
                this.pfc = this.sqlFixCriteria(data[0].parent_object_criteria);
                state.d.resolve();
            },

            _onGetLookupDefError: function(state, evt) {
                logger.info("Could not fetch lookupdef, NamedSearch table might be empty");
                this.afc = [];
                state.d.resolve();
            },

            getLUPSearchResults: function(responder, result, lookupRequest, fields, key, numOfRecords) {
                var req = nativeService.createSQLRequest(),
                    keyword = lookupRequest.KeyWord,
                    lookupDef = lookupRequest.LookupDef,
                    displayCols = [],
                    relatedDisplayCols = [],
                    searchCols = [],
                    joinCols = [];
                var dict = [];
                var operator = lookupRequest.Operator;
                this.referenceFields = {};

                //Will be used to replace RecordType.Name in the WHERE clause later
                var recordTypeTableAlias = null,
                    pfc = lookupDef.lookupDefDetail.preFilterCriteria || "";


                //For alias string replacement
                var rep = {};

                //Get all the search fields
                var displayFields = lookupDef.lookupDefDetail.displayFields,
                    i, l = displayFields.length;
                for (i = 0; i < l; i++) {
                    var fieldDef = this.fieldDefs[displayFields[i].field_name];
                    if (fieldDef.type == "reference") {
                        //Ugly hack, to handle RecordType.Name in the WHERE clause
                        var relatedTable = SVMX.array.get(fieldDef.referenceTo, function(tableName) {
                            return OfflineMetaUtils.isTableInDatabase(tableName);
                        });
                        if (!recordTypeTableAlias && relatedTable && relatedTable == 'RecordType') {
                            //Save the alias so we can try and replace later. We only care about the first
                            recordTypeTableAlias = "tbl" + i;
                        }

                        //Update out pre-filter criteria with table aliases
                        if (relatedTable) {
                            rep[relatedTable] = "tbl" + i;
                        }

                        this._addReferenceToQuery({
                            fieldDef: fieldDef,
                            joinCols: joinCols,
                            displayCols: displayCols,
                            relatedDisplayCols: relatedDisplayCols,
                            searchCols: null,
                            alias: "tbl" + i
                        });
                        dict.push ({key: fieldDef.relationshipName, value: "tbl" + i});

                    } else {
                        displayCols.push("MAIN." + displayFields[i].field_name);
                    }
                }

                var searchFields = lookupDef.lookupDefDetail.searchFields,
                    i, l = searchFields.length;
                for (i = 0; i < l; i++) {
                    var fieldDef = this.fieldDefs[searchFields[i].field_name];
                    if (fieldDef.type == "reference") {
                        //Ugly hack, to handle RecordType.Name in the WHERE clause
                        var relatedTable = SVMX.array.get(fieldDef.referenceTo, function(tableName) {
                            return OfflineMetaUtils.isTableInDatabase(tableName);
                        });
                        if (!recordTypeTableAlias && relatedTable && relatedTable == 'RecordType') {
                            //Save the alias so we can try and replace later. We only care about the first
                            recordTypeTableAlias = "tblsearch" + i;
                        }

                        //Update out pre-filter criteria with table aliases
                        if (relatedTable) {
                            rep[relatedTable] = "tblsearch" + i;
                        }

                        this._addReferenceToQuery({
                            fieldDef: fieldDef,
                            joinCols: joinCols,
                            displayCols: null,
                            relatedDisplayCols: null,
                            searchCols: searchCols,
                            alias: "tblsearch" + i
                        });
                    } else {
                        searchCols.push("MAIN." + searchFields[i].field_name + " qry");
                    }
                }

                //Defect Fix 24782 - Starting Here
                //TODO : Clean up might be required
                if(!recordTypeTableAlias && pfc && pfc.indexOf("RecordType.Name") >0){
                    var fieldDef = this.fieldDefs["RecordTypeId"];

                    recordTypeTableAlias = "tblsearchRecordType";
                     //Update out pre-filter criteria with table aliases
                    if (relatedTable) {
                        rep["RecordType"] = "tblsearchRecordType";
                    }

                    this._addReferenceToQuery({
                        fieldDef: fieldDef,
                        joinCols: joinCols,
                        displayCols: null,
                        relatedDisplayCols: null,
                        searchCols: searchCols,
                        alias: "tblsearchRecordType"
                    });
                }
                //Defect Fix 24782 - Ends Here

                // If this is a local record then add Id into search columns
                if(keyword.match('_local_')){
                    keyword = keyword.replace(/ /g, '');
                    searchCols.push("MAIN.Id" + " qry");
                }

                var queryWithContext = 1;
                //respect context if present
                if(lookupRequest.ContextMatchField != undefined && lookupRequest.ContextValue != undefined){
                    queryWithContext = this.stitchLUPContextToQuery(lookupRequest, responder);
                }
                //stitch the query with advfilter criteria
                var queryWithAFC = this.stitchAdvFiltersToQuery(lookupDef, responder, key), advCriteria= '';
                this.__queryWithAFC = queryWithAFC;

                if(queryWithAFC.advFilters.length > 0){
                    for (var advFiltersIdx = 0; advFiltersIdx < queryWithAFC.advFilters.length; advFiltersIdx++) {
                        var advFilter = queryWithAFC.advFilters[advFiltersIdx];
                        // Add join to the filterObject table
                        joinCols.push(SVMX.string.substitute(
                            "LEFT JOIN '{{advFilterObj}}' ON '{{advFilterObj}}'.'{{lupField}}' = MAIN.Id",
                            {
                               advFilterObj : advFilter.filterObject,
                               lupField : advFilter.lookupField
                            }
                        ));
                        // if(!recordTypeTableAlias && advFilter && advFilter.filterCriteria.indexOf("RecordType.Name") >0){
                        //     var filterObjectFieldDef = {};
                        //     OfflineMetaUtils.describeObject({
                        //         objectName: advFilter.filterObject,
                        //         onSuccess: SVMX.proxy(this, function(describeData) {
                        //             filterObjectFieldDef = {};
                        //             SVMX.array.forEach(describeData.fields, function(f) {
                        //                 filterObjectFieldDef[f.name] = f;
                        //             }, this);
                        //         }),
                        //         onError: SVMX.proxy(this, function(evt, objectName) {
                        //           // the error was logged prior to this; offline.sal.model/utils.js __onDescribeObjectError
                        //           responder.fault(evt, objectName);
                        //         })
                        //     });
                        //
                        //     var fieldDef = filterObjectFieldDef["RecordTypeId"];
                        //
                        //     recordTypeTableAlias = "tblsearchRecordType";
                        //      //Update out pre-filter criteria with table aliases
                        //     if (relatedTable) {
                        //         rep["RecordType"] = "tblsearchRecordType";
                        //     }
                        //
                        //     this._addReferenceToQuery({
                        //         fieldDef: fieldDef,
                        //         joinCols: joinCols,
                        //         displayCols: null,
                        //         relatedDisplayCols: null,
                        //         searchCols: null,
                        //         alias: "tblsearchRecordType",
                        //         otherTableAlias: advFilter.filterObject
                        //     });
                        // }
                        // Combine all selected advanced criteria
                        if (advFiltersIdx > 0) {
                            advCriteria = advCriteria + " AND ";
                        }
                        // add/change parent table names for advanced filter queries.
                        var filterCriteria = advFilter.filterCriteria;
                        filterCriteria = this.__prependAliasToField(filterCriteria, advFilter.filterObject);



                        advCriteria = advCriteria + filterCriteria;
                    }

                    advCriteria = "(" + advCriteria + ")";
                }

                //Hack to replace RecordType in RecordType.Name with an alias
                if (recordTypeTableAlias) {
                    //Take care of the prefilter
                    if (lookupDef.lookupDefDetail.preFilterCriteria) {
                        lookupDef.lookupDefDetail.preFilterCriteria = lookupDef.lookupDefDetail.preFilterCriteria.replace('RecordType.Name', recordTypeTableAlias + '.Name');
                    }
                    //Take care of all the advanced criteria
                    if (advCriteria) {
                        advCriteria = advCriteria.replace('RecordType.Name', recordTypeTableAlias + '.Name');
                    }
                }

                //Prepare our criteria so it is easier to replace table references with aliases
                advCriteria = this.sqlAliasPrepSub(advCriteria, displayFields);
                lookupDef.lookupDefDetail.preFilterCriteria = this.sqlAliasPrepSub(lookupDef.lookupDefDetail.preFilterCriteria, displayFields);

                //Replace and table references in the criteria with aliases
                advCriteria = SVMX.string.substitute(
                    advCriteria,
                    rep
                );
                lookupDef.lookupDefDetail.preFilterCriteria = SVMX.string.substitute(
                    lookupDef.lookupDefDetail.preFilterCriteria,
                    rep
                );

                var initialQuery = SVMX.string.substitute(
                    "SELECT DISTINCT MAIN.* FROM `{{object_name}}` AS MAIN " + joinCols.join("\n") + " WHERE (temp)",
                    {
                       object_name: this.objectName
                    }
                );

                var query = this.buildQuery(initialQuery, operator, displayCols, relatedDisplayCols, searchCols, keyword, lookupDef, responder, key, this.objectName, advCriteria, queryWithContext, dict);

                // Bubble info
                if (this.recordId) {
                    query += " AND MAIN.Id='" + this.recordId + "'";
                } else {
                    query +=  " LIMIT " + numOfRecords;
                }

                req.bind("REQUEST_COMPLETED", SVMX.proxy(this, "_getLUPSearchResultsSuccess", responder, result, lookupRequest, fields, query));
                req.bind("REQUEST_ERROR", SVMX.proxy(this, "_getLUPSearchResultsError", responder, result, lookupRequest, fields));

                req.execute({
                    query: query
                });
            },

            _addReferenceToQuery : function(inParams) {
                var tableAlias = "MAIN";
                var relatedTable = SVMX.array.get(inParams.fieldDef.referenceTo, function(tableName) {
                    return OfflineMetaUtils.isTableInDatabase(tableName);
                });
                if (!relatedTable) return;
                var nameField = OfflineMetaUtils.getNameField(relatedTable);
                if (!nameField) return;
                this.referenceFields[inParams.fieldDef.name] = relatedTable;
                //If record type is on the other table not on Main table then replace Main with othet table alias.
                // if (inParams.otherTableAlias){
                //   tableAlias = inParams.otherTableAlias;
                // }
                inParams.joinCols.push(SVMX.string.substitute(
                    "LEFT JOIN `{{related_table_name}}` as {{alias}} ON {{alias}}.Id = {{table_alias}}.{{source_field_name}}",
                    {
                        table_name: this.objectName,
                        alias: inParams.alias,
                        source_field_name: inParams.fieldDef.name,
                        related_table_name: relatedTable,
                        table_alias: tableAlias
                    }
                ));
                if (inParams.displayCols) {
                    inParams.displayCols.push("MAIN." + inParams.fieldDef.name);
                }
                if (inParams.searchCols) {
                   inParams.searchCols.push(SVMX.string.substitute(
                        "`{{related_table_name}}`.{{field_name}} qry",
                        {related_table_name: inParams.alias, field_name: nameField}
                    ));
                }
                if (inParams.relatedDisplayCols) {
                    inParams.relatedDisplayCols.push(inParams.alias + "." + nameField + " as " + inParams.fieldDef.name.replace(/(__c)?$/, "__r"));
                }
            },

            _onGetPFCError : function(state, evt){
                logger.info("Could not fetch lookupdef, NamedSearch table might be empty");
                this.pfc = [];
                state.d.resolve();
            },

            buildQuery : function(initialQuery, operator, displayCols, relatedDisplayCols, searchCols, keyword, lookupDef, responder, key, objName, advCriteria, queryWithContext, dict) {
                //replace * with displayfields
                var whereQry = "";
                var query = initialQuery;
                var allDisplayCols = displayCols.concat(relatedDisplayCols);

                // Lookup queries need ALL fields so formfield mappings can be executed
                if (this.callType == "BUBBLE") {
                    query = initialQuery.replace("MAIN\.*", allDisplayCols.join());
                } else if (relatedDisplayCols.length) {
                    query = initialQuery.replace("*", "*, " + relatedDisplayCols.join(","));
                }

                //replace temp with searchfields
                whereQry = searchCols.join(" OR ");
                if (whereQry) whereQry = "(" + whereQry + ")";

                //stitch the query with prefilter criteria
                var queryWithPFC = this.stitchPreFilterCriteriaToQuery(lookupDef, responder, key), afc;
                if(queryWithPFC != ""){
                    queryWithPFC = this.__prependAliasToField(queryWithPFC, "MAIN");
                }

                if(queryWithPFC == "" || queryWithPFC == undefined){
                    queryWithPFC = 1;
                }

                var finalQuery = queryWithContext + " AND " + queryWithPFC;
                if(advCriteria !== null && advCriteria != undefined && advCriteria != ""){
                    advCriteria = this.__prependAliasToField(advCriteria, "MAIN");
                    finalQuery = finalQuery + " AND " + advCriteria;
                }

                if(dict) {
                        for(var i in dict ){
                            if(query.search(dict[i].key) > -1 && finalQuery.search(dict[i].key+ "\\.") > -1){
                                    finalQuery = finalQuery.replace(dict[i].key, dict[i].value);
                            }
                        }
                    }

                //TODO Imp : Check what happens when keyword is not present
                if (keyword !== "") {
                    switch (operator) {
                    case "contains":
                        var a = " LIKE '%" + keyword + "%'";
                        var b = finalQuery + " AND " + whereQry.split(' qry').join(a);
                        var formattedQuery = query.replace("temp", b);
                        return formattedQuery;
                    case "ew":
                        var a = " LIKE '%" + keyword + "'";
                        var b = finalQuery + " AND " + whereQry.split(' qry').join(a);
                        var formattedQuery = query.replace("temp", b);
                        return formattedQuery;
                    case "sw":
                        var a = " LIKE '" + keyword + "%'";
                        var b = finalQuery + " AND " + whereQry.split(' qry').join(a);
                        var formattedQuery = query.replace("temp", b);
                        return formattedQuery;
                    case "eq":
                        var a = " = '" + keyword + "'";
                        var b = finalQuery + " AND " + whereQry.split(' qry').join(a);
                        var formattedQuery = query.replace("temp", b);
                        return formattedQuery;
                        //TODO : implement default
                    }
                } else {
                    return query.replace("temp", finalQuery);
                }
            },

            __prependAliasToField: function(expression, alias) {

                //var subquery = expression.match(/(?:([A-z0-9._\-]+ ?(?:LIKE|>|<|>?=|<?=|!?=) ?[^ ()]+))(?: ?(?:AND|OR)?)+/ig);
                //var unEditable = expression.match(/(?:([A-z0-9_\-]+ ?(?:LIKE|>|<|>?=|<?=|!?=) ?[^ ()]+))(?: ?(?:AND|OR)?)+/ig);

                //Since field of word containing "Is" (example IsActive, IsAvailable) was not working because of below reguler expression.
                // Updated below two expression by added space after IS to solve this issue.
                var subquery = expression.match(/(?:((?:cast\()?[A-z0-9._\-]+ ?(?:as (?:double|float)\))?(?:LIKE|IS NOT|IS |>|<|>?=|<?=|!?=) ?[^ ()]+))(?: ?(?:(^|\s)(AND|OR)(?=\s|$))?)+/ig);
                var unEditable = expression.match(/(?:((?:cast\()?[A-z0-9._\-]+ ?(?:as (?:double|float)\))?(?:LIKE|IS NOT|IS |>|<|>?=|<?=|!?=) ?[^ ()]+))(?: ?(?:(^|\s)(AND|OR)(?=\s|$))?)+/ig);
                var castRegex = /(?:cast\()([A-z0-9._\-]+) as (?:double|float)\)((?:LIKE|IS NOT|IS|>|<|>?=|<?=|!?=) ?[^ ()]+)/ig
                if(subquery !== undefined && subquery !== null && subquery.length > 0){
                  for(var i = 0; i < subquery.length; i++){
                    var field = null;
					field = castRegex.exec(subquery[i]);
					castRegex.lastIndex = 0;
                    if(field != null && field.length > 0){
                      subquery[i] = field[1];
                    }
                  }
                }
                if(unEditable !== undefined && unEditable !== null && unEditable.length > 0){
                  for(var i = 0; i < unEditable.length; i++){
                    var field = castRegex.exec(unEditable[i]);
                    if(field != null && field.length > 0){
                      unEditable[i] = field[1];
                    }
                  }
                }
                var checkField;
                var fieldsToEdit = [];
                if(subquery !== undefined && unEditable !== undefined && subquery !== null && unEditable !== null){
                  for(var i = 0; i < unEditable.length; i++ ){
                      checkField = unEditable[i];
                      for(var j = 0; j < subquery.length; j++ ){
                          if(subquery[j] == checkField){
                              fieldsToEdit.push(subquery[j]);
                          }
                      }
                  }

                  //remove duplicates from fieldsToEdit
                  var map = {};
                  var newFieldsToEdit = [];
                  for(var k in fieldsToEdit) {
                      k = fieldsToEdit[k];
                      var index = Math.max(k.indexOf('='), k.indexOf('>'), k.indexOf('<'));
                      if (index > -1) {
                          if(k.substring(0, index).indexOf('.') > -1)
                          continue;
                      }
                      else {
                          if(k.indexOf(".") > -1) {
                              continue;
                          }
                      }
                      if (k.substring(0, 4) == "AND ") {
                         k = k.substring(4);
                      }
                      if (map[k] == null) {
                          map[k] = 1;
                          newFieldsToEdit.push(k);
                      }
                  }

                  fieldsToEdit = newFieldsToEdit;

                  for(var k in fieldsToEdit){
                      // if(alias == "MAIN" ){
                      //     expression = expression.replace(fieldsToEdit[k], alias + "."+fieldsToEdit[k]);
                      // } else if(alias != "MAIN" && fieldsToEdit[k].indexOf("RecordType.Name") >= 0){
                      //     continue;
                      // }
                      expression = expression.replace(fieldsToEdit[k], alias + "."+fieldsToEdit[k]);
                  }
                }
                return expression;
            },

            stitchPreFilterCriteriaToQuery : function(lookupDef, responder, key){
                //Replace literals with value
                var pfc = "";

                if(responder.__parent !== undefined || responder.__parent != null){
                    var pfc = lookupDef.lookupDefDetail.preFilterCriteria, refMetaModel = responder.__parent.getReferenceMetaModel();
                    pfc = OpUtils.replaceLiteralsWithValue(pfc, refMetaModel, key, true);
                    //if it has boolean values, convert it to string
                    pfc = OpUtils.replaceBoolToString(pfc);

                    // Replace literals (SVMX.CURRENTRECORDHEADER and SVMX.CURRENTRECORD) with value for Salesforce lookup request
                    this.__actualLookupPreFilter = OpUtils.replaceLiteralsWithValue(this.__actualLookupPreFilter, refMetaModel, key, true);
                }
                return pfc;
            },

            stitchLUPContextToQuery : function(lookupRequest, responder){
                var contextCriteria = 1;
                if(responder.__parent !== undefined || responder.__parent != null){
                    // contextCriteria = lookupRequest.ContextMatchField + " LIKE " +  "'" +lookupRequest.ContextValue + "'";
                    contextCriteria = " MAIN." + lookupRequest.ContextMatchField + " LIKE " +  "'" +lookupRequest.ContextValue + "'";
                }
                return contextCriteria;
            },

            stitchAdvFiltersToQuery : function(lookupDef, responder, key){
                //Replace literals with value
                if(responder.__parent !== undefined || responder.__parent != null){
                    var lookupDefRequest = SVMX.cloneObject(lookupDef), refMetaModel = responder.__parent.getReferenceMetaModel();;
                    var afc = OpUtils.extractDefWithFiltersToQuery(this.request, lookupDefRequest);
                    for(var i = 0; i < afc.advFilters.length; i++){
                        var filterCriteria = OpUtils.replaceLiteralsWithValue(afc.advFilters[i].filterCriteria, refMetaModel, key, true);
                        afc.advFilters[i].filterCriteria = filterCriteria;
                    }

                  //Start:  Replace literals (SVMX.CURRENTRECORDHEADER and SVMX.CURRENTRECORD) with value for Salesforce lookup request.
                  // 1. Created temporary lookup request which has actual advanced filter criteria.
                  // 2. Replace literals (SVMX.CURRENTRECORDHEADER and SVMX.CURRENTRECORD) from actual advanced filter criteria.
                  var sfdcLookupDefRequest = SVMX.cloneObject(lookupDef), refMetaModel = responder.__parent.getReferenceMetaModel();
                  if(sfdcLookupDefRequest && sfdcLookupDefRequest.advFilters && sfdcLookupDefRequest.advFilters.length > 0) {
                    for(var i=0; i<sfdcLookupDefRequest.advFilters.length; i++) {
                      if(this.__actualLookupAdvFilters && this.__actualLookupAdvFilters.length > 0) {
                        for(var k=0; k<this.__actualLookupAdvFilters.length; k++) {
                          if(this.__actualLookupAdvFilters[k].key === sfdcLookupDefRequest.advFilters[i].key) {
                            sfdcLookupDefRequest.advFilters[i].filterCriteria = this.__actualLookupAdvFilters[k].filterCriteria;
                            break;
                          }
                        }
                      }
                    }
                  }

                  // 3. Updated variable (__actualLookupAdvFilters) with replaced literals.
                  var sfdcAFC = OpUtils.extractDefWithFiltersToQuery(this.request, sfdcLookupDefRequest);
                  if(sfdcAFC && sfdcAFC.advFilters && sfdcAFC.advFilters.length > 0) {
                    for(var i=0; i<sfdcAFC.advFilters.length; i++) {
                      var filterCriteria = OpUtils.replaceLiteralsWithValue(sfdcAFC.advFilters[i].filterCriteria, refMetaModel, key, true);
                      if(this.__actualLookupAdvFilters && this.__actualLookupAdvFilters.length > 0) {
                        for(var k=0; k<this.__actualLookupAdvFilters.length; k++) {
                          if(this.__actualLookupAdvFilters[k].key === sfdcAFC.advFilters[i].key) {
                            this.__actualLookupAdvFilters[k].filterCriteria = filterCriteria;
                            break;
                          }
                        }
                      }
                    }
                  }
                  //end

                }else{
                    var afc = {advFilters : []};
                }

                return afc;
            },

            /*
             * 1) converts the LUP Search results datetime to include timezone offsets
             * 2) creates display records
             * 3) trigger completed method
             */
            _processLUPSearchResults: function(userInfo, responder, result, lookupRequest, fields) {
                var offset = userInfo.TimezoneOffset;

                // Turn all those reference fields into something clearer
                // Though online doesn't yet provide Value so it can't be used yet.
                SVMX.array.forEach(result.data, function(item) {
                    var record = new RecordClass(result.data, lookupRequest.LookupDef.key);
                    var dateTimeFields = record.getFieldsByType("datetime");
                    var hashTable = {};

                    SVMX.array.forEach(dateTimeFields, function(item, idx){
                        hashTable[item.name] = true;
                    });

                    SVMX.forEachProperty(item, SVMX.proxy(this, function(inFieldName, inValue) {
                        //convert datetime
                        if (hashTable[inFieldName]) {
                            item[inFieldName] = inValue;
                        }

                        if (inFieldName.match(/__r$/)) {
                            var keyName = inFieldName.replace(/__r$/,"__c");
                            if (!(keyName in this.referenceFields)) {
                                keyName = keyName.replace(/__c$/,"");
                            }
                            var value = {
                                "attributes": {
                                    "type": this.referenceFields[keyName],
                                    "url": "TODO"
                                },
                                "Name": inValue,
                                "Value": item[keyName]
                            };

                            var field = SVMX.array.get(fields, function(f) {
                                return f[SVMX.OrgNamespace + "__Field_Name__c"] == keyName;
                            });

                            //check if feild exist
                            if(field){
                                item[field.relationshipName] = value;
                            }

                        }
                    }));
                }, this);

                this.response.data = this.__createDisplayRecords(result.data, fields);
                this.response.advFilters = lookupRequest.LookupDef.advFilters;

                this._onSearchCompleted(responder, this.response);
            },

            /*
             * 1) gets the data from the event object,
             * 2) preprocess non"Bubble" call types
             * 3) fetch user data
             * 3a) success: process the results
             * 3b) fail: log error
             */
            _getLUPSearchResultsSuccess: function(responder, result, lookupRequest, fields, query, evt) {
                me = this;
                result.data = getDataFromEvt(evt);
                /*if (this.callType != "BUBBLE") {
                    SVMX.array.forEach(result.data, function(item) {
                        item.svmx_disabled = Boolean(item.Id && item.Id.match(/_local_/));
                    });
                }*/
                //get the user info first, then process
                var userInfo = OfflineSystemUtils.getUserInfo();
                var localRecords = result.data;
                var noOfRecordsToBeSearched = parseInt(lookupRequest.LookupDef.lookupDefDetail.numberOfRecs);
                // Perform ProductIQ DB and online Search. If number of reocords found from local database don't need to search other database.
                // do not search PRIQ Database for objects other than location and IB
                if(noOfRecordsToBeSearched === localRecords.length){
                    me.includePRIQRecords = false;

                }
                else if(!(me.objectName == SVMX.OrgNamespace +'__Installed_Product__c' || me.objectName == SVMX.OrgNamespace +'__Site__c')){
                    me.includePRIQRecords = false;
                }
                me.__findPRIQRecords(userInfo, query,me.includePRIQRecords,lookupRequest.LookupDef.key)
                .done(function(mflRecords, isValid){
                   me.__findServerRecords(lookupRequest, me.searchOnlineRecord, me.__queryWithAFC)
                    .done(function(serverRecords){
                        var records = me.__mergeRecords(localRecords, mflRecords, serverRecords, noOfRecordsToBeSearched);
                        result.data = records;
                        me._processLUPSearchResults(userInfo, responder, result, lookupRequest, fields);
                    });
                });
            },

            __findServerRecords : function(lookupRequest, searchOnlineRecord, advFilter){
                var d = SVMX.Deferred();
                var me = this;
                if(!searchOnlineRecord){
                    d.resolve([]);

                }else{
                    this.__checkConnectivity().done(function(result){
                        if(result == "False"){
                            d.resolve([]);
                            return d;
                        }
                        //Update the request with selected advance filters
                        var lookupreq = SVMX.cloneObject(lookupRequest);

                        // Lookup Advanced filter criteria has been modified for local query.
                        // Hence reassigning the actual Advanced-filter criteria into filterCriteria member of the lookupreq.
                        if(advFilter && advFilter.advFilters && advFilter.advFilters.length > 0) {
                          for(var i=0; i<advFilter.advFilters.length; i++) {
                            if(me.__actualLookupAdvFilters && me.__actualLookupAdvFilters.length > 0) {
                              for(var k=0; k<me.__actualLookupAdvFilters.length; k++) {
                                if(me.__actualLookupAdvFilters[k].key === advFilter.advFilters[i].key) {
                                  advFilter.advFilters[i].filterCriteria = me.__actualLookupAdvFilters[k].filterCriteria;
                                  logger.info("Online Advanced filter name: " + advFilter.advFilters[i].filterName + " - " + advFilter.advFilters[i].filterCriteria);
                                  break;
                                }
                              }
                            }
                          }
                        }

                        if(advFilter !== null){
                          lookupreq.LookupDef = advFilter;
                        }

                        //Lookup prefilter criteria has been modified for local query.
                        // Hence reassigning the actual pre-filter criteria into preFilterCriteria member of the lookupreq.
                        if(lookupreq && lookupreq.LookupDef && lookupreq.LookupDef.lookupDefDetail
                        && lookupreq.LookupDef.lookupDefDetail.preFilterCriteria && me.__actualLookupPreFilter) {
                          lookupreq.LookupDef.lookupDefDetail.preFilterCriteria = me.__actualLookupPreFilter;
                          logger.info("Online Pre filter criteria: " + lookupreq.LookupDef.lookupDefDetail.preFilterCriteria);
                        }

                        me.__downloadRecords(lookupreq)
                        .done(function(results){
                          var records = [];
                          if(results.message !== undefined && results.message != null){
                              logger.error(results.message);
                          }
                          if(results.records !== undefined && results.records.length > 0){
                            records = results.records;
                          }
                          d.resolve(records);
                        });
                    });
                }
                return d;
            },

            __checkConnectivity : function(){
                var d = SVMX.Deferred();
                var me = this;
                var params = {
                    type : "CONNECTIVITY",
                    method : "CHECKCONNECTIVITY"
                };

                var req = nativeService.createConnectivityRequest();
                req.bind("REQUEST_COMPLETED", function(evt){
                    d.resolve(evt.data.data);
                }, me);
                req.bind("REQUEST_ERROR", function(evt){
                    d.resolve("False");
                }, me);
                req.execute(params);
                return d;
            },

            __downloadRecords : function(lookupRequest){
                var d = SVMX.Deferred();
                var me = this;
                var lookupRequestForServer = me.__buildLookupRequest(lookupRequest);
                var OrgNamespace = SVMX.OrgNamespace;
                var url = "/services/apexrest/{{OrgNamespace}}/svmx/rest/SFMDeliveryServiceIntf/getLookupData/9.0/";
                url = SVMX.string.substitute(url, {
                        OrgNamespace : OrgNamespace
                });
                var params = {
                                url : url,
                                method : "POST",
                                data : {lookupRequest : lookupRequestForServer}

                            };
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var nativeReq = nativeService.createHTTPRequest();

                nativeReq.bind("REQUEST_COMPLETED", function(evt){
                    d.resolve(evt.data.data);
                }, this);

                nativeReq.bind("REQUEST_ERROR", function(evt){
                    logger.error(evt.data.data);
                    d.resolve([]);
                }, this);

                nativeReq.execute(params);
                return d;
            },

            __buildLookupRequest : function(lookupRequest){
                var displayFields = lookupRequest.LookupDef.lookupDefDetail.displayFields;
                var searchFields = lookupRequest.LookupDef.lookupDefDetail.searchFields;
                var advanceFilter = lookupRequest.LookupDef.advFilters;
                var displayFieldsTemp = [];
                var searchFieldsTemp = [];
                var fieldMap = {"field_name" : "apiName",
                                "field_relationship_name" : "fieldRelationshipName",
                                "field_type" : "dataType"
                                };

                for(var i = 0;i < displayFields.length; i++){
                    var displayFieldObj = displayFields[i];
                    var tObj = {};
                    for(var key in displayFieldObj){
                        var nKey = fieldMap[key];
                        if(nKey && nKey !== undefined)
                            tObj[fieldMap[key]] = displayFieldObj[key];
                    }
                    displayFieldsTemp.push(tObj);
                }

                for(var i = 0;i < searchFields.length; i++){
                    var searchFieldObj = searchFields[i];
                    var tObj = {};
                    for(var key in searchFieldObj){
                        var nKey = fieldMap[key];
                        if(nKey && nKey !== undefined)
                            tObj[fieldMap[key]] = searchFieldObj[key];
                    }
                    // HACK : refObjectNameField property represents name field of the object. This property is not saved in database. most of
                    //the time object's name field api name is "Name". We need this while reference fields are used in search clause.

                    tObj.refObjectNameField = 'Name';
                    searchFieldsTemp.push(tObj);
                }

                for(var i = 0; i < advanceFilter.length; i++){
                      //Since advanceFilter[i].defaultOn === 'false' was causing issue (empty string), Hence assign default value as a false.
                      advanceFilter[i].allowOverride  = false;
                      if( advanceFilter[i].allowOverride === 'true'){
                          advanceFilter[i].allowOverride = true;
                      }

                      advanceFilter[i].defaultOn  = false;
                      if( advanceFilter[i].defaultOn === 'true'){
                          advanceFilter[i].defaultOn = true;
                      }
                }
                lookupRequest.LookupDef.lookupDefDetail.displayFields = displayFieldsTemp;
                lookupRequest.LookupDef.lookupDefDetail.searchFields = searchFieldsTemp;
                lookupRequest.LookupDef.advFilters = advanceFilter;
                lookupRequest.LookupDef.objectName = lookupRequest.LookupDef.key;
                return lookupRequest;
            },


           /* __doHttpGetQuery : function(queryString,d){
                var me = this;
                var apiVersion = SVMX.getClient().getApplicationParameter("sfdc-api-version") || "32.0";
                var url = "/services/data/v{{apiVersion}}/query?q={{queryString}}";
                url = SVMX.string.substitute(url, {
                    apiVersion : apiVersion,
                    queryString : encodeURI(queryString)
                });
                //var httpObj = SVMX.create("com.servicemax.client.installigence.offline.model.utils.Http", {});
                var params = {
                                url : url,
                                method : "POST"
                            };
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var nativeReq = nativeService.createHTTPRequest();

                nativeReq.bind("REQUEST_COMPLETED", function(evt){
                    d.resolve(evt.data.data);
                }, this);

                nativeReq.bind("REQUEST_ERROR", function(evt){
                     d.resolve(evt);
                }, this);

                nativeReq.execute(params);
                return d;
            },*/

            __findPRIQRecords : function(userInfo, query, includePRIQRecords, objectName){
                var me = this;
                var d = SVMX.Deferred();
                if(!includePRIQRecords){
                    d.resolve([]);
                }
                else{
                  var params = {
                        type : "DATAACCESSAPI",
                        method : "SELECT",
                        objectName: objectName,
                        userName : userInfo.UserLogin,
                        query : query,
                        IsAsync: "false"
                    };

                    var req = nativeService.createDataAccessAPIRequest();
                    req.bind("REQUEST_COMPLETED", function(evt){
                        var records = me.__parseResults(evt.data.data);
                        var isValid = evt.data.data.indexOf('Response Code : 0') === -1;
                        d.resolve(records, isValid);
                    }, me);
                    req.bind("REQUEST_ERROR", function(evt){
                        d.resolve([]);
                    }, me);
                    req.execute(params);
                }
                return d;
            },

            __parseResults: function(data) {
                data = SVMX.toObject(data);
                var i, ilength = data.length, obj = {};
                for(i = 0; i < ilength; i++) {
                    obj[data[i].split(" : ")[0]] = data[i].split(" : ")[1];
                }
                var output = [];
                if(obj["Response Code"] === "1" && obj.Output.length > 0) {
                    output = this.__parseOutput(obj.Output);
                }
                return output;
            },

            __parseOutput: function(data) {
                if(data && data[0] === "[" && data[data.length-1] !== "]"){
                    // Fix incomplete JSON output
                    data += "\"]]";
                }
                data = SVMX.toObject(data);
                var i, ilength = data.length, output = [];
                for(i = 0; i < ilength; i++) {
                    var j = 0; jlength = data[i].length, obj = {};
                    var currData = data[i];
                    for(j = 0; j < jlength; j++){
                        obj[currData[j].split(":")[0]] = currData[j].split(":")[1];
                    }
                    output.push(obj);
                }
                return output;
            },

            __mergeRecords : function(records1, records2, records3, noOfRecordsToBeSearched){
                if(records2.length || records3.length){
                    var recordIds = [];
                    for(var i = 0; i < records1.length; i++){
                        recordIds.push(records1[i].Id);
                    }
                    for(var i = 0; i < records2.length; i++){
                        if(recordIds.indexOf(records2[i].Id) === -1){
                            records1.push(records2[i]);
                            recordIds.push(records2[i].Id);
                        }
                    }
                    for(var i = 0; i < records3.length; i++){
                        if(recordIds.indexOf(records3[i].Id) === -1){
                            records1.push(records3[i]);
                        }
                    }
                }
                var allRecords = records1;
                if(records1.length > noOfRecordsToBeSearched){
                    allRecords = [];
                    for(var i = 0; i < noOfRecordsToBeSearched; i++){
                        allRecords.push(records1[i]);
                    }
                }
                return this.__sort(allRecords, "Name");
            },

            __sort : function(array, key){
                return array.sort(function(a, b) {
                    if(a[key] < b[key]){
                        return -1;
                    }else if(a[key] > b[key]){
                        return 1;
                    }
                    return 0;
                });
            },

            _getLUPSearchResultsError: function(responder, result, lookupRequest, fields, evt) {
                logger.error("ERROR IN _getLUPSearchResultsError: " + evt.data.data);

                // Add Query parameter to match the corresponding success methods, otherwise, error handling is not propagated back to client.
                var query = evt.data.parameters.query || "";

                this._getLUPSearchResultsSuccess(responder, result, lookupRequest, fields, query, {data: {data: []}});
            },

            _onSearchCompleted: function(responder, result) {
                responder.__waitCounter.count--;
                if (responder.__waitCounter.count === 0 && responder.__waitCounter.subRecordsStarted) {
                    logger.info("Lookup results retrieved");
                    responder.result(result);
                }
            },

            __createDisplayRecords: function(records, fieldsInfo) {
                var ret = [];
                if (records) {
                    var i, l = records.length,
                        rec, key, record, value, fieldInfo, rkey;
                    for (i = 0; i < l; i++) {
                        rec = {
                            FieldMap: []
                        };
                        record = records[i];

                        for (key in record) {
                            if (key == "attributes") continue;

                            value = record[key];

                            if (fieldsInfo) {
                                fieldInfo = this.__getFieldInfo(fieldsInfo, key);
                                if (fieldInfo && fieldInfo.dataType == "REFERENCE") {
                                    rkey = fieldInfo.relationshipName;

                                    if (record[rkey]) {
                                        rec.FieldMap.push({
                                            ftype: "Reference",
                                            key: key + "__key",
                                            value: value
                                        });

                                        value = record[rkey].Name;
                                    } else {
                                        value = "";
                                    }

                                }
                            }

                            rec.FieldMap.push({
                                ftype: "Result",
                                key: key,
                                value: value
                            });
                        }

                        ret.push(rec);
                    }
                }
                return ret;
            },

            __getFieldInfo: function(fieldsInfo, fieldName) {
                var i, l = fieldsInfo.length,
                    ret = null;
                for (i = 0; i < l; i++) {
                    if (fieldsInfo[i][SVMX.OrgNamespace + "__Field_Name__c"] == fieldName) {
                        ret = fieldsInfo[i];
                        break;
                    }
                }
                return ret;
            },

            /**
             * Substitute date functions within a string to match SQLite.
             * TODAY becomes CURRENT_DATE
             * TOMORROW becomes date('now', '+1 day')
             * YESTERDAY becomes date('now', '11 day')
             * NOW becomes CURRENT_TIMESTAMP
             *
             * @param inString (String) the string to add substitutions to
             * @return (sting) the new substituted value
             */
            sqlFixCriteria : function (inString) {
                var criteria = "",
                    re_castFields = /\b([\w]+)(?=\s?(?:<>|>|>=|<|<=|=)\s?\d)/gi;

                //Generate our new string
                criteria = String(inString).replace(/["']?\b(TODAY|TOMORROW|YESTERDAY|NOW)\b["']?/gi, function (inTerm) {
                    var output = inTerm;
                    switch(inTerm.toUpperCase()) {
                        case "TODAY":
                            output = "'" + DatetimeUtils.macroDrivenDatetime('Today', "YYYY-MM-DD").split(" ")[0] + "'";
                            break;
                        case "TOMORROW":
                            output = "'" + DatetimeUtils.macroDrivenDatetime('Tomorrow', "YYYY-MM-DD").split(" ")[0] + "'";
                            break;
                        case "YESTERDAY":
                            output = "'" + DatetimeUtils.macroDrivenDatetime('Yesterday', "YYYY-MM-DD").split(" ")[0] + "'";
                            break;
                        case "NOW":
                            output = "'" + DatetimeUtils.macroDrivenDatetime('Now', "YYYY-MM-DD", "HH:mm:ss") + "'";
                            break;
                    }

                    return output;
                });

                //Defect: 012062
                //Cast fields as numbers (doubles) so that SQL comparisons will work correctly
                criteria = criteria.replace( re_castFields, 'cast($1 as double)' );

                //Defect: 010758
                //While we are fixing the criteria, also add brackets.
                // x = y AND a = b OR c = d IS not the same as  x = y AND (a = b OR c = d)
                return (criteria) ? '(' + criteria + ')' : criteria;
            },

            sqlAliasPrepSub : function(criteria, displayFields) {
                if (criteria && displayFields) {
                    var l = displayFields.length;
                    for (var k = 0; k < l; k++) {
                        if (displayFields[k].field_type && displayFields[k].field_type === "REFERENCE"
                            && displayFields[k].field_relationship_name.indexOf("__r") === -1) {
                            //Replace all table instances so we can easily replace them with an alias later
                            //but leave the __r's alone, they are field references found in the SELECT clause.
                            var target = displayFields[k].field_relationship_name ;
                            var re = new RegExp(target+ ".Name", "g");
                            criteria = criteria.replace(re, "{{" + target + "}}.Name");
                        }
                    }
                }

                return criteria;
            }

        }, {});


        /* OPERATION: GetUserInfo
         * STATUS: Working.
         * @description Returns the UserInfo object
         * TODO:
         *    1. Eric: We need to get the DateFormat field in our Users database
         *    2. Indresh: Both online and offline client set the TimeFormat from index.html, should be in the Users db
         */
        sfmdeliveryoperations.Class("GetUserInfo", com.servicemax.client.mvc.api.Operation, {

            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {
                responder.result(OfflineSystemUtils.getUserInfo());
            }
        }, {});

        /* OPERATION: DescribeObject
         * STATUS: Works
         * @description Describes the specified type, returning fields and other information.
         * @param {String} objectName
         */
        sfmdeliveryoperations.Class("DescribeObject", com.servicemax.client.mvc.api.Operation, {
            __constructor: function() {
                this.__base();
            },

            performAsync: function(request, responder) {
                OfflineMetaUtils.describeObject({
                    objectName: request.objectName,
                    onSuccess: function(describeResult) {
                        SVMX.array.forEach(describeResult.fields, function(field) {
                            if(!field.picklistValues) {
                                field.picklistValues = [];
                            }

                            if(!(field.picklistValues instanceof Array)) {
                                field.picklistValues = [field.picklistValues];
                            }

                            // checkbox types can be controlling fields. simulate the picklist values
                            if(field.type == 'boolean'){
                                field.picklistValues = [
                                    {label : "false", value : "false"},
                                    {label : "true", value : "true"}
                                ];
                            }
                        });

                        OfflineCacheUtils.registerJSCache("SFMDELIVERY.ParsedObjectDescribeLayout",10);
                        var describeObjectLayout = OfflineCacheUtils.readFromJSCache("SFMDELIVERY.ParsedObjectDescribeLayout", request.objectName);
                        if (describeObjectLayout) {
                            responder.result(describeObjectLayout, request.objectName);
                        } else {
                            execQuery({
                                query: "SELECT object_layout_describe FROM SFObjectLayoutDescribe WHERE object_name = '{{object_name}}'",
                                queryParams: {object_name : request.objectName}
                            })
                            .then(function(describeLayoutResults) {
                                // Process describeLayoutResults so it is consumable by next step
                                var parsedObj = { recordTypeMappings: [] };
                                if (describeLayoutResults) {
                                    SVMX.array.forEach(describeLayoutResults, function(layout) {
                                        var layoutDescribe = SVMX.toObject(layout.object_layout_describe);
                                        var rtms = layoutDescribe.recordTypeMappings;
                                        // single objects are not converted to array while un-marshalling
                                        if (rtms && !(rtms instanceof Array)) {
                                            rtms = [rtms];
                                        }
                                        SVMX.array.forEach(rtms, function(rtm) {
                                            parsedObj.recordTypeMappings.push(rtm);
                                        });
                                    });
                                }
                                com.servicemax.client.sfmdelivery.operationutils.Utilities.processDescribeResult(describeResult, parsedObj);

                                SVMX.array.forEach(describeResult.recordTypeInfos, function(item) {
                                    item.fixedName = OfflineMetaUtils.getRecordTypeNameFromId(item.recordTypeId);
                                }, this);

                                SVMX.array.forEach(describeResult.recordTypeMapping, function(item) {
                                    item.fixedName = OfflineMetaUtils.getRecordTypeNameFromId(item.recordTypeId);
                                }, this);

                                OfflineCacheUtils.registerJSCache("SFMDELIVERY.RecordTypes", 10);
                                OfflineCacheUtils.writeToJSCache("SFMDELIVERY.RecordTypes", request.objectName, describeResult.recordTypeMapping);
                                OfflineCacheUtils.writeToJSCache("SFMDELIVERY.ParsedObjectDescribeLayout", request.objectName, describeResult);
                                responder.result(describeResult, request.objectName);
                            });
                        }
                    },
                    onError: function(evt) {
                        logger.error("Describe Object Failed for " + request.objectName);
                    }
                });
            }
        }, {});

        /*
    1. SFProcessComponent has a mapping id that points to SFObjectMapping
    INSERT INTO SFProcessComponent (process_id, layout_id, target_object_name, source_object_name, expression_id, object_mapping_id, component_type, local_id, parent_column, value_mapping_id, source_child_parent_column, Sorting_Order) VALUES ('CustTDM004', 'a1370000000FszTAAS', 'SVMXC__RMA_Shipment_Line__c', 'Case', '', 'a0K70000008DccwEAC', 'TARGETCHILD', 482, 'SVMXC__RMA_Shipment_Order__c', 'a0K70000008DccVEAS', '', '')
    2. List of SFProcessComponent entries is done by querying on processId
    3. mapping id also specifies a set of SFObjectMappingComponent
    INSERT INTO SFObjectMappingComponent (local_id, object_mapping_id, source_field_name, target_field_name, mapping_value, mapping_component_type, mapping_value_flag) VALUES (1520, 'a0K70000008DccVEAS', '', 'SVMXC__Expected_Quantity2__c', '1', 'VALUEMAPPING', 1);

    STEP 0. If needed, load SFObject into a global
    STEP 0b. If needed, load all key fields from SFObjectField
    STEP 1. Get table name from SFProcess table.
    STEP 2. Get data from table from the table name, sets pageDataSet.sobjectinfo
    STEP 3. Find each foreign key field using the SFObjectField table
    STEP 4. Use the SFObject entry to find the {key,value} pair to replace the sobjectinfo value with for each field


    STEP 4. Get SFObjectMapping for each SFProcessComponent
    Step 5. Get set of SFObjectMappingComponent for each SFObjectMapping
    STEP 6. Get related object data from table for SFObjectMappingComponent
    Step 7: Lets worry about the bubbleinfo object later...
     *
     * TODO: Manage requestCount so we only fire responder when all queries are complete
     * TODO: All handling of SOURCE components is no longer used and should be removed to simplify this; remove the state.componentType and all reference to it.
     */

    /**
     *
     * @class       com.servicemax.client.offline.sal.model.sfmdelivery.operations.GetPageData
     * @extends     com.servicemax.client.mvc.api.Operation
     */
    sfmdeliveryoperations.Class("GetPageData", com.servicemax.client.mvc.api.Operation, {
        __constructor: function() {
            this.__base();
        },

        /**
         *
         * @param   {Object}    request
         * @param   {Object}    responder
         */
        performAsync: function(request, responder) {
            //Replace record's local_id with remote_id if available
            var remoteId = OfflineSyncUtils.getOpenRecordRemoteId(request.recordId);
            if(remoteId){
                request.recordId = remoteId;
            }

            var recordId = request.recordId;
            var targetId = request.targetId;
            var processId = request.processId;
            var userTrunk = "";
            var result = {}; // object that will be the result of this operation
            var state = {

                // Typically the componentType is "TARGET"; thats what SFMDelivery uses to generate a form for the user
                // However, occasionally we need to get all of the records associated with SOURCE and SOURCECHILD ProcessComponents
                // such as when doing SourceObjectUpdates
                componentType: request.componentType || "TARGET",

                // refreshData used after quickSave when loading updated data from the db but NOT reexecuting the process and its mappings.
                refreshData: request.refreshData,

                // The requesterId lets us indicate that records have been openned by the specified requester,
                // and later lets us mark them as no longer opened.
                requesterId: request.requesterId,

                lookupDisplayFieldMap: request.lookupDisplayFieldMap,

                // Setup the basic structure that we'll be returning
                data: {

                    // While response is part of what we get back from the online call, I don't think we use it anywhewre
                    response: {
                        stringMap: []
                    },

                    // The header record
                    pageDataSet: {
                        sobjectinfo: {},
                        bubbleInfo: []
                    },

                    // The Line Items
                    detailDataSet: [
                        /* Zero or more entries like this:
                        {
                            pageDataSet: {
                                sobjectinfo: null, // TODO
                                bubbleInfo: [] // TODO
                            }
                        }*/
                    ]
                },

                // Number of expressions to be evaluated
                expressionCounter: 0,

                // The name of the table that contains the header record
                tableName: null,

                // Id of the record that is either the Header or SOURCE record.  For STANDALONE CREATE this may be null.
                recordId: recordId,
                targetId: targetId,

                record: request.record, // optional

                // Id of the process that we are getting data for.  The process identifies for us which
                // line items are needed.
                processId: processId,
                responder: responder,
                svmxConstants : []
            };

            this._getUserInfoSuccess(state, OfflineSystemUtils.getUserInfo());
        },

        _getUserInfoSuccess : function(state, UserData){
            var userTrunkValue = UserData.UserTrunkDetail ? UserData.UserTrunkDetail.Id : null;
            state.UserData = UserData;
            state.svmxConstants.push({fieldsToNull : null, key : "SVMX.USERTRUNK", value : userTrunkValue, value1 : null});
            state.data.svmxConstants = state.svmxConstants;

            // Gather information on the process such as the processType and tableName.
            OfflineMetaUtils.getProcess({
                processId: state.processId,
                componentType: state.componentType,
                onSuccess: SVMX.proxy(this, "_getProcessSuccess", state),

                // This is a fatal error.  We have not tested this call to result, but the hope is that it will produce a UI without
                // the spinner so that the user can close it and do something else.
                onError: SVMX.proxy(this, function(evt) {
                    logger.error(evt.data.data);
                    state.data.error = evt.data.data;
                    state.responder.result(SVMX.create("com.servicemax.client.sfmdelivery.operationutils.SFMDeliveryData", state.data));
                }),
                state: state
            });
        },

        _getUserInfoError : function(evt) {
            logger.error("User Info not found");
        },

        _getSortString : function(advancedOptions, objectName) {
            var str = "";
            if (!advancedOptions || !advancedOptions.lstSortingRec) return str;

            var fieldSet;

            // synchronous
            com.servicemax.client.offline.sal.model.utils.FieldSet.getFieldSet(objectName, function(inFieldSet) {
                fieldSet = inFieldSet;
            });
            var data = advancedOptions.lstSortingRec;
            for (var i = 0; i < data.length; i++) {
                var queryField = data[i].queryField || "";
                var dotIndex = queryField.indexOf('.');
                if (dotIndex > 0) {
                    // Reference Field
                    queryField = queryField.substring(0, dotIndex) + "Table" + queryField.substring(dotIndex);
                }
                else {
                    var fieldDef = fieldSet.getFieldType(queryField);
                    if (!fieldDef) continue;
                    queryField = "MAIN." + queryField;
                }
                if (str) str += ", ";
                str += queryField;

                str += " " + data[i].sortingOrder;
            }
            if (str) str = " ORDER BY " + str;
            return str;
        },

        _getSortStringKeys : function(advancedOptions, objectName) {
            var ret = [];
            if (!advancedOptions || !advancedOptions.lstSortingRec) return ret;

            var fieldSet;

            // synchronous
            com.servicemax.client.offline.sal.model.utils.FieldSet.getFieldSet(objectName, function(inFieldSet) {
                fieldSet = inFieldSet;
            });

            var data = advancedOptions.lstSortingRec;
            for (var i = 0; i < data.length; i++) {
                var queryField = data[i].queryField || "";
                ret.push({
                    queryField : queryField,
                    sortingOrder : data[i].sortingOrder
                });
            }

            return ret;
        },

        /* Success handler for getProcess data:
         * Get the processType and tableName, and either create or retrieve the
         * record specified by the recordId.
         * call _onGetDataComplete when finished
         */
        _getProcessSuccess: function(state, evt) {
            var data = state.processData = evt.data.data[0];
            if(state.requesterId === "SYNC"){
                state.processData.process_type = "VIEW RECORD";
            }
            state.processType = data.process_type;
            state.tableName = state.processData.target_object_name;

           // For standalone processes just create an empty record.
           // TODO: CHECKLIST - Figure out if New or existing
           if (state.processData.process_type === "STANDALONE CREATE" ) {
                state.data.pageDataSet.sobjectinfo = new RecordClass({}, state.tableName);
                this._onGetDataComplete(state);
            } else {
                var record = state.record;
                SVMX.when([(function() {
                    return record || OfflineDataUtils.getRecord({
                        Id: state.targetId || state.recordId,
                        loadReferences: true,
                        convertPicklists: true,
                        lookupDisplayFieldMap: state.lookupDisplayFieldMap && state.lookupDisplayFieldMap.head
                    });
                })()])
                .then(
                    // onSuccess: If we successfully retrieved the record, create a RecordClass and pass it along
                    SVMX.proxy(this, function(inData) {
                        // If there is no OwnerId, we need to set an OwnerId; use the current user.
                        // Set here in case the field is editable by the current process; in which case
                        // it needs a value here and not in SaveTargetRecord, and it needs a display value too.
                        if (!inData.OwnerId) {
                            inData.OwnerId = {fieldvalue: {key: state.UserData.UserId, value: state.UserData.UserName}};
                        } else if (typeof inData.OwnerId == "string") {
                            if (inData.OwnerId == state.UserData.UserId) {
                                inData.OwnerId = {fieldvalue: {key: state.UserData.UserId, value: state.UserData.UserName}};
                            }
                        } else if (inData.OwnerId.fieldvalue.key === inData.OwnerId.fieldvalue.value &&
                                    inData.OwnerId.fieldvalue.key === state.UserData.UserId) {
                            inData.OwnerId.fieldvalue.value = state.UserData.UserName;
                        }

                        state.data.pageDataSet.sobjectinfo = new RecordClass(inData, inData.attributes.type);
                        this._onGetDataComplete(state);
                    }),
                    // onError: This is pretty fatal of an error, call the responder so it can do something somewhat graceful.
                    SVMX.proxy(this, function(error) {
                        logger.error(evt.data.data);
                        state.data.error = error;
                        state.responder.result(SVMX.create("com.servicemax.client.offline.sal.model.impl.SFMDeliveryData", state.data));
                    })
                );
            }
        },

        /* At this point in our process, we have the header record; ObjectMappings and other tasks haven't yet occurred;
         * this method is here mostly as a place holder for other actions we may want to trigger here
         */
        _onGetDataComplete: function(state) {
            this.getProcessComponents(state);
        },

        /* METHOD: getProcessComponents
         * Load the processComponents for this process from the database; this will tell us
         * what the TARGETCHILD processComponents are for this process (what line items we need to output)
         * and what SOURCECHILD processComponents are for this process (for SOURCE TO TARGET processes,
         * this tells us how to load the SOURCE that will be used to generate the TARGET line items)
         */
        getProcessComponents: function(state) {
            var processType = state.componentType === "SOURCE" ? "STANDALONE EDIT" : state.processType;
            var processTypeFuncName = processType.toLowerCase().replace(/ /g, "_");
            processTypeFuncName = SVMX.string.capitalize(SVMX.string.camelCase(processTypeFuncName));


            sfmdeliveryoperations.Utilities.getProcessComponents({
                processId: state.processId,
                onSuccess: SVMX.proxy(this, function(inStringMap, processComponents) {
                    this._cacheAllFieldSets(processComponents)
                    .then(SVMX.proxy(this, function() {
                        this["_getProcessComponentsSuccess" + processTypeFuncName](state, inStringMap, processComponents);
                    }));
                })
            });
        },

        /* METHOD: _cacheAllFieldSets
         * Determines all of the FieldSets needed for this getPageData process based on the ProcessComponents
         * description of the line items we must load.  Note that this does NOT load fieldSets for reference objects,
         * only for SOURCE/TARGET/CHILD record types for this process.
         */
        _cacheAllFieldSets : function(processComponents) {
            var objectNameHash = {};
            var deferreds = [];
            var FieldSetClass = com.servicemax.client.offline.sal.model.utils.FieldSet;
            for (var i = 0; i < processComponents.length; i++) {
                var processComponent = processComponents[i];
                var objectName = processComponent.target_object_name;
                if (objectName && !objectNameHash[objectName]) {
                    objectNameHash[objectName] = true;
                    deferreds.push(FieldSetClass.getFieldSet(objectName));
                }
            }
            return SVMX.when(deferreds);
        },

        /* METHOD: _getProcessComponentsSetupProcessComponents
         * Adds the line item structures for each TARGETCHILD or SOURCECHILD
         * to our return structure. Records will be added to the structure later.
         * Handling SOURCECHILD is a special case of SourceObjectUpdates
         */
        _getProcessComponentsSetupProcessComponents: function(state, inStringMap, inData) {
            var stringMap = [],
                data = [];

            SVMX.array.forEach(inData, function(item, i) {
                if (item.component_type === state.componentType + "CHILD") {
                    stringMap.push(inStringMap[i]);
                    data.push(inData[i]);
                    var aliasName = item.layout_id;

                    // SOURCECHILD processComponents do not have a proper layout_id;
                    // Find the TARGETCHILD that is paired with the SOURCECHILD and use its layout_id.
                    // This is cludgy as that layout_id has no real meaning to the SOURCECHILD which
                    // may be of the wrong type to use that layout_id, but we won't be rendering this data anyways.
                    // only TARGETCHILD gets rendered.
                    if (item.component_type === "SOURCECHILD") {
                        var target = SVMX.array.filter(inData, function(possibleTarget) {
                            return possibleTarget.component_type === "TARGETCHILD" && possibleTarget.parent_object === item.processComponentId;
                        })[0];
                        aliasName = target.layout_id;
                    }

                    // Add the line item object to our return data.
                    state.data.detailDataSet.push({
                        pageDataSet: [],
                        aliasName: aliasName
                    });
                }
            });

            // Stash the resulting process data
            state.data.response.stringMap = stringMap;
            state.processComponents = data;
            state.allProcessComponents = inData;
        },

        /* METHOD: _getProcessComponentsSuccessStandaloneEdit
         * Standalone Edit and Standalone Create care only about getting all TARGETCHILD
         * ProcessComponents and using them to setup the line items.
         *
         * Standalone Create may call getAllLineItemRecords (unnecessary as it should return nothing)
         * but they are essentially the same.
         *
         * View processes have the same data gathering requriement as Standalone Edit
         *
         * There is a special case where we gather all SOURCECHILD records instead for SourceObjectUpdates
         *
         * STATUS: Looks like its working correctly.
         */
        _getProcessComponentsSuccessStandaloneEdit: function(state, inStringMap, inData) {
            // Step 1: Setup our return structure
            this._getProcessComponentsSetupProcessComponents(state, inStringMap, inData);

            // Step 2: This should contain only TARGETCHILD (or perhaps only SOURCECHILD) ProcessComponents
            inData = state.processComponents;

            // Step 3: Get all line item records for this process, and put them into the return structure
            this._getAllLineItemRecords(state, state.processComponents, state.data.pageDataSet.sobjectinfo)


            // Step 4: Execute expressions on each set of line items to filter the set of records
            .then(SVMX.proxy(this, function() {
                var deferreds = [];
                SVMX.array.forEach(state.data.detailDataSet, SVMX.proxy(this, function(entry, i) {
                    // Each entry is a part of our return structure, and specifies a line item that will be filtered
                    // by the expression.
                    var processComponent = state.processComponents[i];
                    var d = this._runExpressionOnLineItems(state, entry.pageDataSet, processComponent.target_object_name, processComponent.expression_id, processComponent);
                    d.done(function(data) {
                        entry.pageDataSet = data;
                    });
                    deferreds.push(d);
                }));

                // Go to the next then statement when all deferreds are resolved
               return SVMX.when(deferreds);
            }))

            // Step 5: This is really just a place holder that tells us we've loaded
            // all the data for header and line items
            .then(SVMX.proxy(this, function() {
                return this._onGetHeaderAndLineItemComplete(state);
            }))

            // Step 6: Execute object mapping and value mappings; this will change the values of our header and line item records
            .then(SVMX.proxy(this, function() {
                if (state.processType === "VIEW RECORD" || state.refreshData || state.componentType === "SOURCE") {
                    // Skip object mappings; Return a non-deferred goes to next "then" block
                    return true;
                } else {
                    var tmp = OfflineDataUtils.executeObjectMapping({
                        targetData: [state.data.pageDataSet], // This empty object we just created is to be populated
                        sourceData: state.data.pageDataSet.sobjectinfo,
                        objectMappingId: state.processData.object_mapping_id,
                        valueMappingId: state.processData.value_mapping_id
                    });

                    return tmp;
                }
            }))

            .then(SVMX.proxy(this, function() {
                //We have all the records we want to display and all information that is accessible.
                //Sort the records according to their criteria. This could not be entirely done within
                //the SQL query due to complexities like required data in the SFRecordName table rather than object tables.
                //This only works because we have ALL records, no LIMIT was used in the SQL query.
                if (state.data && state.data.detailDataSet && state.data.detailDataSet.length > 0) {
                    //cycle through each of our detail data sets and order their records
                    for (var i = 0; i < state.data.detailDataSet.length; i++) {
                        if (state.data.detailDataSet[i].pageDataSet && state.data.detailDataSet[i].pageDataSet.length > 0) {
                            var sortCriteria = this.__getListSortCriteria(state.data.detailDataSet[i].aliasName, state.processComponents);
                            //Now sort the records
                            state.data.detailDataSet[i].pageDataSet.sort(this.__pageDataSetSort(sortCriteria));
                        }
                    }
                }

                this.__onDone(state);
            }));
        },
        __pageDataSetSort : function(sortCriteria) {
            var getValue = function(key, item) {
                var value = '';
                if (item[key]) {
                    if ((typeof item[key] == 'string' || item[key] instanceof String)) {
                        value = item[key];
                    } else if (item[key].fieldvalue) {
                        value = item[key].fieldvalue.value;
                    }

                    var dataType = '';
                    if (sortCriteria[0]) {
                        dataType = sortCriteria[0].dataType.toUpperCase();
                    }
                    if (dataType === "DOUBLE" || dataType === "PERCENT" || dataType === "CURRENCY") {
                        var tempValue = Number(value);
                        if (!isNaN(tempValue)) {
                            value = tempValue;
                        }
                    }
                }

                return (value) ? value : '';
            };

            return function(a, b) {
                var value1, value2;
                for (var i = 0; i < sortCriteria.length; i++) {
                    var fieldName = sortCriteria[i].fieldAPIName;
                    if (sortCriteria[i].sortingOrder == 'ASC') {
                        value1 = getValue(fieldName, a.sobjectinfo);
                        value2 = getValue(fieldName, b.sobjectinfo);
                    } else {
                        value2 = getValue(fieldName, a.sobjectinfo);
                        value1 = getValue(fieldName, b.sobjectinfo);
                    }

                    if (value1 != value2) {
                        if (value1 < value2) return -1;
                        if (value1 > value2) return 1;

                        return 0;
                    }
                }

                return 0;
            };
        },
        /*
         * Find sort criteria to sort for details list sorting
         *
         * @private
         * @param   {string}    id
         * @param   {array}     processComponents
         *
         * @return  {array}
         */
        __getListSortCriteria : function(id, processComponents) {
            var sortables = [];

            for (var i = 0; i < processComponents.length; i++) {
                if (processComponents[i].layout_id == id
                        && processComponents[i].advanced_options
                        && processComponents[i].advanced_options.lstSortingRec) {

                    sortables = processComponents[i].advanced_options.lstSortingRec;

                    break;
                }
            }

            return sortables;
        },

        /*
         * Process the datetime fields to the user timezone from GMT
         *
         * @private
         * @param   {Object}    state
         *
         * @return  {Object}
         */
        _processDateToUserTimezone : function(state, record, offset){
            //processing the datetime date to timezone
            var dateTimeFields = record.getFieldsByType("datetime");
            var hashTable = {};

            SVMX.array.forEach(dateTimeFields, function(item, idx){
                hashTable[item.name] = true;
            });

            SVMX.forEachProperty(record, function(inKey, inValue) {
                if (hashTable[inKey]) {
                    if (inValue.fieldvalue){
                        var key = inValue.fieldvalue.key;
                        var value = inValue.fieldvalue.value;
                        var newValue = {
                                key: ((key) ? DatetimeUtils.convertToTimezone(key, offset, false):key),
                                value: ((value) ? DatetimeUtils.convertToTimezone(value, offset, false):value)
                        };
                        record[inKey].fieldvalue = newValue;
                    }
                }
            });
        },

        _processDetailsDate: function(state, collection, offset) {
            SVMX.array.forEach(collection, SVMX.proxy(this, function(record, id) {
                SVMX.array.forEach(record.pageDataSet, SVMX.proxy(this, function(item, idx) {
                    this._processDateToUserTimezone(state, item.sobjectinfo, offset);
                }));
            }));
        },

        /* METHOD: _getProcessComponentsSuccessStandaloneCreate
         * Setup the line items structure and execute any object mappings
         */
        _getProcessComponentsSuccessStandaloneCreate: function(state, inStringMap, inData) {

            // Step 1: For standlone create, we only care about ProcessComponents of type TARGETCHILD
            // TARGETCHILD tells us what line item sections we need to setup in our datastructures
            // and what line item records we should query for.
            this._getProcessComponentsSetupProcessComponents(state, inStringMap, inData);

            if (state.data.pageDataSet.sobjectinfo.getFieldDef("OwnerId")) {
                 state.data.pageDataSet.sobjectinfo.OwnerId = {fieldvalue: {key: state.UserData.UserId, value: state.UserData.UserName}};
            }

            state.data.pageDataSet.sobjectinfo.Id = OfflineDataUtils.__generateId(state.processData.target_object_name);
            state.data.pageDataSet.sobjectinfo.__new = true;

            // Step 2: Execute object mappings/value mappings on the empty record.
            OfflineDataUtils.executeObjectMapping({
                targetData: [state.data.pageDataSet], // This empty object we just created is to be populated
                sourceData: state.data.pageDataSet.sobjectinfo,
                objectMappingId: state.processData.object_mapping_id,
                valueMappingId: state.processData.value_mapping_id
            })


            .then(SVMX.proxy(this, function() {
                this.__onDone(state);
            }));
        },

        /* METHOD: _getProcessComponentsSuccessViewRecord
         * Except for ObjectMapping, this is the same as StandaloneEdit.
         */
        _getProcessComponentsSuccessViewRecord: function(state, inStringMap, inData) {
            this._getProcessComponentsSuccessStandaloneEdit(state, inStringMap, inData);
        },

        /* METHOD: _getProcessComponentsSuccessSourceToTargetChild
         * source-to-target-child rules
         * 1. Update the header using mappings; header is both source and target for these mappings
         *    though most are probably value mappings rather than field mappings.
         * 2. Get the source line items
         * 3. Create new line items using mappings from the source line items
         *    to empty records created for them to map to.
         * NOTE: We only display the newly created records, and do not display any records that already exist
         */
        _getProcessComponentsSuccessSourceToTargetChild: function(state, inStringMap, inProcessComponents) {
            // Step 0: Setup our line item return structure
            this._getProcessComponentsSetupProcessComponents(state, inStringMap, inProcessComponents);

            // Step 1. Update the header using mappings; header is both source and target for these mappings
            // The header for this processType is treated much like STANDLONE EDIT.
            OfflineDataUtils.executeObjectMapping({
                targetData: [state.data.pageDataSet],
                sourceData: state.data.pageDataSet.sobjectinfo,
                objectMappingId: state.processData.object_mapping_id,
                valueMappingId: state.processData.value_mapping_id
            })

            // Steps 2 + 3: Retrieve the line items and use them to generate new line items.
            .then(SVMX.proxy(this, function() {
                return this._generateTargetChildrenFromSourceChildren(state, inProcessComponents);
            }))

            // Place holder for adding new steps to the process that depend upon header and line
            // item gathering being complete
            .then(SVMX.proxy(this, function() {
                return this._onGetHeaderAndLineItemComplete(state);
            }))

            .then(SVMX.proxy(this, function() {
                this.__onDone(state);
            }));
        },

        /* METHOD: _getProcessComponentsSuccessSourceToTargetAll
         * source-to-target-all rules
         * 1. Create a new header
         * 2. Set new header using mappings and the source recordId passed into "GetPageData" operation
         * 3. Get the source record's line items
         * 4. Create new line items for our new header using mappings from the source record line items
         *    to empty records created for them to map to.
         */
        _getProcessComponentsSuccessSourceToTargetAll: function(state, inStringMap, inProcessComponents) {
            // Step 1: Create a new header.
            // NOTE: The previously loaded record is actually our sourceRecord not the record
            // the user is editing (the targetRecord); and we DID need to load that record;
            // stash it in state.sourceRecord.
            state.sourceRecord = state.data.pageDataSet.sobjectinfo;
            state.data.pageDataSet = {
                sobjectinfo: new RecordClass({sourceRecordId: state.sourceRecord.Id}, state.tableName),
                bubbleInfo: []
            };

            if (state.data.pageDataSet.sobjectinfo.getFieldDef("OwnerId")) {
                 state.data.pageDataSet.sobjectinfo.OwnerId = {fieldvalue: {key: state.UserData.UserId, value: state.UserData.UserName}};
            }

            state.data.pageDataSet.sobjectinfo.Id = OfflineDataUtils.__generateId(state.processData.target_object_name);
            state.data.pageDataSet.sobjectinfo.__new = true;

            // Step 2: Setup the line item structures in our return structure
            this._getProcessComponentsSetupProcessComponents(state, inStringMap, inProcessComponents);

            // Step 3: Update the new header using mappings and the source recordId passed into "GetPageData" operation
            OfflineDataUtils.executeObjectMapping({
                targetData: [state.data.pageDataSet],
                sourceData: state.sourceRecord,
                valueMappingId: null,
                objectMappingId: state.processData.object_mapping_id
            })

            // Step 3 + 4: Gets all souce-children, and use mapping to generate all target-children
            .then(SVMX.proxy(this, function() {
                return this._generateTargetChildrenFromSourceChildren(state, inProcessComponents);
            }))

            // Placeholder for additional tasks to execute after header and line items are all loaded.
            .then(SVMX.proxy(this, function() {
                return this._onGetHeaderAndLineItemComplete(state);
            }))

            .then(SVMX.proxy(this, function() {
                this.__onDone(state);
            }));

        },

        /* METHOD: _pairSourceAndTargetChildren
         * Finds all TARGETCHILD process components and pairs them with
         * their SOURCECHILD process component
         */
        _pairSourceAndTargetChildren: function(inProcessComponents) {
            var targetChildProcessEntries = SVMX.array.filter(inProcessComponents, function(item) {
                return item.component_type === "TARGETCHILD";
            });
            var sourceChildProcessEntries = SVMX.array.filter(inProcessComponents, function(item) {
                return item.component_type === "SOURCECHILD";
            });

            var childProcessEntries = SVMX.array.map(targetChildProcessEntries, function(targetItem) {
                var sourceChild = SVMX.array.get(sourceChildProcessEntries, function(sourceItem) {
                    return sourceItem.component_type === "SOURCECHILD" && targetItem.node_source_object_api == sourceItem.object_name;
                });
                if (sourceChild) {
                    SVMX.array.remove(sourceChildProcessEntries, sourceChild);
                    return {
                        source: sourceChild,
                        target: targetItem,
                        data: []
                    };
                } else {
                    return null;
                }
            });

            // remove nulls; drawback of using Array.map instead of Array.forEach.
            childProcessEntries = SVMX.array.filter(childProcessEntries, function(item) {
                return item;
            });

            return childProcessEntries;
        },

        /* METHOD: _generateTargetChildrenFromSourceChildren
         * Generate the target children from the source children in accordance with
         * the ProcessComponents for SOURCECHILD/TARGETCHILD
         */
        _generateTargetChildrenFromSourceChildren: function(state, inProcessComponents) {
            var d = new $.Deferred();

            var headerSource = SVMX.array.get(inProcessComponents, function(item) {return item.component_type = "SOURCE";});

            // STEP 1: Pair up the sourcechild/targetchild process components.
            var childProcessEntries = this._pairSourceAndTargetChildren(inProcessComponents);

            // STEP 2: Setup the onMappingDone function to
            // 1. keep track of when we are done
            // 2. Copy our data into the state.data.detailDataSet,
            // 3. Call onDone.
            var onMappingDone = SVMX.proxy(this, function(childProcessEntry) {
                // sadly, in the chrome multithreaded environment, childProcessEntry may not be
                // === an object from childProcessEntries
                var index = SVMX.array.indexOf(childProcessEntries, function(entry) {
                    return entry.target.layout_id === childProcessEntry.layout_id;
                });
                childProcessEntry = childProcessEntries[index];
                childProcessEntry._isDone = true;
                var isDone = SVMX.array.every(childProcessEntries, function(item, i) {
                    return item._isDone;
                });

                if (isDone) {
                    d.resolve();
                }
            });

            var inChildProcessEntries = function(inProcessComponent) {
                var result = SVMX.array.indexOf(childProcessEntries, function(entry) {
                    return inProcessComponent === entry.target;
                });
                return result != -1;
            };
            var targetChildProcesses = state.processComponents;
            if (childProcessEntries.length === 0) d.resolve();

            // STEP 3: Iterate over each of the sourcechild/targetchild pairs
            SVMX.array.forEach(childProcessEntries, SVMX.proxy(this, function(childProcessEntry) {
                var source = childProcessEntry.source;
                var target = childProcessEntry.target;
                var d;
                // These being the same is a special case where we are mapping from the source header record to a target line item, so no querying for line items needed.
                if (source.target_object_name == headerSource.target_object_name) {
                    d = new $.Deferred();
                    d.resolve([state.sourceRecord]);
                } else {
                    // STEP 3a: Query for all of the source children that we will create targetchildren from.
                    // d = execQuery({
                    //     query: "SELECT * FROM `{{table_name}}` WHERE {{column_name}} = '{{id}}'" + this._getSortString(target.advanced_options, source.target_object_name),
                    //     queryParams: {
                    //         table_name: source.target_object_name,
                    //         column_name: source.parent_column,new $.Deferred();
                    //         id: state.recordId
                    //     }
                    // });
                    d= this.__queryLineItemRecords(source.target_object_name, source.parent_column, state.recordId, target.advanced_options);
                }

                // STEP 3b: Create a Record for each returned entry, and then run the array of results through the expression engine
                d.then(SVMX.proxy(this, function(data) {
                    data = SVMX.array.map(data, function(item) {
                        var r;
                        if (item instanceof RecordClass == false) {
                            r = new RecordClass(item, source.target_object_name);
                            r.messupData();
                        } else {
                            r = item;
                        }
                        return {
                            sobjectinfo: r,
                            bubbleInfo: []
                        };
                    });
                    return this._runExpressionOnLineItems(state, data, source.target_object_name, target.expression_id, source);
                }))

                // STEP 3c: Create a new record (TARGETCHILD) for each SOURCECHILD record passed in
                .then(SVMX.proxy(this, function(data) {
                    // So if we don't get an entry just use an empty entry.
                    var source = childProcessEntry.source,
                        target = childProcessEntry.target,
                        targetDetailSet = SVMX.array.filter(state.data.detailDataSet, function(entry) {
                            return entry.aliasName === childProcessEntry.target.layout_id;
                        })[0],
                        targetChildren = targetDetailSet.pageDataSet = childProcessEntry.data;


                    // STEP 3b: Create target children for each source child.
                    // Return if there are no target children to create.
                    if (data.length === 0 || !target.object_mapping_id) {
                        return onMappingDone(target);
                    }
                    var sourceAttributes = {
                        type: source.object_name,
                        url: "TODO"
                    };

                    // Setup the attributes for the source children
                    // Setup empty objects for the target children.
                    var deferreds = SVMX.array.map(data, function(sourceDataItem, i) {
                        // We will not keep nor edit the sourceChildren
                        // so just have them all point to a single attributes object
                        sourceDataItem.attributes = sourceAttributes;

                        // These we will pass around to others who may edit them,
                        // so best to let each have their own copy.
                        targetChildren.push({
                            sobjectinfo: new RecordClass({
                                sourceRecordId: sourceDataItem.sobjectinfo.Id}, target.target_object_name),
                            bubbleInfo: []
                        });

                        // STEP 3c: Execute the mapping on all of the target children
                        // we just created.
                        return OfflineDataUtils.executeObjectMapping({
                            targetData: targetChildren[i],
                            sourceData: sourceDataItem.sobjectinfo,
                            headSourceData: state.data.pageDataSet.sobjectinfo,
                            valueMappingId: '',
                            objectMappingId: target.object_mapping_id
                        });
                    });

                    SVMX.when(deferreds).then(
                        SVMX.proxy(this, function() {
                            onMappingDone(target);
                        }),
                        SVMX.proxy(this, function() {
                            onMappingDone(target);
                        })
                    );
                }),
                // onError within "then" for runExpressionsOnLineItem
                SVMX.proxy(this, function(error) {
                    logger.error("ERROR: Failed to load source child: " + error);
                    onMappingDone(childProcessEntry.target);
                }));
            }));
            return d;
        },

        /* METHOD: _getAllLineItemRecords
         * STANDLONE EDIT and VIEW PROCESS use this to get all of their line items from the database
         */
        _getAllLineItemRecords: function(state, processComponents, parentRecord) {
            var d = new $.Deferred();
            state.expressionCounter = processComponents.length;

            // For testing the call back ONLY, getAllLineItemRecords only pause on the last detail when debugging!
            //delete processComponents[1];
            // TODO: Replace counter with an array of Deferreds
            var counter = processComponents.length;

            SVMX.array.forEach(processComponents, SVMX.proxy(this, function(processComponent, i) {
                var newPageDataset = state.data.detailDataSet[i];
                this._getLineItemRecords(state, processComponent.target_object_name, processComponent.parent_column, processComponent.expression_id, parentRecord.Id, newPageDataset.pageDataSet, processComponent)
                .then(
                    SVMX.proxy(this, function(data) {
                        var d = new $.Deferred();
                        d.resolve(data);
                        return d;
                    }),
                    SVMX.proxy(this, function(data) {
                        var d = new $.Deferred();
                        d.resolve(data);
                        return d;
                    })
                )

                .then(SVMX.proxy(this, function(data) {
                    // Execute this regardless of whether success or error handler of previous then() was used .then(
                    counter--;
                    if (data.length === 0 && counter === 0) {
                        d.resolve();
                    } else {
                        SVMX.array.forEach(data, function(dataItem, i) {
                            var r = new RecordClass(dataItem, processComponent.target_object_name);
                            r.messupData();

                            newPageDataset.pageDataSet.push({
                                sobjectinfo: r,
                                bubbleInfo: []
                            });

                            if (counter === 0 && i === data.length - 1) {
                                d.resolve();
                            }

                        }, this);
                    }
                }));
            }));

            if (processComponents.length === 0) {
                d.resolve();
            }
            return d;
        },

        /* METHOD: _getLineItemRecords
         * Gets the line item records for a single ProcessComponent
         */
        _getLineItemRecords: function(state, tableName, columnName, expressionId, recordId, pageDataSet, processComponent) {
            state.getLineItemsCounter++;
            var refFieldNameMap = state.lookupDisplayFieldMap && state.lookupDisplayFieldMap.details[processComponent.layout_id];
            return this.__queryLineItemRecords(tableName, columnName, recordId, processComponent.advanced_options, refFieldNameMap);
        },

        __queryLineItemRecords: function(tableName, columnName, recordId, advanced_options, refFieldNameMap) {
            var d = new $.Deferred();
            var fieldSet, fields = [], referenceFields, picklistFields;
            com.servicemax.client.offline.sal.model.utils.FieldSet.getFieldSet(tableName, function(inFieldSet) {
                fieldSet = inFieldSet;
            });
            fieldSet.forEach(function(f) {fields.push(f);});
            referenceFields = fieldSet.getFieldsByType("reference");
            picklistFields = fieldSet.getFieldsByType("picklist");

            var q = OfflineDataUtils.buildQuery("MAIN." + columnName + " = '"+ recordId + "'", tableName, fields,
                this._getSortString(advanced_options, tableName), refFieldNameMap);

            execQuery({
                query: q
            }).then(
                SVMX.proxy(this, function(data) {
                    var namefieldIds = [];
                    for (var i = 0; i < data.length; i++) {
                        var dataItem = data[i];
                        dataItem.attributes = {
                            type: tableName,
                            url: "TODO" // TODO: Does this matter?
                        };

                        // android defect fix. if the field value comes a null then update the field value to empty string.
                        for(var item in dataItem) {
                            var value = dataItem[item];
                            if( !(item.indexOf("__r", item.length - "__r".length) !== -1) && value === null) {
                                dataItem[item] = "";
                            }
                        }

                        // Find reference fields that missing ids.
                        for (var j = 0; j < referenceFields.length; j++) {
                            var f = referenceFields[j];
                            if (!dataItem[f.relationshipName] && dataItem[f.name]) namefieldIds.push(dataItem[f.name]);
                        }

                        this.__assembleRelatedData(dataItem, referenceFields);
                    }

                    OfflineDataUtils.getFromRecordNameTable(namefieldIds).then(
                        SVMX.proxy(this, function(nameFieldData) {
                            var idHash = {};
                            SVMX.array.forEach(nameFieldData, function(item) {
                                idHash[item.Id] = item.Name;
                            });

                            for (var i = 0; i < data.length; i++) {
                                var dataItem = data[i];
                                this.__assembleNameFieldDataNameMap(dataItem, referenceFields, idHash);

                                // See OfflineDataUtils.__fixupReferenceFields
                                for (var j = 0; j < referenceFields.length; j++) {
                                    var f = referenceFields[j];
                                    dataItem[f.name] = {
                                        fieldvalue: dataItem[f.name], // value already assembled.
                                        fieldapiname: f.name
                                    };
                                }
                                // See OfflineDataUtils.__fixPicklists. Do we need to take care of datetime and other fields types as in header?
                                for (j = 0; j < picklistFields.length; j++) {
                                    var f = picklistFields[j];
                                    dataItem[f.name] = {
                                        fieldvalue: {
                                            value: dataItem[f.name],
                                            key: dataItem[f.name]
                                        },
                                        fieldapiname: f.name
                                    };
                                }
                            }
                            d.resolve(data);
                        })
                    );


                }),
                SVMX.proxy(this, function(error) {
                    logger.error("ERROR IN _getLineItemRecords: " + error);
                    d.resolve([]); // continue anyways...
                })
            );

            return d;
        },

        // See OfflineDataUtils.__assembleRelatedData
        __assembleRelatedData: function(data, referenceFields) {
            for (var i = 0; i < referenceFields.length; i++) {
                var f = referenceFields[i];
                var id = data[f.name];
                data[f.name] = {
                    key: id,
                    value: data[f.relationshipName || "field" + i],
                    hasViewSFM: id ? OfflineMetaUtils.doesObjectHaveViewProcess(OfflineMetaUtils.getTableForId(id)) : false
                };
                delete data[f.relationshipName || "field" + i];
            }
        },

        // See OfflineDataUtils.__assembleNameFieldDataNameMap
        __assembleNameFieldDataNameMap: function(data, referenceFields, idNameMap) {
            for (var i = 0; i < referenceFields.length; i++) {
                var f = referenceFields[i];
                if (data[f.name] && !data[f.name].value) {
                    // Make value the looked up value or the ID and a Space. We do not want the value to be blank nor can it match the key.
                    data[f.name].value = idNameMap[data[f.name].key] || (data[f.name].key && data[f.name].key + " ");
                    data[f.name].isNameSyncData = true;
                    data[f.name].hasViewSFM = (data[f.name].key) ? OfflineMetaUtils.doesObjectHaveViewProcess(OfflineMetaUtils.getTableForId(data[f.name].key)) : false;
                }
            }
        },

        /* METHOD: _runExpressionOnLineItems
         * Run each record of a Line Item record set through the expression engine to filter it down to just those
         * that belong in this Record Set
         */
        _runExpressionOnLineItems: function(state, data, tableName, expressionId, processComponent) {
            var d = new $.Deferred();
            if (expressionId && data.length) {
                OfflineExprUtils.evaluate({
                    expressionId: expressionId,
                    data: SVMX.array.map(data, function(item) {
                        return item.sobjectinfo;
                    }),
                    onSuccess: SVMX.proxy(this, function(exprResults) {
                        state.expressionCounter--;
                        var newdata = [];
                        for (var i = 0; i < exprResults.length; i++) {
                            if (exprResults[i]) newdata.push(data[i]);
                        }
                        d.resolve(newdata);
                    }),
                    onError: SVMX.proxy(this, function(inError) {
                        logger.error("ERROR in _runExpressionOnLineItems: " + inError);
                        state.expressionCounter--;

                        // If the expressionId wasn't found in the db, just show all items
                        d.resolve(data);
                    })
                });
            } else {
                state.expressionCounter--;
                d.resolve(data);
            }
            return d;
        },

        /**
         * METHOD: _getProcessComponentsSuccessChecklist
         *
         */
        _getProcessComponentsSuccessChecklist: function(state, inStringMap, inData) {
            //If checklist record is created first time (New State) then it's Source To Target All flow as we need to apply field mapping
            //from source record to target record.
            if(state.targetId == null){
                this._getProcessComponentsSuccessSourceToTargetAll(state, inStringMap, inData);
            }else{
              // If checklist record  is already created (inProgress) we need to re-apply mapping.
              this._getProcessComponentsSuccessChecklistInProgress(state, inStringMap, inData);
            }

        },

        _getProcessComponentsSuccessChecklistInProgress: function(state, inStringMap, inData){
          // Build the Source Record
          var sourceRecord;
          OfflineDataUtils.getRecord({
              Id: state.recordId,
              loadReferences: true,
              convertPicklists: true,
              lookupDisplayFieldMap: state.lookupDisplayFieldMap && state.lookupDisplayFieldMap.head
          })
          .then(SVMX.proxy(this, function(inData) {
              // If there is no OwnerId, we need to set an OwnerId; use the current user.
              // Set here in case the field is editable by the current process; in which case
              // it needs a value here and not in SaveTargetRecord, and it needs a display value too.
              if (!inData.OwnerId) {
                  inData.OwnerId = {fieldvalue: {key: state.UserData.UserId, value: state.UserData.UserName}};
              } else if (typeof inData.OwnerId == "string") {
                  if (inData.OwnerId == state.UserData.UserId) {
                      inData.OwnerId = {fieldvalue: {key: state.UserData.UserId, value: state.UserData.UserName}};
                  }
              } else if (inData.OwnerId.fieldvalue.key === inData.OwnerId.fieldvalue.value &&
                          inData.OwnerId.fieldvalue.key === state.UserData.UserId) {
                  inData.OwnerId.fieldvalue.value = state.UserData.UserName;
              }
              sourceRecord  = new RecordClass(inData, inData.attributes.type);

              // Execute fieldMapping
              OfflineDataUtils.executeObjectMapping({
                  targetData: [state.data.pageDataSet],
                  sourceData: sourceRecord,
                  valueMappingId: null,
                  objectMappingId: state.processData.object_mapping_id
              })
              .then(SVMX.proxy(this, function() {
                  return this.__onDone(state);
              }));
          }));
        },

        /**
         * METHOD: _getProcessComponentsSuccessChecklistList
         *
         */
        _getProcessComponentsSuccessChecklistList: function(state, inStringMap, inData) {
            // TODO: Possibly grab the JSON out of the checklist object and convert it to something consumable.
            this._getProcessComponentsSuccessStandaloneEdit(state, inStringMap, inData);
        },

        /*
         * Hijack the on complete to do the datetime conversion for header
         * and line data
         *
         */
        _onGetHeaderAndLineItemComplete: function(state) {
            var d = $.Deferred();

            // DatetimeUtil Revamp. These should be converted when we display, not in the sal layer.
            // var offset = state.UserData.TimezoneOffset;
            // //header dates
            // var record = state.data.pageDataSet.sobjectinfo;
            // this._processDateToUserTimezone(state, record, offset);
            //
            // //line data dates
            // var collection = state.data.detailDataSet;
            // this._processDetailsDate(state, collection, offset);

            d.resolve();

            return d;
        },

        /* METHOD: _flagOpenrecords
         * If there is as requesterId, then we should mark all Records being shown to the user as Open
         * and therefore unsyncable.
         */
        _flagOpenRecords: function(state) {
            if (state.requesterId && state.processType !== "VIEW RECORD" && state.processType !== "STANDALONE CREATE" && state.processType !== "SOURCE TO TARGET ALL") {
                var recordIds = [];
                var headerId = state.data.pageDataSet.sobjectinfo.getValue("Id");
                if (headerId) recordIds.push(headerId);
                var details = state.data.detailDataSet;
                SVMX.array.forEach(details, function(detailSet) {
                    SVMX.array.forEach(detailSet.pageDataSet, function(recordItem) {
                        var record = recordItem.sobjectinfo;
                        if (record.getValue("Id")) recordIds.push(record.getValue("Id"));
                    });
                });
                OfflineSyncUtils.setOwnerId(state.requesterId);
                OfflineSyncUtils.addOpenRecords(state.requesterId, recordIds);
            } else if (!OfflineSyncUtils.getOwnerId() && state.requesterId) {
                // We will need this set later if we are inserting records
                OfflineSyncUtils.setOwnerId(state.requesterId);
            }
        },
        __onDone: function(state) {
            if(state.requesterId !== "SYNC"){
                this._flagOpenRecords(state);
            }
            state.responder.result(SVMX.create("com.servicemax.client.offline.sal.model.impl.SFMDeliveryData", state.data));
        }
    });

    /**
     * Get a list of CHECKLIST or OUTPUTDOCUMENT templates.
     *
     * @class       com.servicemax.client.offline.sal.model.sfmdelivery.operations.GetTemplateData
     * @extends     com.servicemax.client.mvc.api.Operation
     */
    sfmdeliveryoperations.Class("GetTemplateData", com.servicemax.client.mvc.api.Operation, {
        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            request = request || {};

            // Optional
            var userTrunk = "";
            var processId = null;

            var result = {}; // object that will be the result of this operation
            var state = {
                //What type of templates are we looking for? CHECKLIST or "OUTPUT DOCUMENT"
                templateType: request.templateType || "CHECKLIST",

                // Typically the componentType is "TARGET"; thats what SFMDelivery uses to generate a form for the user
                // However, occasionally we need to get all of the records associated with SOURCE and SOURCECHILD ProcessComponents
                // such as when doing SourceObjectUpdates
                componentType: request.componentType || "TARGET",

                // refreshData used after quickSave when loading updated data from the db but NOT reexecuting the process and its mappings.
                refreshData: request.refreshData,

                // The requesterId lets us indicate that records have been openned by the specified requester,
                // and later lets us mark them as no longer opened.
                requesterId: request.requesterId,

                templates: [],
                virtualFieldName : request.virtualFiledName || "LIST_SECTION_FIELD_ID",

                // Setup the basic structure that we'll be returning
                data: {

                    // While response is part of what we get back from the online call, I don't think we use it anywhewre
                    response: {
                        stringMap: []
                    },

                    // The header record
                    pageDataSet: {
                        sobjectinfo: {},
                        bubbleInfo: []
                    },

                    // The Line Items
                    detailDataSet: [
                        /* Zero or more entries like this:
                        {
                            pageDataSet: {
                                sobjectinfo: null, // TODO
                                bubbleInfo: [] // TODO
                            }
                        }*/
                    ]
                },

                // Number of expressions to be evaluated
                expressionCounter: 0,

                // The name of the table that contains the header record
                tableName: request.virtualTableName || "Virtual__c",

                // Id of the record that is either the Header or SOURCE record.  For STANDALONE CREATE this may be null.
                recordId: request.recordId,

                responder: responder,
                svmxConstants : []
            };

            var d = this._getUserInfo(state);
            d = d.then(SVMX.proxy(this, this._getTemplates));
            d = d.then(SVMX.proxy(this, this._getExistingTemplates));
            d = d.then(SVMX.proxy(this, this._populateSObjectInfo));

            d.done(SVMX.proxy(this, this.__onDone));
            d.fail(SVMX.proxy(this, this.__onError));
        },

        _getUserInfo : function(state){
            var d = SVMX.Deferred();

            var userData = OfflineSystemUtils.getUserInfo();

            var userTrunkValue = userData.UserTrunkDetail ? userData.UserTrunkDetail.Id : null;
            state.UserData = userData;
            state.svmxConstants.push({fieldsToNull : null, key : "SVMX.USERTRUNK", value : userTrunkValue, value1 : null});
            state.data.svmxConstants = state.svmxConstants;

            d.resolve(state);

            return d;
        },

        _getTemplates : function(state) {
            state = state || {};
            var prefix = (state.recordId && state.recordId.length > 3) ? state.recordId.substring(0,3) : "";

            var query = "SELECT " +
                "    p.process_id, p.process_unique_id, p.process_type, " +
                "    p.process_name, p.process_description, " +
                "    pc.expression_id " +
                "FROM SFProcess AS p " +
                "JOIN SFProcessComponent AS pc " +
                "    ON p.process_id = pc.process_id  " +
                "AND " +
                "    pc.component_type = 'TARGET' " +
                "WHERE " +
                "   p.process_type = 'CHECKLIST' " +
                "AND " +
                "    p.process_id IN ( " +
                "                       SELECT " +
                "                           p2.process_id " +
                "                       FROM SFProcess AS p2 " +
                "                       JOIN SFObjectDescribe AS d2 " +
                "                           ON d2.object_name = pc2.object_name " +
                "                       AND " +
                "                           d2.key_prefix = '{{object_prefix}}' " +
                "                       JOIN SFProcessComponent AS pc2 " +
                "                           ON p2.process_id = pc2.process_id " +
                "                       AND " +
                "                           pc2.component_type = 'SOURCE' " +
                "                       WHERE " +
                "                           p2.process_type = 'CHECKLIST' " +
                "                   )";

            var d = execQuery({
                query: query,
                queryParams: {
                    object_prefix: prefix
                }
            }).then(SVMX.proxy(this, this.__populateTemplates, state));

            return d;
        },

        _getExistingTemplates : function(state) {
            state = state || {};

            var query  = "SELECT " +
                "    c.Id as targetId, " +
                "    c."+SVMX.OrgNamespace+"__Completed_On__c, " +
                "    c."+SVMX.OrgNamespace+"__Status__c, " +
                "    c."+SVMX.OrgNamespace+"__ChecklistProcessID__c, " +
                "    p.process_id, p.process_unique_id, p.process_type, " +
                "    p.process_name, p.process_description, " +
                "    pc.expression_id " +
                "FROM "+SVMX.OrgNamespace+"__Checklist__c AS c " +
                "JOIN SFProcess as p " +
                "    ON p.process_id = c."+SVMX.OrgNamespace+"__ChecklistProcessID__c " +
                "LEFT JOIN SFProcessComponent AS pc " +
                "    ON c."+SVMX.OrgNamespace+"__ChecklistProcessID__c  = pc.process_id  " +
                "    AND pc.component_type = 'TARGET' " +
                "WHERE " +
                "    c."+SVMX.OrgNamespace+"__What_Id__c = '{{record_id}}'";

            var d = execQuery({
                query: query,
                queryParams: {
                    record_id: state.recordId
                }
            }).then(SVMX.proxy(this, this.__populateExistingTemplates, state));

            return d;
        },

        _populateSObjectInfo : function(state) {
            var d = SVMX.Deferred();
            state = state || {};
            state.data = state.data || {};


            var objectDescribe = {
                "activateable": false,
                "childRelationships": [],
                "createable": true,
                "custom": true,
                "customSetting": false,
                "deletable": true,
                "deprecatedAndHidden": false,
                "feedEnabled": false,
                "fields": [

                    {
                        "autoNumber": false,
                        "byteLength": 393216,
                        "calculated": false,
                        "calculatedFormula": null,
                        "caseSensitive": false,
                        "controllerName": null,
                        "createable": true,
                        "custom": true,
                        "defaultValue": null,
                        "defaultValueFormula": null,
                        "defaultedOnCreate": false,
                        "dependentPicklist": false,
                        "deprecatedAndHidden": false,
                        "digits": 0,
                        "externalId": false,
                        "filterable": false,
                        "groupable": false,
                        "htmlFormatted": false,
                        "idLookup": false,
                        "inlineHelpText": null,
                        "label": "Checklist",
                        "length": 131072,
                        "name": state.virtualFiledName,
                        "nameField": true,
                        "namePointing": false,
                        "nillable": true,
                        "permissionable": true,
                        "picklistValues": [],
                        "precision": 0,
                        "referenceTo": [],
                        "relationshipName": null,
                        "relationshipOrder": null,
                        "restrictedPicklist": false,
                        "scale": 0,
                        "soapType": "xsd:string",
                        "sortable": false,
                        "type": "textarea",
                        "unique": false,
                        "updateable": true,
                        "writeRequiresMasterRead": false
                    }
                ],
                "keyPrefix": "---",
                "label": "Checklist",
                "labelPlural": "Checklists",
                "layoutable": true,
                "listviewable": null,
                "lookupLayoutable": null,
                "mergeable": false,
                "name": state.tableName,
                "queryable": true,
                "recordTypeInfos": [],
                "replicateable": true,
                "retrieveable": true,
                "searchLayoutable": null,
                "searchable": true,
                "triggerable": true,
                "undeletable": true,
                "updateable": true,
                "urls": {}
            };

            state.data.pageDataSet = {
                sobjectinfo: new VirtualRecordClass(
                    {
                        sourceRecordId: state.recordId,
                        Id: state.recordId,
                        LIST_SECTION_FIELD_ID: {fieldvalue: {key:"templates", value:state.templates}},
                        objectDescribe: objectDescribe
                    },
                    state.tableName
                ),
                bubbleInfo: []
            };

            d.resolve(state);

            return d;
        },

        __populateTemplates : function(state, data) {
            var d = SVMX.Deferred();
            state = state || {};
            data = data || [];
            state.templates = state.templates || [];

            OfflineMetaUtils.validateProcessesQualificationForRecord({
                record: state.record,
                recordId: state.recordId
            }, data)
            .then(SVMX.proxy(this, function(checklistProcesses) {
                if(checklistProcesses && checklistProcesses.length > 0) {
                    console.info("Qualified checklist processes: " + checklistProcesses.length);
                    for (var i = 0; i < checklistProcesses.length; i++) {
                        state.templates.push({
                            "status": "Qualified",
                            "recordId": state.recordId,
                            "processName": checklistProcesses[i].process_name,
                            "processId": checklistProcesses[i].process_unique_id,
                            "sfProcessId": checklistProcesses[i].process_id,
                            "description": checklistProcesses[i].process_description
                        });
                    }
                }
                d.resolve(state);

            }));
            return d;
        },

        __populateExistingTemplates : function(state, data) {
            var d = SVMX.Deferred();

            state = state || {};
            data = data || [];
            state.templates = state.templates || [];

            OfflineMetaUtils.validateProcessesQualificationForRecord({
                record: state.record,
                recordId: state.recordId
            }, data)
            .then(SVMX.proxy(this, function(checklistProcesses) {
                if(checklistProcesses && checklistProcesses.length > 0) {
                    console.info("Qualified existing checklist processes: " + checklistProcesses.length);
                    for (var i = 0; i < checklistProcesses.length; i++) {
                        state.templates.push({
                            "status": checklistProcesses[i][SVMX.OrgNamespace+"__Status__c"] || "In Progress",
                            "recordId": state.recordId,
                            "processName": checklistProcesses[i].process_name,
                            "processId": checklistProcesses[i].process_unique_id,
                            "sfProcessId": checklistProcesses[i].process_id,
                            "description": checklistProcesses[i].process_description,
                            "completionDate": checklistProcesses[i][SVMX.OrgNamespace+"__Completed_On__c"],
                            "targetId" : checklistProcesses[i].targetId
                        });
                    }
                }
                d.resolve(state);

            }));
            return d;
        },

        __onError: function(state) {
            state = state || {};
            state.data = state.data || {};
            state.data.error = state.data.error || {};

            logger.error(state.data.error);

            if (state && state.responder) {
                state.responder.result(SVMX.create("com.servicemax.client.sfmdelivery.operationutils.SFMDeliveryData", state.data));
            }
        },

        __onDone: function(state) {
            if (state && state.responder) {
                state.responder.result(SVMX.create("com.servicemax.client.offline.sal.model.impl.SFMDeliveryData", state.data));
            }
        }

    }, {});

    sfmdeliveryoperations.Class("CloseProcess", com.servicemax.client.mvc.api.Operation, {
        performAsync: function(request, responder) {
            OfflineSyncUtils.removeOpenRecords(request.requesterId);
            OfflineSyncUtils.setOwnerId(null);
        }
    });
    sfmdeliveryoperations.Class("GetNextStepInfo", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {

        }

    }, {});

    sfmdeliveryoperations.Class("InvokeEvent", com.servicemax.client.mvc.api.Operation, {
        __responder: null,
        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            request.additionalInfo.eventType = request.event.eventType;
            this.__responder = responder;
            var utils = com.servicemax.client.offline.sal.model.utils;

            //Due to aggressive sync local record can get replaced with the sf id
            //check before invoking event
            var recordIdItem = request.data.getTargetRecordId();
            var mapRemoteIds = utils.SyncData.getOpenRecordRemoteIds();
            if (recordIdItem in mapRemoteIds) {
                request.data.setTargetRecordId(mapRemoteIds[recordIdItem]);
            }

            var eventInfo = request.event;
            if(eventInfo.callType == "WEBSERVICE"){
                responder.result(); // noop
            }else if(eventInfo.callType == "JAVASCRIPT"){
                this.__invokeJavaScriptEvent(request, responder);
            }else if(eventInfo.callType == "URL"){
                responder.result(); // noop
            }else{
                responder.result(); // unknown event type
            }
        },
        __invokeJavaScriptEvent : function(request, responder) {
            var eventRawData = request.event.eventRawData;
            this.__getCodeSnippet(eventRawData)

            .then(SVMX.proxy(this, function(snippet){

                // secureEval fails since snippets will contain functions
                if(typeof snippet == 'string'){
                    snippet = eval(snippet);
                }

                if(snippet && (snippet instanceof Array) && snippet.length > 0){
                    this.__invokeSnippet(snippet, request);
                }else{
                    this.__responder.result();
                }
            }));
        },

        __invokeSnippet : function(allSnippets, request){
            var finalSnippet = "", snippet;
            for(var inSnippet in allSnippets){
                snippet = allSnippets[inSnippet].snippet;

                // TODO: Michael, SQLRequest call escapes all newlines. Please check with Eric
                snippet = snippet.replace(new RegExp("&#10;", "g"), "\n");

                finalSnippet += snippet;
            }

            // snadbox the snippet
            finalSnippet = "try { (function(){" + finalSnippet + "})(); } catch(e) {$EXPR.Logger.error('JS Snippet Error: ' + e); $RETURN(context);}";


             var targetRecord = SVMX.create("com.servicemax.client.sfmdelivery.operationutils.SFMTargetRecord",
                request.data, request.metadata, request.additionalInfo);
            var requestData = targetRecord.getRequest();

            $EXPR.SVMXEvalExpression(finalSnippet, requestData, function(result){
                request.data.copyFromTargetRecord(result);
                    this.__responder.result();
            }, this);

        },

        // returns a Deferred: this.__getCodeSnippet(info).then(...)
        __getCodeSnippet : function(eventInfo){
            return execQuery({
                query: "Select {{ns}}__Referenced_Code_Snippet__c as sid from {{ns}}__Code_Snippet_Manifest__c where {{ns}}__Code_Snippet__c = '{{sid}}'",
                queryParams: {
                    ns: SVMX.OrgNamespace, sid : eventInfo[SVMX.OrgNamespace + "__Code_Snippet__c"]
                }
            })
            .then(SVMX.proxy(this, function(allIds) {
                var ids = [];
                ids.push("'" + eventInfo[SVMX.OrgNamespace + "__Code_Snippet__c"] + "'");
                for(var i in allIds){
                    ids.push("'" + allIds[i].sid + "'");
                }

                return execQuery({
                    query: "Select {{ns}}__Data__c as snippet from {{ns}}__Code_Snippet__c where Id in ({{ids}})",
                    queryParams: {
                        ns: SVMX.OrgNamespace, ids : ids.join(",")
                    }
                });
            }));
        }
    }, {});


    sfmdeliveryoperations.Class("SaveTargetRecord", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var data = request.data.__data.sfmData;
            var detailIdMap = {};
            var layoutIds = [];

            SVMX.forEachProperty(data.details, function(inKey, inValue) {layoutIds.push(inKey);});
            execQuery({
                query: "SELECT layout_id, object_name FROM SFProcessComponent where layout_id IN ('{{ids}}')",
                queryParams: {ids: layoutIds.join("','")}
            })
            .then(SVMX.proxy(this, function(inData) {
                for (var i = 0; i < inData.length; i++) {
                    var item = inData[i];
                    detailIdMap[item.layout_id] = item.object_name;
                }

                // Store all the state we'll need to process this request
                var state = {
                    responder: responder,

                    // The processId that identifies the data we are saving
                    processId: request.additionalInfo.processId,

                    // Process information based on processId
                    processData: null,

                    // Typically we are saving "TARGET" and "TARGETCHILD" records, but SourceObjectUpdates may
                    // require us to call this with "SOURCE" and "SOURCECHILD" records.
                    componentType: request.componentType || "TARGET",

                    // Name of the table to write the header record
                    objectName: data.attributes.type,

                    // For SOURCE TO TARGET processes, we'll need a sourceRecordId so we can
                    // find the record and its line items that need to be updated
                    sourceRecordId: request.sourceRecordId,

                    // The dat we are writing.
                    // we'll be editing this structure, clone it so we don't change the model's data
                    data: SVMX.cloneObject(data),

                    // Array of recordIds to be deleted
                    deletedRecords: request.data.__deletedRecords,

                    // Maps from detail Ids (aliasName/layout_id) to a table name
                    detailMap: detailIdMap,

                    // Counter for tracking how many deletions remain before we are done
                    deleteCounter: 0,

                    // Hash of tasks that need to be done for us to be finished
                    itemsDoneHash: {
                        header: false
                    },

                    // Is the sourceObjectUpdate finished?  Defaults to true unless it turns out our process requires this feature
                    sourceObjectUpdateDone: true,

                    // To keep the sync insert records
                    syncInsertRecords: [],

                    // To keep the sync update records
                    syncUpdateRecords: [],

                    // To keep the sync delete records
                    syncDeleteRecords: [],

                    // To keep field merge enabled setting value
                    isFieldMergeEnabled: false,

                    // To keep webservice actions
                    wsInfo: null,

                    skipAggressiveSync: request.skipAggressiveSync,
                    doSourceObjectUpdate : request.doSourceObjectUpdate
                };

                if(request.metadata && request.metadata.page && request.metadata.page.header) {
                    var actions = this.getWebServiceActions(request.metadata.page.header.pageEvents);
                    if(actions && actions.length){
                        state.wsInfo = {
                            actionTime: (new Date().getTime()),
                            processType: request.metadata.response.sfmProcessType,
                            processId: state.processId,
                            actions: actions
                        };
                    }
                }

                // Step 1: Get the process data
                OfflineMetaUtils.getProcess({
                    processId: state.processId
                })

                .then(SVMX.proxy(this, function(data) {
                    state.processData = data[0];
                    state.sfProcessId = data[0].process_id;
                    state.processType = state.processData.process_type;

                    // Step 2: Trigger the SourceObjectUpdate if the process supports it, and we aren't writing a "SOURCE" componentType
                    // (a SOURCE componentType means we're writing the results of a SourceObjectUpdate)
                    if (state.componentType === "TARGET" && (state.processType === "SOURCE TO TARGET ALL" || state.processType === "SOURCE TO TARGET CHILD" || (state.processType === "CHECKLIST" && state.doSourceObjectUpdate) )) {
                        this.executeSourceObjectUpdate(state);
                    }

                    // Step 3: Load all of the field types
                    // TODO: Should reuse GetPageData's _cacheAllFieldSets method
                    OfflineMetaUtils.describeObject({
                        objectName: state.objectName,
                        onSuccess: SVMX.proxy(this, function(data) {

                            // Step 3a: Replace all reference fields with just the key
                            this.__replaceRefs(state, state.data, data.fields);

                            // Step 3b: For each line item set (processcomponent) and record in the line item set, add an entry to itemsDoneHash
                            // This lets us track when the multi-threaded process is done
                            SVMX.forEachProperty(state.data.details, SVMX.proxy(this, function(inKey, inValue) {
                                for (var i = 0; i < state.data.details[inKey].lines.length; i++) {
                                    state.itemsDoneHash[inKey + "_" + i] = false;
                                }
                            }));

                            // Step 3c: Modify record for specific use cases
                            this.__modifyDataForSpecificUseCases(state.objectName, state.data);



                            this.getIsFieldMergeEnabled(function(isFieldMergeEnabled){
                                state.isFieldMergeEnabled = isFieldMergeEnabled;
                                // Step 3d: Write the header record
                                this.__writeItem(state, state.objectName, state.data, data.fields, null, "header");

                                // Step 3e: Write each set of line items
                                SVMX.forEachProperty(state.data.details, SVMX.proxy(this, function(inKey, inValue) {
                                    this.__processLineItem(state.data.details[inKey].lines, inKey, state);
                                }));
                            });
                        }),

                        // If describeObject fails, pass the message back through the responder.
                        onError: function(evt) {
                            logger.error("Describe Object Failed for " + request.objectName);
                            state.error = "Describe Object Failed for SaveTargetRecord while requesting " + state.objectName;
                            if (evt.data.data) state.error += "; " + evt.data.data;
                            state.responder.result(state);
                        }
                    });
                }));
            }));
        },

        getWebServiceActions: function(pageEvents){
            var actions = [];

            for(var i = 0, l = pageEvents.length; i < l;i++){
                var pageEvent = pageEvents[i];

                var callType = pageEvent[SVMX.OrgNamespace+"__Event_Call_Type__c"];
                var eventType = pageEvent[SVMX.OrgNamespace+"__Event_Type__c"];
                var methodName = pageEvent[SVMX.OrgNamespace+"__Target_Call__c"];

                //Before Save/Update, After Save/Update, After Save/Insert
                if(callType && eventType && callType === 'WEBSERVICE' && eventType !== "Before Save/Insert" ){
                    var eventDetail = {
                        callType: callType,
                        eventType: eventType,
                        methodName: methodName
                    };
                    actions.push(eventDetail);
                }
            }
            return actions;
        },

        // Replace all refererence fields with the key value... unless its a RecordTypeId; for some reason those have to be written as values.
        __replaceRefs: function(state, sobjectinfo, fields) {
            var data = $.isArray(sobjectinfo) ? sobjectinfo : [sobjectinfo];
            for (var dataIndex = 0; dataIndex < data.length; dataIndex++) {
                var d = data[dataIndex];
                for (var i = 0; i < fields.length; i++) {
                    var f = fields[i];
                    if ((f.type == "reference" || f.type == "picklist") && d[f.name] && typeof d[f.name] == "object" && "fieldvalue" in d[f.name]) {
                        // Insert entries in SFRecordName for all references to ProductIQ Records
                        if(f.type == "reference" && (f.referenceTo == SVMX.OrgNamespace + "__Installed_Product__c" || f.referenceTo == SVMX.OrgNamespace + "__Site__c")){
                            OfflineDataUtils.insertUpdateRecordIntoNameTable( d[f.name].fieldvalue.key,  d[f.name].fieldvalue );
                        }
                        d[f.name] = d[f.name].fieldvalue.key;
                    }
                }
            }
        },

        // Modify records for targeted use cases,
        // Example: auto set TechnicianId on SVMX_Event records
        __modifyDataForSpecificUseCases: function(objectName, data) {
            // New SVMX_Event records need user related technician id set
            if (objectName === SVMX.OrgNamespace+'__SVMX_Event__c') {
                var userInfo = OfflineSystemUtils.getUserInfo();
                data[SVMX.OrgNamespace+'__Technician__c'] = userInfo.UserTechId;
            }
        },

        // Write a record; find its parent column so that it gets set to point to the header record... unless we're working on the header.
        __writeItem: function(state, tableName, sobjectinfo, fields, detailId, isDoneKey, callbackObj) {
            // We also don't bother updating the parent column if state.componentType == "SOURCE"; we're not updating
            // these values when doing SourceObjectUpdates.
            if (isDoneKey != "header" && state.componentType === "TARGET") {
                sfmdeliveryoperations.Utilities.getProcessComponents({
                    processId: state.processId,
                    onSuccess: SVMX.proxy(this, function(inStringMap, inData) {
                        for (var i = 0; i < inData.length; i++) {
                            var d = inData[i];
                            if (d.layout_id === detailId) {
                                var parentColumn = d.parent_column;
                                this.__writeItem2(state, tableName, sobjectinfo, fields, detailId, parentColumn, isDoneKey, callbackObj);
                                return;
                            }
                        }
                    })
                });
            } else {
                this.__writeItem2(state, tableName, sobjectinfo, fields, detailId, null, isDoneKey, callbackObj);
            }
        },

        getIsFieldMergeEnabled: function(callback){
            execQuery({
                query: "SELECT * FROM MobileDeviceSettings WHERE setting_id = '{{settingId}}'",
                queryParams: {settingId: 'IPAD018_SET016'}
            })
            .then(SVMX.proxy(this, function(inData) {
                var val = false;
                if(inData && inData.length && inData[0].value){
                    val = inData[0].value.toLowerCase() === "true" ? true: false;
                }
                callback && callback.call( this, val );
            }));
        },

        __writeItem2: function(state, tableName, sobjectinfo, fields, detailId, parentColumn, isDoneKey, callbackObj) {
            var setText = [];

            // If there is a parentColumn (not a header item), then assign the value
            // for that parentColumn to point to the header_item's local_id
            if (parentColumn) {
                sobjectinfo[parentColumn] = state.data.Id;
            }
            OfflineDataUtils.writeRecord({
                data: sobjectinfo,
                type: tableName,
                fields: fields,
                parentId: parentColumn ? state.data.Id : null,
                isFieldMergeEnabled: state.isFieldMergeEnabled,
                onSuccess: SVMX.proxy(this, function(isInsert, syncRecordData) {
                    if(syncRecordData){
                        if(state.wsInfo && !state.wsInfo.recordId) {
                            if(syncRecordData.parentId){
                                state.wsInfo.recordId = syncRecordData.parentId;
                            }else{
                                state.wsInfo.recordId = syncRecordData.Id;
                            }
                        }
                        if(isInsert){
                            state.syncInsertRecords.push(syncRecordData);
                        }else{
                            state.syncUpdateRecords.push(syncRecordData);
                        }
                    }
                    if(callbackObj && callbackObj.handler){
                        callbackObj.handler.call(callbackObj.context);
                    }
                    state.itemsDoneHash[isDoneKey] = true;
                    this.__isDone(state);
                }),
                onError: SVMX.proxy(this, function(inError) {
                    if(callbackObj && callbackObj.handler){
                        callbackObj.handler.call(callbackObj.context);
                    }
                    logger.error("writeItem2 FAILED: " + inError);
                    state.itemsDoneHash[isDoneKey] = true;
                    //alert("Write Item Failed!"); // TODO: we need better error handling
                    this.__isDone(state);
                })
            });
        },

        __processLineItem : function(dataList, detailId, state) {
            if (dataList.length == 0 && !SVMX.array.contains(state.deletedRecords, function(inItem) {
                return inItem.alias === detailId;
            })) {
                return;
            }

            // Type from dataList may not match detailMap if we're doing sourceobjectupdates (we have a SOURCECHILD)
            var type = dataList.length ? dataList[0].attributes.type : state.detailMap[detailId];
            OfflineMetaUtils.describeObject({
                objectName: type,
                onSuccess: SVMX.proxy(this, function(describeObjectData) {
                    var i,
                        me = this,
                        j = 0;

                    for (i = 0; i < dataList.length; i++) {
                        this.__replaceRefs(state, dataList, describeObjectData.fields);
                    }

                    //Start Block for Defect Fix : 026269: Adding Lines One by One
                    //Sending Lines one by one to retain the lines in the order they were added
                    var callbackObj = {
                        handler : function(){
                            j++;
                            if(j<dataList.length){
                             addLinesOneByOne(j);
                            }
                        },
                        context : me
                    };
                    function addLinesOneByOne(j)
                    {
                        me.__writeItem(state, type, dataList[j], describeObjectData.fields, detailId, detailId + "_" + j, callbackObj );
                    }
                    if(dataList.length){
                        addLinesOneByOne(j);
                    }
                    //End Block Defect Fix: 026269 : Adding Lines One by One

                    var delRecs = SVMX.cloneObject(state.deletedRecords);
                    state.deletedRecords.length = 0;

                    SVMX.array.forEach(delRecs, function(record) {
                        if (record.alias === detailId) {
                            state.deleteCounter++;
                            OfflineDataUtils.deleteRecord({
                                Id: record.id,
                                isHeader: false,
                                onSuccess: SVMX.proxy(this, function(syncRecordData) {
                                    state.deleteCounter--;
                                    if(syncRecordData){
                                        state.syncDeleteRecords.push(syncRecordData);
                                    }
                                    this.__isDone(state);
                                }),
                                onError: SVMX.proxy(this, function() {
                                    state.deleteCounter--;
                                    logger.error("Failed to delete record");
                                    this.__isDone(state);
                                })
                            });
                        }else{
                            state.deletedRecords.push(record);
                        }
                    }, this);
                }),
                onError: function(evt) {
                    logger.error("Describe Object Failed for " + state.objectName);
                    state.error = "Describe Object Failed for SaveTargetRecord while requesting " + type;
                    if (evt.data.data) state.error += "; " + evt.data.data;
                    state.responder.result(state);
                }
            });
        },


        executeSourceObjectUpdate: function(state) {
            // flag that sourceObjectUpdate needs to be finished before SaveTargetRecord is done
            state.sourceObjectUpdateDone = false;
            var sourceUpdateData, sourceRecords = {};


            // Gather the Source Update config data
            execQuery({
                query: "select * from SFSourceUpdate LEFT JOIN SFProcessComponent ON SFProcessComponent.Id = SFSourceUpdate.target_process_node where SFProcessComponent.process_id='{{process_id}}' AND configuration_type='Source Update'",
                queryParams: {
                    process_id: state.sfProcessId
                }
            })

            // Call GetPageData to gather the SOURCE and SOURCECHILD records
            .then(SVMX.proxy(this, function(sourceUpdateDataIn) {
                sourceUpdateData = sourceUpdateDataIn; // now visible to entire parent method
                if (sourceUpdateData.length === 0) {
                    state.sourceObjectUpdateDone = true;
                    return;
                }

                // Gather the sourceRecordIds
                var sourceRecordIds = {};
                if(state.processType === "CHECKLIST" && state.sourceRecordId != null && !state.data.hasOwnProperty("sourceRecordId")){
                    state.data.sourceRecordId = state.sourceRecordId;
                }
                if (state.data.sourceRecordId) {
                    sourceRecordIds[OfflineMetaUtils.getTableForId(state.data.sourceRecordId)] = [state.data.sourceRecordId];
                }
                SVMX.forEachProperty(state.data.details, function(inKey, inValue) {
                    SVMX.array.forEach(inValue.lines, function(item) {
                        if (item.sourceRecordId) {
                            var tableName = OfflineMetaUtils.getTableForId(item.sourceRecordId);
                            if (!sourceRecordIds[tableName]) sourceRecordIds[tableName] = [];
                            sourceRecordIds[tableName].push(item.sourceRecordId);
                        }
                    });
                });


                // Load all source records from the sourceRecordIds
                var deferreds = [];
                SVMX.forEachProperty(sourceRecordIds, SVMX.proxy(this, function(tableName, ids) {
                    var d = new $.Deferred();
                    deferreds.push(d);
                    execQuery({
                        query: "SELECT * FROM '{{table_name}}' WHERE Id IN ('{{ids}}')",
                        queryParams: {table_name: tableName, ids: ids.join("','")}
                    }).then(SVMX.proxy(this, function(sourceRecordData) {
                        for (var i = 0; i < sourceRecordData.length; i++) {
                            sourceRecords[sourceRecordData[i].Id] = new RecordClass(sourceRecordData[i], tableName);
                        }
                        d.resolve();
                    }));
                }));

                return SVMX.when(deferreds);
            }))

            // Execute the mappings on the sourceRecords
            .then(SVMX.proxy(this, function() {
                SVMX.array.forEach(sourceUpdateData, function(updateData) {
                    var layoutId = updateData.layout_id;
                    var type = updateData.component_type;

                    // Execute TARGET mappings on the SOURCE record
                    if (type === "TARGET") {
                        var targetRecord = state.data;
                        var sourceRecord = sourceRecords[targetRecord.sourceRecordId];
                        if (sourceRecord) {
                            this.executeOneSourceObjectUpdate(
                                state.data,
                                sourceRecord,
                                updateData
                            );
                        }
                    }

                    // Execute TARGETCHILD mappings on the specified line item records
                    else {
                        var targetData = state.data.details;
                        SVMX.forEachProperty(targetData, SVMX.proxy(this, function(inKey, inValue) {
                            var targetLines = inValue.lines;
                            SVMX.array.forEach(targetLines, function(targetRecord) {
                                var sourceRecord = sourceRecords[targetRecord.sourceRecordId];
                                if (sourceRecord) {
                                    this.executeOneSourceObjectUpdate(targetRecord, sourceRecord, updateData);
                                }
                            }, this);
                        }));
                    }
                }, this);


                // Save all sourceRecords
                var saveDeferreds = [];
                SVMX.forEachProperty(sourceRecords, SVMX.proxy(this, function(inId, inRecord) {
                    var d = new $.Deferred();
                    saveDeferreds.push(d);
                    inRecord.writeRecord(
                        function(isInsert, syncRecordData) {
                            // Defect 020511
                            if(syncRecordData){
                                if(isInsert){
                                    state.syncInsertRecords.push(syncRecordData);
                                }else{
                                    state.syncUpdateRecords.push(syncRecordData);
                                }
                            }
                            d.resolve();
                        },
                        function(e) {
                            logger.error("Failed to write sourceObjectUpdate record " + inId + ": " + e.message + "; " + e.stack);
                            d.resolve();
                        }
                    );
                }));
                return SVMX.when(saveDeferreds);
            }))
            .then(
                SVMX.proxy(this, function() {
                    state.sourceObjectUpdateDone = true;
                    this.__isDone(state);
                }),
                SVMX.proxy(this, function(error) {
                    logger.error("ERROR IN executeSourceToTargetMappings: " + error);
                    state.sourceObjectUpdateDone = true;
                    this.__isDone(state);
                })
            );

        },

        // Executes a SourceObjectUpdate for a single SourceUpdate Entry and a single Record.
        executeOneSourceObjectUpdate: function(copyFromRecord, copyToRecord, updateData) {

            if (updateData.source_field_name && (updateData.source_field_name.toLowerCase() === "id")) {
                SVMX.getLoggingService().getLogger().error("Source Update: Cannot mapping into id field. Please remove the mapping!");
            }

            var value;
            if (updateData.target_field_name) {
                value = copyFromRecord[updateData.target_field_name];
            } else {
                value = updateData.display_value;
                switch (value) {
                    case "Now":
                        value = com.servicemax.client.lib.datetimeutils.DatetimeUtil.macroDrivenDatetime(value, "YYYY-MM-DD", "HH:mm:ss");
                        break;
                    case "Yesterday":
                    case "Today":
                    case "Tomorrow":
                        value = com.servicemax.client.lib.datetimeutils.DatetimeUtil.macroDrivenDatetime(value, "YYYY-MM-DD", "HH:mm:ss");
                        if(copyToRecord.getFieldType(updateData.source_field_name) && copyToRecord.getFieldType(updateData.source_field_name)  === 'datetime') {
                            value = com.servicemax.client.lib.datetimeutils.DatetimeUtil.convertToTimezone(value, undefined, true);
                        }
                        break;
                }
            }

            var currentValue = copyToRecord.getValue(updateData.source_field_name);
            switch (updateData.action) {
                case "Set":
                    break;
                case "Increase":
                    value = Number(currentValue) + Number(value);
                    break;
                case "Decrease":
                    value = Number(currentValue) - Number(value);
                    break;
            }

            copyToRecord.setValue(updateData.source_field_name, value);
        },

        // Call SaveTargetRecord on the Source records updated via SourceObjectUpdates
        saveSourceRecordData: function(state, recordData) {
            var d = new $.Deferred();
            var data = recordData.__data.sfmData;

            new sfmdeliveryoperations.SaveTargetRecord().performAsync({
                data: {
                    __data: {
                        sfmData: data
                    },
                    __deletedRecords: []
                },
                additionalInfo: {
                    processId: state.processId
                },
                componentType: "SOURCE"
            }, {
                result: SVMX.proxy(this, function() {
                    state.sourceObjectUpdateDone = true;
                    d.resolve();
                })
            });
            return d;
        },
        updateSuccSyncRecords: function (updateRecords) {
            var mapRecords = {};
            var mapRemoteIds = OfflineSyncUtils.getOpenRecordRemoteIds();

            for (var i = 0; i < updateRecords.length; i++) {
                var rec = updateRecords[i];
                if (rec.Id in mapRemoteIds) {
                    rec.Id = mapRemoteIds[rec.Id];
                }
                mapRecords[rec.Id] = rec;
            }

            function done(records) {
                if (!(records && records.length)) {
                    return;
                }
                var existingRecords = {};
                for (var i = 0; i < records.length; i++) {
                    var server = OfflineSyncUtils.parseSyncRecord(records[i]);
                    var record = OfflineSyncUtils.parseSyncRecord(records[i]);
                    if(!(record.Id in existingRecords) || (record.changeType === "client" && existingRecords[record.Id].changeType === "server")) {
                        existingRecords[record.Id] = record;
                    }
                }
                for (var recId in existingRecords) {
                    var server = existingRecords[recId];
                    var client = mapRecords[server.Id];

                    if (!client) {
                        continue;
                    }
                    var data = {};
                    for (var key in client.oldValues) {
                        data[key] = {
                            client: {
                                oldValue: client.oldValues[key],
                                newValue: client.newValues[key]
                            }
                        };
                    }
                    for (var key in server.oldValues) {
                        var values = {
                            oldValue: server.oldValues[key],
                            newValue: server.newValues[key]
                        };
                        if (key in data) {
                            data[key].server = values;
                        } else {
                            data[key] = {server: values};
                        }
                    }
                    client.oldValues = {};
                    client.newValues = {};

                    for (var key in data) {
                        var record = data[key];
                        if (record.client) {
                            if (record.server && record.client.newValue === record.server.oldValue) {
                                client.newValues[key] = record.server.newValue;
                                client.oldValues[key] = record.server.oldValue;
                            } else {
                                client.newValues[key] = record.client.newValue;
                                client.oldValues[key] = record.client.oldValue;
                            }
                        }
                    }
                }
            }

            var query = "SELECT * FROM ClientSuccSyncLog WHERE Id in ('" + Object.keys(mapRecords).join("','") + "')";
            return execQuery({query: query}).always(done);
        },
        __isDone: function (state) {
            var isDone = true;
            SVMX.forEachProperty(state.itemsDoneHash, function (inKey, inValue) {
                if (!inValue)
                    isDone = false;
            });
            if (isDone && !state.deleteCounter && state.sourceObjectUpdateDone) {
                //TODO : Vinod - check if responder.result must be called in teh call back of checkresponse status
                Module.instance.checkResponseStatus();

                var syncImpl = SVMX.getCurrentApplication().getSyncImpl();
                var successive = syncImpl.isSuccessiveSyncEnabled();

                var callbackFunc = function () {
                    state.responder.result(state);
                    if (!state.skipAggressiveSync) {
                        syncImpl.performAggressiveSync();
                    }
                };

                function done() {
                    var params = {
                        insertRecords: state.syncInsertRecords,
                        updateRecords: state.syncUpdateRecords,
                        deleteRecords: state.syncDeleteRecords,
                        isSuccessive: successive,
                        callback: function () {
                            if (state.wsInfo && state.wsInfo.recordId) {
                                var params = {
                                    wsInfo: state.wsInfo,
                                    isSuccessive: successive,
                                    callback: callbackFunc
                                };
                                OfflineSyncUtils.writeSyncWebServiceRecords(params);
                            } else {
                                callbackFunc();
                            }
                        }
                    };
                    OfflineSyncUtils.writeSyncRecords(params);
                }

                if (successive && state.syncUpdateRecords.length) {
                    this.updateSuccSyncRecords(state.syncUpdateRecords).always(done);
                } else {
                    done();
                }
            }
        }
    }, {});



    /* OPERATION: AddRecords
     * STATUS: Faked it;
     * @param {string} objectName
     * @description Returns a template for a new record
     * TODO:
     *    1. MICHAEL: Once recordTemplate is available in the PageLayout data, we can return a proper template.
     */
    sfmdeliveryoperations.Class("AddRecords", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var key = request.processId + "-" + request.alias;
            var template = recordTemplateCache[key];

            this.__getProcessInfo(request.processId, request.alias, SVMX.proxy(this, function(mappingIds, objectName) {
                if (template) {
                    template = SVMX.cloneObject(template);
                } else {
                    template = [{
                        sobjectinfo: new RecordClass({}, objectName),
                        bubbleInfo: []
                    }];
                }

                new sfmdeliveryoperations.DescribeObject().performAsync({
                    objectName: request.objectName
                }, {
                    result: SVMX.proxy(this, function(objectInfo) {
                        OfflineDataUtils.executeObjectMapping({
                            targetData: template,
                            sourceData: {},
                            //objectMappingId: mappingIds.objectMap, //Never need object mappings when adding a child record. Adding this back will generate invalid children.
                            valueMappingId: mappingIds.valueMap
                        }).then(SVMX.proxy(this, function() {
                            // Only mark record is new for add new, multi add via lookup show not be marked as new.
                            //    Otherwise, they will get deleted if cancelled from open for edit form
                            if (!request.multiAddFieldRecordIds) {
                                SVMX.array.forEach(template, function(record, i) {
                                    record.sobjectinfo.__new = true;
                                }, this);
                            }
                            var newIds;
                            if (request.multiAddFieldRecordIds) {
                                newIds = SVMX.array.map(request.multiAddFieldRecordIds, function(item) {
                                    return OfflineDataUtils.__generateId(template[0].sobjectinfo.getTableName());
                                }, this);
                            } else {
                                template[0].sobjectinfo.Id = OfflineDataUtils.__generateId(template[0].sobjectinfo.getTableName());
                            }

                            //Defect Fix : 28782 - Block Start
                            //If bubble info is missing pushing sobjectInfo to it as we expect bubble info to be present
                            var sObjInfo = template[0].sobjectinfo, bInfo = template[0].bubbleInfo;
                            for(var key in sObjInfo){
                                if(sObjInfo[key]){
                                    if(sObjInfo.hasOwnProperty(key) && sObjInfo[key].fieldapiname){
                                        var filteredBInfo = SVMX.array.filter(bInfo, function(item){
                                            return item.fieldapiname === sObjInfo[key].fieldapiname;
                                        });
                                        if(filteredBInfo.length == 0){
                                            template[0].bubbleInfo.push(sObjInfo[key]);
                                        }
                                    }
                                }

                            }
                            //Defect Fix : 28782 - Block End

                            OpUtils.addRecords_processData({
                                request: request,
                                responder: responder,
                                data: template,
                                objectInfo: SVMX.cloneObject(objectInfo),
                                operation: this,
                                cacheKey: "",
                                optionalNewIds: newIds,
                                onSuccess: SVMX.proxy(this, function(data) {
                                    responder.result(data);
                                })
                            });
                        }));
                    })
                });
            }));
        },
        __getProcessInfo: function(processUniqueId, layoutId, onSuccess) {
            execQuery({
                query: "SELECT SFPC.* FROM SFProcessComponent as SFPC LEFT JOIN SFProcess AS SFP ON SFPC.process_id=SFP.process_id where process_unique_id='{{process_unique_id}}' AND layout_id = '{{layout_id}}'",
                queryParams: {
                    layout_id: layoutId,
                    process_unique_id: processUniqueId
                },

                onSuccess: function(evt) {
                    var data = evt.data.data[0];
                    onSuccess({
                        objectMap: data.object_mapping_id,
                        valueMap: data.value_mapping_id
                    }, data.object_name);
                }
            });
        }
    }, {});

    /* We don't actually delete records when the user clicks the delete button; we only delete from the
     * database when the user hits save (when deleting line items)
     */
    sfmdeliveryoperations.Class("DeleteRecords", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            request.data.deleteDetailRecords(request.records, request.alias);
            responder.result({});
        }

    }, {});

    sfmdeliveryoperations.Class("GetBubbleData", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        // request.ObjectName OR request.LookupRecordId identifies the lookup config that we are getting the bubble data for
        // request.RecordId identifies the record we are getting data for.  ObjectName now required even if LookupRecordId provided.
        performAsync: function(request, responder) {
            request.callType = "BUBBLE";
            request.KeyWord = "";
            new sfmdeliveryoperations.GetLookupConfig().performAsync(request, {
                result: SVMX.proxy(this, function(result) {
                    var result = {
                        bubbleinfo: result.data.length ?
                            result.data[0].FieldMap :
                            [{
                                key: "",
                                value: "Info not available"
                            }]
                    };

                    result.bubbleinfo = SVMX.array.filter(result.bubbleinfo, function(item) {
                        //Defect 011021: showing field api names and record id (added __key and object check)
                        return (
                                !item.key.match(/__r$/)
                                && !item.key.match(/__key$/)
                                && (!item.value || (typeof item.value == 'string' || item.value instanceof String)));
                    });

                    responder.result(result);
                })
            });
        }

    }, {});


    /* STATUS: In Progress...
     * TODO: Figure out what this is supposed to return
     */
    sfmdeliveryoperations.Class("GetRecordTypes", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var recordTypeInfos = OfflineCacheUtils.readFromJSCache("SFMDELIVERY.RecordTypes", request.objectName);

            // REMOVE the "Master" record, this is never shown to the user.  Its known to be master by either having the name
            // "Master" or having no fixedName.
            recordTypeInfos = SVMX.array.filter(recordTypeInfos, function(entry) {
                return entry.name != "Master" && entry.fixedName;
            });

            SVMX.doLater(function() {
                responder.result(recordTypeInfos);
            });
        }
    }, {});

    sfmdeliveryoperations.Class("ListAttachments", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            execQuery({
                query: "SELECT SFAttachments.*, SFRecordName.name as author1 " +
                    "FROM SFAttachments " +
                    "LEFT JOIN SFRecordName ON SFRecordName.Id = SFAttachments.created_by_id " +
                        "WHERE parent_id='{{record_id}}' " +
                    "ORDER BY last_modified_date DESC",
                queryParams: {record_id : request.recordId}
            })
            .then(function(data) {
                var userInfo = OfflineSystemUtils.getUserInfo();
                var offset = userInfo.TimezoneOffset;
                var files = SVMX.array.map(data, function(item) {
                    var author = item.author1;
                    if (!author && item.created_by_id == userInfo.UserId) {
                        author = userInfo.UserName;
                    }

                    var modified_date = DatetimeUtils.convertToTimezone(item.last_modified_date, offset, false);
                    var fileName = item.name.split(".");
                    var lastIndex = fileName.length - 1;
                    var fileExtName = (fileName.length > 1) ? fileName[lastIndex]:"---";
                    return {
                        name: item.name,
                        // TODO: Turn File object into something that can understand name, path, last_modified
                        file: new com.servicemax.client.offline.sal.model.nativeservice.File(item.file_path),
                        last_modified: modified_date,
                        Id: item.Id,
                        description: item.description,
                        downloaded: item.downloaded,
                        type: fileExtName,//(item.content_type.length > 0)?item.content_type:
                        size: item.content_length,
                        author: author
                    };
                });
                responder.result(files);
            });
        }
    }, {});

    /**
     * Special list of attachments.
     * These are the HTML files that are for unsubmitted Output Documents.
     * Not relevant for MFL but required for Android and iOS so a user
     * can view them before the get transfered to the server and converted to PDFs.
     */
    sfmdeliveryoperations.Class("ListOutputDocAttachments", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            execQuery({
                query: "SELECT " +
                    "datetime(substr(sd.id, 11)/1000.0, 'unixepoch') AS last_modified_date, " +
                    "sd.*, " +
                    "p.process_name AS document_name " +
                    "FROM SmartDocHTML AS sd " +
                    "LEFT JOIN SFProcess AS p ON sd.process_id = p.process_unique_id " +
                    "WHERE " +
                    "submitted IS NULL " +
                    "AND " +
                    "sd.record_id = '{{record_id}}' "+
                    "ORDER BY last_modified_date DESC",

                queryParams: {record_id : request.recordId}
            })
            .then(function(data) {
                var userInfo = OfflineSystemUtils.getUserInfo();
                var offset = userInfo.TimezoneOffset;
                var author = userInfo.UserName;

                var files = SVMX.array.map(data, function(item) {
                    var modified_date = DatetimeUtils.convertToTimezone(item.last_modified_date, offset, false);
                    return {
                        name: item.document_name,
                        // TODO: Turn File object into something that can understand name, path, last_modified
                        file: new com.servicemax.client.offline.sal.model.nativeservice.File("{UploadDirectory}/" + item.name),
                        last_modified: modified_date,
                        Id: item.Id,
                        downloaded: "true",
                        type: "html",
                        size: 0,
                        author: author
                    };
                });

                responder.result(files);
            });
        }
    }, {});


    sfmdeliveryoperations.Class("EditAttachment", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var that = this;
            var recordId = request.data.Id;
            var name = request.data.name;
            var desc = request.data.description;

            com.servicemax.client.offline.sal.model.utils.Data.getRecord({Id: recordId})
                .fail(SVMX.proxy(this, function() {
                    this.__logger.error("Cannot update name and description on attachment record. Record not found for: " + recordId);
                    this.__failedUpdate(responder);
                }))
                .done(SVMX.proxy(this, function(inRecord) {
                    inRecord['Name'] = name;
                    inRecord['Description'] = desc;

                    inRecord.writeRecord(
                        SVMX.proxy(that, that.__sync, responder),
                        SVMX.proxy(that, that.__failedUpdate, responder)
                    );
                }));
        },

        __sync : function(responder, isInsert, syncRecordData) {
            SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveStarted();
            if (isInsert) {
                OfflineDataUtils.writeSyncRecords([syncRecordData], null, null, SVMX.proxy(this, this.__updateSFTable, responder));
            } else {
                OfflineDataUtils.writeSyncRecords(null, [syncRecordData], null, SVMX.proxy(this, this.__updateSFTable, responder));
            }
        },

        __updateSFTable : function(responder) {
            var data = responder.getEventObj().data.request.data;
            execQuery({
                query: "UPDATE SFAttachments SET name = '{{name}}', description = '{{description}}' WHERE Id = '{{id}}'",
                queryParams: {
                    id: data.Id,
                    name: data.name,
                    description: data.description
                }
            })
            .fail(SVMX.proxy(this, function() {
                this.__logger.error("Failed to update SFAttachments for record: " + recordId);
                this.__failedUpdate(responder);
            }))
            .done(SVMX.proxy(this, this.__finish, responder));

        },

        __finish : function(responder) {
            // Start Aggressive sync if applicable
            SVMX.getCurrentApplication().getSyncImpl() && SVMX.getCurrentApplication().getSyncImpl().onSaveCompleted();
            responder && responder.result(true);
        },

        __failedUpdate : function(responder) {
            responder && responder.result(false);
        }
    }, {});

    sfmdeliveryoperations.Class("DeleteAttachments", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var files = SVMX.array.map(request.data, function(item) {return item.file;});
            var paths = SVMX.array.map(files, function(file) {return file.getPath();});
            var ids = SVMX.array.map(request.data, function(item) {return item.Id;});

            execQuery({
                query: "DELETE FROM SFAttachments WHERE Id IN ('{{ids}}')",
                queryParams: {ids: ids.join("','")}
            }).then(SVMX.proxy(this, function(data){
                this.getSmartDocFilesToDelete(files, ids)
                .done(function(files){
                    var fileDeferreds = SVMX.array.map(files, function(file) {return file.deleteFile();});
                  SVMX.when(fileDeferreds).then(function(){
                    for (var i = 0; i < ids.length; i++)
                      OfflineSyncUtils.deleteRecord({Id:ids[i]});
                    responder.result(true);
                    var service = SVMX.getClient().getService("com.servicemax.client.attachmentnotifications").getInstance();
                    var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                        "ATTACHMENTS_CHANGED", this, {
                            request : {
                                recordId: request.recordId
                            }
                        }
                    );
                    service.triggerEvent(evt);
                  });
                });
            }));
        },

        getSmartDocFilesToDelete: function(files, ids){
          var d = SVMX.Deferred();
          execQuery({
              query: "SELECT name FROM SmartDocHTML WHERE Id IN ('{{ids}}')",
              queryParams: {ids: ids.join("','")}
          }).then(SVMX.proxy(this, function(smartDocHTMLFiles){
            if(smartDocHTMLFiles){
              execQuery({
                  query: "DELETE FROM SmartDocHTML WHERE Id IN ('{{ids}}')",
                  queryParams: {ids: ids.join("','")}
              });
              var htmlFilesName = SVMX.array.map(smartDocHTMLFiles, function(file) {return file.name;});
              this.deleteHTMLSignatures(htmlFilesName, files)
              .done(function(files){
                  d.resolve(files);
              });
            }else{
              d.resolve(files);
            }
          }));
          return d;
        },

        deleteHTMLSignatures: function(htmlFilesName, files){
          var d1 = SVMX.Deferred();

          execQuery({
              query: "SELECT name FROM SmartDocSignature WHERE html_name IN ('{{htmlFilesName}}')",
              queryParams: {htmlFilesName: htmlFilesName.join("','")}
          }).then(SVMX.proxy(this, function(signatureFiles){
            console.log("7. deleting signature.");
            if(signatureFiles){
              for(var i=0; i<signatureFiles.length; i++){
                var sigFile = SVMX.create("com.servicemax.client.offline.sal.model.nativeservice.File", "{UploadDirectory}/" + signatureFiles[i].name);
                files.push(sigFile);
              }

              execQuery({
                  query: "DELETE FROM SmartDocSignature WHERE html_name IN ('{{htmlFilesName}}')",
                  queryParams: {htmlFilesName: htmlFilesName.join("','")}
              });

              d1.resolve(files);
            }else{
              d1.resolve(files);
            }
        }));
        return d1;
      }
    }, {});

    sfmdeliveryoperations.Class("ShareAttachments", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            request = request || {};
            request.attachments = request.attachments || [];

            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;

            var deviceInfo = SVMX.getClient().getApplicationParameter("device-info");
            var platform = deviceInfo['device-platform'] || "";

            if (platform.toLowerCase() === "ios" || platform.toLowerCase() === "android") {
                  // Use the native share functionality on platforms that support it.
                  // TODO: Add windows to this filter if we do a UWA
                  var req = nativeService.createShareRequest();


                  req.bind("REQUEST_COMPLETED", function (evt) {
                      responder.result(true);
                  }, this);
                  req.bind("REQUEST_ERROR", function (evt) {
                      responder.result(true);
                  }, this);

                  req.execute({
                      operation: "SHARE",
                      files: request.attachments
                  });
            } else {
                // Default behavior if not on a platform that supports sharing
                var req = nativeService.createEmailRequest();


                req.bind("REQUEST_COMPLETED", function (evt) {
                    responder.result(true);
                }, this);
                req.bind("REQUEST_ERROR", function (evt) {
                    responder.result(true);
                }, this);

                req.execute({
                    operation: "EMAIL",
                    attachmentFiles: request.attachments
                });
            }

            responder.result(true);
        }
    }, {});

    sfmdeliveryoperations.Class("AttachFile", com.servicemax.client.mvc.api.Operation, {

        fileSizeLimitName: '25MB',
        fileSizeLimitBytes: 26214400,

        __constructor: function() {
            this.__base();
        },

        /**
         * @param {Object} request
         * @param {String} request.recordId Id of the data record that this attachment is associated with (salesforceid)
         */
        performAsync: function(request, responder) {

            var fileRequest = nativeService.createFileRequest();
            fileRequest.bind("REQUEST_COMPLETED", SVMX.proxy(this, "onFileSelect", request, responder));

            fileRequest.bind("REQUEST_ERROR", function(evt){
                logger.error(evt);
                responder.fault(evt);
            }, this);

            fileRequest.execute({
                operation: "SELECT",
                multiSelect: false,
                targetPath: "{UploadDirectory}"
            });
        },


        onFileSelect: function(request, responder, evt) {

            SVMX.array.forEach(evt.data.data, function(fileSelect) {

                var fileRequest = nativeService.createFileRequest();
                fileRequest.bind("REQUEST_COMPLETED", SVMX.proxy(this, "onFileInfo", request, responder, fileSelect));

                fileRequest.bind("REQUEST_ERROR", function(evt){
                    logger.error(evt);
                    responder.fault(evt);
                }, this);

                fileRequest.execute({
                    operation: "INFO",
                    file: fileSelect.FilePath
                });
            }, this);
        },

        onFileInfo: function(request, responder, fileSelect, evt) {
            var fileInfo = evt.data.data;
            var err = this.validateFileInfo(fileInfo, fileSelect.FilePath);
            if(err){
                return responder.fault(err);
            }else{
                this.onFileSelected(request, responder, fileSelect, fileInfo);
            }
        },

        validateFileInfo: function(fileInfo, filePath) {
            var fileSize = fileInfo.FileSizeInBytes;
            if(fileSize > this.fileSizeLimitBytes){
                // Delete file, too big to keep
                var file = new com.servicemax.client.offline.sal.model.nativeservice.File(filePath);
                file.deleteFile();

                return {
                    fileInfo: fileInfo,
                    fileSizeExceeded: true,
                    fileSizeLimitName: this.fileSizeLimitName
                };
            }
        },

        onFileSelected: function(request, responder, fileSelect, fileInfo){
            /*Ashwini : Escape single quotes (') in the filename - issue 031278*/
            var name = fileSelect.OriginalFileName;
            name = name.replace(/'/g, "''");
            var path = fileSelect.FilePath;
            path = path.replace(/'/g, "''");

            var userInfo = OfflineSystemUtils.getUserInfo();
            var offset = userInfo.TimezoneOffset;
            var modified_date = com.servicemax.client.lib.datetimeutils.DatetimeUtil.getTimestampWithSaveFormat();

            modified_date = DatetimeUtils.convertToTimezone(modified_date, offset, true);

            var newid = "attach_local_" + new Date().getTime();
            execQuery({
                query: "INSERT INTO SFAttachments (Id, parent_id, created_by_id, file_path, downloaded, name, last_modified_date, content_length) "
                            +"VALUES('{{id}}', '{{record_id}}', '{{created_by_id}}', '{{file_name}}', 'true', '{{name}}', '{{last_modified}}', '{{content_length}}')",
                queryParams: {
                    id: newid,
                    record_id: request.recordId,
                    created_by_id: userInfo.UserId,
                    file_name: path,
                    name: name,
                    last_modified: modified_date,
                    content_length: fileInfo && fileInfo.FileSizeInBytes
                }
            }).then(SVMX.proxy(this, function() {
                OfflineSyncUtils.insertAttachment({
                    Id: newid,
                    isAttachment: true
                });

                try {
                    var service = SVMX.getClient().getService("com.servicemax.client.attachmentnotifications").getInstance();
                    var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                        "ATTACHMENTS_CHANGED", this, {
                            request : {
                                recordId: request.recordId
                            }
                        }
                    );
                    service.triggerEvent(evt);
                } catch(e) {
                    logger.error("Error thrown in onFileInfo:" + e);
                }
                responder.result(false);
            }));
        }
    }, {});


    sfmdeliveryoperations.Class("OpenFile", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var file = request.file;
            file.execute();
        }
    }, {});


    sfmdeliveryoperations.Class("GetRecordConflicted", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            OfflineSyncUtils.isRecordInConflict(request.recordId)
            .then(function(isConflict) {
                responder.result(isConflict);
            });
        }
    }, {});

    sfmdeliveryoperations.Class("GetViewProcesses", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            OfflineMetaUtils.getQualifiedProcessesForRecord({
                objectName: OfflineMetaUtils.getTableForId(request.record.Id),
                record: request.record,
                processType: "VIEW RECORD"
            })
            .then(SVMX.proxy(this, function(viewProcesses) {
                responder.result(viewProcesses);
            }));
        }
    }, {});



    sfmdeliveryoperations.Class("GetRecordAlreadyOpen", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            // Handle when this is a CHECKLIST Linked SFM
            var targetId = (request.additionalInfo && request.additionalInfo.targetId) ? request.additionalInfo.targetId : request.recordId;

            responder.result(OfflineSyncUtils.isRecordOpen(targetId));
        }
    }, {});

    /**
     * For mobile phones and tablets when a separate webview must be opened to view a link
     * and the target attribute of an anchor tag is not appropriate.
     *
     * No response returned since we do not really care if this succeeds or not, we just make a best effort.
     */
    sfmdeliveryoperations.Class("OpenBrowser", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var browserRequest = nativeService.createBrowserRequest();

            browserRequest.execute({
                link: request.link
            });
        }
    }, {});

    /* OPERATION: GetUrlAndParameters
     * @param {string} processId
     * @description returns a custom url and it's parameters if they exist
     */
    sfmdeliveryoperations.Class("GetUrlAndParameters", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            // get the custom url, class_name, and method_name, and then get the relevant parameters
            SVMX.when([
                execQuery({
                    query: "SELECT customUrl, class_name, method_name FROM SFWizardComponent" +
                        " WHERE process_id = '{{processId}}'",
                    queryParams: {
                        processId: request.processId
                    }
                }),
                execQuery({
                    query: "SELECT ParameterName, ParameterValue, ParameterType FROM CustomActionParams" +
                        " WHERE DispatchProcessId = '{{processId}}'",
                    queryParams: {
                        processId: request.processId
                    }
                })
            ]).then(function(urlData, paramData) {
                var urlFields = {
                    customUrl: urlData[0].customUrl,
                    class_name: urlData[0].class_name,
                    method_name: urlData[0].method_name
                };

                var params = [];
                if (paramData.length > 0) {
                    SVMX.array.forEach(paramData, function(currentParam) {
                        params.push({
                            name: currentParam.ParameterName,
                            value: currentParam.ParameterValue,
                            type: currentParam.ParameterType
                        });
                    });
                }

                responder.result({
                    urlData: urlFields,
                    customUrlParams: params
                });
            });
        },

        _onGetUrlError: function(responder, evt) {
            logger.error("GetUrlAndParameters failed to get custom url: " + evt.data);
        },


    }, {});

    /**
     * For mobile phones and tablets when a separate webview must be opened to view a link
     * and the target attribute of an anchor tag is not appropriate.
     *
     * No response returned since we do not really care if this succeeds or not, we just make a best effort.
     */
    sfmdeliveryoperations.Class("OpenTelephone", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var browserRequest = nativeService.createTELRequest();

            browserRequest.execute({
                phone: request.phone
            });
        }
    }, {});

    /**
     * For mobile phones and tablets when a separate webview must be opened to view a link
     * and the target attribute of an anchor tag is not appropriate.
     *
     * No response returned since we do not really care if this succeeds or not, we just make a best effort.
     */
    sfmdeliveryoperations.Class("OpenSMS", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var browserRequest = nativeService.createSMSRequest();

            browserRequest.execute({
                phone: request.phone
            });
        }
    }, {});

    /**
     * For mobile phones and tablets when a separate webview must be opened to view a link
     * and the target attribute of an anchor tag is not appropriate.
     *
     * No response returned since we do not really care if this succeeds or not, we just make a best effort.
     */
    sfmdeliveryoperations.Class("OpenEmail", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var browserRequest = nativeService.createEmailRequest();

            browserRequest.execute({
                address: request.address
            });
        }
    }, {});

    /**
    * Get if sfmdelivery object is a data sync conflict item,
    * to see if conflict icon displays on the toolbar
    *
    *
    */
    sfmdeliveryoperations.Class("CheckIfConflict", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            execQuery({
                query: "SELECT * FROM ClientSyncConflict" +
                    " WHERE Id = '{{recordId}}'",
                queryParams: {
                    recordId: request.recordId
                }
            })
            .then(function(data) {
                responder.result(data);
            });

        }
    }, {});

    sfmdeliveryoperations.Class("GetProductHistory", com.servicemax.client.mvc.api.Operation, {
       __constructor : function() {
           this.__base();
       },

        performAsync : function(request, responder) {
            var result = [];
            var woRecord = request.woRecord;
            var problemDescField = SVMX.OrgNamespace + "__Problem_Description__c";
            var componentField = SVMX.OrgNamespace + "__Component__c";
            var orderStatusField = SVMX.OrgNamespace + "__Order_Status__c";
            var objectName = SVMX.OrgNamespace + "__Service_Order__c";

            var woCreatedDate = woRecord["CreatedDate"].fieldvalue.key;
            var woComponentObj =  woRecord[componentField];

            if(woCreatedDate && woComponentObj && woComponentObj.fieldvalue.key) {
                var woComponent =  woComponentObj.fieldvalue.key;

                execQuery({
                    query: "SELECT " +
                            " c." + "Id, " +
                            " c." + problemDescField + ", " +
                            " c." + "Name, " +
                            " c." + "CreatedDate " +
                            " FROM " + objectName + " AS c " +
                            " WHERE " +
                            " c." + componentField + " = '{{component}}' AND " +
                            " c." + orderStatusField + " = 'Closed' AND " +
                            " c.CreatedDate < '{{createdDate}}'",
                    queryParams: {
                        component: woComponent,
                        createdDate: woCreatedDate
                    }
                }).then(SVMX.proxy(this, function(data) {
                    if (!data || data.length == 0) {
                        responder.result(result);
                    }
                    else {
                        for(var i = 0; i <data.length; i++) {
                            result.push({
                                Id: data[i]['Id'],
                                name: data[i]['Name'],
                                productDesc: data[i][problemDescField],
                                createdDate: data[i]['CreatedDate']
                            });
                        }
                        responder.result(result);
                    }
                }));
            }
            else {
                responder.result(result);
            }
        }
    });

    sfmdeliveryoperations.Class("GetOnlineProductHistory", com.servicemax.client.mvc.api.Operation, {
       __constructor : function() {
           this.__base();
       },

        performAsync : function(request, responder) {
            var result = [];
            var woRecord = request.woRecord;
            var problemDescField = SVMX.OrgNamespace + "__Problem_Description__c";
            var componentField = SVMX.OrgNamespace + "__Component__c";
            var orderStatusField = SVMX.OrgNamespace + "__Order_Status__c";
            var objectName = SVMX.OrgNamespace + "__Service_Order__c";
            var woCreatedDate = woRecord["CreatedDate"].fieldvalue.key;
            if(woCreatedDate) {
                woCreatedDate = DatetimeUtils.parseGMTDate(woCreatedDate).toISOString()
            }
            var woComponentObj =  woRecord[componentField];

            if(woCreatedDate && woComponentObj && woComponentObj.fieldvalue.key) {
                var woComponent =  woComponentObj.fieldvalue.key;
                var onlineProductHistories = SVMX.string.substitute("SELECT " +
                    "Id, " +
                    problemDescField + ", " +
                    "Name, " +
                    "CreatedDate " +
                    "FROM " + objectName + " " +
                    "WHERE " +
                    componentField + " = '{{component}}' AND " +
                    orderStatusField + " = 'Closed' AND " +
                    "CreatedDate < {{createdDate}} "
                    + "Limit 50",
                    {
                        component: woComponent,
                        createdDate: woCreatedDate
                    }
                );

                var syncMgr = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager").getInstance();
                var reject = function(err, isConnectivityError){
                    err = err || {};
                    err.isSuccess = false;
                    err.isConnectivityError = !!isConnectivityError;
                    responder.result(err);
                };

                var onSuccess = function(data){
                    if(data.data.done) {
                        records = data.data.records;
                        result = (records || []).map(function(rec) {
                            var record = {
                                Id: rec['Id'],
                                name: rec['Name'],
                                productDesc: rec[problemDescField],
                                createdDate: rec['CreatedDate'],
                                online: 'true'
                            };
                            return record;
                        });
                    }
                    responder.result(result);
                };

                syncMgr.checkConnectivity().then(function(){
                    syncMgr.getServerRecords({data: request, query: onlineProductHistories}).then(onSuccess, reject);
                }, function(err){
                    reject(err, true);
                });
            }
            else {
                responder.result(result);
            }
        }
    });

    sfmdeliveryoperations.Class("DownloadRecordOnDemand", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            var onSuccess = function(result){
                responder.result(result);
            }

            var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
            servDef.getInstance().downloadRecordOnDemand(request)
                .then(SVMX.proxy(this, onSuccess));
        }
    }, {});


    sfmdeliveryoperations.Class("GetAccountHistory", com.servicemax.client.mvc.api.Operation, {
       __constructor : function() {
           this.__base();
       },

        performAsync : function(request, responder) {

            var result = [];
            var woRecord = request.woRecord;
            var problemDescField = SVMX.OrgNamespace + "__Problem_Description__c";
            var accountField = SVMX.OrgNamespace + "__Company__c";
            var orderStatusField = SVMX.OrgNamespace + "__Order_Status__c";
            var objectName = SVMX.OrgNamespace + "__Service_Order__c";

            var woCreatedDate = woRecord["CreatedDate"].fieldvalue.key;
            var woAccountObj =  woRecord[accountField];

            if(woCreatedDate && woAccountObj && woAccountObj.fieldvalue.key) {
                var woAccount =  woAccountObj.fieldvalue.key;

                execQuery({
                    query: "SELECT " +
                            " c." + "Id, " +
                            " c." + problemDescField + ", " +
                            " c." + "Name, " +
                            " c." + "CreatedDate " +
                            " FROM " + objectName + " AS c " +
                            " WHERE " +
                            " c." + accountField + " = '{{account}}' AND " +
                            " c." + orderStatusField + " = 'Closed' AND " +
                            " c.CreatedDate < '{{createdDate}}'",
                    queryParams: {
                        account: woAccount,
                        createdDate: woCreatedDate
                    }
                }).then(SVMX.proxy(this, function(data) {
                    if (!data || data.length == 0) {
                        responder.result(result);
                    }
                    else {
                        for(var i = 0; i <data.length; i++) {
                            result.push({
                                Id: data[i]['Id'],
                                name: data[i]['Name'],
                                productDesc: data[i][problemDescField],
                                createdDate: data[i]['CreatedDate']
                            });
                        }
                        responder.result(result);
                    }
                }));
            }
            else {
                responder.result(result);
            }
        }
    });

    sfmdeliveryoperations.Class("GetOnlineAccountHistory", com.servicemax.client.mvc.api.Operation, {
       __constructor : function() {
           this.__base();
       },

        performAsync : function(request, responder) {
            var result = [];
            var woRecord = request.woRecord;
            var problemDescField = SVMX.OrgNamespace + "__Problem_Description__c";
            var accountField = SVMX.OrgNamespace + "__Company__c";
            var orderStatusField = SVMX.OrgNamespace + "__Order_Status__c";
            var objectName = SVMX.OrgNamespace + "__Service_Order__c";

            var woCreatedDate = woRecord["CreatedDate"].fieldvalue.key;
            if(woCreatedDate) {
                woCreatedDate = DatetimeUtils.parseGMTDate(woCreatedDate).toISOString()
            }
            var woAccountObj =  woRecord[accountField];

            if(woCreatedDate && woAccountObj && woAccountObj.fieldvalue.key) {
                var woAccount =  woAccountObj.fieldvalue.key;
                var onlineProductHistories = SVMX.string.substitute("SELECT " +
                    "Id, " +
                    problemDescField + ", " +
                    "Name, " +
                    "CreatedDate " +
                    "FROM " + objectName + " " +
                    "WHERE " +
                    accountField + " = '{{account}}' AND " +
                    orderStatusField + " = 'Closed' AND " +
                    "CreatedDate < {{createdDate}} " +
                    "Limit 50",
                    {
                        account: woAccount,
                        createdDate: woCreatedDate
                    }
                );

                var syncMgr = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager").getInstance();
                var reject = function(err, isConnectivityError){
                    err = err || {};
                    err.isSuccess = false;
                    err.isConnectivityError = !!isConnectivityError;
                    responder.result(err);
                };

                var onSuccess = function(data){
                    if(data.data.done) {
                        records = data.data.records;
                        result = (records || []).map(function(rec) {
                            var record = {
                                Id: rec['Id'],
                                name: rec['Name'],
                                productDesc: rec[problemDescField],
                                createdDate: rec['CreatedDate'],
                                online: 'true'
                            };
                            return record;
                        });
                    }
                    responder.result(result);
                };

                syncMgr.checkConnectivity().then(function(){
                    syncMgr.getServerRecords({data: request, query: onlineProductHistories}).then(onSuccess, reject);
                }, function(err){
                    reject(err, true);
                });
            }
            else {
                responder.result(result);
            }
        }
    });


    sfmdeliveryoperations.Class("IsDodRecord", com.servicemax.client.mvc.api.Operation, {

        __constructor: function() {
            this.__base();
        },

        performAsync: function(request, responder) {
            execQuery({
                query: "SELECT * FROM ClientDataOnDemand" +
                " WHERE Id = '{{recordId}}'",
                queryParams: {
                    recordId: request.recordId
                }
            })
                .then(function(data) {
                    responder(data);//it is just a callback function.
                });

        }
    }, {});


};
})();
// end of file
