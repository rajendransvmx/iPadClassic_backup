/**
 * This file needs a description
 * @class com.servicemax.client.offline.sal.model.sfmconsole.operations
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */
(function() {
    var sfmconsoleoperations = SVMX.Package("com.servicemax.client.offline.sal.model.sfmconsole.operations");
sfmconsoleoperations.init = function(){


    var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
    var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.sfmdelivery.operations");
    var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;



    /**
     * Returns the UserInfo object
     *
     * @class com.servicemax.client.offline.sal.model.sfmconsole.operations.GetUserInfo
     * @extends com.servicemax.client.mvc.api.Operation
     */
    sfmconsoleoperations.Class("GetUserInfo", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            responder.result(OfflineSystemUtils.getUserInfo());
        }
    }, {});

    /**
     * GetAppInfo operation returns an appinfo object that can be used in about screens across platforms.
     *
     * {
     *   version: 'app version number (ex: 15.49.002)',
     *   server_version: 'server version number (ex: 15.20000)',
     *   org_type: 'production or sandbox',
     *   org_tag: 'translation tag',
     *   user_name: 'logged in user name',
     *   user_login: 'logged in user email address'
     * }
     *
     * @class com.servicemax.client.offline.sal.model.sfmconsole.operations.GetAppInfo
     * @extends com.servicemax.client.mvc.api.Operation
     */
    sfmconsoleoperations.Class("GetAppInfo", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
          var response = {
            version: '0.0.0',
            server_version: 'N/A',
            org_type: 'Unknown',
            org_tag: 'NA',
            user_name: 'ServiceMax User',
            user_login: 'user@servicemax.com'
          };

          //Get Application and user information
          var deferreds = [
              this.__getLoginInfo(),
              this.__getUserInfo()
          ];

          var result = SVMX.when(deferreds);
          result.always(SVMX.proxy(this, function(infoResults, userResults) {
              infoResults = infoResults || {};
              userResults = userResults || {};

              response.version = infoResults.AppVersion || response.version;
              response.server_version = userResults.SvmxVersion || response.server_version;
              response.org_type = infoResults.EnvDefault || response.org_type;
              response.org_tag = infoResults.EnvTag || response.org_tag;
              response.user_name = userResults.UserName || response.user_name;
              response.user_login = userResults.UserLogin || response.user_login;

              // Give our response back to the caller
              responder.result(response);
        }));
      },

      /**
       * Get login info from the native layer so we get an application version.
       */
      __getLoginInfo : function() {
          var deferred = SVMX.Deferred();
          var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
          var request = nativeService.createLoginInfoRequest();

          request.bind("REQUEST_COMPLETED", function(evt){
              var result = evt.data.data;
              deferred.resolve(result);
          }, this);

          request.bind("REQUEST_ERROR", function(evt){
              deferred.resolve({});
          }, this);

          request.execute();

          return deferred.promise();
      },

      /**
       * Get user info from cache so we have some more human readable info.
       */
      __getUserInfo : function() {
          var deferred = SVMX.Deferred();

          var promise =  com.servicemax.client.sync.api.Utils.Cache.readFromDBCache('USER_INFO');

          promise.done(function(data){
              //Change from string to object
              deferred.resolve(SVMX.toObject(data));
          });

          promise.fail(function(){
              // If this is failing, sync didn't store the user info or someone tampered with the DB
              deferred.resolve({});
          });

          return deferred.promise();
      }
    }, {});

    /* OPERATION: RetrieveDisplayTags
     * @description Returns the translations
     */
    sfmconsoleoperations.Class("RetrieveDisplayTags", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
             OfflineSystemUtils.getDisplayTags({
                onSuccess: function(translationService) {
                    responder.result(translationService);
                },
                onError: function(evt) {
                    logger.error("getDisplayTags Failed");
                    var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.translation");
                    responder.result(servDef.getInstance());
                }
            });
        }
    }, {});

};
})();
