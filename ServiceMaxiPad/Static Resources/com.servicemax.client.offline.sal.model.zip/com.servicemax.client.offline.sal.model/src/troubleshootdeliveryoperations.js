/**
 * @author Sumit Gupta
 * @package com.servicemax.client.offline.sal.model.troubleshootdelivery.operations
 */

(function() {
    var troubleshootImpl = SVMX.Package("com.servicemax.client.offline.sal.model.troubleshootdelivery.operations");

troubleshootImpl.init = function(){

    var feedInfoParser = com.servicemax.client.offline.sal.model.sfchatterfeedutils.FeedInfoParser;
    var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
    var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.troubleshootdelivery.operations");


    function execQuery(inParams) {
        var d = $.Deferred();
        var req = nativeService.createSQLRequest();
        req.bind("REQUEST_COMPLETED", function(evt) {
            d.resolve(evt.data.data);
        });
        req.bind("REQUEST_ERROR", function(evt) {
            d.reject(evt.data.data);
        });
        req.execute({
            query: inParams.query,
            queryParams: inParams.queryParams
        });
        return d;
    }

    /**
     * Returns feed info for product record
     *
     * { recordId: '0D5J000000YmOpNKAV' }
     *
     * @class com.servicemax.client.offline.sal.model.troubleshootdelivery.operations.GetFeedInfo
     * @extends com.servicemax.client.mvc.api.Operation
     */
    troubleshootImpl.Class("GetFeedInfo", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            var syncMgr = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager").getInstance();

            syncMgr.checkConnectivity().then(function(){
                syncMgr.getFeedInfo({data: request}).then(function(result){
                    if(result && result.data && result.data.feedItems){
                        var record = {
                            Id: request.recordId,
                            feedJSON: JSON.stringify(result.data)
                        };
                        execQuery({
                            query: "INSERT OR REPLACE INTO SFChatterFeedInfo (Id,feedJSON) VALUES('{{Id}}','{{feedJSON}}')", 
                            queryParams: record
                        }).then(function(){
                            responder.result({
                                isSuccess: true,
                                data: feedInfoParser.parse(JSON.parse(record.feedJSON))
                            });
                        }, function(err){
                            getOfflineRecords(function(res){
                                if(res.isSuccess){
                                    err.data = res.data;
                                }
                                responder.result(err);
                            });
                        });
                    }else{
                        responder.result({ isSuccess: false });
                    }
                }, SVMX.proxy(responder, responder.result));
            }, function(){
                getOfflineRecords(function(res){
                    responder.result(res);
                });
            });

            var getOfflineRecords = function(callback){
                execQuery({ 
                    query: "SELECT Id, feedJSON FROM SFChatterFeedInfo WHERE Id = '{{Id}}'",
                    queryParams: {Id: request.recordId}
                }).then(function(record){
                    if(record && record.length && record[0].feedJSON){
                        callback({
                            isSuccess: true,
                            data: feedInfoParser.parse(JSON.parse(record[0].feedJSON))
                        });
                    }else{
                        callback({ isSuccess: false });
                    }
                }, function(){
                    callback({ isSuccess: false });
                });
            }
        }
    }, {});

    /**
     * Save feed info for product record
     *
     * { parentId: '01tJ0000004Yqis', recordId: '0D5J000000cbaVVKAY', type: 'comment', text: 'client update' }
     *
     * @class com.servicemax.client.offline.sal.model.troubleshootdelivery.operations.SaveFeedInfo
     * @extends com.servicemax.client.mvc.api.Operation
     */
    troubleshootImpl.Class("SaveFeedInfo", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            var syncMgr = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager").getInstance();

            syncMgr.checkConnectivity().then(function(){
                var response = SVMX.proxy(responder, responder.result);
                syncMgr.saveFeedInfo({data: request}).then(response, response);
            }, function(){
                responder.result({ isSuccess: false });
            });
        }
    }, {});

    troubleshootImpl.Class("DownloadDocumentOnDemand", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            var syncMgr = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager").getInstance();

           syncMgr.checkConnectivity().then( function(){
               var callback = SVMX.proxy(responder, responder.result);
               syncMgr.downloadDocumentOnDemand({data: request}).then( callback, callback );
           }, function(err){ 
               responder.result({ isSuccess: false, isConnectivityError: true }); 
           });
        }
    }, {});

    troubleshootImpl.Class("GetProductDocuments", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            var syncMgr = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager").getInstance();

            var reject = function(err, isConnectivityError){
                err = err || {};
                err.isSuccess = false;
                err.isConnectivityError = !!isConnectivityError; 
                responder.result(err);
            };

            var response = function(data){
                data = data || {};
                data.isSuccess = true;
                responder.result(data);
            };

            var onSuccess = function(result){
                if(!(result && result.data && result.data.records)){
                    return reject();
                } 

                var defers = [];
                (result.data.records || []).forEach(function(rec){ 
                    var record = {
                        Id: rec.Id,
                        Name: rec.Name,                            
                        Description:rec.Description,
                        Keywords:rec.Keywords,
                        Type:rec.Type,
                        BodyLength:rec.BodyLength,
                        attType:rec.attributes.type,
                        attUrl:rec.attributes.url,
                        docType:'TROUBLESHOOTING_DOCUMENT',
                        online:true,
                        parentId:request.parentId
                    };     
                    defers.push(
                        execQuery({
                            query: "INSERT OR REPLACE INTO Product_Troubleshoot_Documents (Id,Name,Description,Keywords,Type,BodyLength,attType,attUrl,docType,online,parentId) SELECT * FROM (SELECT '{{Id}}','{{Name}}','{{Description}}','{{Keywords}}','{{Type}}','{{BodyLength}}','{{attType}}','{{attUrl}}','{{docType}}','{{online}}','{{parentId}}') AS tmp WHERE NOT EXISTS (SELECT online FROM product_Troubleshoot_Documents WHERE online = 'false' AND Id = '{{Id}}') LIMIT 1;",
                            queryParams: record
                        })
                    );                    
                });

                SVMX.when(defers).then(response, reject);
            };

            syncMgr.checkConnectivity().then(function(){
                syncMgr.getProductDocuments({data: request}).then(onSuccess, reject);
            }, function(err){
                reject(err, true);
            });
        }
    }, {});

 troubleshootImpl.Class("GetProductManual", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            var syncMgr = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager").getInstance();

            var reject = function(err, isConnectivityError){
                err = err || {};
                err.isSuccess = false;
                err.isConnectivityError = !!isConnectivityError; 
                responder.result(err);
            };

            var response = function(data){
                data = data || {};
                data.isSuccess = true;
                responder.result(data);
            };

            var onSuccess = function(result){
                if(!(result && result.data && result.data.records)){
                    return reject();
                } 

                var defers = [];
                (result.data.records || []).forEach(function(rec){
                    var record = {
                        Id: rec.Id,
                        Name: rec.Name,                            
                        Description:rec.Description,
                        Keywords:rec.Keywords,
                        Type:rec.Type,
                        BodyLength:rec.BodyLength,
                        attType:rec.attributes.type,
                        attUrl:rec.attributes.url,
                        docType:'TROUBLESHOOTING_PRODUCT_MANUAL',
                        online:true,
                        parentId:request.parentId
                    };                            
                    defers.push(
                        execQuery({
                            query: "INSERT OR REPLACE INTO Product_Troubleshoot_Documents (Id,Name,Description,Keywords,Type,BodyLength,attType,attUrl,docType,online,parentId) SELECT * FROM (SELECT '{{Id}}','{{Name}}','{{Description}}','{{Keywords}}','{{Type}}','{{BodyLength}}','{{attType}}','{{attUrl}}','{{docType}}','{{online}}','{{parentId}}') AS tmp WHERE NOT EXISTS (SELECT online FROM product_Troubleshoot_Documents WHERE online = 'false' AND Id = '{{Id}}') LIMIT 1;",
                            queryParams: record
                        })
                    ); 
                });

                SVMX.when(defers).then(response, reject);   
            };

            syncMgr.checkConnectivity().then(function(){
                syncMgr.getProductManual({data: request}).then(onSuccess, reject);
            }, function(err){
                reject(err, true);
            });
        }
    }, {});

    troubleshootImpl.Class("GetAllDocuments", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            var callback = SVMX.proxy(responder, responder.result);
            var req = { 
                query: "SELECT *  FROM Product_Troubleshoot_Documents WHERE parentId = '{{Id}}'" + (request.offlineRecordsOnly ? " AND online = 'false'" : ""),
                queryParams: {Id: request.parentId}
            };
            execQuery(req).then(callback, callback);
        }
    });
}
})();