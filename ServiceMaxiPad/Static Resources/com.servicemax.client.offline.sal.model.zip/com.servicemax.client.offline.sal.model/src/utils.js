/**
    @author      : Michael Kantor
    @since       : The minimum version where this file is supported
    @description : Utilities used by sfmdeliveryoperations.js
    @copyright   : ServiceMax, Inc
 */

/* TEST SCRIPT
(function testScript() {
    com.servicemax.client.offline.sal.model.utils.Data.getRecord({
        Id: "a0q70000002CTNOAA4",
        onSuccess: function(record) {
            record.onReady(function() {
                alert("Account is " + record.getValue("SVMXC__Company__c") + " | " + record.getValue("Company") + " | " + record.getValue("Account"));
                record.addListener("Name", function(inField, inValue) {
                    alert("Name changed to " + inValue);
                });
                record.setValue("Name", "Fred");
                alert("Name value is now " + record.getValue("Name"));
                record.loadReferences({
                    onSuccess : function() {
                        alert("Display value for Account is " + record.getDisplayValue("Account"));
                        alert("Value for Account is " + record.getValue("Account"));
                        alert("getNameValue for Account record is " + record.getReferenceRecord("Account").getNameValue());
                    }
                })
            })
        }
    })
})()
*/
// TODO: XXX
(function(){
    var utils = SVMX.Package("com.servicemax.client.offline.sal.model.utils");

utils.init = function(){
    var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.utils");
    var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
    var DatetimeUtils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
    var getDataFromEvt = function(evt) {
        return SVMX.toObject(evt.data.data);
    };


    /* Utility for calling a query; a bit less wordy than our default.
     * @param {String} query
     * @param {Object} [context]
     * @param {String|Function} [onSuccess] Name of method to fire on context
     * @param {String|Function} [onError] Name of method to fire on context
     */
    function execQuery(inParams) {
        var d = $.Deferred();
        var req = nativeService.createSQLRequest();
        req.bind("REQUEST_COMPLETED", function(evt) {
            d.resolve(evt.data.data);
            if (inParams.onSuccess) {
                inParams.onSuccess(evt);
            }
        });
        req.bind("REQUEST_ERROR", function(evt) {
            d.reject(evt.data.data);
            if (inParams.onError) {
                inParams.onError(evt);
            }
        });
        req.execute({
            query: inParams.query,
            queryParams: inParams.queryParams,
            queryArray: inParams.queryArray
        });
        return d;
    }


    utils.Class("Field", com.servicemax.client.data.impl.Field, {});
    utils.Class("FieldSet", com.servicemax.client.data.impl.FieldSet, {}, {
             getFieldSet : function(tableName, onSuccess) {
                var d = new $.Deferred();
                if (this.fieldSets[tableName]) {
                    if (onSuccess) onSuccess(this.fieldSets[tableName]);
                    d.resolve(this.fieldSets[tableName]);
                } else {
                    utils.MetaData.describeObject({
                        objectName: tableName,
                        sync: true,
                        onSuccess: SVMX.proxy(this, function(inDescribeData) {
                            new utils.FieldSet(inDescribeData.fields, tableName);
                            if (onSuccess) onSuccess(this.fieldSets[tableName]);
                            d.resolve(this.fieldSets[tableName]);
                        })
                    });
                }
                return d;
            }
        }
    );

    utils.Class("VirtualRecord", com.servicemax.client.data.impl.Record, {
        __loadFieldSet : function(tableName) {
            this._fields = new utils.FieldSet(this.objectDescribe.fields, tableName);
            var picklists = this._fields.getFieldsByType("picklist");
            for (var i = 0; i < picklists.length; i++) {
                this.__setDisplayValue(picklists[i], this.getValue(picklists[i]));
            }

            // Do nothing
        },
        /**
         * @todo writeRecord must support a parentId parameter for line items
         */
        writeRecord : function(onSuccess, onError) {
            if (onSuccess) {
                onSuccess();
            }
        },
        deleteRecord : function(onSuccess, onError) {
            if (onSuccess) {
                onSuccess();
            }
        },

        loadReferences : function(inParams) {
            inParams = inParams || {};
            var onSuccess = inParams.onSuccess;

            if (onSuccess) {
                onSuccess();
            }
        }
    });

    /**************************************************************
     * Class: Record
     * @description Represents a salesforce record pulled from our database. As some of the data
     * is loaded asynchronously, do not call methods on your record without using the onReady method:
     *      record.onReady(function() {...});
     * @todo When creating a detail record, it needs to include the parentId and the record needs to know what that parentId field is so
     *       that writeRecord can correctly update the ClientSyncData table.
     *
     * Key methods:
     * 1. addListener/removeListener: Methods to support MVC apps by letting the view register to be
     *    notified when any field of the record has changed.  All listers fire asynchronously.
     * 2. getValue/setValue: Returns the value of the requested field; field can be specified using SVMXC__Company__c, Company or "Account" (i.e. the Label)
     * 3. getDisplayValue: For most fields, returns the value; for reference and picklists, returns the display value.
     * 4. loadReferences: Loads the records for all reference fields (needed for getDisplayValue() and getReferenceRecord)
     * 5. getReferenceRecord: returns a record for the specified reference field
     * 6. writeRecord/deleteRecord: Database operations
     * 7. getNameValue: Call this on a reference record to get the value to display to represent the entire record
     * 8. getTableName: Returns the name of the table that this record type is stored in.
     *************************************************************/
    utils.Class("Record", com.servicemax.client.data.impl.Record, {
        /* WARNING: If descirbeObject is not cached, then fields and all setup dependent on
         * fields will happen asynchronously; do not assume that the record is ready for use
         * as soon as you've called constructor
         */
        __loadFieldSet : function(tableName) {
            utils.FieldSet.getFieldSet(tableName, SVMX.proxy(this, function(fieldSet) {
                this._fields = fieldSet;
                var picklists = this._fields.getFieldsByType("picklist");
                for (var i = 0; i < picklists.length; i++) {
                    this.__setDisplayValue(picklists[i], this.getValue(picklists[i]));
                }
                for (var i = 0; i < this.__onReadyListeners.length; i++) {
                    this.__onReadyListeners[i](this);
                }
                delete this.__onReadyListeners;
            }));
        },
        /**
         * @todo writeRecord must support a parentId parameter for line items
         */
        writeRecord : function(onSuccess, onError) {
            utils.Data.writeRecord({
                data: this,
                type: this.getTableName(),
                onSuccess: onSuccess,
                onError: onError
            });
        },
        deleteRecord : function(onSuccess, onError) {
            utils.Data.deleteRecord({
                Id: this.Id,
                data: this,
                onSuccess: onSuccess,
                onError: onError
            });
        },


        /* REFERENCES */
       // Typically, the constructor just gets the raw field values
        // which will NOT be able to drive getDisplayValue calls for
        // reference fields.  This method will load all of the data
        // needed to get the display value and even get the
        // full reference record.
        // @param {function} onSuccess onSuccess event handler has no parameters, it simply indicates when this record has been updated
        // @param {[FieldDef|FieldNames]} [fields] Array of field names or fieldDef objects.  Leave blank to load ALL reference fields
        loadReferences : function(inParams) {
            inParams = inParams || {};
            var onSuccess = inParams.onSuccess;

            var referenceFields;
            if (inParams.fields) {
                referenceFields = [];
                for (var i = 0; i < inParams.fields.length; i++) {
                    var f = this._fields.getField(inParams.fields[i]);
                    if (f) referenceFields.push(f);
                }
            } else {
                referenceFields = this._fields.getFieldsByType("reference");
            }
            if (!referenceFields.length) {
                if (onSuccess) onSuccess();
                return;
            }
            if (!this.getTableName()) {
                if (onSuccess) onSuccess();
                return;
            }

            if (this.__loadAllReferencesState) return;
            this.__loadAllReferencesState = {
                counter: referenceFields.length
            };

            // Don't let this method be called directly, by making it an inner method
            var getReferenceRecord = SVMX.proxy(this, function(fieldDef) {
                var fieldName = fieldDef.name;
                var displayValue = this.getDisplayValue(fieldDef);
                var fieldValue = this.getValue(fieldDef);

                if (displayValue || !fieldValue) {
                    this.__loadAllReferencesState.counter--;
                    onGetRecordDone();
                    return;
                }


                utils.MetaData.getTableForId(fieldValue, SVMX.proxy(this, function(tableName) {
                    if (!tableName) {
                        this.__loadAllReferencesState.counter--;
                        onGetRecordDone();
                    } else {
                        utils.MetaData.getNameField(tableName, SVMX.proxy(this, function(nameField) {
                            if (!nameField) {
                                this.__loadAllReferencesState.counter--;
                                onGetRecordDone();
                            } else {
                                var req = nativeService.createSQLRequest();
                                req.bind("REQUEST_ERROR",     SVMX.proxy(this, onGetRecordError, nameField, fieldDef));
                                req.bind("REQUEST_COMPLETED", SVMX.proxy(this, onGetRecordSuccess, tableName, nameField, fieldDef));
                                req.execute({
                                    query: "SELECT * FROM '{{table_name}}' where Id='{{Id}}'",
                                    queryParams: {
                                        table_name: tableName,
                                        Id: fieldValue
                                    }
                                });
                            }
                        }));
                    }
                }));
            });

            // NOTE: SVMX.proxy is called on this elsewhere
            var onGetRecordSuccess = function(tableName, nameField, fieldDef, evt) {
                var data = evt.data.data;
                if (data && data.length) {
                    var record = new utils.Record(data[0], tableName);
                    record.onReady(SVMX.proxy(this, function() {
                        var displayValue = record.getNameValue();
                        this.__setDisplayValue(fieldDef, displayValue);
                        this.__setReferenceRecord(fieldDef, record);
                        this.__loadAllReferencesState.counter--;
                        onGetRecordDone();
                    }));
                } else {
                    this.__loadAllReferencesState.counter--;
                    onGetRecordDone();
                }
            };

            // NOTE: SVMX.proxy is called on this elsewhere
            var onGetRecordError = function() {
                this.__loadAllReferencesState.counter--;
                onGetRecordDone();
            };
            var onGetRecordDone = SVMX.proxy(this, function() {
                if (this.__loadAllReferencesState.counter <= 0) {
                    delete this.__loadAllReferencesState;
                    if (onSuccess) onSuccess();
                }
            });

            // Get all the references
            for (var i = 0; i < referenceFields.length; i++) {
                getReferenceRecord(referenceFields[i]);
            }
        }

    },
    /* STATIC METHODS/PROPERTIES */
    {
        __insertKeyTimestamp : new Date().getTime(), // gaurenteed to be unique for any given compilation of this file (a run of the app)
        __insertKeyIndex : 1 // global index that is incremented with each usage.

        // TODO: If we are loading in reference records, we need a record repository so that we don't rerequest those
        // reference records from the db and end up with multiple copies of them.
        // That also means we need some kind of destroy() or done() method to remove a record and all of its references
        // from the repository.  And the repository would then need to keep a counter of who is using a record
        // so that when calling done on a reference, it stays in the repository if another console app is using that record.
    });

    /**************************************************************
     * Class: RecordSet (UNFINISHED/UNTESTED!!)
     * @description Represents a set of records such as one might
     *    get as a set of lineitems or search results.
     *    By collecting them together, we can provide them as a dataSet
     *    to grids (line item grid, Lookup Window, Search Results grid).
     *    And by dealing with them as a set, we can optimize gathering
     *    reference records.
     *
     * Key methods:
     * 1. getItem/getValue/setValue: Accessing individual records or fields of records
     * 2. forEach: Basic iterator
     * 3. getSize: Duh.
     *************************************************************/
    utils.Class("RecordSet", com.servicemax.client.data.impl.RecordSet, {

        // This does not yet work.  it needs to query for full records
        // which utils.Data.getAllReferences does not do.
        resolveReferences : function(onSuccess) {
            if (this.getSize() > 0) {
                var referenceFields = this.getItem(0).fields.getFieldsByType("reference");
                var picklistFields  = this.getItem(0).fields.getFieldsByType("picklist");
                utils.Data.getAllReferences({
                    data: this.toArray(),
                    convertPicklists: false,
                    onSuccess: SVMX.proxy(this, function() {
                        this.forEach(function(record) {
                            for (var i = 0; i < referenceFields.length; i++) {
                                var f = referenceFields[i];
                                var value = record.getValue(f);
                                if (typeof value === "object" && "fieldvalue" in value) {
                                    record.__setDisplayValue(f,value.fieldvalue.value);
                                    record.setValue(f, value.fieldvalue.key);
                                    //record.__setReferenceRecord(f, )
                                }
                            }
                            for (var i = 0; i < picklistFields.length; i++) {
                                var f = picklistFields[i];
                                var value = record.getValue(f);
                                record.__setDisplayValue(f,value);
                            }
                        }, this);
                        onSuccess();
                    })
                });
            }
        }
    },
    /* STATIC METHODS/PROPERTIES */
    {
        // UNTESTED!
        getRecordSet : function(inParams) {
            var req = nativeService.createSQLRequest();
            if (inParams.onError) {
                req.bind("REQUEST_ERROR", inParams.onError);
            }
            req.bind("REQUEST_COMPLETED", SVMX.proxy(this, "__queryForRecordsSuccess", inParams));
            req.execute({query: inParams.query, queryParams: inParams.queryParams});
        },
        __queryForRecordsSuccess : function(inParams, evt) {
            inParams.onSuccess(new utils.RecordSet(evt.data.data, inParams.tableName));
        }
    });

    /**************************************************************
     * STATIC CLASS: Data
     * @description Provides access to user data
     *    1. Lookup a record by Id
     *    getRecord({Id: "abcde", onSuccess: function(inRecord) {alert("Found it!");)}})
     *    2. Write a record to the specified table; will insert or update appropriately.
     *    writeRecord({data: myRecord, type: myTableName, onSuccess: function() {alert("Saved!");}});
     *    3. Delete a record from the specified table
     *    deleteRecord({id: "abcdefg", onSuccess: function() {alert("Deleted!");}})
     *    4. Take an array of records and resolve all reference fields
     *    getAllReferences({data: [array of records], onSuccess: function(inData) {});})
     *************************************************************/
    utils.Class("Data", com.servicemax.client.lib.api.Object, {}, {

        /**
         * PUBLIC METHOD writeRecord
         * @description
         *    Writes the specified data to the database.  Uses Id to determine
         *    if doing an INSERT or UPDATE operation.
         *    REQUIREMENTS:
         *    1. If table doesn't have an Id field as primary key then do not use this utility.
         *    2. If table is not described via DescribeObject calls, this may not be
         *       a good utility (you will need to provide the fields array to try it).
         *
         * @param {Object} inParams
         *      @param {Object} inParams.data Javascript hash of values to write to database
         *      @param {String} inParams.type Name of the database table to write to
         *      @params {String} [inParams.parentId] If the record is a detail record, then the parentId value is required
         *      @param {[Object]} [inParams.fields] Array of field definitions; optional, will call describeObject if fields not provided
         *      @param {Function} [inParams.onSuccess] Function to call when finished; no parameters to callback
         *      @param {Function} [inParams.onError] Function to call when error is thrown
         *
         * @returns undefined
         */
        __insertKeyTimestamp : new Date().getTime(), // gaurenteed to be unique for any given compilation of this file (a run of the app)
        __insertKeyIndex : 1, // global index that is incremented with each usage.

        writeRecord : function(inParams) {
            utils.MetaData.describeObject({
                objectName: inParams.type,
                onSuccess: SVMX.proxy(this, function(describeObjectData) {
                    inParams.fields = describeObjectData.fields;
                    inParams.recordTypeInfos = describeObjectData.recordTypeInfos;
                    this.__writeRecord(inParams);
                }),
                onError: function(evt) {
                    if (inParams.onError) inParams.onError(evt.data.data);
                }
            });
        },

        writeSyncRecords: function(insertRecords, updateRecords, deleteRecords, callback){
            utils.SyncData.writeSyncRecords({
                insertRecords: insertRecords,
                updateRecords: updateRecords,
                deleteRecords: deleteRecords,
                callback: callback
            });
        },

        __checkIfRecordExists : function(inParams) {
            var defer = SVMX.Deferred();
            var tableName = inParams.type;
            var sobjectinfo = inParams.data;
            var query = "SELECT * FROM `" + tableName + "` WHERE Id='" + sobjectinfo.Id + "'";

            var request = nativeService.createSQLRequest();

            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(evt) {
                defer.resolve((evt.data.data.length == 0));
            }));
            request.bind("REQUEST_ERROR", function(evt) {
                defer.reject(evt);
            });

            request.execute({query:query});

            return defer;
        },

        __generateId : function(tableName) {
            var idPrefix = utils.MetaData.getIdForTable(tableName);
            return idPrefix + "_local_" + this.__insertKeyTimestamp + "_" + this.__insertKeyIndex++;
        },
        __writeRecord : function(inParams) {
            var sobjectinfo = inParams.data;
            if (!sobjectinfo.Id) {
                sobjectinfo.Id = this.__generateId(inParams.type);
                this.__writeRecordWithId(inParams, true);
            } else {

            	// Replace the local id with remote it which comes as a result of putInsert Call.
                var remoteId = utils.SyncData.getOpenRecordRemoteId(sobjectinfo.Id);
                if(remoteId){
                    sobjectinfo.Id = remoteId;
                }

                //__new flag gets lost with GetPrice, so we will check the DB just to be sure
                var defer = this.__checkIfRecordExists(inParams);

                defer.done(SVMX.proxy(this, function(isNew) {
                    this.__writeRecordWithId(inParams, isNew);
                }));

                defer.fail(SVMX.proxy(this, function(evt) {
                    if (inParams.onError) inParams.onError(evt.data.data);
                }));
            }
        },
        __writeRecordWithId : function(inParams, isInsert) {
            var mapRemoteIds = utils.SyncData.getOpenRecordRemoteIds();

            // Replace the local id with remote it which comes as a result of putInsert Call.
            if (inParams.parentId in mapRemoteIds) {
                inParams.parentId = mapRemoteIds[inParams.parentId];
            }

            var tableName = inParams.type;
            var sobjectinfo = inParams.data;
            var writeFields = [];

            for (var i = 0; i < inParams.fields.length; i++) {
                var f = inParams.fields[i];
                var v = sobjectinfo[f.name];

                if (v && typeof v === "object" && "fieldvalue" in v) {
                    v = v.fieldvalue.key;
                }
                if (f.name === "OwnerId" && !v && isInsert) {
                    v = utils.SystemData.getUserInfo().UserId;
                }
                if (f.name === "RecordTypeId") {
                    if (!v && isInsert) {
                        var defaultRecordType = SVMX.array.get(inParams.recordTypeInfos, function (item) {
                            return item.defaultRecordTypeMapping;
                        });
                        if (defaultRecordType && defaultRecordType.name != "Master" ) {
							v = defaultRecordType.recordTypeId;
                        }
                    } else {
                        // If needed replace RecordTypeId name with id
                        var recordType = SVMX.array.get(inParams.recordTypeInfos, function (item) {
                            return v === item.name;
                        });
                        if (recordType) {
                            v = recordType.recordTypeId;
                        }
                    }
                }
                if (f.name === "IsDeleted" && (v === "" || v === null || v === undefined)) {
                    v = false;
                }

                switch (f.type) {
                    case "int":
                    case "double":
                    case "percent":
                    case "currency":
                        v = (v !== null && v !== undefined && v !== "") ? Number(v) : (isInsert ? "''" : null);
                        break;
                    case "bool":
                    case "boolean":
                        if (!(v !== null && v !== undefined)) {
                            v = "null";
                            break;
                        }
                        if (v === "true") {
                            v = true;
                        } else if (v === "false") {
                            v = false;
                        }
                        v = v ? "'true'" : "'false'";
                        break;
                    case "date":
                    case "datetime":
                        v = (v !== null && v !== undefined) ? "'" + v + "'" : "null";
                        break;
                    case "reference":
                        if (v in mapRemoteIds) {
                            v = mapRemoteIds[v];
                        }
                        this.__updateDependentRecords(v, f, tableName, sobjectinfo);
                    default:
                        // if v is null or undefined, set v to empty string
                        // else if v is a string, replace single quotes with double quotes and enclose entire string in single quotes
                        if (v === null || v === undefined) {
                            v = "''";
                        } else if (typeof v === "string") {
                            v = "'" + v.replace(new RegExp("'", "g"), "''") + "'";
                        }
                }
                writeFields.push({name: f.name, value: v});
            }

            function onSuccess(result) {
                // No sync operation here, keeping the sync record data in memory to use it later
                if (inParams.sync === undefined) {
                    inParams.sync = true;
                }
                if (inParams.sync) {
                    var syncRecordData = null;
                    if (isInsert || (result && result.isUpdated)) {
                        syncRecordData = {
                            Id: sobjectinfo.Id,
                            parentId: inParams.parentId,
                            objectName: tableName
                        };
                        if (!isInsert) {
                            syncRecordData.oldValues = result.oldValues;
                            syncRecordData.newValues = result.newValues;
                        }
                    }
                    inParams.onSuccess(isInsert, syncRecordData);
                }
            }

            function executeQuery(query, callback) {
                var request = nativeService.createSQLRequest();
                request.bind("REQUEST_COMPLETED", function () {
                    if (callback) {
                        callback();
                    } else {
                        onSuccess();
                    }
                });
                request.bind("REQUEST_ERROR", function (evt) {
                    if (inParams.onError) {
                        inParams.onError(evt.data.data);
                    }
                });
                request.execute({query: query});
            }

            if (!isInsert) {
                var fieldValues = SVMX.array.map(writeFields, function (item) {
                    return item.name + " = " + item.value;
                });
                var recId = sobjectinfo.Id;
                if(recId in mapRemoteIds){
                    recId = [recId, mapRemoteIds[recId]];
                }
                var query = "UPDATE `" + tableName + "` SET " + fieldValues.join(",") + " WHERE Id IN ('" + ($.isArray(recId) ? recId.join("','") : recId) + "')";
                this.__getUpdatedValues(recId, function(callback){
                    executeQuery(query, callback);
                }, onSuccess);
            } else {
                // Add this newly created record to Open Records
                utils.SyncData.addOpenRecords(utils.SyncData.getOwnerId(), [sobjectinfo.Id]);

                var fieldList = SVMX.array.map(writeFields, function (item) {
                    return item.name;
                });
                var fieldValues = SVMX.array.map(writeFields, function (item) {
                    return item.value;
                });
                var query = "INSERT INTO `" + tableName + "` ('" + fieldList.join("','") + "') VALUES (" + fieldValues + ")";
                executeQuery(query);
            }
        },

        getUpdatedValues: function(recordIds, updateCallback, callback){
            var count = recordIds.length;
            var callbackMap = {};
            var resultMap = {};

            function onSuccess(recordIds){
                count = recordIds.length;
                if(count){
                    for(var i = 0, l = count; i < l; i++){
                        var recId = recordIds[i];
                        if(recId in callbackMap){
                            callbackMap[recId]();
                        }
                    }
                } else {
                    callback(resultMap);
                }
            }

            recordIds.forEach(function(recId){
                utils.Data.__getUpdatedValues(recId, function(callback){
                    callbackMap[recId] = callback;
                    count--;
                    if(!count){
                        updateCallback(onSuccess);
                    }
                }, function(results){
                    if(results){
                        resultMap[recId] = results;
                    }
                    count--;
                    if(!count){
                        callback(resultMap);
                    }
                });
            });
        },

        __getUpdatedValues: function(recordId, updateCallback, callback){

            function done(err, rec){
                if(err){
                    logger.error("SERIOUS ERROR: Failed to write record in db: " + recordId);
                }
                if(callback){
                    callback(rec);
                }
            }

            function getRecord(query, onSuccess){
                execQuery({query: query}).then(function (records) {
                    onSuccess($.isEmptyObject(records) ? {} : records[0]);
                }, done);
            }

            function getDifference(oldRecord, newRecord){
                var result = {
                    oldValues: {Id: newRecord.Id},
                    newValues: {Id: newRecord.Id},
                    isUpdated: false
                };
                var blankValues = ["0", "novalue", "null"];

                for(var key in newRecord){
                    var oldValue = oldRecord[key];
                    var newValue = newRecord[key];

                    if(!oldValue || (SVMX.typeOf(oldValue) === "string" && blankValues.indexOf(oldValue) >= 0)){
                        oldValue = "";
                    }
                    if(!newValue || (SVMX.typeOf(newValue) === "string" && blankValues.indexOf(newValue) >= 0)){
                        newValue = "";
                    }
                    if(key !== 'Id' && oldValue !== newValue){
                        result.isUpdated = true;
                        result.oldValues[key] = oldValue;
                        result.newValues[key] = newValue;
                    }
                }
                done(null, result);
            }

            var tableName = utils.MetaData.getTableForId($.isArray(recordId) ? recordId[0] : recordId);
            if (tableName) {
                var query = "SELECT * FROM '" + tableName + "' WHERE ID IN ('" + ($.isArray(recordId) ? recordId.join("','"): recordId) + "')";
                getRecord(query, function (oldRecord) {
                    updateCallback(function () {
                        getRecord(query, function (newRecord) {
                            getDifference(oldRecord, newRecord);
                        });
                    });
                });
            } else {
                done(true);
            }
        },

         //Methods to update/insert the Dependent Table of the new records from Product IQ used in Reference fields.
        __updateDependentRecords: function(v, f, tableName, sobjectinfo){
            if(v && v.indexOf("transient-") != -1 && f.referenceTo && f.referenceTo.length > 0){
                for(var refTo = 0; refTo < f.referenceTo.length; refTo++){
                    var refObjName = f.referenceTo[refTo];
                    //Create an entry for the dependent records in Sync Dependent Log table
                    if(refObjName.indexOf('Site__c') != -1 ||
                        refObjName.indexOf('Installed_Product__c') != -1 ||
                        refObjName === 'Account' ||
                        refObjName.indexOf('Sub_Location__c') != -1){

                        this.__createDependentEntry(v, tableName, sobjectinfo.Id, f.name);
                    }
                }
            }
        },

        __createDependentEntry: function(fieldValue, objectName, recId, fieldName){
            var request = nativeService.createSQLRequest();
            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(data) {
                request = nativeService.createSQLRequest();
                if(data && data.length > 0){
                    request.execute({
                        query:"UPDATE SyncDependentLog SET parent_record_id = '{{rec_id}}', local_id = '{{l_id}}', parent_object_name = '{{object_name}}', parent_field_name = '{{field_name}}' ",
                        queryParams: {rec_id: recId, l_id: fieldValue, object_name: objectName, field_name: fieldName}
                    });
                }else{
                    request.execute({
                        query: "INSERT INTO SyncDependentLog (parent_record_id, local_id, parent_object_name, parent_field_name) VALUES ('{{rec_id}}','{{l_id}}', '{{object_name}}', '{{field_name}}')",
                        queryParams: {rec_id: recId, l_id: fieldValue, object_name: objectName, field_name: fieldName}
                    });
                }
            }));
            request.bind("REQUEST_ERROR", function(data) {
                //TODO
            });
            request.execute({
                query:"SELECT * FROM SyncDependentLog WHERE parent_record_id = '{{rec_id}}' AND  parent_field_name='{{field_name}}'",
                queryParams: {rec_id: recId, field_name: fieldName}
            });
        },

        /**
         * PUBLIC METHOD deleteRecord
         * @description
         *    Deletes the specified entry from the database.  Object is specified using Id.
         *    REQUIREMENTS:
         *    1. If table doesn't have an Id field as primary key then do not use this utility.
         *    2. If table is not described via DescribeObject calls, then this call won't be able
         *       to find the table using the Id.
         *
         * @param {Object} inParams
         *      @param {String} Id Id of the entry to be deleted.
         *      @param {Boolean} isHeader If true, then writing a headerRecord; else writing a child record
         *                       This is required for the sync logic,
         *                       TODO: there should be a way to store this information in the record itself.
         *      @param {Function} [onSuccess] Function to call when finished; no parameters to callback
         *      @param {Function} [onError] Function to call when error is thrown
         *
         * @returns undefined
         */
        deleteRecord : function(inParams) {
            if (inParams.sync == undefined) inParams.sync = true;
           // alert("DELETE " + inParams.Id);

            // Replace the local id with remote it which comes as a result of putInsert Call.
            var remoteId = utils.SyncData.getOpenRecordRemoteId(inParams.Id);
            if(remoteId){
                inParams.Id = remoteId;
            }
            utils.SyncData.removeOpenRecord(utils.SyncData.getOwnerId(), inParams.Id);

            var tableName = utils.MetaData.getTableForId(inParams.Id);
            if (tableName) {
                var request = nativeService.createSQLRequest();
                request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function() {
                    //Delete the dependent records form the Sync Dependent Log table
                    this.__deleteDependentEntry(inParams.Id);

                	var syncRecordData;
                    if (inParams.sync) syncRecordData = {Id: inParams.Id, parentId: inParams.parentId, objectName: tableName};
                    if (inParams.onSuccess) inParams.onSuccess(syncRecordData);
                }));
                request.bind("REQUEST_ERROR", inParams.onError || function() {});
                request.execute({
                    query:"DELETE FROM '{{table_name}}' WHERE Id='{{id}}'",
                    queryParams: {table_name: tableName, id: inParams.Id}
                });
            } else {
                logger.error("SERIOUS ERROR: Failed to delete because table not found for Id=" + inParams.Id);
                if (inParams.onError) inParams.onError("Table not found for Id=" + inParams.Id);
            }
        },

        //Methods to delete the Dependent Table of the new records from Product IQ used in Reference fields.
        __deleteDependentEntry: function(recId){
            var request = nativeService.createSQLRequest();
            request.execute({
                query:"DELETE FROM SyncDependentLog WHERE parent_record_id = '{{rec_id}}'",
                queryParams: {rec_id: recId}
            });
        },

        /**
         * PUBLIC METHOD getRecord
         * @description
         *    Looks up the the specified record, and gets the displayField
         *    for each reference field.
         *    getRecord({Id: "abcde", onSuccess: function(inRecord) {}, onError: function(inErrorMsg) {}})
         * @param {Object} inParams
         *      @param {String} Id  Record Id to lookup; used to find the tableName as well.
         *      @param {booelan} loadReferences If true, load each refernece field; if false we are only getting this one record.
         *      @param {boolean} convertPicklists If true, picklist values are replaced with {key/value} pair instead of left as a string.
         *
         * @returns undefined
         */
        getRecord : function(inParams) {
            var d = new $.Deferred();

            // To simplify the callbacks where a record may or may not be available,
            // allow this to be called with a record already prepared and call the callback
            // without further processing.
            if (inParams.record) {
                d.resolve(inParams.record);
            } else {

                var tableName = utils.MetaData.getTableForId(inParams.Id);
                if (tableName) {

                    utils.MetaData.describeObject({
                        objectName: tableName,
                        sync: true,
                        onSuccess: SVMX.proxy(this, function(describeObjectData) {
                            var fields = describeObjectData.fields;
                            var recordTypeInfos = describeObjectData.recordTypeInfos;
                            var request = nativeService.createSQLRequest();
                            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, "__getRecordSuccess", d, inParams, tableName, fields, recordTypeInfos));
                            request.bind("REQUEST_ERROR", SVMX.proxy(this, "__getRecordError", d, inParams));

                            //Replace record's local_id with remote_id if available
                            var remoteId = utils.SyncData.getOpenRecordRemoteId(inParams.Id);
                            if(remoteId){
                                inParams.Id = remoteId;
                            }

                            var query = this.buildQuery("MAIN.Id='" + inParams.Id + "'", tableName, fields, "", inParams.lookupDisplayFieldMap);
                            request.execute({
                                query: query
                            });
                        })
                    });
                } else {
                    var error = "FATAL ERROR: Unable to find tableName in getRecord for ID: " + inParams.Id;
                    logger.error(error);
                    if (inParams.onError) inParams.onError(error);
                    d.reject(error);
                }
            }
            return d;
        },

        // TODO: 1. handle multiple referenceTo values
        buildQuery: function(whereClause, tableName, fields, orderBy, refFieldNameMap) {
            var referenceFields = SVMX.array.filter(fields, function(f) {return f.type == "reference";});
            var query = "SELECT {{fieldList}}\n FROM `{{tableName}}` AS MAIN\n {{joins}}\n WHERE {{whereClause}}";
            var joins = [];
            var fieldList = ["MAIN.*"];//SVMX.array.map(fields, function(f) {return "MAIN." + f.name;});
            for (var i = 0; i < referenceFields.length; i++) {
                var f = referenceFields[i];
                var referenceTo = f.referenceTo[f.referenceTo.length-1];
                if (utils.MetaData.isTableInDatabase(referenceTo)) {
                    var relationshipTableName = f.relationshipName ? f.relationshipName  + "Table" : "table" + i;
                    var join = SVMX.string.substitute("LEFT JOIN `{{referenceTo}}` AS {{alias}} ON MAIN.{{fieldName}} = `{{alias}}`.Id",
                        {
                            referenceTo: referenceTo,
                            fieldName: f.name,
                            alias: relationshipTableName
                        }
                    );
                    joins.push(join);
                    // Ref Field can be specified in lookup as display field.
                    var nameField = (refFieldNameMap && refFieldNameMap[f.name]);
                    nameField = nameField || utils.MetaData.getNameField(referenceTo);
                    fieldList.push(SVMX.string.substitute("`{{tableName}}`.{{nameField}} AS {{relationshipName}}", {
                        referenceTo: referenceTo,
                        nameField: nameField,
                        tableName: relationshipTableName,
                        relationshipName: f.relationshipName || "field" + i
                    }));
                }
            }
            return SVMX.string.substitute(query, {
                fieldList: fieldList,
                tableName: tableName,
                joins: joins.join("\n"),
                whereClause: whereClause
            }) + (orderBy || "");
        },

        __getRecordError: function(deferred, inParams, evt) {
            logger.error("SEVERE ERROR: getRecord FAILED: " + evt.data.data + " : " + evt.data.parameters.query);
            if (inParams.onError) inParams.onError(evt.data.data);
            deferred.reject(evt.data.data);
        },

        __getRecordSuccess : function(deferred, inParams, tableName, fields, recordTypeInfos, evt) {
            var data = getDataFromEvt(evt), me = this;
            if (data.length === 0) {
                return this.__getRecordError(deferred, inParams, evt);
            }
            data = data[0];
            this.__assembleRelatedData(data, fields);
            var ids = this.__getMissingIds(data, fields);

            execQuery({
                query: "SELECT * FROM SFRecordName WHERE ID IN ({{ids}})",
                queryParams: {ids: "'" + ids.join("','") + "'"}
            }).then(SVMX.proxy(this, function(recordNameData) {
                this.__assembleNameFieldData(data, fields, recordNameData);
                this.__fixupReferenceFields(data, fields);

                data = new utils.Record(data, tableName);
                this.__fixPicklists(data, inParams, fields);
                deferred.resolve(data);
            }));
        },

        __assembleRelatedData: function(data, fields) {
            var referenceFields = SVMX.array.filter(fields, function(f) {return f.type == "reference";});
            for (var i = 0; i < referenceFields.length; i++) {
                var f = referenceFields[i];
                var id = data[f.name];
                data[f.name] = {
                    key: id,
                    value: data[f.relationshipName || "field" + i],
                    hasViewSFM: id ? utils.MetaData.doesObjectHaveViewProcess(utils.MetaData.getTableForId(id)) : false
                };
                delete data[f.relationshipName || "field" + i];
            }
        },

        __getMissingIds: function(data, fields) {
            var ids = [];
            var referenceFields = SVMX.array.filter(fields, function(f) {return f.type == "reference";});
            for (var i = 0; i < referenceFields.length; i++) {
                var f = referenceFields[i];
                if (data[f.name] && data[f.name].key && !data[f.name].value) ids.push(data[f.name].key);
            }
            return ids;
        },

        __assembleNameFieldData: function(data, fields, nameFieldData) {
            var idHash = {};
            SVMX.array.forEach(nameFieldData, function(item) {
                idHash[item.Id] = item.Name;
            });
            var referenceFields = SVMX.array.filter(fields, function(f) {return f.type == "reference";});
            this.__assembleNameFieldDataNameMap(data, referenceFields, idHash);
        },

        __assembleNameFieldDataNameMap: function(data, referenceFields, idNameMap) {
            for (var i = 0; i < referenceFields.length; i++) {
                var f = referenceFields[i];
                if (data[f.name] && !data[f.name].value) {
                    // Make value the looked up value or the ID and a Space. We do not want the value to be blank nor can it match the key.
                    data[f.name].value = idNameMap[data[f.name].key] || (data[f.name].key && data[f.name].key + " ");
                    data[f.name].isNameSyncData = true;
                    data[f.name].hasViewSFM = (data[f.name].key) ? utils.MetaData.doesObjectHaveViewProcess(utils.MetaData.getTableForId(data[f.name].key)) : false;
                }
            }
        },

        __fixupReferenceFields: function(data, fields) {
            var referenceFields = SVMX.array.filter(fields, function(f) {return f.type == "reference";});
            for (var i = 0; i < referenceFields.length; i++) {
                var f = referenceFields[i];
                if (data[f.name]) data[f.name] = {
                    fieldvalue: data[f.name],
                    fieldapiname: f.name
                };
            }
        },

        __fixPicklists : function(record, inParams, fields){
            var me = this;

            /* Convert the picklist format */
            if (inParams.convertPicklists) {
                var structuredData = record.getFieldsByType("picklist");
                structuredData = structuredData.concat(record.getFieldsByType("boolean"));
                structuredData = structuredData.concat(record.getFieldsByType("date"));
                structuredData = structuredData.concat(record.getFieldsByType("datetime"));

                for (var i = 0; i < structuredData.length; i++) {
                    var fname = structuredData[i].name;
                    var ftype = structuredData[i].type;
                    var value = record[fname];
                    if (value === "" && ftype == "boolean") value = "false";
                    record[fname] = {
                        fieldvalue: {value: value, key: value},
                        fieldapiname: fname
                    };
                }
            }
        },

        getRefDisplayValue : function(recordId, fieldName, refTable, defaultName) {
           var queryObj = {
                query : "SELECT ref.{{fieldName}} AS RefName, rn.Name AS DisplayName FROM [{{refTable}}] AS ref"
                            + " LEFT JOIN SFRecordName AS rn ON RefName = rn.Id"
                            + " WHERE ref.Id = '{{recordId}}'",
                queryParams : {recordId: recordId, fieldName: fieldName, refTable: refTable}
            };

            if(defaultName){
                queryObj.query = "SELECT ref.{{fieldName}} AS RefName, ref.{{defaultName}} AS DefaultName, rn.Name AS DisplayName FROM [{{refTable}}] AS ref"
                            + " LEFT JOIN SFRecordName AS rn ON RefName = rn.Id"
                            + " WHERE ref.Id = '{{recordId}}'";
                queryObj.queryParams["defaultName"] = defaultName;
            }

            return execQuery(queryObj);
        },

        /**
         * Takes an array of zero or more record Ids and returns the name value for that Id.
         * @param {[string]} ids An array of salesforce Ids
         * @return {[Object]} Returns an array of Name/Id pairs: [{Name: "Fred", Id: "a0k11111"}]
         */
        getFromRecordNameTable: function(ids) {
            var d = new $.Deferred();
            if (ids.length) {
                return execQuery({
                    query: "SELECT Id, Name FROM SFRecordName WHERE Id IN ({{recordId}})",
                    queryParams: {recordId: '"' + ids.join('","') + '"'}
                });
            } else {
                d.resolve([]);
            }
            return d;
        },

        insertUpdateRecordIntoNameTable: function(recId, data){
            this.getFromRecordNameTable([recId]).then(function(records){
                var query = "INSERT INTO SFRecordName (Id, Name) VALUES ('{{id}}','{{name}}')";
                if(records && records.length){
                    data.value = data.value || records[0].Name;
                    query = "UPDATE SFRecordName SET Id='{{id}}', Name='{{name}}' WHERE Id='{{rec_id}}'";
                }
                execQuery({
                    query: query,
                    queryParams: {id: data.key || recId, name: data.value, rec_id: recId}
                });
            })
        },

        /**
         * @params inParams
         * @params inParams.processId Provide a processId as a salesforce id, not as a process_unique_id
         * @params inParams.data Provide a single record to have the mappings executed on; must be instance of Record class
         * @returns Deferred
         * @todo No support yet for target_field_name; does not appear to be used yet
         * @todo Try and merge with sfmdeliveryoperations.js method executeSourceObjectUpdate
         */
        executeSourceUpdateMapping : function(inParams) {
           var d = new $.Deferred();
           execQuery({
               query: "select SFSourceUpdate.* from SFSourceUpdate LEFT JOIN SFProcessComponent on SFProcessComponent.Id = SFSourceUpdate.target_process_node where SFProcessComponent.process_id='{{process_id}}'",
               queryParams: {process_id: inParams.processId}
           })
           .then(SVMX.proxy(this, function(data) {
                if (!data) data = [];
                var record = inParams.data;
                SVMX.array.forEach(data, function(inMapping) {
                    var value = inMapping.display_value;
                    switch(value) {
                        case "Today":
                        case "Tomorrow":
                        case "Yesterday":
                        case "Now":
                            var format = record.getFieldType(inMapping.source_field_name);
                            if(format === 'datetime'){
                                value = DatetimeUtils.macroDrivenDatetime(value, "YYYY-MM-DD", "HH:mm:ss");
                                value = DatetimeUtils.convertToTimezone(value, undefined, true);
                            }else if(format === 'date'){
                                value = DatetimeUtils.macroDrivenDatetime(value, "YYYY-MM-DD" ,'','date');
                            }
                            break;
                    }

                    switch(inMapping.action) {
                        case "Set":
                            record.setValue(inMapping.source_field_name, value);
                            break;
                        case "Increase":
                            record.setValue(inMapping.source_field_name, Number(value) + Number(record.getValue(inMapping.source_field_name)));
                            break;
                        case "Decrease":
                            record.setValue(inMapping.source_field_name, Number(record.getValue(inMapping.source_field_name)) - Number(value));
                            break;
                    }
                }, this);

                record.writeRecord(function(isInsert, syncRecordData) {
                    // Defect 020510
                        if (inParams.sync == undefined) inParams.sync = true; // write to the sync table.
                        if (inParams.sync) {
                        	if (isInsert && syncRecordData) {
                                utils.Data.writeSyncRecords([syncRecordData], null, null, null);
                            } else if(syncRecordData){
                                utils.Data.writeSyncRecords(null, [syncRecordData], null, null);
                            }
                        }
                        d.resolve();
                    },
                    function(e) {
                        logger.error("SERIOUS ERROR IN utils.js executeSourceUpdateMapping: " + e);
                        d.resolve();
                    }
                );

            }));
            return d;
        },

        /**
         * Executes the mappings specified by valueMappingId to
         * 1. Copy values from sourceData into targetData.
         * 2. Copy static values from the mapping into targetData
         * @params inParams
         * @param {Array of Object|Record} targetData: A record instance of sobjectinfo; attributes.type must be populated
         *                    prior to this call
         * @param {Object|Record} sourceData: Could just be {} if only concerned with copying
         *                    static values from the mapping itself. But if doing source-to-target
         *                    mapping then provide a sourceData that is either an sobjectinfo or a Record instance.
         * @param {salesforceRef|Array of salesforceRefs} valueMappingId Id of the mapping we need to execute
         * @param {Function} onSuccess Callback function takes no parameters, simply signals the caller
         *                   that targetData has finished being modified.
         */

        // sourceData is typically just {}, but is the data we copy from if copying a field
        // instead of a value.
        executeObjectMapping : function(inParams) {//targetData, sourceData, headSourceData, valueMappingId
            var d = new $.Deferred();
            var mappingIds = [];
            if (inParams.valueMappingId) mappingIds.push(inParams.valueMappingId);
            if (inParams.objectMappingId) mappingIds.push(inParams.objectMappingId);
            if (inParams.targetData && !$.isArray(inParams.targetData)) inParams.targetData = [inParams.targetData];
            var order = "ASC";
            if (inParams.valueMappingId && inParams.objectMappingId) {
                // Have to do value mappings before w can do object mappings
                // values tend to be literals or constants; object mappings
                // may be copied from the same record into itself and is only
                // possible if those values are set first.
                order = (inParams.valueMappingId > inParams.objectMappingId) ? "DESC" : "ASC";
            }
            if(mappingIds.length && inParams.targetData.length >= 0) {
                var req = nativeService.createSQLRequest();
                req.bind("REQUEST_ERROR",     SVMX.proxy(this, "__executeObjectMappingError",   d));
                req.bind("REQUEST_COMPLETED", SVMX.proxy(this, "__executeObjectMappingSuccess", d,
                    inParams.targetData, inParams.sourceData, inParams.headSourceData));
                req.execute({
                    query: "Select * FROM SFObjectMappingComponent WHERE object_mapping_id IN ('{{object_mapping_id}}') ORDER BY object_mapping_id {{order}}",
                    queryParams: {
                        object_mapping_id : mappingIds.join("','"),
                        order:  order
                    }
                });
            }else{
                d.resolve();
            }
            return d;
        },

        __executeObjectMappingSuccess: function(deferred, targetData, sourceData, headSourceData, evt) {
            var logger = SVMX.getLoggingService().getLogger("svmxc-mapping-service");
            var mapdata = getDataFromEvt(evt);
            if (mapdata.length === 0) {
                return deferred.fail(evt);
            }

            // Ensure this is set. It is optionally set
            sourceData = sourceData || {};
            headSourceData = headSourceData || {};

            // We probably won't need to do any reference loookups, but if we do,
            // don't call onSuccess until they have all finished.
            var referenceLookups = targetData.length * mapdata.length;
            var onDone = function() {
                referenceLookups--;
                if (referenceLookups === 0) {
                    deferred.resolve();
                }
            };

            // We'll need the FieldSet for our target record
            // Note that if we could insure that sobjectinfo was a Record instance,
            // then we'd know it already has a fieldSet and this wouldn't be asynchronous.
            utils.FieldSet.getFieldSet(targetData[0].sobjectinfo.attributes.type, SVMX.proxy(this, function(fieldSet) {
                // For each record in targetData, execute our mapping.
                SVMX.array.forEach(targetData, function(record) {
                    // For each mappingComponent, execute our mapping.
                    SVMX.array.forEach(mapdata, function(mapdataItem) {
                        var fname = mapdataItem.target_field_name;

                        if (fname && (fname.toLowerCase() === 'id')) {
                            logger.error("Field Mapping: Cannot mapping into id field. Please remove the mapping!");
                            onDone();
                            return true;
                        }

                        var fieldDef = fieldSet.getField(fname) || {type: "string", name: fname};
                        var value = mapdataItem.mapping_value;
                        var data; // data from source
                        // Vinod TODO: You had this test if it was null;
                        // why is null special? I changed to test to verify that there
                        // is such a field
                        //if(record.sobjectinfo[fname] !== null){

                        // TODO VINOD: what if the value mapped is zero, need to check why db has zero when field map is present.
                        // Appears that the DB treats "0" and "" as field mappings (based on its use of the source_field_name)
                        // for those entries.  Appears to eliminate "0" as a default value.  Or perhaps its saying
                        // map the field value and if it doesn't exist, use "0".  Need to get this answered.

                        // If we are doing a value mapping instead of a field mapping (value mapping maps
                        // predefined values rather than copying fields of the sourceData), execute this block
                        if (value !== 0 && value !== "" && (value.match(/^SVMX.CURRENTRECORD\./) || {}).input !== undefined) {
                            var currFieldName = value.match(/SVMX\.CURRENTRECORD\.(.*)/)[1];
                            data = record.sobjectinfo[currFieldName];

                            // Some really evil code
                            // We are mapping a record that has an ID but no record in the DB
                            // We must have a value but that value cannot be equal to the key or auto-resolve will break later.
                            if (data && typeof data === "object" && data.fieldvalue && data.fieldvalue.key && data.fieldvalue.value === undefined) {
                                data.fieldvalue.value = data.fieldvalue.key + " ";
                            }

                            record.sobjectinfo[fname] = data;
                        } else if (value !== 0 && value !== "" && (value.match(/^SVMX.CURRENTRECORDHEADER/) || {}).input !== undefined) {
                            // The engine already took care of these for new detail lines ONLY and doing differently by calling getDetailMappedInfo
                            var currHeadFieldName = value.match(/SVMX\.CURRENTRECORDHEADER\.(.*)/)[1];
                            data = headSourceData[currHeadFieldName];

                            // Some really evil code
                            // We are mapping a record that has an ID but no record in the DB
                            // We must have a value but that value cannot be equal to the key or auto-resolve will break later.
                            if (data && typeof data === "object" && data.fieldvalue && data.fieldvalue.key && data.fieldvalue.value === undefined) {
                                data.fieldvalue.value = data.fieldvalue.key + " ";
                            }

                            record.sobjectinfo[fname] = data;

                        } else if (value !== 0 && value !== "") {

                            // TODO: How do we differentiate between "Now" the string and "Now" the constant?
                            // Maybe we need seperate handling of value_mapping_id and object_mapping_id?

                            // SOMEONE TODO: MERGE THIS CODE WITH IDENTICAL CODE IN SFMDELIVERY/UI/API.js
                            switch(value) {
                                case "Now":
                                case "Today":
                                case "Tomorrow":
                                case "Yesterday":
                                    value = DatetimeUtils.macroDrivenDatetime(value, "YYYY-MM-DD", "HH:mm:ss");
                                    break;
                                case "SVMX.NOW":
                                    value = DatetimeUtils.macroDrivenDatetime("Now", "YYYY-MM-DD", "HH:mm:ss");
                                    break;
                                case "SVMX.TODAY":
                                    value = DatetimeUtils.macroDrivenDatetime("Today", "YYYY-MM-DD", "HH:mm:ss");
                                    break;
                                case "SVMX.TOMORROW":
                                    value = DatetimeUtils.macroDrivenDatetime("Tomorrow", "YYYY-MM-DD", "HH:mm:ss");
                                    break;
                                case "SVMX.YESTERDAY":
                                    value = DatetimeUtils.macroDrivenDatetime("Yesterday", "YYYY-MM-DD", "HH:mm:ss");
                                    break;
                                case "SVMX.CURRENTUSERID":
                                case "SVMX.CURRENTUSER":
                                case "SVMX.OWNER":
                                  //value = utils.SystemData.getUserInfo().UserId;
                                    if(fieldDef.type === "reference")
                                      value =  {
                                          fieldvalue: {
                                              key: utils.SystemData.getUserInfo().UserId,
                                              value: utils.SystemData.getUserInfo().UserName
                                          },
                                          fieldapiname: fieldDef.name
                                      };
                                    else if(fieldDef.type !== "boolean" && fieldDef.type !== "date" && fieldDef.type !== "datetime")
                                      value = utils.SystemData.getUserInfo().UserName;
                                    break;
                                case "SVMX.USERTRUNK":
                                    var userTrunkValue = utils.SystemData.getUserInfo().UserTrunkDetail ? utils.SystemData.getUserInfo().UserTrunkDetail.Id : null;
                                    value = userTrunkValue;
                                    break;

                                // Not allowed in mapping
                                // THIS_WEEK
                                // NEXT_WEEK
                                // LAST_WEEK

                                // THIS_MONTH
                                // NEXT_MONTH
                                // LAST_MONTH

                                // NEXT_90_DAYS
                                // LAST_90_DAYS

                                // CURRENTRECORD, CURRENTRECORDHEADER are handled in the engine.
                            }

                            switch (fieldDef.type) {
                                case "boolean":
                                    if (typeof value === "string") value = value.toLowerCase();
                                    // no break
                                case "picklist":
                                    record.sobjectinfo[fname] = {
                                        fieldvalue: {
                                            key: value, value: value
                                        },
                                        fieldapiname: fname
                                    };
                                    break;
                                case "date":
                                   if(mapdataItem.mapping_value !== "Now" &&
                                    mapdataItem.mapping_value !== "Today" &&
                                    mapdataItem.mapping_value !== "Tomorrow" &&
                                    mapdataItem.mapping_value !== "Yesterday" &&
                                    mapdataItem.mapping_value !== "SVMX.NOW" &&
                                    mapdataItem.mapping_value !== "SVMX.TODAY" &&
                                    mapdataItem.mapping_value !== "SVMX.TOMORROW" &&
                                    mapdataItem.mapping_value !== "SVMX.YESTERDAY")
                                      break;
                                      record.sobjectinfo[fname] = {
                                          fieldvalue: {
                                              key: value, value: value
                                          },
                                          fieldapiname: fname
                                      };
                                      break;
                                case "datetime":
                                    if(mapdataItem.mapping_value !== "Now" &&
                                    mapdataItem.mapping_value !== "Today" &&
                                    mapdataItem.mapping_value !== "Tomorrow" &&
                                    mapdataItem.mapping_value !== "Yesterday" &&
                                    mapdataItem.mapping_value !== "SVMX.NOW" &&
                                    mapdataItem.mapping_value !== "SVMX.TODAY" &&
                                    mapdataItem.mapping_value !== "SVMX.TOMORROW" &&
                                    mapdataItem.mapping_value !== "SVMX.YESTERDAY")
                                      break;
                                    //If mapped literals are Today,Tomorrow, Yesterday then only change it to timezone. For literal Now it's already in GMT and no conversion needed.
                                    if(mapdataItem.mapping_value !== "Now" && mapdataItem.mapping_value !== "SVMX.NOW"){
                                        value = DatetimeUtils.convertToTimezone(value, undefined, true);
                                    }
                                    record.sobjectinfo[fname] = {
                                        fieldvalue: {
                                            key: value, value: value
                                        },
                                        fieldapiname: fname
                                    };
                                    break;
                                // TODO: Do we need to handle any other types here
                                // or is it ok to just have a literal here?
                                // references are handled below.
                                default:
                                    record.sobjectinfo[fname] = value;
                            }
                        }
                        // Else we are NOT doing a value mapping but rather a field mapping; just copy the value over
                        else {
                            value = this.getFieldValue(sourceData, mapdataItem.source_field_name);
                            if (value === undefined || value === null) value = "";
                            var tmpvalue = typeof value === "object" && value.fieldvalue !== undefined  ? value.fieldvalue.value : value;
                            if ((tmpvalue === undefined || tmpvalue === null || tmpvalue === "") && mapdataItem.preference_2) {
                                value = this.getFieldValue(sourceData,mapdataItem.preference_2);
                            }
                            tmpvalue = typeof value === "object"  && value.fieldvalue !== undefined  ? value.fieldvalue.value : value;
                            if ((tmpvalue === undefined || tmpvalue === null || tmpvalue === "") && mapdataItem.preference_3 ) {
                                value = this.getFieldValue(sourceData, mapdataItem.preference_3);
                            }

                            if (value === undefined || value === null) value = "";
                            switch (fieldDef.type) {
                                case "boolean":
                                    if (typeof value === "string") value = value.toLowerCase();
                                    // no break
                                case "picklist":
                                case "date":
                                case "datetime":
                                    record.sobjectinfo[fname] = typeof value === "object" ? value : {
                                        fieldvalue: {
                                            key: value, value: value
                                        }
                                    };
                                    record.sobjectinfo[fname].fieldapiname = fname;
                                    break;
                                // TODO: Do we need to handle any other types here
                                // or is it ok to just have a literal here?
                                // references are handled below.
                                default:
                                    record.sobjectinfo[fname] = value;
                            }
                        }

                        // Finally, if its a reference, and the value for our reference
                        // isn't already fieldvalue: {key/value}, then we need to lookup
                        // the display field for that reference.
                        // WARNING: Chrome somehow loses record.sobjectinfo[fname] between entering
                        // this if statement and firing the callback, so we need to localize it
                        // as a variable separate from record.sobjectinfo.
                        var value = record.sobjectinfo[fname];
                        if (fname === "RecordTypeId" && fieldDef.type === "reference"){
                            var recordTypeValue = record.sobjectinfo.RecordTypeId;
                            if (typeof recordTypeValue === "object" && "fieldvalue" in recordTypeValue) {
                                record.sobjectinfo.RecordTypeId = recordTypeValue;
                                onDone();
                            } else {
                                utils.MetaData.describeObject({
                                    objectName: record.sobjectinfo.getTableName(),
                                    onSuccess: SVMX.proxy(this, function(describeObjectData) {
                                        var recordTypeInfo = describeObjectData.recordTypeInfos;
                                        var newValue = SVMX.array.get(recordTypeInfo, function(item) {
                                            return item.fixedName === recordTypeValue;
                                        });
                                        if (newValue) {
                                            recordTypeValue = newValue.name; // values are usually the same but if translating to other languages, recordTypeValue will now be the foreign name
                                            newValue = newValue.recordTypeId;
                                        }
                                        record.sobjectinfo.RecordTypeId = {
                                            fieldvalue: {key: newValue, value: recordTypeValue},
                                            fieldapiname: "RecordTypeId"};
                                        onDone();
                                    }),
                                    onError: function(error) {
                                        logger.error("ERROR: executeObjectMapping describeObject call failed: " + error);
                                        onDone();
                                    }
                                });
                            }
                        } else if (fieldDef.type === "reference" && value && typeof value !== "object" && fname != "RecordTypeId") {
                            value =  {
                                fieldvalue: {
                                    key: value, value: null // value to be set
                                },
                                fieldapiname: fieldDef.name
                            };

                            // Don't need to lookup the record if the field we used was
                            // our sourceData's Id; the record IS the sourceData.
                            if (mapdataItem.source_field_name.toLowerCase() === "id") {
                                value.fieldvalue.value = sourceData[utils.MetaData.getNameField(sourceData.attributes.type)];
                                record.sobjectinfo[fname] = value; // chrome bug requires this to be reset; it loses its value otherwise
                                onDone();
                            }

                            // Otherwise, we need to lookup the record and get its display field.
                            else {
                                utils.Data.getRecord({
                                    Id: value.fieldvalue.key
                                })
                                .then(
                                    function(referenceRecord) {
                                        value.fieldvalue.value = referenceRecord.getNameValue();
                                        record.sobjectinfo[fname] = value;
                                        onDone();
                                    },
                                    function(error) {
                                        onDone();
                                    }
                                );
                            }
                        } else {
                            onDone();
                        }

                        logger.info("ObjectMap: SET " + fname + " TO " + record.sobjectinfo[fname]);
                    }, this);
                }, this);
                if (referenceLookups === 0) {
                    onDone();
                }
            }));
        },

        getFieldValue : function(inObj, inField) {
            if (inField in inObj) return inObj[inField];
            var lcObj = {};
            SVMX.forEachProperty(inObj, function(inKey, inValue) {
                lcObj[inKey.toLowerCase()] = inValue;
            });
            return lcObj[inField.toLowerCase()];
        },

        // If the mapping fails, just call onSuccess anyways so that the UI can continue.
        // TODO: Should this be treated as a severe error and abort?
        __executeObjectMappingError : function(deferred, evt){
            //map the values
            logger.error("Unable to find Object Mapping: " + evt.data.data + "; " + evt.data.parameters.query);
            deferred.resolve();
        },

        /**
         * PUBLIC METHOD getAllReferences
         * @description
         *    Takes an array of records, and looks up the display field
         *    for all reference fields in all records.  This call modifies
         *    the input array, so using the onSuccess parameter is not neccessary.
         *    getAllReferneces({data: [{...},{...}], onSuccess: function(inRecord) {}, onError: function(inErrorMsg) {}})
         * @param {Object} inParams
         *      @param {[Object]} data Array of record objects
         *      @param {boolean} replaceReferenceWithString If true, replaces reference field value with its display value, else replaces it with {key/value} pair.  Default is false.
         *      @param {boolean} convertPicklists If true, picklist values are replaced with {key/value} pair instead of left as a string.  Default is false.
         *      @param {Function} onSuccess Takes one input: the array or records.
         *      @param {Function} onError Takes one input, the error message
         *
         * @returns undefined
         */
        getAllReferences : function(inParams) {
            var d = new $.Deferred();
            if (inParams.onSuccess) {
                d.done(function(data) {
                    inParams.onSuccess(data);
                });
            }
            if (inParams.onError) {
                d.fail(function(error) {
                    inParams.onError(error);
                });
            }

            if (inParams.data.length === 0) {
                d.resolve(inParams.data);
                return d;
            }
            inParams.referencedSetCounter = 0;

            var tableName = utils.MetaData.getTableForId(inParams.data[0].Id);
            if (!tableName) {
                logger.error("FATAL ERROR: Could not find table for Id " + inParams.data[0].Id + " in getAllReferences");
                d.reject("Could not find table");
                return d;
            }
            utils.MetaData.describeObject({
                objectName: tableName,
                onSuccess: SVMX.proxy(this, function(describeObjectData) {
                    var fields = describeObjectData.fields;
                    var recordTypeInfo = describeObjectData.recordTypeInfos;
                    if (inParams.convertPicklists) {
                        var picklistFields = SVMX.array.filter(fields, function(inItem) {return inItem.type === "picklist";});
                        for (var i = 0; i < picklistFields.length; i++) {
                            var fname = picklistFields[i].name;
                            SVMX.array.forEach(inParams.data, function(dataItem) {
                                var value = dataItem[fname];
                                dataItem[fname] = {fieldvalue: {value: value, key: value},
                                                    fieldapiname: fname};
                            });
                        }
                    }
                    var referenceFields = SVMX.array.filter(fields, function(inItem) {return inItem.referenceTo.length;});
                    inParams.referencedSetCounter = referenceFields.length;
                    for (var i = 0; i < referenceFields.length; i++) {
                        this.__getAllReferencesForField(inParams, referenceFields[i], recordTypeInfo, d);
                    }
                    if (inParams.referencedSetCounter === 0) {
                        d.resolve(inParams.data);
                    }
                })
            });
            return d;
        },

        __getAllReferencesForField : function(inParams, fieldDef, recordTypeInfo, deferred) {
            var fieldName = fieldDef.name;
            var fieldValues = SVMX.array.map(inParams.data, function(inItem) {
                return inItem[fieldName];
            });

            // Remove empty elements from array
            var nonEmptyfieldValues = SVMX.array.filter(fieldValues, function(inItem) {return inItem;});
            if (nonEmptyfieldValues.length === 0) {
                inParams.referencedSetCounter--;
                if (inParams.referencedSetCounter === 0) {
                    deferred.resolve(inParams.data);
                }
                return;
            }

            var tableName = utils.MetaData.getTableForId(nonEmptyfieldValues[0]);
            if (tableName) {
                if (fieldName === "RecordTypeId") {
                    var data = inParams.data;
                    for (var i = 0; i < data.length; i++) {
                        var key = data[i].RecordTypeId;
                        var newValue = SVMX.array.filter(recordTypeInfo, function(item) {return item.recordTypeId === key;})[0];
                        if (newValue === undefined) {
                            newValue = key;
                        } else {
                            newValue = newValue.name;
                        }

                        if (inParams.replaceReferenceWithString) {
                            data[i].RecordTypeId = key;
                        } else {
                            data[i].RecordTypeId = {
                                fieldvalue: {
                                    key: key, value: newValue
                                },
                                fieldapiname: "RecordTypeId"
                            };
                        }
                    }
                    inParams.referencedSetCounter--;
                    if (inParams.referencedSetCounter === 0) {
                        deferred.resolve(inParams.data);
                    }
                } else {
                    var nameField = utils.MetaData.getNameField(tableName);
                    var req = nativeService.createSQLRequest();
                    req.bind("REQUEST_ERROR",     SVMX.proxy(this, "__getAllReferencesForFieldError",   inParams, deferred));
                    req.bind("REQUEST_COMPLETED", SVMX.proxy(this, "__getAllReferencesForFieldSuccess", fieldName, fieldValues, inParams, deferred));
                    req.execute({
                        query: "SELECT {{name_field}} as name_field_value, Id, '{{replace_field}}' as replace_field " +
                                "FROM '{{table_name}}' where Id IN({{Ids}})",
                        queryParams: {
                            table_name: tableName,
                            Ids: "'" + fieldValues.join("','") + "'",
                            name_field: nameField,
                            replace_field: fieldName
                        }
                    });
                }
            } else {
                // if there is no tableName, check the SFRecordName table...
                this.__getAllReferencesForFieldSuccess(fieldName, fieldValues, inParams, deferred,
                    {data: {}});
            }

        },
        __getAllReferencesForFieldError: function(inParams, deferred, evt) {
            inParams.referencedSetCounter--;
            // NOTE: Some data just isn't available in offline mode; don't abort just because we
            // can't find the related table entries
            if (inParams.referencedSetCounter === 0) {
                deferred.resolve(inParams.data);
            }
        },

        __getAllReferencesForFieldSuccess: function(fieldName, fieldValues, inParams, deferred, evt) {
            var isNameSyncData = evt.data.parameters && evt.data.parameters.query.match(/SFRecordName/);
            var noData = Boolean(!evt.data.data);
            var displayData = noData ? null : getDataFromEvt(evt);
            var dataHash = {};
            var unresolvedReferences = false;

            if (!noData && displayData.length === 0) noData = true;
            if (noData) {
                unresolvedReferences = true;
            } else {
                SVMX.array.forEach(fieldValues, function(inItem) {
                    if (inItem) {
                        dataHash[inItem] = false;
                    }
                }, this);

                var replaceField = displayData[0].replace_field;
                for (var i = 0; i < displayData.length; i++) {
                    var d = displayData[i];
                    dataHash[d.Id] = d.name_field_value;
                }

                var data = inParams.data;
                for (var i = 0; i < data.length; i++) {
                    var key = data[i][replaceField];
                    var newValue = dataHash[key];
                    if (newValue !== false) {
                        if (newValue === undefined) newValue = key;
                        if (inParams.replaceReferenceWithString) {
                            data[i][replaceField] = newValue;
                        } else if (data[i][replaceField] && typeof data[i][replaceField] == "object") {
                            // reference already resolved in previous call;
                            // typically happens when first call (from main table query) resolves the value
                            // but a second pass with SFRecordName table results sees some values previously resolved
                            ;
                        } else {
                            data[i][replaceField] = {
                                fieldvalue: {
                                    key: key, value: newValue
                                },
                                fieldapiname: replaceField
                            };
                            if (isNameSyncData) data[i][replaceField].fieldvalue.isNameSyncData = true;
                        }
                    }
                }

                fieldValues = [];
                SVMX.forEachProperty(dataHash, function(inKey, inValue) {
                    if (inValue === false) {
                        unresolvedReferences = true;
                        fieldValues.push(inKey);
                    }
                });
            }

            if (unresolvedReferences && (!evt.data.parameters || !evt.data.parameters.query.match(/SFRecordName/))) {
                /* Note that we don't query the name field record from the start because its possible for the Name field to be changed
                 * by the user, so first we checked the original table, and then only checked SFRecordName if that has no data
                 */
                var req = nativeService.createSQLRequest();
                req.bind("REQUEST_ERROR",     SVMX.proxy(this, "__getAllReferencesForFieldError",   inParams, deferred));
                req.bind("REQUEST_COMPLETED", SVMX.proxy(this, "__getAllReferencesForFieldSuccess", fieldName, fieldValues, inParams, deferred));
                req.execute({
                    query: "SELECT Id, Name as name_field_value, '{{replace_field}}' as replace_field FROM SFRecordName WHERE Id IN({{Ids}})",
                    queryParams: {
                        Ids: "'" + fieldValues.join("','") + "'",
                        replace_field: fieldName
                    }
                });

            } else {
                inParams.referencedSetCounter--;
            }
            if (inParams.referencedSetCounter === 0) {
                deferred.resolve(inParams.data);
            }
        },

        updateExternalLocalRecords: function(data, callback){
            var mapRecordIds = data.insertRecordsMap;
            var lstLocalRecIds = [];
            for(var localId in mapRecordIds){
                lstLocalRecIds.push(localId);
                // Update Record in SFRecordName Table
                this.insertUpdateRecordIntoNameTable(localId, {key: mapRecordIds[localId]});
            }

            if(!lstLocalRecIds.length){
                return callback && callback.handler.call(callback.context);
            }

            function getSyncDependentRecords(lstLocalRecIds){
                var d = SVMX.Deferred();
                execQuery({
                    query : "SELECT parent_object_name, local_id, parent_record_id, parent_field_name FROM SyncDependentLog WHERE local_id IN ('{{ids}}')",
                    queryParams: {
                        ids: lstLocalRecIds.join("','")
                    }
                }).then(
                    SVMX.proxy(this, function(data){
                        d.resolve(data);
                    }),
                    SVMX.proxy(this, function(data){
                        logger.info("Sync Dependent records query failed");
                        d.resolve();
                    })
                );
                return d;
            }

            function updateDependentRecord(record, value){
                var d = SVMX.Deferred();
                execQuery({
                    query : "UPDATE {{parent_object_name}} SET {{parent_field_name}} = '{{parent_field_value}}' WHERE Id = '{{parent_record_id}}'",
                    queryParams: {
                        parent_object_name: record.parent_object_name,
                        parent_field_name: record.parent_field_name,
                        parent_record_id: record.parent_record_id,
                        parent_field_value: value
                    }
                }).then(
                    SVMX.proxy(this, function(data){
                        logger.info("Sync Dependent record ("+ record.parent_record_id +") update completed");
                        deleteSyncDependentRecord(record, d);
                    }),
                    SVMX.proxy(this, function(data){
                        logger.info("Sync Dependent record ("+ record.parent_record_id +") update failed");
                        d.resolve();
                    })
                );
                return d;
            }

            function deleteSyncDependentRecord(record, d){
                execQuery({
                    query : "DELETE FROM SyncDependentLog WHERE parent_field_name = '{{parent_field_name}}' AND parent_record_id = '{{parent_record_id}}'",
                    queryParams: {
                        parent_field_name: record.parent_field_name,
                        parent_record_id: record.parent_record_id
                    }
                }).then(
                    SVMX.proxy(this, function(data){
                        logger.info("Sync Dependent log ("+ record.local_id +") delete completed");
                        d.resolve();
                    }),
                    SVMX.proxy(this, function(data){
                        logger.info("Sync Dependent log ("+ record.local_id +") delete failed");
                        d.resolve();
                    })
                );
            }

            getSyncDependentRecords(lstLocalRecIds)
                .done( SVMX.proxy( this, function(data){
                    if(data && data.length){
                        var defers = [];
                        for(var i = 0; i < data.length; i++){
                            defers.push( updateDependentRecord(data[i], mapRecordIds[data[i].local_id]) );
                        }
                        $.when(defers).then(
                            function(){
                                callback && callback.handler.call(callback.context);
                            }
                        );
                    }else{
                        callback && callback.handler.call(callback.context);
                    }
                }));
        }
    });

   /**************************************************************
    * STATIC CLASS: MetaData
    * @descriptions Retrieves data from various meta tables
    *               including tables that describe other tables,
    *               and tables that describe processes, layouts, etc...
    * describeObject({objectName: "SVMXC__Service_Order__c", onSuccess: function(describeData) {}})
    * isTableInDatabase("Accounts", function(exists) {alert(exists);})
    * getTableForId("abcdefg", function(inTableName) {alert(inTableName);})
    * getIdForTable("Accounts", function(inId) {alert(inId);})
    * getNameField("Accounts", function(inNameField) {alert(inNameField);})
    *
    */
    utils.Class("MetaData", com.servicemax.client.lib.api.Object, {
    }, {

        /**
         * PUBLIC METHOD describeObject
         * @description
         *    Retrieves the DescribeObject data
         *
         * @param {Object} inParams
         *    {string} objectName
         *    {boolean} synch  Defaults to asynchronous, even when the data is cached;
         *                     If you specify sync, it will TRY to return synchronously
         *                     but will still be async of data not cached.
         *    {Function} [onSuccess] Function to call when results are available
         *    {Function} [onError] Function to call when error is thrown
         * @returns undefined
         *
         */
        __describeObjectPendingEvents: {},
        describeObject : function(inParams) {
            var d = new $.Deferred();
            //Handle our requireddefaults
            inParams = inParams || {};
            inParams.onSuccess = inParams.onSuccess || function() {};
            // If the results are already cached, retrieve them from javascript cache
            // and flag the entry in cache as recently accessed
            utils.Cache.registerJSCache("DescribeObject", 15);
            var defineObjResult = utils.Cache.readFromJSCache("DescribeObject", inParams.objectName);
            if (defineObjResult) {
                if (inParams.sync) {
                    inParams.onSuccess(defineObjResult);
                    d.resolve(defineObjResult);
                } else {
                    SVMX.doLater(function() {
                        inParams.onSuccess(defineObjResult);
                        d.resolve(defineObjResult);
                    }, this);
                }
                return d;
            }

            // If there is already a request running for the specified object, don't run it twice,
            // simply add a listener to the first request
            inParams.deferred = d;
            if (!this.__describeObjectPendingEvents[inParams.objectName]) {
                this.__describeObjectPendingEvents[inParams.objectName] = [inParams];
            } else {
                this.__describeObjectPendingEvents[inParams.objectName].push(inParams);
                return;
            }
            var request = nativeService.createSQLRequest();
            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, "__onDescribeObjectSuccess", inParams));
            request.bind("REQUEST_ERROR", SVMX.proxy(this, "__onDescribeObjectError", inParams));
            request.execute({
                query: "SELECT object_describe FROM SFObjectDescribe WHERE object_name='{{object_name}}'",
                queryParams: {object_name: inParams.objectName}
            });
            return d;
        },
        __onDescribeObjectSuccess : function(inParams, evt) {
            var result = getDataFromEvt(evt);

            if (!result.length || !result[0].object_describe) {
                return this.__onDescribeObjectError(inParams, evt);
            }

            result = SVMX.toObject(result[0].object_describe);

            // TODO: Figure out where the accessible field actually comes from
            SVMX.array.forEach(result.fields, function(inField) {
                inField.accessible = true;
            });

            SVMX.array.forEach(result.recordTypeInfos, function(recordTypeInfo) {
                recordTypeInfo.fixedName =  utils.MetaData.getRecordTypeNameFromId(recordTypeInfo.recordTypeId);
            }, this);

            SVMX.array.forEach(result.fields, function(field) {
                field.dataType = field.type;
            });

            utils.Cache.writeToJSCache("DescribeObject", inParams.objectName, result);

            var responders = this.__describeObjectPendingEvents[inParams.objectName];
            for (var i = 0; i < responders.length; i++) {
                if (responders[i].onSuccess) {
                    responders[i].onSuccess(result, inParams.objectName);
                }

                //removed objectName from response to match describeObject, causes errors when deferred is used in a SVMX.when
                responders[i].deferred.resolve(result);
            }
            delete this.__describeObjectPendingEvents[inParams.objectName];
        },

        __onDescribeObjectError : function(inParams, evt) {
            logger.error("DescribeObject Failed: " + evt.data.parameters.query + "; " + evt.data.data);
            var responders = this.__describeObjectPendingEvents[inParams.objectName];

            delete this.__describeObjectPendingEvents[inParams.objectName];

            for (var i = 0; i < responders.length; i++) {
                if (responders[i].onError) {
                    responders[i].onError(evt, inParams.objectName);
                }
                //AND-1601
                //deferred reject causes output doc to not load, so always resolve
                responders[i].deferred.reject(evt, inParams.objectName);
            }
        },


        /**
         * PUBLIC METHOD isTableInDatabase
         * @description
         *    Not all tables that are referenced by something are in our database
         *    and querying something that does not exist will throw errors.
         *    isTableInDatabase("Accounts", function(exists) {alert(exists);})
         *    First call will be asynchronous as it queries the database, all future
         *    calls are synchronous, using cached data.
         *
         * @param {String} tableName Name of the table whose existence we are testing for.
         * @param {Function} callback "function(exists) {if (exists) {...}}"
         *
         * @returns undefined
         */
        __tablesInDbHash : null,
         isTableInDatabase : function(inTableName, inCallback) {
            var result = this.__tablesInDbHash ? this.__tablesInDbHash[inTableName] : null;
            if (inCallback) {
                inCallback(result);
            }
            return result;
        },

        registerNewTableInDatabase : function(inTableName) {
            if (!this.__tablesInDbHash) return;
            this.__tablesInDbHash[inTableName] = true;
        },

        /**
         * PUBLIC METHOD getTablesInDatabase
         * @description
         *    Get the full list of database tables that are in our sql database; returns as hash.
         *
         * @returns {Object} Hash of table names
         */
        getTablesInDatabase : function() {
            return this.__tablesInDbHash;
        },

        __setupTableInDBData : function() {
            var d = new $.Deferred();
            var request = nativeService.createSQLRequest();
            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(evt) {
                // Initialize the table
                this.__tablesInDbHash = {};
                try {
                    for (var i = 0; i < evt.data.data.length; i++) {
                        this.__tablesInDbHash[evt.data.data[i].name] = true;
                    };
                } catch(e) {
                    logger.error("SERIOUS ERROR IN __setupTableInDBData: " + e.data);
                }
                d.resolve();
            }));
            request.bind("REQUEST_ERROR", function(evt) {
                logger.error("ERROR: __setupTableInDBData failed; this error is expected prior to initial sync and is serious if it occurs after sync");
                d.resolve();
            });
            request.execute({query:"SELECT name FROM sqlite_master"});
            return d;
        },

        __objectsWithViewProcessesHash : null,
        __setupObjectsWithViewProcesses : function() {
            var d = new $.Deferred();
            var request = nativeService.createSQLRequest();
            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(evt) {
                // Initialize the table
                this.__objectsWithViewProcessesHash = {};
                try {
                    for (var i = 0; i < evt.data.data.length; i++) {
                        this.__objectsWithViewProcessesHash[evt.data.data[i].object_name] = true;
                    };
                } catch(e) {
                    logger.error("SERIOUS ERROR IN __setupObjectsWithViewProcesses: " + e.data);
                }
                d.resolve();
            }));
            request.bind("REQUEST_ERROR", function(evt) {
                logger.error("ERROR: __setupObjectsWithViewProcesses failed; this error is expected prior to initial sync and is serious if it occurs after sync");
                d.resolve();
            });
            request.execute({query:"select object_name from SFProcess LEFT JOIN SFProcessComponent ON SFProcessComponent.process_id = SFProcess.process_id WHERE process_type='VIEW RECORD' group by object_name"});
            return d;
        },


        /**
         * PUBLIC METHOD doesObjectHaveViewProcess
         * @description
         *    Indicates if the specified object has a view process to show it
         *
         * @param {String} inObjectName Name of the object that we are testing
         *
         * @returns {boolean} true means it can be displayed in a view process
         */
        doesObjectHaveViewProcess: function(inObjectName) {
            return Boolean(this.__objectsWithViewProcessesHash[inObjectName]);
        },

        __recordTypeIdCache: {},
        __setupRecordTypeIds : function() {
            var d = new $.Deferred();
            var request = nativeService.createSQLRequest();
            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(evt) {
                // Initialize the table
                this.__recordTypeIdCache = {};
                try {
                    for (var i = 0; i < evt.data.data.length; i++) {
                        var item = evt.data.data[i];

                        this.__recordTypeIdCache[item.Id] = item.Name;
                    };
                } catch(e) {
                    logger.error("SERIOUS ERROR IN __setupRecordTypeIds: " + e.data);
                }
                d.resolve();
            }));
            request.bind("REQUEST_ERROR", function(evt) {
                logger.error("ERROR: __setupRecordTypeIds failed; this error is expected prior to initial sync and is serious if it occurs after sync");
                d.resolve();
            });
            request.execute({query:"SELECT Name, Id FROM RecordType"});
            return d;
        },
        getRecordTypeNameFromId : function(id) {
            return this.__recordTypeIdCache[id];
        },

        /**
         * PUBLIC METHOD getTableForId
         * @description
         *    Looks up the table name for the given ID.  Only works if our DescribeObject
         *    table contains your ID's prefix.  The first call gathers the data from the
         *    database and then calls your callback asynchronously.  All subsequent calls
         *    use cached data and should call the callback synchronously.
         *
         * @param {String} Id  Takes either a salesforce reference or a newly inserted ID string
         *                     generated by writeRecord.
         * @param {Function} callback "function(tableName) {if (tableName) {...}}"
         *
         * @returns undefined
         */
        __tablePrefixHash : null,
        __tableReversePrefixHash : null,
        getTableForId : function(inId, inCallback) {
            if (inCallback) {
                inCallback(this.__tablePrefixHash[inId.substring(0,3)]);
            }
            return this.__tablePrefixHash[inId.substring(0,3)];
        },
        __setupTableIdPrefixes : function(inCallback) {
            var d = new $.Deferred();
            var request = nativeService.createSQLRequest();
            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(evt) {
                // Initialize the table
                this.__tablePrefixHash = {};
                this.__tableReversePrefixHash = {};
                try {
                    for (var i = 0; i < evt.data.data.length; i++) {
                        this.__tablePrefixHash[evt.data.data[i].key_prefix] = evt.data.data[i].object_name;
                        this.__tableReversePrefixHash[evt.data.data[i].object_name] = {prefix: evt.data.data[i].key_prefix, label: evt.data.data[i].label};
                    };
                } catch(e) {
                    logger.error("SERIOUS ERROR IN __setupTableIdPrefixes: " + e.data);
                }
                d.resolve();
            }));
            request.bind("REQUEST_ERROR", function(evt) {
                logger.error("FATAL ERROR: setupTableIdPrefixes failed; this error is expected prior to initial sync and is serious if it occurs after sync");
                d.resolve();
            });
            request.execute({query:"SELECT object_name, key_prefix, label from SFObjectDescribe"});
            return d;
        },
        getIdForTable : function(inTableName, callback) {
            return this.__tableReversePrefixHash[inTableName].prefix;
        },
        getLabelForTable : function(inTableName, callback) {
            return this.__tableReversePrefixHash[inTableName].label;
        },

        /**
         * PUBLIC METHOD getNameField
         * @description
         *    Looks up the display field for the specified table
         *
         * @param {String} tableName
         * @param {Function} callback "function(tableName) {if (tableName) {...}}"
         *
         * @returns String
         *
         * @note This USED to return __nameFieldsHash[tableName], until it was determined that some tables have
         * multiple nameFields in their meta data, and to work around this, we've hardcoded in all name fields.
         */

         __nameFieldsHash : null,
         getNameField : function(tableName, inCallback) {
            var result;
            if (tableName == "Case") {
                result = "CaseNumber";
            } else if (tableName == "Event") {
                result = "Subject";
            } else if (tableName == "Solution") {
                result = "SolutionName";
            } else if (tableName == "PartnerNetworkConnection") {
				result = "ConnectionName";
			} else if (tableName == "Task") {
                result = "Subject";
            } else {
                result = "Name";
            }
             if (inCallback) {
                inCallback(result);
            }
            return result;
            /*
            if (inCallback) {
                inCallback(this.__nameFieldsHash[tableName]);
            }
            return this.__nameFieldsHash[tableName];
            */
        },
        __setupNameFieldData : function(callback) {
            var d = new $.Deferred();
            var request = nativeService.createSQLRequest();
            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(evt) {
                // Initialize the table
                this.__nameFieldsHash = {};
                var data = evt.data.data;
                try {
                    for (var i = 0; i < data.length; i++) {
                        this.__nameFieldsHash[data[i].object_api_name] = data[i].api_name;
                    }
                } catch(e) {
                    logger.error("SERIOUS ERROR IN __setupNameFieldData: " + e.data);
                }
                d.resolve();
            }));
            request.bind("REQUEST_ERROR", function(evt) {
                logger.error("FATAL ERROR: setupNameFieldData Failed; this error is expected prior to initial sync and is serious if it occurs after sync");
                d.resolve();
            });
            request.execute({query:"SELECT object_api_name, api_name FROM SFObjectField WHERE name_field = 'true'"});
            return d;
        },


        /**
         * PUBLIC METHOD getProcess
         * @description
         *    Queries the SFProcess and SFProcessComponents to get information about the specified process
         *
         * @param {Object} inParams
         *    {string} [processId] process name/id
         *    {string} [salesforceProcessId] process id as a Salesforce reference.
         *    {object} [state] Any state you want passed into your callbacks
         *    {string} [componentType] Default is TARGET; can be used to get the SOURCE.
         *    {Function} [onSuccess] Function to call when results are available
         *    {Function} [onError] Function to call when error is thrown
         * @returns undefined
         *
         */
        getProcess : function(inParams) {
            if (!inParams.componentType) inParams.componentType = "TARGET";
            return execQuery({
                query: "SELECT SFProcess.*, SFProcessComponent.object_name as target_object_name, SFProcessComponent.expression_id, SFProcessComponent.value_mapping_id, SFProcessComponent.object_mapping_id " +
                       "FROM SFProcess " +
                       "LEFT JOIN SFProcessComponent ON SFProcess.process_id = SFProcessComponent.process_id " +
                       "WHERE component_type='{{component_type}}' AND {{id_name}}='{{process_id}}'",
                queryParams: {
                    id_name: inParams.salesforceProcessId ? "SFProcess.process_id" : "process_unique_id",
                    process_id: inParams.salesforceProcessId || inParams.processId,
                    component_type: inParams.componentType
                },
                onSuccess: inParams.onSuccess,
                onError: inParams.onError
            });
        },

        getExpressionIdFromProcessId : function(inParams){
            this.getProcess({
                    processId: inParams.processId,
                    salesforceProcessId: inParams.salesforceProcessId,
                    onSuccess: SVMX.proxy(this, function(evt) {
                        var data = evt.data.data;
                        if (!data || data.length === 0) {
                            if (inParams.onSuccess) inParams.onSuccess(data);
                        } else if (inParams.onSuccess) {
                            inParams.onSuccess(data[0].expression_id);
                        }
                    }),
                    onError: SVMX.proxy(this, function(evt) {
                        inParams.onError
                    })
            });
        },

        /**
         * Gets the list of processes for a given record that pass the qualification criteria and will allow that record to be oppenned.
         * @param {Object} inParams
         * @param {[string]} inParams.recordId Id of the record that any qualification criteria will be evaluated against
         * @param {[Object]} inParams.record To save time, provide a Record instead of a recordId
         * @param {string} inParams.objectName Name of the table to get the object from
         * @param {string} inParams.processType Type of process to search on; one of "VIEW RECORD", "STANDALONE EDIT", "STANDALONE CREATE", etc..
         * @param {string} inParams.considerDefaultView flag to indicate whether default view needs to be get / set.
         * @return {Deferred} Callback for deffered provides an array of process data for matching processes, and a record (useful if you provided recordId as input)
         *
         *       getQualifiedProcessesForRecord({recordId: "fred", objectName: "SVMXC__Service_Order__c"}).then(
         *          function(processList, record) {
         *             ...
         *          }
         *       );
         */
        getQualifiedProcessesForRecord : function(inParams) {

            var d = SVMX.Deferred();
            var qualifiedProcesses = [];
            var data = null;

            this.getDefaultView(inParams).then(SVMX.proxy(this, function(defaultViewProcesses) {

                //LAP-6009: Consider default view, if available.
                if(inParams.considerDefaultView === true && defaultViewProcesses && defaultViewProcesses.length > 0) {
                    logger.info("Considered default View Process: " + defaultViewProcesses[0].process_unique_id);
                    d.resolve(defaultViewProcesses);
                }
                else {

                    execQuery({
                        query : "Select SFProcess.*, SFProcessComponent.object_name as target_object_name, SFProcessComponent.expression_id " +
                            "FROM SFProcess " +
                            "LEFT JOIN SFProcessComponent ON SFProcess.process_id = SFProcessComponent.process_id " +
                        "WHERE (process_type = '{{process_type}}' AND component_type='TARGET' AND target_object_name = '{{object_name}}') ORDER BY process_unique_id",
                            queryParams: {
                            object_name : inParams.objectName,
                            process_type : inParams.processType
                        }
                    })
                    .then(SVMX.proxy(this, this.validateProcessesQualificationForRecord, inParams))
                    .then(SVMX.proxy(this, function(inProcesses, inData) {

                        qualifiedProcesses = inProcesses;
                        data = inData;

                        //Set first process as a default view for view process only, if considerDefaultView parameter is set to true.
                        if(inParams.considerDefaultView === true && inParams.processType === "VIEW RECORD"
                            && qualifiedProcesses && qualifiedProcesses.length > 0) {

                            this.setDefaultView({
                                objectName: inParams.objectName,
                                defaultProcess: qualifiedProcesses[0].process_unique_id
                            })
                            .then(SVMX.proxy(this, function() {
                                d.resolve(qualifiedProcesses, data);
                            }));
                        }
                        else {
                            d.resolve(qualifiedProcesses, data);
                        }
                    }));
                }
            }));
            return d;
        },


        /**
         * To check whether given processes are qualified for the given record or not.
         * @param {Object} and list of processes inParams
         * @param {[string]} inParams.recordId Id of the record that any qualification criteria will be evaluated against
         * @param {[Object]} inParams.record To save time, provide a Record instead of a recordId
         * @param list of processes - processes which needs to be validated.
         * @return {Deferred} Callback for deffered provides an array of process data for matching processes, and a record (useful if you provided recordId as input)
         *
         *       isProcessesQualifiedForRecord({record: {}, processes: []}).then(
         *          function(checklistProcesses, record) {
         *             ...
         *          }
         *       );
         */
        validateProcessesQualificationForRecord : function(params, potentialProcesses) {

            var d = SVMX.Deferred();
            var qualifiedProcesses = [], potentialProcesses = potentialProcesses || [];
            var counter = potentialProcesses.length;

            if (counter) {
                utils.Data.getRecord({
                    Id: params.recordId,
                    record: params.record,
                    loadReferences: true, // TODO: See if this is needed; presumably needed for RecordTypeId
                    convertPicklists: false
                }).then(
                    SVMX.proxy(this, function(inData) {
                        if (inData) {
                            SVMX.array.forEach(potentialProcesses, function(p) {
                                if (p.expression_id) {
                                    utils.Expressions.evaluate({
                                        data: inData,
                                        expressionId: p.expression_id,
                                        onSuccess : SVMX.proxy(this, function(result) {
                                            if (result[0]) {
                                                qualifiedProcesses.push(p);
                                            } else {
                                                logger.info("Process " + p.process_unique_id + " failed qualifying criteria");
                                            }
                                            counter--;
                                            if (counter === 0) {
                                                d.resolve(qualifiedProcesses, inData);
                                            }
                                        })
                                    });
                                } else {
                                    qualifiedProcesses.push(p);
                                    counter--;
                                    if (counter === 0) {
                                        d.resolve(qualifiedProcesses, inData);
                                    }
                                }
                            }, this);
                        } else {
                            d.resolve(potentialProcesses, null); // If there's no record, ignore the qualifying criteria
                        }
                    })
                );
            } else {
                d.resolve([], null);
            }
            return d;
        },

        /**
         * Gets qualified default view for the record.
         * @param {Object} inParams
         * @param {[string]} inParams.recordId Id of the record that any qualification criteria will be evaluated against
         * @param {[Object]} inParams.record To save time, provide a Record instead of a recordId
         * @param {string} inParams.objectName Name of the table to get the object from
         * @return {Deferred} Callback for deffered provides an array of process data for matching processes, and a record (useful if you provided recordId as input)
         */
        getDefaultView: function(inParams) {
            var d = SVMX.Deferred();
            var inData = inParams.data;

            if(inParams.considerDefaultView === true) {
                com.servicemax.client.offline.sal.model.utils.Cache.readObjectFromDBCache('DEFAULT_VIEW.' + inParams.objectName, function(defaultViewId) {
                    this.getProcess({
                        processId: defaultViewId,
                        onSuccess: SVMX.proxy(this, function(evt) {
                            var defaultProcess = evt.data.data;
                            this.validateProcessesQualificationForRecord(inParams, defaultProcess).then(SVMX.proxy(this, function(defaultQualifiedViewes, data) {
                                d.resolve(defaultQualifiedViewes, data);
                            }));
                        }),
                        onError: SVMX.proxy(this, function(evt) {
                            d.resolve([], null);
                        })
                    });
                }, this);
            }
            else {
                d.resolve([], null);
            }
            return d;
        },


        /**
         * Sets default view for the given object
         * @param {Object} inParams
         * @param {[string]} inParams.objectName
         * @param {[Object]} inParams.defaultProcess
         * @return {Deferred}
         */
        setDefaultView: function(inParams) {
            var d = SVMX.Deferred();
            com.servicemax.client.offline.sal.model.utils.Cache.writeToDBCache("DEFAULT_VIEW." + inParams.objectName, inParams.defaultProcess, function() {
                logger.info("saved process ("+ inParams.defaultProcess + ") as default view for object " + inParams.objectName);
                d.resolve();
            }, this);
            return d;
        }
    });

    utils.Class("SetupNameFieldExtension", com.servicemax.client.lib.api.AbstractExtension, {
        perform : function(caller){
            return utils.MetaData.__setupNameFieldData();
        }
    });

    utils.Class("SetupTableIdPrefixExtension", com.servicemax.client.lib.api.AbstractExtension, {
        perform : function(caller){
            return utils.MetaData.__setupTableIdPrefixes();
        }
    });

    utils.Class("SetupTableInDBExtension", com.servicemax.client.lib.api.AbstractExtension, {
        perform : function(caller){
            return utils.MetaData.__setupTableInDBData();
        }
    });

    utils.Class("CacheRecordTypeIdsExtension", com.servicemax.client.lib.api.AbstractExtension, {
        perform : function(caller){
            return utils.MetaData.__setupRecordTypeIds();
        }
    });

    utils.Class("CacheObjectsWithViewProcessesExtension", com.servicemax.client.lib.api.AbstractExtension, {
        perform : function(caller){
            return utils.MetaData.__setupObjectsWithViewProcesses();
        }
    });

    /**************************************************************
	 * --Sumit--
     * STATIC CLASS: SyncData
     * @description PUBLIC ClientSyncLog And ClientSuccSyncLog Management methods
     *    insertRecord: Indicates that the specified ID has been inserted and needs to be synced
     *    updateRecord: Indicates that the specified ID has been updated and needs to be synced
     *    deleteRecord: Indicates that the specified ID has been deleted and needs to be synced
     *    insertAttachment: Indicates that the specified SFAttachments record has been inserted
     *    isRecordInConflict(inId); Returns deferred that evaluates to true or false
     *************************************************************/
    utils.Class("SyncData", com.servicemax.client.lib.api.Object, {}, {
        __ownerId: null,
        __openRecordOwners: {},
        __openRecordRemoteIds: {},
        insertRecord: function (inParams, callback) {
            if(inParams){
                this.writeSyncRecords({insertRecords: [inParams], callback: callback});
            }
        },
        updateRecord: function (inParams, callback) {
            if(inParams){
                this.writeSyncRecords({updateRecords: [inParams], callback: callback});
            }
        },
        deleteRecord: function (inParams, callback) {
            if(inParams){
                this.writeSyncRecords({deleteRecords: [inParams], callback: callback});
            }
        },
        insertAttachment: function (inParams, callback) {
            if(inParams){
                this.insertRecord({Id: inParams.Id, isAttachment: true}, callback);
            }
        },
        isRecordInConflict: function (inId) {
            var d = new $.Deferred();
            execQuery({
                query: "SELECT operation FROM ClientSyncConflict WHERE Id='{{Id}}' AND error_type='conflict'",
                queryParams: {Id: inId}
            }).then(function (data) {
                d.resolve(Boolean(data.length));
            });
            return d;
        },
        // NOTE: Adding open records for a given ownerId blows away all previous records open by that owner.  This is intentional; it means that when
        // the user saves and we reopen everything, we don't need to explicitly mark everything as closed and then reopen them again.
        // In the future we may need to allow one to add an individual open record; in which case this can be done using a separate method.
        addOpenRecords: function (ownerId, recordIds) {
            this.__openRecordOwners[ownerId] = recordIds;
        },
        removeOpenRecords: function (ownerId) {
            delete this.__openRecordOwners[ownerId];
        },
        removeOpenRecord: function (ownerId, recordId) {
            var openRecords = this.__openRecordOwners[ownerId];
            if (openRecords) {
                var ind = openRecords.indexOf(recordId);
                if (ind >= 0) {
                    delete openRecords[ind];
                }
            }
        },
        updateOpenRecordId: function (localId, remoteId) {
            SVMX.forEachProperty(this.__openRecordOwners, function (inKey, inRecords) {
                var ind = inRecords.indexOf(localId);
                if (ind >= 0) {
                    inRecords[ind] = remoteId;
                }
            });
        },
        getOpenRecords: function () {
            var recordIds = [];
            var recordIdsHash = {};
            SVMX.forEachProperty(this.__openRecordOwners, function (inKey, inRecords) {
                SVMX.array.forEach(inRecords, function (recordId) {
                    if (!recordId)
                        return;
                    if (!recordIdsHash[recordId]) {
                        recordIdsHash[recordId] = true;
                    }
                    recordIds.push(recordId);
                });
            });
            return recordIds;
        },
        isRecordOpen: function (inId) {
            var recordIds = this.getOpenRecords();
            return SVMX.array.contains(recordIds, function (id) {
                return id === inId;
            });
        },
        setOwnerId: function (ownerId) {
            this.__ownerId = ownerId;
        },
        getOwnerId: function () {
            return this.__ownerId;
        },
        addOpenRecordRemoteId: function (localId, remoteId) {
            this.__openRecordRemoteIds[localId] = remoteId;
            this.updateOpenRecordId(localId, remoteId);
        },
        getOpenRecordRemoteIds: function () {
            return this.__openRecordRemoteIds;
        },
        getOpenRecordRemoteId: function (localId) {
            return this.__openRecordRemoteIds[localId];
        },
        writeSyncRecords: function (params) {
            if (!params) {
                return;
            }
            var successive = false;
            var tableName = 'ClientSyncLog';
            var changeType = '';

            if ('isSuccessive' in params) {
                successive = params.isSuccessive;
            } else {
                successive = SVMX.getCurrentApplication().getSyncImpl().isSuccessiveSyncEnabled();
            }
            if (successive){
                tableName = 'ClientSuccSyncLog';
                changeType = 'client';
                if(params.isServerUpdates) {
                    changeType = 'server';
                }
            }
            var modifiedAt = DatetimeUtils.getCurrentDatetimeGMT(DatetimeUtils.getSaveFormat('dateTime'));

            var insertQuery = "INSERT INTO {{table_name}} (Id,parent_id,record_type,operation,modified_at,old_values,new_values{{objname_fld}}{{changetype_fld}}) VALUES ('{{id}}','{{parent_id}}','{{record_type}}','{{operation}}','{{modified_at}}','{{old_values}}','{{new_values}}'{{object_name}}{{change_type}})";
            var updateQuery = "UPDATE {{table_name}} SET id='{{id}}',operation='{{operation}}',new_values='{{new_values}}',old_values='{{old_values}}' WHERE id='{{where_id}}'{{change_type_clause}}";
            var deleteQuery = "DELETE FROM {{table_name}} WHERE Id IN ({{rec_ids}})";

            var mapRemoteIds = utils.SyncData.getOpenRecordRemoteIds();

            function getInsertQueryArray(existingRecords, queryArray) {
                for (var i = 0, l = params.insertRecords.length; i < l; i++) {
                    var record = params.insertRecords[i];

                    if (record.Id in existingRecords) {
                        params.updateRecords.push(record);
                        continue;
                    }
                    var recordType = record.recordType;
                    if (!recordType) {
                        recordType = 'detail';
                        if (record.isAttachment) {
                            recordType = "attachment";
                        } else if (!record.parentId) {
                            recordType = "master";
                        }
                    }
                    var queryParams = {
                        id: record.Id,
                        parent_id: record.parentId,
                        table_name: tableName,
                        record_type: recordType,
                        operation: 'insert',
                        old_values: SVMX.toJSON(record.oldValues) || '',
                        new_values: SVMX.toJSON(record.newValues) || '',
                        modified_at: modifiedAt
                    };
                    if (successive) {
                        if(record.objectName){
                            queryParams.objname_fld = ",object_name";
                            queryParams.object_name = ",'" + record.objectName + "'";
                        }
                        queryParams.changetype_fld = ",change_type";
                        queryParams.change_type = ",'" + changeType + "'";
                    }
                    queryArray.push(SVMX.string.substitute(insertQuery, queryParams));
                }
            }

            function getUpdateQueryArray(existingRecords, queryArray) {
                for (var i = 0, l = params.updateRecords.length; i < l; i++) {
                    var record = params.updateRecords[i];

                    var query = null, queryParams = null;
                    var isNewRecord = (record.Id.match(/_local_/) || record.Id.match(/^local_/));

                    if (record.Id in existingRecords) {
                        var existingRecord = existingRecords[record.Id];

                        if (existingRecord.new_values) {
                            if (record.newValues) {
                                record.newValues = mergeValues(existingRecord.new_values, record.newValues);
                            } else {
                                record.newValues = existingRecord.new_values;
                            }
                        }
                        if (existingRecord.old_values) {
                            if (record.oldValues) {
                                record.oldValues = mergeValues(record.oldValues, existingRecord.old_values);
                            } else {
                                record.oldValues = existingRecord.old_values;
                            }
                        }
                        query = updateQuery;
                        queryParams = {
                            id: record.Id,
                            where_id: record.localId || record.Id,
                            table_name: tableName,
                            operation: isNewRecord ? 'insert' : 'update',
                            old_values: SVMX.toJSON(record.oldValues) || '',
                            new_values: SVMX.toJSON(record.newValues) || '',
                            modified_at: modifiedAt
                        };
                        if(successive){
                            queryParams.change_type_clause = " AND change_type='" + changeType + "'";
                        }
                    } else {
                        query = insertQuery;
                        queryParams = {
                            id: record.Id,
                            parent_id: record.parentId,
                            table_name: tableName,
                            record_type: record.recordType || (!record.parentId ? "master" : "detail"),
                            operation: isNewRecord ? 'insert' : 'update',
                            old_values: SVMX.toJSON(record.oldValues) || '',
                            new_values: SVMX.toJSON(record.newValues) || '',
                            modified_at: modifiedAt
                        };
                        if (successive) {
                            if(record.objectName){
                                queryParams.objname_fld = ",object_name";
                                queryParams.object_name = ",'" + record.objectName + "'";
                            }
                            queryParams.changetype_fld = ",change_type";
                            queryParams.change_type = ",'" + changeType + "'";
                        }
                    }
                    //Defect 027230
                    //If single quotes are present in the fields, add two single quotes
                    if (queryParams.new_values.indexOf("'") > -1) {
                        queryParams.new_values = queryParams.new_values.replace(/'/g, "''");
                    }
                    if (queryParams.old_values.indexOf("'") > -1) {
                        queryParams.old_values = queryParams.old_values.replace(/'/g, "''");
                    }
                    queryArray.push(SVMX.string.substitute(query, queryParams));
                }
            }

            function getDeleteQueryArray(queryArray) {
                var recIds = [];
                getRecordIds(params.deleteRecords, recIds);

                if (recIds.length) {
                    var queryParams = {
                        table_name: tableName,
                        rec_ids: recIds
                    };
                    queryArray.push(SVMX.string.substitute(deleteQuery, queryParams));
                }
                for (var i = 0, l = params.deleteRecords.length; i < l; i++) {
                    var record = params.deleteRecords[i];

                    if (record.Id.match(/_local_/) || record.Id.match(/^local_/)) {
                        continue;
                    }
                    var queryParams = {
                        id: record.Id,
                        parent_id: record.parentId,
                        table_name: tableName,
                        record_type: record.recordType || (!record.parentId ? "master" : "detail"),
                        operation: 'delete',
                        old_values: '',
                        new_values: '',
                        modified_at: modifiedAt
                    };
                    if (successive) {
                        if(record.objectName){
                            queryParams.objname_fld = ",object_name";
                            queryParams.object_name = ",'" + record.objectName + "'";
                        }
                        queryParams.changetype_fld = ",change_type";
                        queryParams.change_type = ",'" + changeType + "'";
                    }
                    queryArray.push(SVMX.string.substitute(insertQuery, queryParams));
                }
            }

            function getRecordIds(records, recIds) {
                for (var i = 0, l = records.length; i < l; i++) {
                    var record = records[i];

                    var recId = "'" + record.Id + "'";
                    if (recIds.indexOf(recId) < 0) {
                        recIds.push(recId);
                    }
                    record.localId = record.Id;
                    if (record.Id in mapRemoteIds) {
                        record.Id = mapRemoteIds[record.Id];
                    }
                    if (record.parentId in mapRemoteIds) {
                        record.parentId = mapRemoteIds[record.parentId];
                    }
                    if (record.oldValues) {
                        updateValues(record.oldValues);
                    }
                    if (record.newValues) {
                        updateValues(record.newValues);
                    }
                }
            }

            function updateValues(record) {
                for (var key in record) {
                    var val = record[key];
                    if (val && val in mapRemoteIds) {
                        record[key] = mapRemoteIds[val];
                    }
                }
            }

            function mergeValues(newValues, existingValues, results) {
                var values = results;
                if (!values) {
                    values = {};
                }
                for (var key in existingValues) {
                    if (key in newValues) {
                        values[key] = newValues[key];
                    } else {
                        values[key] = existingValues[key];
                    }
                }
                if (!results) {
                    mergeValues(existingValues, newValues, values);
                }
                return values;
            }

            function onSuccess(records) {
                var existingRecords = {};
                var queryArray = [];

                if (records && records.length) {
                    for (var i = 0, l = records.length; i < l; i++) {
                        var record = records[i];

                        if (record.Id in mapRemoteIds) {
                            record.Id = mapRemoteIds[record.Id];
                        }
                        if (record.parent_id in mapRemoteIds) {
                            record.parent_id = mapRemoteIds[record.parent_id];
                        }
                        if (record.old_values) {
                            record.old_values = JSON.parse(record.old_values);
                            updateValues(record.old_values);
                        }
                        if (record.new_values) {
                            record.new_values = JSON.parse(record.new_values);
                            updateValues(record.new_values);
                        }
                        existingRecords[record.Id] = record;
                    }
                }
                if (params.insertRecords && params.insertRecords.length) {
                    getInsertQueryArray(existingRecords, queryArray);
                }
                if (params.updateRecords && params.updateRecords.length) {
                    getUpdateQueryArray(existingRecords, queryArray);
                }
                if (params.deleteRecords && params.deleteRecords.length) {
                    getDeleteQueryArray(queryArray);
                }
                if (queryArray.length) {
                    execQuery({queryArray: queryArray}).then(params.callback, onError);
                } else if (params.callback) {
                    params.callback();
                }
            }

            function onError(err) {
                logger.error("SERIOUS ERROR: Failed to insert/update record(s) into ClientSyncLog: " + err);
                if (params.callback) {
                    params.callback();
                }
            }

            var recIds = [];
            if (params.insertRecords && params.insertRecords.length) {
                getRecordIds(params.insertRecords, recIds);
            }
            if (params.updateRecords && params.updateRecords.length) {
                getRecordIds(params.updateRecords, recIds);
            }
            if (recIds.length) {
                execQuery({
                    query: "SELECT * FROM {{table_name}} WHERE Id In ({{rec_ids}})" + (successive ? " AND change_type='{{change_type}}'" : ""),
                    queryParams: {
                        table_name: tableName,
                        rec_ids: recIds,
                        change_type: changeType
                    }
                }).then(onSuccess, onError);
            } else {
                onSuccess();
            }
        },
        writeSyncWebServiceRecords: function (params) {
            if (!(params && params.wsInfo && params.wsInfo.actions && params.wsInfo.actions.length)) {
                if (params.callback) {
                    params.callback();
                }
                return;
            }

            function onSuccess(existingActions) {
                var actions = params.wsInfo.actions;

                if (existingActions && existingActions.length) {
                    var validActions = [];
                    for (var i = 0; i < actions.length; i++) {
                        var action = actions[i];
                        var isExist = false;
                        for (var j = 0; j < existingActions.length; j++) {
                            if (action.eventType === existingActions[j].event_type) {
                                isExist = true;
                                break;
                            }
                        }
                        if (!isExist) {
                            validActions.push(action);
                        }
                    }
                    actions = validActions;
                }
                if (actions && actions.length) {
                    var query = "INSERT INTO SfmWebServiceActionsLog (Id,record_type,sfm_process_id,event_type,process_type,action_time,method_name,call_type,sync_type) VALUES ('{{Id}}','{{record_type}}','{{sfm_process_id}}','{{event_type}}','{{process_type}}','{{action_time}}','{{method_name}}','{{call_type}}','{{sync_type}}')";
                    var queryArray = [];

                    for (var i = 0; i < actions.length; i++) {
                        var action = actions[i];

                        var queryParams = {
                            Id: params.wsInfo.recordId,
                            record_type: 'master',
                            sfm_process_id: params.wsInfo.processId,
                            process_type: params.wsInfo.processType,
                            event_type: action.eventType,
                            action_time: params.wsInfo.actionTime,
                            method_name: action.methodName,
                            call_type: action.callType,
                            sync_type: params.isSuccessive ? 'successive' : ''
                        };
                        queryArray.push(SVMX.string.substitute(query, queryParams));
                    }
                    if (queryArray.length) {
                        execQuery({queryArray: queryArray}).always(params.callback);
                    } else if (params.callback) {
                        params.callback();
                    }
                } else if (params.callback) {
                    params.callback();
                }
            }

            execQuery({
                query: "SELECT Id, event_type FROM SfmWebServiceActionsLog WHERE Id = '{{Id}}' AND sfm_process_id = '{{processId}}'",
                queryParams: {
                    Id: params.wsInfo.recordId,
                    processId: params.wsInfo.processId
                }
            }).always(onSuccess);
        },
        getSyncWebServiceData: function (params) {

            function getMetadata() {
                var d = $.Deferred();
                var className = "com.servicemax.client.offline.sal.model.sfmdelivery.operations.GetPageLayout";
                SVMX.create(className).performAsync(params, {
                    result: function (data) {
                        if (data) {
                            params.metadata = data;
                            d.resolve();
                        }
                    }
                });
                return d;
            }

            function getData() {
                var d = $.Deferred();
                var className = "com.servicemax.client.offline.sal.model.sfmdelivery.operations.GetPageData";
                SVMX.create(className).performAsync(params, {
                    result: function (data) {
                        if (data) {
                            params.data = data;
                            d.resolve();
                        }
                    }
                });
                return d;
            }

            function getTargetRecord() {
                var className = "com.servicemax.client.offline.sal.model.sfmdelivery.targetrecord.impl.SFMTargetRecord";
                var targetRecord = SVMX.create(className, params.data, params.metadata, params);
                var request = targetRecord.getRequest();
                request.stringMap = [
                    {key: "SVMX_processId", value: params.processId},
                    {key: "SVMX_recordId", value: params.recordId}
                ];
                return request;
            }

            function isTriggerable(data, excludeIds) {
                if (excludeIds && excludeIds.length) {
                    if (excludeIds.indexOf(data.pageDataSet.sobjectinfo.Id) >= 0) {
                        return false;
                    }
                    for (var i = 0, l = data.detailDataSet.length; i < l; i++) {
                        var dataSet = data.detailDataSet[i];
                        for (var j = 0, m = dataSet.pageDataSet.length; j < m; j++) {
                            if (excludeIds.indexOf(dataSet.pageDataSet[j].sobjectinfo.Id) >= 0) {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }

            return SVMX.when([getMetadata(), getData()]).then(function () {
                var triggerable = isTriggerable(params.data.__data, params.excludeIds);
                return {
                    triggerable: triggerable,
                    targetRecord: triggerable ? getTargetRecord() : null
                };
            });
        },
        parseSyncRecord: function (record) {
            var result = {
                Id: record.Id,
                parentId: record.parent_id,
                recordType: record.record_type,
                operation: record.operation,
                modifiedAt: record.modified_at,
                oldValues: record.old_values ? JSON.parse(record.old_values) : null,
                newValues: record.new_values ? JSON.parse(record.new_values) : null,
                objectName: record.object_name,
                changeType: record.change_type
            };
            return result;
        }
    });

    /******************************************************
     * @class com.servicemax.client.offline.sal.model.utils.Cache
     * @extends com.servicemax.client.lib.api.Object
     * @description Manages a Javascript cache and a DB Cache
     * <br/><br/>
     * JAVASCRIPT CACHE: To use the javascript cache, a cache needs to be registered
     * Its safe to repeatedly reregister the same cache -- this
     * will do nothing if its already registered.
     * <br/><br/>
     * CACHE SIZE: Each cache has a size limit that it will not grow beyond.  The cache
     * manages which items to pop off the cache by removing the least recently accessed item.
     * This means that any access to an item on cache will move it top of the array;
     * last to be removed.
     * <br/><br/>
     *
     * DB CACHE: Read/writes to your database cache
     * @example
     * // sets up a cache of the given name, and limits the number of items it will store
     * registerJSCache(cacheName, cacheSize)
     *
     * // Looks up the specified key in the specified cache.  If found, flags it as the most recently used item in cache
     * getFromJSFache(cacheName, inKey);
     *
     * // Stores the specified key/value pair in cache as the most recent item
     * writeToJSCache(cacheName, inKey, inValue)
     *
     * writeToDBCache(key, value, function() {}, context)
     *
     * readFromDBCache(key, function(inData) {}, context)
     *
     * // Also provides some convenience methods for reading/writing objects
     * readObjectFromDBCache(key, function(inData) {}, context)
     *
     * writeObjectToDBCache(key, value, function() {}, context)
     * @todo Need a mechanism for clearing cache
     */
    utils.Class("Cache", com.servicemax.client.lib.api.Object, {}, {
        __jscache: {},
        __configSyncSetup: false,

        resetAllJSCaches: function() {
           SVMX.forEachProperty(this.__jscache, function(inKey, inValue) {
                inValue.items = [];
            }, this);
        },

        /**
         * Before you can use a JS Cache you must register its name and maximum size
         * @method
         * @param {string} cacheName The name of your cache that you will use when accessing the cache
         * @param {number} limit The size of the cache after which the least recently accessed entry will be dropped
         * @returns {null}
         * @description something to say
         */
        registerJSCache : function(cacheName, limit) {
            if (cacheName in this.__jscache) return;
            this.__jscache[cacheName] = {limit: limit, items: []};
            if (!this.__configSyncSetup) this.__setupConfigSyncHandler();
        },

        clearJSCache : function(cacheName) {
            var items = this.__getJSCacheItems(cacheName);
            if (items) items.length = 0; // I don't like this way of emptying an array, but it insures that the items pointer isn't changed
        },

        readFromJSCache : function(cacheName, objectName) {
            this.__flagJSCache(cacheName, objectName); // WARNING: This changes the order, and therefore the value of index
            var cacheItems = this.__getJSCacheItems(cacheName);
            var index = SVMX.array.indexOf(cacheItems, function(inItem) {
                return inItem.name === objectName;
            });
            if (index !== -1) {
                var result =  cacheItems[index].value;
                if (cacheItems[index].isObject) result = SVMX.toObject(result);
                return result;
            }
        },
        __flagJSCache : function(cacheName, objectName) {
            var cacheItems = this.__getJSCacheItems(cacheName);
            var match = SVMX.array.filter(cacheItems, function(inItem) {
                return inItem.name === objectName;
            })[0];
            if (match) {
                SVMX.array.remove(cacheItems, match);
                cacheItems.push({name: objectName, value: match.value, isObject: match.isObject});
            }
        },
        writeToJSCache : function(cacheName, objectName, objectValue) {
            var cacheItems = this.__getJSCacheItems(cacheName);
            this.removeFromJSCache(cacheName, objectName);

            // We store objects as strings so that the when the value is cached, it can't be further modified by the caller
            // and when the object is retrieved and modified, the value in cache is still unaffected
            var isObject = typeof objectValue == "object";
            cacheItems.push({name: objectName, value: isObject ? SVMX.toJSON(objectValue) : objectValue, isObject: isObject});
            this.__limitJSCacheSize(cacheName);
        },
        removeFromJSCache : function(cacheName, objectName) {
            var cacheItems = this.__getJSCacheItems(cacheName);
            var index = SVMX.array.indexOf(cacheItems, function(inItem) {return inItem.name === objectName;});
            if (index != -1) SVMX.array.removeElementAt(cacheItems, index);
        },
        __limitJSCacheSize : function(cacheName) {
            var cacheObj = this.__jscache[cacheName];
            if (!cacheObj) {
                return;
            }
            var limit = cacheObj.limit;
            while (cacheObj.items.length > limit) cacheObj.items.shift();
        },

        // TODO: Should error be thrown for invalid cache access or just log the error?
        __getJSCacheItems : function(cacheName) {
            var cache = this.__jscache[cacheName];
            if (!cache) {
                logger.error("ERROR: Cache " + cacheName + " not found");
                return [];
            }
            return cache.items;
        },

        __setupConfigSyncHandler : function() {
            this.__configSyncSetup = true;
            var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
            this.__syncManager = servDef.getInstance();
            this.__syncManager.bind("SYNC_COMPLETED", function(evt){
                if (this.__syncManager.getSyncType() == "INITIAL" || this.__syncManager.getSyncType() == "CONFIG") {
                    this.resetAllJSCaches();
                    execQuery({query: "DELETE FROM ClientCache WHERE key like 'PURGE_ON_CONFIG_SYNC.%'"});
                }
            }, this);

        },

        /**
         * PUBLIC METHOD deleteFromDBCache
         * @description Deletes a key from the DB cache
         */
         deleteFromDBCache : function(key, callback, context) {
           var me = this, q = SVMX.string.substitute("delete from ClientCache where key='{{key}}'",{key : key});
           me.__executeQuery(q, function(){
               if(callback){
                   callback.call(context);
               }
           });
         },


        /**
         * PUBLIC METHOD writeObjectToCache
         * @description
         * TODO: Need method to invalidate cache.  Also recommend having an owner field:
         * writeObjectToChache("DescribeObject", "SVMXC__Service_Order__c", f, this);
         * Now we can find just do invalidateCache("DescribeObject");
         */
        writeObjectToDBCache : function(key, value, callback, context){
            value = SVMX.toJSON(value);
            this.writeToDBCache(key, value, callback, context);
        },

        writeToDBCache : function(key, value, callback, context){
            var me = this, q = SVMX.string.substitute(
                    "delete from ClientCache where key='{{key}}'",{key : key});
            me.__executeQuery(q, function(){

                if(typeof(value) == 'string'){
                    // escape sql special characters
                    var re = new RegExp("'", 'gi');
                    value = value.replace(re, "''");
                }

                q = SVMX.string.substitute("insert or replace into ClientCache values( '{{key}}', '{{value}}')",
                        {key : key, value : value});

                me.__executeQuery(q, function(){
                    if(callback){
                        callback.call(context);
                    }
                });
            });
        },

        readObjectFromDBCache : function(key, callback, context){
            var d = this.readFromDBCache(key);
            var d2 = new $.Deferred();
            d.then(
                function(resp){
                    resp = SVMX.toObject(resp);
                    if (callback) callback.call(context, resp);
                    d2.resolve(resp);

                },
                function() {
                    if (callback) callback.call(context, null);
                    d2.resolve(null);
                }
            );
            return d2;
        },

        readFromDBCache : function(key, callback, context){
            var d = new $.Deferred();
            var me = this, q = SVMX.string.substitute(
                    "select value from ClientCache where key='{{key}}' limit 1",{key : key});
            me.__executeQuery(q, function(resp){
                var ret = null;
                if(resp && resp.length > 0){
                    ret = resp[0].value;
                }
                if (callback) callback.call(context, ret);
                d.resolve(ret);
            });
            return d;
        },

        __syncDbData: {},
        /**
         * Read an entry from the SynchronousCache which provides fast access to cached data.
         *
         * @public
         * @method
         * @param {string} cacheName The name of your cache; the name is an arbitrary string such as "UserPreferences"
         * @param {string} key The key to use to lookup this cached data
         * @description Reads from the SynchronousCache database in a synchronous manner.  It does this
         * by preloading all data from this database into javascript.  All reads are done
         * from the javascript hash; all writes go to both javascript and database.
         * As all data is loaded into javascript memory, only small items should be stored this way,
         * and this should not be used for data that will constantly accumulate over time.<br/><br/>
         * <b>NOTE</b>: Object data will be returns as a string in all cases.
         *
         * @example
         * var utils = com.servicemax.client.offline.sal.model.utils;
         * var preferredWidth = utils.Cache.readFromSyncrhonousDBCache("UserPreferences", "PreferredWidth");
         */
        readFromSynchronousDBCache : function(cacheName, key) {
            var cache = this.__syncDbData[cacheName];
            if (cache) {
                var value = cache[key];
                if (value) {
                    if (value.isObject) return SVMX.toObject(value.value);
                    else return value.value;
                } else {
                    return undefined;
                }
            }
            logger.error("MINOR ERROR: Sync Cache " + cacheName + " does not exist");
        },

        /**
         * Read an entry from the SynchronousCache which provides fast access to cached data.
         *
         * @public
         * @method
         * @param {string} cacheName The name of your cache; the name is an arbitrary string such as "UserPreferences"
         * @param {string} key The key to use to lookup this cached data
         * @param {any} value The value to write into the cache.
         * @description Writes to the SynchronousCache database and to a javascript cache of that database.  It does this
         * As all data is loaded into javascript memory, only small items should be stored this way,
         * and this should not be used for data that will constantly accumulate over time.
         * Objects will be converted to JSON; Callers of the read operations will need to convert it back.
         *
         * @example
         * var utils = com.servicemax.client.offline.sal.model.utils;
         * var preferredWidth = utils.Cache.writeToSyncrhonousDBCache("UserPreferences", "PreferredWidth", "500px");
         */
        writeToSynchronousDBCache : function(cacheName, key, value) {
            var isObject = value && typeof value == "object";
            if (value && typeof value == "object") value = SVMX.toJSON(value);
            if (value === null || value === undefined) value = "";
            var cache = this.__syncDbData[cacheName];
            if (!cache) cache = this.__syncDbData[cacheName] = {};
            cache[key] = {value: value, isObject: isObject};

            // Note: Delete sql fails if we quote the field names
            this.__executeQuery(
                SVMX.string.substitute( "DELETE FROM 'SynchronousCache' WHERE cache_key='{{key}}' AND cache_name='{{cache_name}}';" +
                                        "INSERT INTO 'SynchronousCache' ('cache_key', 'cache_name', 'cache_value', is_object) VALUES ('{{key}}', '{{cache_name}}', '{{value}}', {{is_object}})",
                                        {
                                            key: key,
                                            cache_name: cacheName,
                                            value: String(value).replace(new RegExp("'", "g"), "''"),
                                            is_object : isObject ? 1 : 0
                                        }
                                    )
            );
        },

        /**
         * Load all data from database into the Syncrhonous Cache.
         *
         * @method
         * @private
         * @description Load all data from database into the Syncrhonous Cache. Run as an onLoadFramework Extension
         */
        initializeSynchronousDbCache : function() {
            var deferred = new $.Deferred();
            var caches = this.__syncDbData = {};
            this.__executeQuery("SELECT * FROM 'SynchronousCache'", SVMX.proxy(this, function(data) {
                for (var i = 0; i < data.length; i++) {
                    var d = data[i];
                    if (!caches[d.cache_name]) caches[d.cache_name] = {};
                    caches[d.cache_name][d.cache_key] = {value: d.cache_value, isObject: d.is_object && d.is_object !== "0"};
                }
                deferred.resolve();
            }));
            return deferred;
        },
        __executeQuery : function(query, callback){

            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var request = nativeService.createSQLRequest();

            request.bind("REQUEST_COMPLETED", function(evt){
              if (callback) callback(evt.data.data);
            }, this);

            request.bind("REQUEST_ERROR", function(evt){
              logger.error(evt.data);
              if (callback) callback(false);
            }, this);

            request.execute({query : query, async : false });
        }
    });

    utils.Class("SynchronousDbExtension", com.servicemax.client.lib.api.AbstractExtension, {
        perform : function(caller){
            return utils.Cache.initializeSynchronousDbCache();
        }
    });

    /*
     * 1. getUserInfo: Retrieves the UserInfo data from DB or cache
     * getUserInfo()
     * 2. getDisplayTags: Retrieves all localization tags
     * getDisplayTags({onSuccess: function(tags) {}, onError: function(inError){}})
     * 3. getUserContextMenuAuthorization: Retrieves the authorization flag for the LM API key
     * getUserContextMenuAuthorization({onSuccess: function(tags) {}, onError: function(inError){}})
     *
     */
    utils.Class("SystemData", com.servicemax.client.lib.api.Object, {}, {
        /**
         * PUBLIC METHOD getUserInfo
         * @description
         *    Retrieves the UserInfo data
         *
         *
         * @returns {Object} UserInfo data
         *
         */
        __userInfoCache: null,
        __userInfoPendingEvents: [],

        /*
         * TODO: waiting for the data structure from the user content to be updated
         */
        getUserInfo : function(inParams) {
            return SVMX.getCurrentApplication().getUserInfo();
        },

        /**
         * executes query into MobileDeviceSettings to get "Allow API Access" flag
         */
        getUserContextMenuAuthorization: function(params) {
            var request = nativeService.createSQLRequest();
            var sql = "SELECT value as api_key FROM MobileDeviceSettings WHERE setting_id = '{{fieldName}}'";

            request.bind("REQUEST_COMPLETED", SVMX.proxy(this, "__getUserContextMenuAuthorizationSuccess", params));
            request.bind("REQUEST_ERROR", SVMX.proxy(this, "__getUserContextMenuAuthorizationError", params));

            request.execute({
                query: sql,
                queryParams: {
                    fieldName: params.apiAccessFieldName
                }
            });
        },

        /*
         * On success, return a boolean of true or false
         *
         */
        __getUserContextMenuAuthorizationSuccess : function(params, event) {
            var request = event.data;
            var status = false;

            if (request.success) {
                if (!!request.data[0]) {
                    status = (request.data[0].api_key === "true");
                }
            }

            params.onSuccess(status);
        },

        /*
         * On error, log a warning, non fatal, execute the error callback
         *
         */
        __getUserContextMenuAuthorizationError : function(params, event) {
            logger.warn("getUserContextMenuAuthorization Failed; typically happens in initial sync when settings table isn't present yet");
            params.onError(params);
            //logger.error("getDisplayTags Failed: " + evt.data.parameters.query + "; " + evt.data.data);
        },

        /**
         * PUBLIC METHOD getDisplayTags
         * @description
         *    Retrieves the Display Tags (localization) data
         *
         * @param {Object} inParams
         *    {Function} [onSuccess] Function to call when results are available
         *    {Function} [onError] Function to call when error is thrown
         * @returns undefined
         *
         */
        __displayTagsCache : {},
        getDisplayTags : function(inParams) {

            var translationService = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.translation").getInstance();
            if (!translationService.isEmpty()) {
                inParams.onSuccess(translationService);
                return;
            }
            if (utils.MetaData.isTableInDatabase("MobileDeviceTags")) {
                execQuery({
                    query: "SELECT tag_id, value, module_id FROM MobileDeviceTags"
                }).then(
                    SVMX.proxy(this, function(data) {

                        translationService.setData(data);

                        inParams.onSuccess(translationService);
                    }),
                    SVMX.proxy(this, function(error) {
                        logger.error("getDisplayTags failed:" + error);
                        if (inParams.onError) inParams.onError(translationService);
                    })
                );
            } else {
                inParams.onSuccess(translationService);
            }
        }
    });


    utils.Class("Expressions", com.servicemax.client.lib.api.Object, {}, {

        /**
         * PUBLIC METHOD evaluate & loadExpressionIntoCache
         * @description
         *    Retrieves the expressions and evaluates them against the data
         *
         * @param {Object} inParams
         *      @param {salesforceId} expressionId; ID of the expression we want evaluated
         *      @param {[Object]} [data]  Typically an array of sobjectinfo; preferred over recordId
         *      @param {salesforceRef} [recordId] Use this if you haven't yet loaded your record data
         *      @param {boolean} returnMessage Use this if you want a response of [{result: true/false, message: "error_message"}] instead of [true/false]
         *      @param {Function} [onSuccess] Called as onSuccess(result); where result is an array of boolean
         *      @param {Function} [onError] Function to call when error is thrown
         * @returns undefined
         * @description For each element of data, will execute it against the specified expression id, and return an
         *              array of booleans, one for each element in the data array.
         */

        loadExpressionIntoCache : function(inParams) {
           utils.Cache.registerJSCache("Expressions", 15);
            var cache = utils.Cache.readFromJSCache("Expressions", inParams.expressionId);
            if (cache) {
                if (inParams.onSuccess) inParams.onSuccess(cache);
                return;
            }
            var request = nativeService.createSQLRequest();
            if (inParams.onSuccess) {
                request.bind("REQUEST_COMPLETED", SVMX.proxy(this, function(evt) {
                    var data = getDataFromEvt(evt);
                    if (!data.length) {
                        evt.data.data = "No expressions found in DB for " + inParams.expressionId;
                        return inParams.onError(evt);
                    }

                    utils.Cache.writeToJSCache("Expressions", inParams.expressionId, data);
                    inParams.onSuccess();
                }));
            }
            if (inParams.onError) {
                request.bind("REQUEST_ERROR", inParams.onError);
            }
            request.execute({
                query:  "SELECT * FROM SFExpression " +
                        "LEFT JOIN SFExpressionComponent ON " +
                        "SFExpressionComponent.expression_id = SFExpression.expression_id " +
                        "WHERE SFExpression.expression_id='{{expression_id}}' GROUP BY sequence ORDER BY CAST(sequence AS INTEGER)",
                queryParams: {expression_id: inParams.expressionId}
            });

        },
        evaluate : function(inParams) {
            if (inParams.recordId) {
                var getRecordDeferred = utils.Data.getRecord({
                    Id: inParams.recordId
                });
                getRecordDeferred.done(SVMX.proxy(this, function(inRecord) {
                    delete inParams.recordId;
                    inParams.data = inRecord;
                    this.evaluate(inParams);
                }));
                getRecordDeferred.fail(inParams.onError);
                return;
            }

            if (!inParams.expressionId && inParams.processId) {
                utils.MetaData.getExpressionIdFromProcessId({
                    processId: inParams.processId,
                    onSuccess: SVMX.proxy(this, function(inId) {
                        inParams.expressionId = inId;
                        // all data passes is there isn't an expression to fail it.
                        if (!inParams.expressionId) {
                            var count = inParams.data instanceof Array ? inParams.data.length : 1;
                            var result = [];
                            for (var i = 0; i < count; i++) result.push(inParams.returnMessage ? {result:true} : true);

                            return inParams.onSuccess(result);
                        } else {
                            this.evaluate(inParams);
                        }
                    }),
                    onError: inParams.onError
                });
                return;
            }

            if (!inParams.expressionId) {
                logger.error("Expression evaluate with no expressionId or valid processId failed");
            }

            // Just in case any of the expressions use RecordTypeId:
            utils.MetaData.describeObject({
                objectName: inParams.data instanceof Array ? inParams.data[0] && inParams.data[0].attributes.type : inParams.data && inParams.data.attributes.type,
                onSuccess: SVMX.proxy(this, function(describeObjectData) {
                    inParams.recordTypeInfos = describeObjectData.recordTypeInfos;
                    this.loadExpressionIntoCache({
                        expressionId: inParams.expressionId,
                        onSuccess: SVMX.proxy(this, "__onGetExpressionsSuccess", inParams),
                        onError: SVMX.proxy(this, "__onGetExpressionsError", inParams)
                    });
                }),
                onError: SVMX.proxy(this, function(evt) {
                    this.__onGetExpressionsError(inParams);
                })
            });
        },

         __onGetExpressionsSuccess : function(inParams) {
            var expressions = utils.Cache.readFromJSCache("Expressions", inParams.expressionId);
            var results = [];
            if(inParams.data instanceof Array){
                 for (var i = 0; i < inParams.data.length; i++) {
                    results.push(this.__evaluateExpressions(inParams.data[i], expressions, inParams.recordTypeInfos, inParams.returnMessage));
                }
            }else{
                results.push(this.__evaluateExpressions(inParams.data, expressions, inParams.recordTypeInfos, inParams.returnMessage));
            }
            inParams.onSuccess(results);
        },

        __onGetExpressionsError : function(inParams, evt) {
            evt = evt || { data: { data : [] , parameters: { query: '' } } };
            logger.error("evaluateExpressions Failed to find Expression: " + evt.data.parameters.query+ "; " + evt.data.data);
            inParams.onSuccess([{ result: false }]);
        },

        __evaluateExpressions : function(inData, inExprs, recordTypeInfos, returnMessage) {
            var exprs = [], data, v;

            // Both forms of getting data provide us with a local object that can be modified without side-effect.
            if (inData instanceof utils.Record) {
                // TODO: Once we have a proper Record class and no more of this fieldvalue: {key/value}
                // we should get rid of this
                data = inData.getRawValues();
            } else {
                data = {};
                for (var key in inData) {
                    if (inData.hasOwnProperty(key)) {
                        v = inData[key];
                        if (v && typeof v === "object" && "fieldvalue" in v) {
                            data[key] = v.fieldvalue.value;
                        } else {
                            data[key] = v;
                        }
                    }
                }
            }

            // If we have a record name rather than a record id, this will convert it to a record type.
            // this happens when using the getRawValues call above.  If its already a salesforceid,
            // this code will do nothing.  There are cases where we end up with only the salesforce id,
            // so just normalize to that case.
            if (data.RecordTypeId && recordTypeInfos) {
                var match = SVMX.array.get(recordTypeInfos, function(recordType) {return recordType.name == data.RecordTypeId;});
                if (match) data.RecordTypeId = match.recordTypeId;
            }

            // At this point, any RecordTypeId should be a salesforce id that can be looked up in our recordType
            // hash.
            if (data.RecordTypeId) {
                var recordTypeId = utils.MetaData.getRecordTypeNameFromId(data.RecordTypeId);
                if (recordTypeId) data.RecordTypeId = recordTypeId;
            }

            for (var i = 0; i < inExprs.length; i++) {
                exprs.push(this.__generateExpression(inExprs[i]));
            }

            var results = SVMX.executeExpressions(exprs, data);
            if(results !== undefined && results !== null) {
                results = SVMX.array.map(results, function(value) { return SVMX.executeExpressionsResultInvalid(value) ? false : value;});
            }
            var advancedExpr = inExprs[0].advance_expression;
            var errorMessage = inExprs[0].error_message;
            var evalResults = false, isError = false;
            if (!results || results.length === 0) {
                isError = true;
            } else if (!advancedExpr || advancedExpr === "1") {
                evalResults = SVMX.array.every(results, function(inResult) {return inResult;});
            } else {
                try {
                    // Replace OR with " || ", AND with " && " and all numbers with values from
                    // the results array
                    advancedExpr = advancedExpr.replace(/OR/ig, "||")
                                               .replace(/AND/ig,"&&")
                                               .replace(/NOT\s*/ig, "!")
                                               .replace(/\d+/g, function(inValue) {return results[inValue-1]});
                    evalResults = eval(advancedExpr);
                } catch(e) {
                    SVMX.getLoggingService().getLogger("offline.sal.model.getExpressions").error("EXPR:" + advancedExpr + " fails to compile to javascript");
                    isError = true;
                }
            }
            return returnMessage ? {result: evalResults, message: errorMessage} : evalResults;
        },
        /* Generate an expression from the expr object
         * TODO: Handle globals in the value field such as "SVMX.CURRENTUSER"
         */
        __generateExpression : function(inExprObj) {
            var operand1, operand2, operator;

            switch(inExprObj.field_type.toLowerCase()) {
                case "int":
                case "currency":
                case "double":
                case "percent":
                    operand1 = "Number(" + inExprObj.source_field_name + ")";
                    break;
                case "datetime":
                    //First assume we just want date without time. Easier to do this once and change back if we are comparing now.
                    //Need to convert GMT to user's timezone
                    operand1 = "$DATE( (" + inExprObj.source_field_name + ") ? com.servicemax.client.lib.datetimeutils.DatetimeUtil.convertToTimezone(" + inExprObj.source_field_name  +", com.servicemax.client.lib.datetimeutils.DatetimeUtil._timeZone, false).substring(0, 10) : null)";
                    break;
                case "date":
                    operand1 = "$DATE(" + inExprObj.source_field_name + ")";
                    break;
                default:
                    operand1 = inExprObj.source_field_name;
            }

            switch(inExprObj.field_type.toLowerCase()) {
                case "datetime":
                case "date":
                    if (inExprObj.value && inExprObj.value.toLowerCase() == "yesterday") {
                        operand2 = "$DATEYESTERDAY()";
                    } else if (inExprObj.value && inExprObj.value.toLowerCase() == "today") {
                        operand2 = "$DATETODAY()";
                    } else if (inExprObj.value && inExprObj.value.toLowerCase() == "tomorrow") {
                        operand2 = "$DATETOMORROW()";
                    } else if (inExprObj.value == "now") {
                        operand1 = "$DATE(" + inExprObj.source_field_name + ")";
                        operand2 = "$DATENOW()"; //For DateTime in GMT
                    } else {
                        operand2 = "$DATE('" + inExprObj.value + "')";
                    }
                    break;
                case "int":
                case "currency":
                case "double":
                case "percent":
                    operand2 = "Number(" + inExprObj.value + ")";
                    break;
                default:
                    if (inExprObj.value === undefined || inExprObj.value === null) {
                        operand2 = "null";
                    } else {
                        operand2 = '"' +  inExprObj.value.replace(/('|")/g, "\\$1") + '"';
                    }
            }

            // Special null expressions
            if (operator === "ISNULL" || operator === "ISNOTNULL") {
                operand1 = inExprObj.source_field_name;
            }

            var operationMap = {"NOTCONTAIN": "NOTCONTAINS"}; // rename some of our operations to match our expression engine.
            operator = inExprObj.operator.toUpperCase();
            operator = operationMap[operator] || operator;
            // Special date handling
            if ((operator !== "ISNULL" && operator !== "ISNOTNULL") && (inExprObj.field_type.toLowerCase() === "date" || inExprObj.field_type.toLowerCase() === "datetime")) {
                operator = "$DATE"+ operator;
            } else {
                operator = "$" + operator;
            }

            return operator + "(" + operand1 + "," + operand2 + ")";
        }

    });

    /*
     *
     * All attachments methods goes here.
     */

    utils.Class("Attachments", com.servicemax.client.lib.api.Object, {}, {

       copyAttachmentIntoDownloads: function(fileLocation, callback) {
            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var nativeRequest = nativeService.createFileRequest();

            var targetFile = this.getTargetFileName(fileLocation);

            var params = {
                file: fileLocation,
                operation: "COPY",
                targetPath: "{UploadDirectory}",
                targetFile: targetFile
            };

            nativeRequest.bind("REQUEST_COMPLETED", function(evt) {
                //append target name with time stamp before extension
                var result = {
                    success: evt.data.success,
                    targetPath: evt.data.parameters.targetPath,
                    targetFileName: evt.data.parameters.targetFile
                };
                callback(result);
            });

            nativeRequest.execute(params);
        },

       copyAttachmentIntoUploads: function(fileLocation, callback) {
            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var nativeRequest = nativeService.createFileRequest();

            var targetFile = this.getTargetFileName(fileLocation);

            var params = {
                file: fileLocation,
                operation: "COPY",
                targetPath: "{DownloadDirectory}",
                targetFile: targetFile
            };

            nativeRequest.bind("REQUEST_COMPLETED", function(evt) {
                var result = {
                    success: evt.data.success,
                    targetPath: evt.data.parameters.targetPath,
                    targetFileName: evt.data.parameters.targetFile
                };
                callback(result);
            });

            nativeRequest.execute(params);
        },

        getTargetFileName: function(filePath) {
            var targetFileName = "";
            if (filePath.indexOf("\\") > -1) {
                targetFileName = filePath.split("\\").pop();
            } else if (filePath.indexOf("/") > -1) {
                targetFileName = filePath.split("/").pop();
            }

            var ind = targetFileName.lastIndexOf("."),
                extension = targetFileName.substring(ind, targetFileName.length);
            //Append time stamp to the filename
            targetFileName = targetFileName.substring(0, ind) + new Date().getTime() + extension;

            return targetFileName;
        }

    });

    /**
     * Database logging target. logs to the database.
     *
     * @class           com.servicemax.client.lib.services.DBLogTarget
     * @extends         com.servicemax.client.lib.services.AbstractLogTarget
     *
     */
    utils.Class("DBLogTarget", com.servicemax.client.lib.services.AbstractLogTarget, {
        isDefaultTarget: false,
        defaultLogLevel: "DEBUG",
        tableName: "UserLog",
        __constructor: function(options) {
            this.tableName = options.tableName;
            this.__base(options);
        },

        log: function(message, options) {
            var query = "";
            if (!utils.MetaData.isTableInDatabase(this.tableName)) {

                query += SVMX.string.substitute("CREATE TABLE '{{table_name}}'( source varchar, level varchar, text varchar,  json varchar,  created_at varchar);", {
                    table_name: this.tableName
                });
                utils.MetaData.registerNewTableInDatabase(this.tableName);
            }

            var type = options.type;
            if (message instanceof Error) {
                message = message.stack ? message.stack.toString() : message.toString();
            }

            query += SVMX.string.substitute("INSERT INTO '{{table_name}}' (source, level, text, json, created_at) VALUES ('{{source}}', '{{level}}', '{{text}}', '{{json}}', '{{created_at}}')", {
                table_name: this.tableName,
                source: options.source,
                level: type,
                text: message,
                json: "",
                created_at: options.timeStamp
            });
            execQuery({
                query: query
            });
        }
    }, {});
    SVMX.getLoggingService().generateMissingLogTargets();
};
})();
