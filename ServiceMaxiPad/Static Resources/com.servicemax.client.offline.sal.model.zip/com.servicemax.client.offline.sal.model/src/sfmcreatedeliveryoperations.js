/**
 * This file needs a description
 * @class com.servicemax.client.offline.sal.model.sfmcreatedelivery.operations
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){
	var sfmcreateOps = SVMX.Package("com.servicemax.client.offline.sal.model.sfmcreatedelivery.operations");

sfmcreateOps.init = function(){

	// imports
	var utils = com.servicemax.client.offline.sal.model.utils.Utilities;
	var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
	// end imports

	// constants
	var CACHE_KEY = "CREATE_RECENT_ITEMS";
	// end constants

	sfmcreateOps.Class("GetCreateProcessInfo", com.servicemax.client.mvc.api.Operation, {

		__constructor : function(){ this.__base(); },

		performAsync : function(request, responder) {
			SVMX.doLater(function(){
				var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmcreateutils.Utils");
					utils.getCreateProcessInfo({}, function(resp){
					responder.result(resp);
				}, this);
			});
		}

	}, {});

	sfmcreateOps.Class("GetRecentsInfo", com.servicemax.client.mvc.api.Operation, {

		__constructor : function(){ this.__base(); },

		performAsync : function(request, responder) {
			SVMX.doLater(function(){
				utils.readObjectFromCache(CACHE_KEY, function(resp){
					if(!resp) resp = [];
					responder.result(resp);
				}, this);
			});
		}

	}, {});



	sfmcreateOps.Class("AddToRecents", com.servicemax.client.mvc.api.Operation, {

		__constructor : function(){ this.__base(); },

		performAsync : function(request, responder) {

			SVMX.doLater(function(){

				utils.readObjectFromCache(CACHE_KEY, function(resp){
					if(!resp) resp = [];

					var i, l = resp.length, found = false, item = request.item;
					for(i = 0; i < l; i++){
						if(item.id == resp[i].id){
							found = true;
							break;
						}
					}

					if(!found){
						resp.splice(0, 0, item);
					}else{
						var removed = resp.splice(i, 1);
						resp.splice(0, 0, item);
					}

					utils.writeObjectToCache(CACHE_KEY, resp, function(){}, this);
					responder.result({});
				}, this);
			});
		}

	}, {});

    sfmcreateOps.Class("GetProcessId", com.servicemax.client.mvc.api.Operation, {
       __constructor : function() {
           this.__base();
       },

       /**
        *
        * @param    {Object}    request         data request object
        * @param    {Object}    responder       responder object
        */
        performAsync : function(request, responder) {
            var record = request.record;
            var id = record.data.id;

            var query = "SELECT process_unique_id FROM SFProcess WHERE process_id ='" + id+ "';";
            this.__executeQuery(query, function(result) {
                responder(result);
            })
        },


        __executeQuery : function(query, binds, callback){

            if(typeof binds === "function"){
                callback = binds;
                binds = {};
            }

            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var request = nativeService.createSQLRequest();

            request.bind("REQUEST_COMPLETED", function(evt){
                callback.call(this, SVMX.toObject(evt.data.data)[0].process_unique_id);
            }, this);

            request.bind("REQUEST_ERROR", function(evt){
                SVMX.getLoggingService().getLogger("__getRealProcessId Failed" + evt.data.data);
                callback.call(this, false);
            }, this);

            request.execute({query : query, async : true, queryBinds: binds });
        }
    });

};
})();
