/**
 * This file needs a description
 * @class com.servicemax.client.offline.sal.model.sfmcreateutils
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){
    var utilsImpl = SVMX.Package("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils");

utilsImpl.init = function(){
  var DatetimeUtils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
  var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
  var OfflineMetaUtils  = com.servicemax.client.offline.sal.model.utils.MetaData;
  var OfflineDataUtils  = com.servicemax.client.offline.sal.model.utils.Data;
  var OfflineAttachmentsUtils  = com.servicemax.client.offline.sal.model.utils.Attachments;
  var OfflineCacheUtils = com.servicemax.client.offline.sal.model.utils.Cache;
  var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("SFMSEARCH");
  var TSIPAD = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("IPAD");
  var fields = '';
  var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
  var SyncUtils = com.servicemax.client.offline.sal.model.utils.SyncData;
  var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils");

  function execQuery(inParams) {
      var d = $.Deferred();
      var req = nativeService.createSQLRequest();
      req.bind("REQUEST_COMPLETED", function(evt) {
          d.resolve(evt.data.data);
      });
      req.bind("REQUEST_ERROR", function(evt) {
          d.reject(evt.data.data);
      });

      req.execute({
          query: inParams.query,
          queryParams: inParams.queryParams
      });
      return d;
  }

  utilsImpl.Class("Utils", com.servicemax.client.lib.api.Object, {

    __templateData : {}, __specialFieldsData : {}, __expressionsInfo : null, __sortingOptions : null,
    __constructor : function(){

    },

    getUserInfo : function(params, callback, context){
        var userInfo  = OfflineSystemUtils.getUserInfo();
        var tomorrow  = DatetimeUtils.macroDrivenDatetime("Tomorrow", userInfo.DateFormat, userInfo.TimeFormat, "date");
        var yesterday = DatetimeUtils.macroDrivenDatetime("Yesterday", userInfo.DateFormat, userInfo.TimeFormat, "date");
        var today     = DatetimeUtils.macroDrivenDatetime("Today", userInfo.DateFormat, userInfo.TimeFormat, "date");
        //var now       = DatetimeUtils.macroDrivenDatetime("Now", userInfo.DateFormat, userInfo.TimeFormat);
        var now = DatetimeUtils.getFormattedDatetime(DatetimeUtils.getCurrentDatetime(DatetimeUtils.getSaveFormat('dateTime')), userInfo.DateFormat+' '+userInfo.TimeFormat );

        userInfo.Yesterday = yesterday;
        userInfo.Tomorrow = tomorrow;
        userInfo.Today = today;
        userInfo.Now = now;
        userInfo.DateFormat = userInfo.DateFormat;
        userInfo.TimeFormat = userInfo.TimeFormat;
        userInfo.Locale = userInfo.Language;
        userInfo.amText = "AM";
        userInfo.pmText = "PM";

        return userInfo;
    },

    getTemplate : function(params, callback){
        //fetch doc_template_id from params.processId
        var fileLocation = "", template = '', me = this, opTemplate;
        this.__getDocTemplateId(params.ProcessId, "", function(result){
            var docTemplateId = result.docTemplateId;
            if(docTemplateId){
              setTimeout(function(){
                  me.__getTemplateLocation(docTemplateId, function(attr) {
                      if(attr){
                          fileLocation = attr.filePath.replace(/\//g, "\\\\");
                          //fileLocation = "{DownloadDirectory}\\00PJ00000015pCMMAY_SFM_Doc_Template.html";
                          setTimeout(function(){
                              me.__readTemplate(fileLocation, function(resp){
                                  if(resp){
                                      callback(resp);
                                  }else{
                                      console.error("Read template failed for process.id: " + params.ProcessId);
                                      callback(false);
                                  }
                              });
                          },100);
                      } else {
                console.error("Unable to retrieve o/p doc template  file path for process.id: " + params.ProcessId);
                callback(false);
              }
                  });
              },100);
          } else {
              console.error("Unable to retrieve o/p doc template for process.id: " + params.ProcessId);
              callback(false);
          }
        });
    },

    __getDocTemplateId : function(processId, recordId, callback){
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
        var request = nativeService.createSQLRequest();

        request.bind("REQUEST_COMPLETED", function(evt) {
            var data = evt.data.data;
            if(data && data.length){
                var result =  {docTemplateId : SVMX.toObject(data)[0].doc_template_id , recordId : recordId, sfProcessId : SVMX.toObject(data)[0].process_id } ;
                callback(result);
            }
        }, this);

        request.bind("REQUEST_ERROR", function(evt) {
            logger.error(" __getDocTemplateId Failed. Error : " + evt.data.data);
            callback(false);
        });

        request.execute({
            query : "SELECT process_id, doc_template_id FROM SFProcess WHERE process_unique_id = '{{process_id}}'",
            queryParams : {
                process_id : processId
            },
            async : true
        });
    },

    //get the template location. It will typically be stored in the DownloadDirectory
    __getTemplateLocation : function(docTemplateId, callback) {
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
        var request = nativeService.createSQLRequest();

        request.bind("REQUEST_COMPLETED", function(evt) {
            var data = evt.data.data;
            var result = (data && data.length) ? {
                filePath : SVMX.toObject(data)[0].file_path
            } : null;
            callback(result);
        }, this);

        request.bind("REQUEST_ERROR", function(evt) {
            logger.error(" __getTemplateLocation Failed. Error : " + evt.data.data);
            callback(false);
        });

        request.execute({
            query : "SELECT file_path FROM SFAttachments WHERE parent_id = '{{parent_id}}' ORDER BY datetime(last_modified_date) DESC LIMIT 1",
            queryParams : {
                parent_id : docTemplateId
            },
            async : true
        });
    },

    __readTemplate : function(fileLocation, callback){
        var nativeRequest = com.servicemax.client.offline.sal.model.nativeservice.Facade.createFileRequest();

        var params = {
            type: "FILEIO",
            operation: "READ",
            file : fileLocation,
            parameters: {
                  file: fileLocation
            },
            async : true
        };

        nativeRequest.bind("REQUEST_COMPLETED", function(evt) {
               var data = evt.data.data;
               var result = {Template : data};
            callback(result);
        }, this);

        nativeRequest.bind("REQUEST_ERROR", function(evt) {
            logger.error(" __readTemplate  Failed. Error Info : " + evt.data.data);
            callback(false);
        });

        nativeRequest.execute(params);
    },

    describeObject : function(request, responder){

         return OfflineMetaUtils.describeObject({
          objectName: request.objectName,
          onSuccess : SVMX.proxy(this, function(resp){
              return resp;
          }),
          onError : SVMX.proxy(this, function(resp){
              return {};
          })
        });

    },

    //Currently hard coded
     getDocumentMetaData : function(params, callback){
         var me = this;
         /*prepare TemplateRecord :
         1. Fetch the field SVMXC__Media_Resources__c which contains all the image names
         */
         this.__getImageNames(params, function(resp){
             var imgNames = resp.MediaResources, docTemplateId = resp.DocTemplateId;
             //prepare AllObjectInfo
             setTimeout(function(){
                 me.__getAllObjectInfo(docTemplateId, function(res){
                     //Get the document template detail records for the document template id
                     var docMetaData = {"AllObjectInfo" : res};
                     callback(docMetaData);

                 });
             },100);
         });
              },

     __getAllObjectInfo : function(docTemplateId, callback){
         var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
        var request = nativeService.createSQLRequest();

        request.bind("REQUEST_COMPLETED", function(evt) {
            var data = evt.data.data;
            if(data && data.length){
                var attributes = '', idField = "", idRes = '', svmxFields = '';
                var svmxObjName = '', svmxAlias = '', svmxType = '';
                //idRes has to be populated with what ID
                for(var i = 0; i < data.length ; i++){
                    fields = SVMX.toJSON(data[i].fields);

                    idField = '"' + "Id" + '"' + ":" + '"' + idRes + '"';
                    svmxFields = '"' + SVMX.OrgNamespace + "__Fields__c" + '"' +":" + fields;
                    svmxObjName = '"' + SVMX.OrgNamespace + "__Object_Name__c" + '"' + ":" + '"' + data[i].object_name+ '"';
                    svmxAlias = '"' + SVMX.OrgNamespace + "__Alias__c" + '"' + ":" + '"' + data[i].alias + '"';
                    svmxType = '"' + SVMX.OrgNamespace + "__Type__c" + '"' + ":" + '"' + data[i].type+ '"';

                    attributes = attributes + "{" + idField + "," + svmxFields + "," + svmxObjName + "," + svmxAlias + "," + svmxType + "}" +",";
                }
            }
            //remove the last comma.
            attributes = attributes.substring(0, attributes.lastIndexOf(","));
            var result = "[" + attributes + "]";
            callback(eval(result));
        }, this);

        request.bind("REQUEST_ERROR", function(evt) {
            SVMX.getLoggingService().getLogger("__getMediaResources Failed" + evt.data.data);
        });

        request.execute({
            query : "SELECT fields, type, alias, object_name FROM SFDocTemplateDetail WHERE doc_template  = '{{id}}'",
            queryParams : {
                id : docTemplateId
            },
            async : true
        });
     },

     __getImageNames : function(params, callback){
        var me = this;
         this.__getDocTemplateId(params.ProcessId, "", function(result){
             var docTemplateId = result.docTemplateId;
             setTimeout(function(){
                 me.__getMediaResources(docTemplateId, function(resp){
                     if(resp){
                        var result = {MediaResources : resp.mediaResources, DocTemplateId : docTemplateId};
                        callback(result);
                    }else{
                        return;
                    }
                });
             },100);
         });
     },

     __getMediaResources : function(docTemplateId, callback){
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
        var request = nativeService.createSQLRequest();

        request.bind("REQUEST_COMPLETED", function(evt) {
            var data = evt.data.data;
            var result = (data && data.length) ? {
                mediaResources : SVMX.toObject(data)[0].media_resources
            } : null;
            callback(result);
        }, this);

        request.bind("REQUEST_ERROR", function(evt) {
            SVMX.getLoggingService().getLogger("__getMediaResources Failed" + evt.data.data);
        });

        request.execute({
            query : "SELECT media_resources FROM SFDocTemplate WHERE Id = '{{id}}'",
            queryParams : {
                id : docTemplateId
            },
            async : true
        });
     },

    getDocumentData : function(params, callback){
        //Fetch process, process node, doc template, doc template detail records for the process id,
        //For each doc template detail record create query based on SVMXC__Fields__c which is JSON String
        //JSON can have any number of rows, but the max level is three.
    //*Ex JSON String :
        var me = this;
         this.__getDocTemplateId(params.ProcessId, params.RecordId, function(result) {
             var docTemplateId = result.docTemplateId, recordId = result.recordId, sfProcessId = result.sfProcessId;

             setTimeout(function(){
                 me.__getProcessNodeDetails(sfProcessId, function(records) {
                     var i = 0, length = records.length;
                     this.__expressionsInfo = {};
                     this.__sortingOptions = {};
                     for(i = 0; i < length; i++) {
                         this.__expressionsInfo[records[i].doc_template_detail_id] = records[i].expression_id;
                         this.__sortingOptions[records[i].doc_template_detail_id] = records[i].advanced_options;
                     }
                     me.__getTemplateDetails(docTemplateId, recordId, function(resp){
                        if(resp){
                            var i = 0, length = resp.recs.length;
                            var docDetailsCollection = [];
                            for(i = 0; i < length; i++) {
                                var currRec = resp.recs[i]; recordId = resp.recordId;
                                var allQueriesInfo = me.__constructQueries(currRec, recordId);
                                docDetailsCollection.push(allQueriesInfo);
                            }
                            me.__docDetailsCollection = docDetailsCollection;
                            me.__executeDocumentDetails(docDetailsCollection, me.__finalizeData, me, callback);

                        }else{
                            return;
                        }
                    });
                 }, me);
             },100);
        });
    },

    __getProcessNodeDetails : function(sfProcessId, callback, context) {
        var processDetailQuery = SVMX.string.substitute("SELECT Id, process_id, expression_id, doc_template_detail_id, advanced_options  FROM SFProcessComponent where process_id = '{{processId}}'",
                {processId: sfProcessId});
        this.__executeQuery(processDetailQuery, function(processNodeDetails) {
            callback.call(context, processNodeDetails);
        }, this);
    },

    __getSortString : function(advancedOptions, objectName) {

        var sortD = $.Deferred();
        var str = "";
        if (!advancedOptions || !advancedOptions.lstSortingRec) {
          sortD.resolve(str);
        } else {
          var fieldSet;
          //asynchronous
          com.servicemax.client.offline.sal.model.utils.FieldSet.getFieldSet(objectName, function(inFieldSet) {
              fieldSet = inFieldSet;
              var data = advancedOptions.lstSortingRec;
              for (var i = 0; i < data.length; i++) {
                  var queryField = data[i].queryField || data[i].queryfield;
                  var fieldDef = fieldSet.getFieldType(queryField);
                  if (!fieldDef) continue;
                  if (str) str += ", ";
                  str += queryField;
                  str += " " + data[i].sortingOrder;
              }

              if (str) str = " ORDER BY " + str;
              sortD.resolve(str);
          });
        }
        return sortD;
    },

    __executeTemplateQueries : function(allQueriesInfo, callback) {

        var firstLevelQuery = allQueriesInfo.firstLevelQuery;
        var allQueriesInfo = allQueriesInfo;
        var me = this;
        var objName = allQueriesInfo.objName;
        // fix for defect - 034966
        if(objName === SVMX.OrgNamespace+'__Checklist__c'){
          allQueriesInfo.arrCols.push(SVMX.OrgNamespace+'__ChecklistJSON__c');
          allQueriesInfo.arrCols.push(SVMX.OrgNamespace+'__ChecklistMetaJSON__c');
        }
        //End of defect - 034966 fix
        if(firstLevelQuery !== undefined && firstLevelQuery !== null) {
            var d = $.Deferred();
            var sortingExpr = this.__sortingOptions[allQueriesInfo.docTemplateDetailId];
            if(sortingExpr !== undefined && sortingExpr !== null) {

                sortingExpr =  SVMX.toObject(sortingExpr);
                var orderByDeferred = this.__getSortString(sortingExpr, objName);
                orderByDeferred.then(SVMX.proxy(this, function(orderBy) {
                    //var orderBy = this.__getSortString(sortingExpr, objName);

                    if(orderBy !== undefined && orderBy !== null && orderBy.length > 0) {
                        firstLevelQuery = firstLevelQuery + orderBy;
                    }
                    d.resolve();

                }));

            } else {
                d.resolve();
        }
        d.then(SVMX.proxy(this, function(){
            this.__executeQueryValidateExpression(firstLevelQuery, objName, allQueriesInfo.arrCols, function(firstLevelData) {
            //now process the second level data
                var i = 0;
                var secondLevelInfo = allQueriesInfo.secondLevelInfo;
                var recData = {};
                var keyReferenceData = {};
                var sortingExpr = this.__sortingOptions[allQueriesInfo.docTemplateDetailId];
        		recData = firstLevelData;
                var fieldName = null;
                //get the reference data from the firstlevel data
                for(i = 0; i < recData.length; i++){
                    var currData = recData[i];
                    for(var currKey in secondLevelInfo) {
                        var fldValue = currData[currKey];
                        if(fldValue === undefined || fldValue === null) continue;
                        if(keyReferenceData[currKey] === undefined || keyReferenceData[currKey] === null) {
                            keyReferenceData[currKey] = "";
                        }
                        keyReferenceData[currKey] += ",'" + fldValue + "'";
                    }
                }
                this.__templateData[allQueriesInfo.alias] = recData;
                if(this.__getObjectLength(secondLevelInfo) === 0) {
                    this.__processDateTimeFields(allQueriesInfo);
                    callback.call();
                }else{
                    this.__queryLevelData(secondLevelInfo, keyReferenceData, allQueriesInfo, this.__processSecondLevelData, callback, this);
                }
            }, this.__expressionsInfo[allQueriesInfo.docTemplateDetailId] , this);
        }));

    }

    },

    __processDateTimeFields : function(allQueriesInfo) {
        var userInfo = OfflineSystemUtils.getUserInfo();
        var offset = userInfo.TimezoneOffset;
        var specialFields = allQueriesInfo.specialFields;
        this.__specialFieldsData[allQueriesInfo.alias] = [];
        var recordData = this.__templateData[allQueriesInfo.alias];
        for(i = 0; i < recordData.length; i++){
            var datetimeFieldValues = {};
            var currData = recordData[i];
            datetimeFieldValues["Key"] = currData["Id"];
            var arfieldInfo = [];
            for(var key in specialFields) {
                var fieldInfo = {};
                var val = currData[key];
                var fields = key.split(".");
                if(fields !== undefined && fields !== null && fields.length === 2) {
                    val = currData[fields[0]][fields[1]];
                }
                var format = specialFields[key];
                if(format === 'date'){
                    fieldInfo["Value"] = ((val) ? DatetimeUtils.convertDatetimeForSave(val) : val);
                }
                if(format === 'datetime'){
                    fieldInfo["Value"] = ((val) ? DatetimeUtils.convertToTimezone(val, offset, false) : val);
                }
                fieldInfo["Key"] = key;
                fieldInfo["Info"] = specialFields[key];
                arfieldInfo.push(fieldInfo);
            }
            datetimeFieldValues["Value"] = arfieldInfo;
            this.__specialFieldsData[allQueriesInfo.alias].push(datetimeFieldValues);
        }
    },

    __queryLevelData : function(levelInfo, keyReferenceData, allQueriesInfo, callback, finalCallback, context ) {
        //now execute the queries
        var queryCollection = [];
        for(var currKey in levelInfo) {

            var columns = (levelInfo[currKey].cols !== undefined && levelInfo[currKey].cols !== null &&
                        levelInfo[currKey].cols.length > 1) ? levelInfo[currKey].cols.substring(1) : "";
            var tableName = levelInfo[currKey].objName;
            var ids = (keyReferenceData[currKey] !== undefined && keyReferenceData[currKey] !== null &&
                    keyReferenceData[currKey].length > 1) ? keyReferenceData[currKey].substring(1) : "";
            var fldName = levelInfo[currKey].fldName;
            if(columns.length === 0 || ids.length === 2) {
                continue;
            }
            columns = "Id," + columns;
            levelInfo[currKey].arrCols.push("Id");
            var templateQuery = SVMX.string.substitute("SELECT * FROM '{{table_name}}' WHERE {{fldName}} IN ({{ids}})",
                    {cols: columns, table_name: tableName, ids: ids, fldName: fldName});
            queryCollection.push({type : currKey, query : templateQuery, arrCols: levelInfo[currKey].arrCols});
        }

        if(queryCollection.length > 0) {
            this.__executeQueryCollection(queryCollection, callback, allQueriesInfo, finalCallback, context);
        } else {
            callback.call(context, {}, allQueriesInfo, finalCallback, context);
        }


   },

   __getObjectLength : function (obj) {
       var count = 0;
       var i;

       for (i in obj) {
           if (obj.hasOwnProperty(i)) {
               count++;
           }
       }
       return count;
   },

   __processSecondLevelData : function(results, allQueriesInfo, finalCallback, context) {
      var levelData = {};
      for(var key in results) {
          var sourceRecordData = results[key];
          for (var i = 0; i < sourceRecordData.length; i++) {
              levelData[sourceRecordData[i].Id] = sourceRecordData[i];
             }
      }

      var alias = allQueriesInfo.alias;
      var levelInfo = allQueriesInfo.secondLevelInfo;
      var recData = context.__templateData[alias];
      var thirdLevelInfo = allQueriesInfo.thirdLevelInfo;

       for(i = 0; i < recData.length; i++) {
            var currData = recData[i];
            for(var currKey in levelInfo) {
                var recFieldValue = currData[currKey];
                var relationFld = levelInfo[currKey].relationName;
                if(recFieldValue !== undefined && recFieldValue !== null
                        && levelData[recFieldValue] !== undefined && levelData[recFieldValue] !== null) {
                    currData[relationFld] = levelData[recFieldValue];
                }else
                {
                    currData[relationFld] = {};
                }
            }
        }
       if(this.__getObjectLength(thirdLevelInfo) === 0) {
           this.__processDateTimeFields(allQueriesInfo);
           finalCallback.call();
       }else{
           var keyReferenceData = {};
           //now start processing third level info;
           for(i = 0; i < recData.length; i++){
                var currData = recData[i];
                for(var currKey in thirdLevelInfo) {
                    var keys = currKey.split(".");
                    if(currData[keys[0]] === undefined || currData[keys[0]] === null) continue;
                    var fldValue = currData[keys[0]][keys[1]];
                    if(fldValue === undefined || fldValue === null) continue;
                    if(keyReferenceData[currKey] === undefined || keyReferenceData[currKey] === null) {
                        keyReferenceData[currKey] = "";
                    }
                    keyReferenceData[currKey] += ",'" + fldValue + "'";
                }
           }
           this.__queryLevelData(thirdLevelInfo, keyReferenceData, allQueriesInfo, this.__processThirdLevelData, finalCallback, this);
       }
   },

   __processThirdLevelData : function(results, allQueriesInfo, finalCallback, context) {
    var levelData = {};
    for(var key in results) {
      var sourceRecordData = results[key];
      for (var i = 0; i < sourceRecordData.length; i++) {
        levelData[sourceRecordData[i].Id] = sourceRecordData[i];
      }
    }
    var alias = allQueriesInfo.alias;
    var recData = this.__templateData[alias];
    var levelInfo = allQueriesInfo.thirdLevelInfo;
    for(i = 0; i < recData.length; i++) {
      var currData = recData[i];
      for(var currKey in levelInfo) {
        var keys = currKey.split(".");
        var recFieldValue;
        if(currData[keys[0]] !== undefined && currData[keys[0]] !== null) {
          recFieldValue = currData[keys[0]][keys[1]];
        }
        var relationFld = levelInfo[currKey].relationName;
        var fields = relationFld.split(".");
        if(recFieldValue !== undefined && recFieldValue !== null
            && levelData[recFieldValue] !== undefined && levelData[recFieldValue] !== null) {
          currData[fields[0]][fields[1]] = levelData[recFieldValue];
        }else {
          currData[fields[0]][fields[1]] = {};
        }
      }
    }
    this.__processDateTimeFields(allQueriesInfo);
    finalCallback.call();
   },

   //Query and process the document details
   __executeDocumentDetails : function(docDetailsCollection, handler, context, callback) {
       var i, j, length = docDetailsCollection.length;
       var result = {};
       var remItems = length;
       for(i = 0; i < length; i++){
           context.__executeTemplateQueries(docDetailsCollection[i], function(){
                remItems--;
                if(remItems == 0){

                    handler.call(context, callback);
                }
            },context);
       }

   },

   __finalizeData : function(callback) {
       var data = [];
       for(var key in this.__templateData) {
           data.push({"SpecialFields" : this.__specialFieldsData[key] ,"Records" : this.__templateData[key],"Key" : key});
       }
       if(data.length > 0 && this.__docDetailsCollection.length > 0) {
           for(var i = 0; i < data.length; i++) {
               for(var j = 0; j < this.__docDetailsCollection.length; j++) {
                   if(data[i].Key && this.__docDetailsCollection[j].alias) {
                       if(data[i].Key == this.__docDetailsCollection[j].alias) {
                           data[i].docTemplateDetailId = this.__docDetailsCollection[j].docTemplateDetailId;
                       }
                   }
               }
           }
           for(var i = 0; i < data.length; i++) {
               if(data[i].docTemplateDetailId) {
                   var docId = data[i].docTemplateDetailId;
                   var fieldName = null;
                   if(this.__sortingOptions) {
                       var sortingExpr = this.__sortingOptions[docId];
                       if(sortingExpr != undefined && sortingExpr != null && sortingExpr != "") {
               			   sortingExpr =  SVMX.toObject(sortingExpr);
                           if(data[i].Records) {
                               if(data[i].Records.length > 0) {
                                  data[i].Records = this.__sortLines(data[i].Records, sortingExpr);
                               }
                           }
                       }
                   }
               }
            }
       }
       //hardcoding for now
      var me = this;
       setTimeout(function(){
           me.__constructData(data, function(response){
            callback(response);
           });
       },100);

   },

   __sortLines : function(data, sortingExpr) {
       var sortingFields = sortingExpr.lstSortingRec;
       var sort_helper = function(a, b, i) {
           var criteria = sortingExpr.lstSortingRec[i];
           var fieldName = criteria.fieldAPIName;
           var nameField = null;
           var first;
           var second;
           var dateTimeUtil = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
           if(criteria.dataType == "REFERENCE") {
               fieldName  = criteria.queryField.split(".")[0];
               nameField = criteria.queryField.split(".")[1];
               first = a[fieldName][nameField];
               second = b[fieldName][nameField];
           }
           else {
               first = a[fieldName];
               second = b[fieldName];
           }
           if(first) {
              first = first.toLowerCase();
           }
           if(second) {
             second = second.toLowerCase();
           }
           if((first === second) && (i != sortingExpr.lstSortingRec.length - 1)) {
               return sort_helper(a, b, i+1);
           }
           else if(first == undefined) {
               return -1;
           }
           else if(second == undefined) {
               return 1;
           }
           else if(criteria.sortingOrder == "ASC") {
               if(first < second) {
                   return -1;
               }
               else {
                  return 1;
               }
           }
           else {
               if(first < second) {
                   return 1;
               }
               else {
                   return -1;
               }
           }
       };
       if(sortingExpr.lstSortingRec.length > 0) {
           data.sort(function(a, b) {
              return sort_helper(a, b, 0);
           });
       }
       return data;
   },

 //Query execution related methods
   __executeQueryCollection : function(queryCollection, handler, allQueriesInfo, finalCallback, context){
         var i, j, length = queryCollection.length;
         var result = {};
         var remItems = length;
         for(i = 0; i < length; i++){
             this.executeQuery(queryCollection[i].query, queryCollection[i].type,
                                             queryCollection[i].arrCols, function(type, resp, arrCols){
                 SVMX.getLoggingService().getLogger("Remaining Query count: " + remItems);
                 var i = 0, j = 0, recs = [];
                 for(i = 0; i < resp.length; i++) {
                     var rec = {};
                     for(j = 0; j < arrCols.length; j++) {
                          rec[arrCols[j]] = resp[i][arrCols[j]];
                      }
                     recs.push(rec);
                 }

                 result[type] = recs;
                 remItems--;
                 if(remItems == 0){
                     SVMX.getLoggingService().getLogger("Finished now calling back: " + remItems);

                     handler.call(context, result, allQueriesInfo, finalCallback, context);
                 }
             },context);
         }

     },

   executeQuery : function(query, type, arrCols, callback, context){
       this.__executeQuery(query, function(resp){
           callback.call(context, type, resp, arrCols);
       });
   },

   __executeQuery : function(query, callback, context){

     var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
     var request = nativeService.createSQLRequest();

     request.bind("REQUEST_COMPLETED", function(evt){
       callback.call(context, SVMX.toObject(evt.data.data));
     }, this);

     request.bind("REQUEST_ERROR", function(evt){
           SVMX.getLoggingService().getLogger(evt.data);
       callback.call(context, false);
     }, this);

     request.execute({query : query, async : true });
   },

   __executeQueryValidateExpression : function(query, objName, arrCols, callback, expressionId, context){

         var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
         var request = nativeService.createSQLRequest();

         request.bind("REQUEST_COMPLETED", function(evt){
             var resultData = SVMX.toObject(evt.data.data);
             if(expressionId !== undefined && expressionId !== null && expressionId.length > 0 && resultData.length > 0) {
                 var i = 0, length = resultData.length, resultLength = resultData.length;
                 var data = [], tempData = {};
                 for(i = 0; i < length; i++) {

                     var resData = resultData[i], j = 0;
                     var currData = {};
                     if(arrCols !== undefined && arrCols !== null) {
                         for(j = 0; j < arrCols.length; j++){
                             currData[arrCols[j]] = resData[arrCols[j]];
                         }
                     }
                     this.__evaluateExpression(currData, expressionId, function(response, inputdata) {
                         resultLength--;
                         if(response[0].result){
                             data.push(inputdata);
                         }
                         if(resultLength === 0) {
                             callback.call(context, data);
                         }
                     }, this);
                 }

             } else {
                 callback.call(context, SVMX.toObject(evt.data.data));
             }

         }, this);

         request.bind("REQUEST_ERROR", function(evt){
               SVMX.getLoggingService().getLogger(evt.data);
           callback.call(context, false);
         }, this);

         request.execute({query : query, async : true });
   },
    __evaluateExpression : function(resultData, expressionId, callback, context) {
        com.servicemax.client.offline.sal.model.utils.Expressions.evaluate({
            recordId: resultData.Id,
            expressionId: expressionId,
            returnMessage: true,
            onSuccess : SVMX.proxy(this, function(response) {
                callback.call(context, response, resultData);
            }),

            onError: SVMX.proxy(this, function(inError) {
                callback.call(context, [{result : false}], resultData);
            })
        });
    },

    __constructQueries : function(docTemplateDetail, recordId) {
        var fieldsMetadata = SVMX.toObject(docTemplateDetail.fields).Metadata, alias = docTemplateDetail.alias, recordId = recordId;
        var i = 0, cols = "", arrcols = [];
        var firstLevelQuery = {}, secondLevelInfo = {}, thirdLevelInfo = {}, specialFields = {};
        var processFields = {};
        if(fieldsMetadata !== undefined && fieldsMetadata !== null) {
            for(i = 0 ; i < fieldsMetadata.length; i++) {
                var currFieldInfo = fieldsMetadata[i];
                //first level information
                if(currFieldInfo.FN !== undefined && currFieldInfo.FN !== null && processFields[currFieldInfo.FN] == undefined) {
                    processFields[currFieldInfo.FN] = currFieldInfo.FN;
                    cols = cols + "," + currFieldInfo.FN;
                    arrcols.push(currFieldInfo.FN);
                }

                //second level information
                if(currFieldInfo.TYP !== undefined && currFieldInfo.TYP === "reference" && currFieldInfo.RFN !== undefined && currFieldInfo.RFN !== null) {
                    if(secondLevelInfo[currFieldInfo.FN] === undefined || secondLevelInfo[currFieldInfo.FN] === null) {
                        secondLevelInfo[currFieldInfo.FN] = {};
                        secondLevelInfo[currFieldInfo.FN].cols = "";
                        secondLevelInfo[currFieldInfo.FN].arrCols = [];
                    }

                    secondLevelInfo[currFieldInfo.FN].arrCols.push(currFieldInfo.RFN);
                    secondLevelInfo[currFieldInfo.FN].cols += "," + currFieldInfo.RFN;
                    secondLevelInfo[currFieldInfo.FN].objName = currFieldInfo.ROBJ;
                    secondLevelInfo[currFieldInfo.FN].fldName = "Id";
                    secondLevelInfo[currFieldInfo.FN].relationName = currFieldInfo.RLN;

                    //third level information
                    if(currFieldInfo.RTYP !== undefined && currFieldInfo.RTYP === "reference") {
                        var parentFldName = currFieldInfo.RLN + "." + currFieldInfo.RFN;
                        if(thirdLevelInfo[parentFldName] === undefined || thirdLevelInfo[parentFldName] === null) {
                            thirdLevelInfo[parentFldName] = {};
                            thirdLevelInfo[parentFldName].cols = "";
                            thirdLevelInfo[parentFldName].arrCols = [];
                        }
                        thirdLevelInfo[parentFldName].arrCols.push(currFieldInfo.RFN2);
                        thirdLevelInfo[parentFldName].cols += "," + currFieldInfo.RFN2;
                        thirdLevelInfo[parentFldName].objName = currFieldInfo.ROBJ2;
                        thirdLevelInfo[parentFldName].fldName = "Id";
                        thirdLevelInfo[parentFldName].relationName = currFieldInfo.RLN + "." + currFieldInfo.RLN2;
                    } else if(currFieldInfo.RTYP !== undefined && (currFieldInfo.RTYP === 'datetime' || currFieldInfo.RTYP === 'date')) {
                        var parentFldName = currFieldInfo.RLN + "." + currFieldInfo.RFN;
                        specialFields[parentFldName] = currFieldInfo.RTYP;
                    }
                } else if(currFieldInfo.TYP !== undefined && (currFieldInfo.TYP === 'datetime' || currFieldInfo.TYP === 'date')) {
                    specialFields[currFieldInfo.FN] = currFieldInfo.TYP;
                }

            }
        }
        cols = cols.substring(1);
        cols = "Id," + cols;
        arrcols.push("Id");
        //using * because of the field level permissions
        firstLevelQuery = SVMX.string.substitute("SELECT * FROM '{{objName}}' WHERE {{fldName}} = '{{recordId}}'",
                          { cols: cols,
                               objName: docTemplateDetail.object_name,
                               fldName: docTemplateDetail.header_ref_fld,
                               recordId: recordId});
        var allLevelQueryInfo = {};
        allLevelQueryInfo.firstLevelQuery = firstLevelQuery;
        allLevelQueryInfo.arrCols = arrcols;
        allLevelQueryInfo.secondLevelInfo = secondLevelInfo;
        allLevelQueryInfo.thirdLevelInfo = thirdLevelInfo;
        allLevelQueryInfo.specialFields = specialFields;
        allLevelQueryInfo.alias = alias;
        allLevelQueryInfo.objName = docTemplateDetail.object_name;
        allLevelQueryInfo.docTemplateDetailId = docTemplateDetail.Id;
        return allLevelQueryInfo;
    },

    __constructData : function(data, callback){
        var data = {
            "Status":true, "Message":"",
            "DocumentData":data
        };
        //prepare DocumentData with the following structure- {"SpecialFields":[],"Records":[],"Key":""} where key is alias
        callback(data);
    },

    __firstLevelData : function(data, recordId, alias, callback){
        var i, query = '', queryParams = '', objName = '';
        for(i = 0; i < data.length; i++){
            if(data[i].RTYP == undefined){
                //prepare query
                queryParams = queryParams + "," + data[i].FN;
                objName = data[i].OBJ;
            }/*else if(data[i].RTYP !== undefined && data[i].RTYP2 == undefined){
                queryParams = queryParams + "," + data[i].FN;
            } */
        }

        queryParams = queryParams.substring(1);

        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
          var request = nativeService.createSQLRequest();

          request.bind("REQUEST_COMPLETED", function(evt) {
              var data = evt.data.data, result = '';
              if(data && data.length){
                  //shud be outside ideally - Vinod
                  var result = {data : data, alias :alias};
                  callback(result);
              }
          }, this);

          request.bind("REQUEST_ERROR", function(evt) {
              SVMX.getLoggingService().getLogger("__getMediaResources Failed" + evt.data.data);
          });

          request.execute({
              query : "SELECT {{cols}} FROM '{{objName}}' WHERE Id = '{{recordId}}'",
              queryParams : {
                  cols : queryParams,
                  objName : objName,
                  recordId : recordId
              },
              async : true
          });
    },

    __getTemplateDetails : function(docTemplateId, recordId, callback){
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
        var request = nativeService.createSQLRequest();

        request.bind("REQUEST_COMPLETED", function(evt) {
            var data = evt.data.data, result = '';
            if(data && data.length){
                result = {recordId : recordId, recs : data};
            }
            callback(result);
        }, this);

        request.bind("REQUEST_ERROR", function(evt) {
            SVMX.getLoggingService().getLogger("__getMediaResources Failed" + evt.data.data);
        });

        request.execute({
            query : "SELECT Id, fields, alias, type, header_ref_fld, object_name FROM SFDocTemplateDetail WHERE doc_template  = '{{id}}' ",
            queryParams : {
                id : docTemplateId
            },
            async : true
        });
    },

    //pass back all the info, along with the path of the captured signature.
    captureDeviceSignature : function(request, callback){
        var processId = request.processId, recordId = request.recordId, uniqueName = request.uniqueName, capturedSignature = request.capturedSignature;
        var height = request.imgHeight, width = request.imgWidth;
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
          var request = nativeService.createSignatureCaptureRequest();

          request.bind("REQUEST_COMPLETED", function(evt) {
              //get the path of the image
              var data = evt.data;
              data = {path : evt.data.fileLocation.replace(/\\/g, '/'), height : height, width : width, uniqueName : uniqueName};
              if(data){
                  callback(data);
              }else{
                  callback(null);
              }
          }, this);

          request.bind("REQUEST_ERROR", function(evt) {
              SVMX.getLoggingService().getLogger("createSignatureRequest Failed" + evt.data);
          });

          request.execute({
              operation : "SIGNATURECAPTURE",
              type : "SIGNATURECAPTURE",
              recordId : recordId,
              processId : processId,
              uniqueName : uniqueName,
              async : false
          });
    },

    // pass back all the info, along with the path of the captured signature.
    captureHtmlSignature : function(request, callback){
      var processId = request.processId, recordId = request.recordId, uniqueName = request.uniqueName, capturedSignature = request.capturedSignature;
      var height = request.imgHeight, width = request.imgWidth;
      var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
      var DatetimeUtil = com.servicemax.client.lib.datetimeutils.DatetimeUtil;

      //Remove px and convert to numbers

      // Call a command and operation
      // We call another Command/Operation rather than using the original since
      // MFL, iOS and Android all use this same operation.
      // Would be better if this still went to native layer for mobile but that layer
      // does not have access to Sencha or jQuery

      //Get User Information to get date format for our watermark
      var userInfo = com.servicemax.client.offline.sal.model.utils.SystemData.getUserInfo();
      var dateFormat =  userInfo.DateFormat;
      var timeFormat =  userInfo.TimeFormat;
      var displayFormat = DatetimeUtil.convertFormatForExt(dateFormat).split(" ")[0];

      // Get Object name and date for watermark
      var d = com.servicemax.client.offline.sal.model.utils.Data.getRecord({
        Id: recordId,
        loadReferences: false,
        convertPicklists: false
      });

      d.done(SVMX.proxy(this, function(data){
        var watermark = "";
        if (data && data.Name) {
          watermark = data.Name +" ";
        } else if (data && data.CaseNumber) {
          watermark = data.CaseNumber +" ";
        }
          //Get Date
          watermark += DatetimeUtil.getFormattedDatetime(DatetimeUtils.getCurrentDatetime(DatetimeUtils.getSaveFormat('dateTime'))) + "   ";





        var evt = SVMX.create("com.servicemax.client.lib.api.Event",
          "SFMOPDOCDELIVERY.CAPTURE_HTML_SIGNATURE", this,{
            request : {
              processId   : processId,
              recordId    : recordId,
              uniqueName  : uniqueName,
              watermark   : watermark,
              imgHeight   : height,
              imgWidth    : width,
              callback    : SVMX.proxy(this, callback),
              handler     : SVMX.proxy(this, this.onCaptureHtmlSignatureComplete)
            }
        });

        var app = SVMX.getCurrentApplication();

        app.triggerEvent(evt);
      }));
    },

    onCaptureHtmlSignatureComplete : function(results) {
      if (!results.success) {
        return;
      }

      var data = results.data;
      var path = "";
      var isBase64Encoded = results.isBase64Encoded || false;

      if (data) {
        // Clear any pre-existing signature file
        var d = this.__clearSignatureFile({
          uniqueName  : results.uniqueName,
          processId   : results.processId,
          recordId    : results.recordId
        });

        // Save file
        d = d.then(SVMX.proxy(this, function(results) {
          return this.__saveSignatureFile({
            uniqueName  : results.uniqueName,
            processId   : results.processId,
            recordId    : results.recordId,
            data        : data,
            isBase64Encoded: isBase64Encoded
          });
        }));

        // Save database record
        d = d.then(SVMX.proxy(this, this.__saveSignatureRecord));

        d.done(SVMX.proxy(this, function(saveResults) {
          var captureResults = {
            path        : saveResults.path,
            uniqueName  : saveResults.uniqueName,
            width       : results.imgWidth,
            height      : results.imgHeight
          };

          results.callback(captureResults); // done with image
        }))

        //Something went wrong
        d.fail(SVMX.proxy(this, function() {
          results.callback({
            uniqueName: results.uniqueName
          }); // done Clear image
        }));

      } else {
        // Clear any current signatures by this unique id from FS and DB
        var d = this.__clearSignatureFile({
          uniqueName  : results.uniqueName,
          processId   : results.processId,
          recordId    : results.recordId
        });

        d.always(SVMX.proxy(this, function() {
          results.callback({
            uniqueName: results.uniqueName
          }); // done Clear image
        }));
      }
    },

    /**
     * Remove any signature that is not tied to a finalized document
     */
    clearOrphanSignatures : function() {
      var d = new SVMX.Deferred();

      //Get list or records
      var promise = execQuery({
          query: "SELECT name, process_id, record_id, unique_id FROM SmartDocSignature " +
              "WHERE html_name = '' OR html_name IS NULL",
          queryParams: {}
      });

      promise = promise.then(SVMX.proxy(this, function(data) {
        var l = data.length;
        var i = 0;
        if (l) {
          var files = new SVMX.Deferred();
          files.resolve(); //Start the chain of events off

          for (i = 0; i < l; i++) {
            var clearRequest = {
              fileName    : data[i].name,
              processId   : data[i].process_id,
              recordId    : data[i].record_id,
              uniqueName  : data[i].unique_id
            };

            files = files.then(SVMX.proxy(this, this.__clearSignatureFile, clearRequest));
          }

          files.always(SVMX.proxy(this, function() {
            d.resolve(); // done
          }));
        } else {
          d.resolve(); // done
        }

      }));

      promise.fail(SVMX.proxy(this, function() {
        d.resolve(); // done
      }));

      return d;
    },

    __clearSignatureFile : function(request) {
      var d = new SVMX.Deferred();
      var promise;
      var fileName = request.fileName;

      // Get existing signature file for this uniqeID and process
      if (fileName) {
        // Use what we have and start the chain
        promise = new SVMX.Deferred();
        promise.resolve({
          fileName : fileName
        });
      } else {
        // Get the filename
        promise = this.__getSignatureRecord({
          processId   : request.processId,
          recordId    : request.recordId,
          uniqueName  : request.uniqueName
        });
      }

      // Delete file
      promise = promise.then(SVMX.proxy(this, function(result) {
        fileName = result.fileName;
        return this.__deleteSignatureFile({
          processId   : request.processId,
          recordId    : request.recordId,
          uniqueName  : request.uniqueName,
          fileName    : result.fileName
        });
      }));

      // Delete database record.
      promise = promise.then(SVMX.proxy(this, function(result) {
        return this.__deleteSignatureRecord({
          processId   : request.processId,
          recordId    : request.recordId,
          uniqueName  : request.uniqueName,
          fileName    : result.fileName
        });
      }));

      promise.always(SVMX.proxy(this, function() {
        d.resolve(request); // Regardless of what happens, we return a successful response.
      }));

      return d;
    },

    __getSignatureRecord : function(request) {
      var d = new SVMX.Deferred();

      var promise = execQuery({
          query: "SELECT name FROM SmartDocSignature " +
              "WHERE process_id = '{{processId}}' AND record_id = '{{recordId}}' AND unique_id = '{{uniqueName}}' AND (html_name = '' OR html_name IS NULL)",
          queryParams: request
      });

      promise = promise.then(SVMX.proxy(this, function(data) {
        var l = data.length;
        var i = 0;
        if (l) {
          d.resolve({
            fileName: data[0].name
          }); // done
        } else {
          d.reject(); // done
        }
      }));

      return d;
    },

    __deleteSignatureFile : function(request) {
      var d = new SVMX.Deferred();

      var fileRequest = com.servicemax.client.offline.sal.model.nativeservice.Facade.createFileRequest();

      fileRequest.bind("REQUEST_COMPLETED", function(evt){
          d.resolve(request);
      }, this);

      fileRequest.bind("REQUEST_ERROR", function(evt){
           d.resolve(request); //Always pretend everything is good
      }, this);

      fileRequest.execute({
          operation : "DELETE",
          file      : "{UploadDirectory}/" + request.fileName
      });

      return d;
    },

    __deleteSignatureRecord : function(request) {
      var d = new SVMX.Deferred();

      var promise = execQuery({
          query: "DELETE FROM SmartDocSignature " +
              "WHERE name = '{{fileName}}' AND process_id = '{{processId}}' AND record_id = '{{recordId}}' AND unique_id = '{{uniqueName}}'",
          queryParams: request
      });

      promise.always(SVMX.proxy(this, function() {
        d.resolve(request);
      }));

      return d;
    },

    __saveSignatureFile : function(request) {
      var d = new SVMX.Deferred();
      var timestamp = new Date().getTime();

      // Create file requests
      var fileRequest = com.servicemax.client.offline.sal.model.nativeservice.Facade.createFileRequest();
      var infoRequest = com.servicemax.client.offline.sal.model.nativeservice.Facade.createFileRequest();
      var fileName = request.processId + "_" + request.uniqueName + "_"  + timestamp + ".png";

      // Bind success paths
      fileRequest.bind("REQUEST_COMPLETED", function(evt){
          //Now we need to get info so we can pass back the full path
          infoRequest.execute({
              operation : "Info",
              file      : "{UploadDirectory}/" + fileName
          });
      }, this);
      infoRequest.bind("REQUEST_COMPLETED", function(evt){
          var path = evt.data.data.FilePath;
          d.resolve({
            uniqueName  : request.uniqueName,
            processId   : request.processId,
            recordId    : request.recordId,
            path        : path,
            fileName    : fileName
          });
      }, this);

      // Bind error paths, currently we don't care why, just that there was an error
      fileRequest.bind("REQUEST_ERROR", function(evt){
           d.reject();
      }, this);
      infoRequest.bind("REQUEST_ERROR", function(evt){
           d.reject();
      }, this);

      // Start the process
      // By default signature capture image is PNG
      fileRequest.execute({
          operation : "WRITE",
          file      : "{UploadDirectory}/" + fileName,
          data      : request.data,
          isBase64Encoded: request.isBase64Encoded
      });

      return d;
    },

    __saveSignatureRecord : function(request) {
      var d = new SVMX.Deferred();
      var newid = "sig_local_" + new Date().getTime();

      var query = execQuery({
          query: "INSERT INTO SmartDocSignature " +
              "(Id, name, html_name, process_id, record_id, unique_id) " +
              "VALUES('{{id}}', '{{file_name}}', null, '{{process_id}}', '{{record_id}}', '{{unique_id}}')",
          queryParams: {
              id          : newid,
              record_id   : request.recordId,
              file_name   : request.fileName, //Name of file without full path
              process_id  : request.processId,
              record_id   : request.recordId,
              unique_id   : request.uniqueName

          }
      });

      query.always(SVMX.proxy(this, function() {
        d.resolve({
          uniqueName  : request.uniqueName,
          processId   : request.processId,
          recordId    : request.recordId,
          path        : request.path // Full path to file
        });
      }));

      return d;
    },

    __parseHTMLContentForStyle : function(htmlContent) {
        var style = '';
        if(htmlContent !== undefined && htmlContent !== null) {
            var startIndex = htmlContent.indexOf('<style'), contentStartIndex = 0;
            if(startIndex != -1){
                contentStartIndex = htmlContent.indexOf('>', startIndex) + 1;
            }

            var endIndex = htmlContent.indexOf('</style>'), contentEndIndex = 0;
            if(endIndex != -1){
                contentEndIndex = endIndex;
            }

            if(startIndex != -1 && endIndex != -1){
                endIndex = endIndex + 8;
                style = htmlContent.substring(contentStartIndex, contentEndIndex);
                htmlContent = htmlContent.substring(0, startIndex) + htmlContent.substring(endIndex, htmlContent.length);
            }
        }
        var document = '<html><head><style type=\"text/css\">' + style + '</style>' +
                ' <style>body {font-family: Arial Unicode MS;}</style></head>' + htmlContent + '</html>';
        return document;
    },

    executeTargetObjectUpdate: function(request, callback, context){
        var d = SVMX.Deferred();

        execQuery({
            query: "select process_id from SFProcess where process_unique_id = '{{process_id}}'",
            queryParams: {
                process_id: request.processId
            }
        }).then(SVMX.proxy(this, function(sfmopdocProcess){
          execQuery({
              query: "select * from SFSourceUpdate LEFT JOIN SFProcessComponent ON SFProcessComponent.Id = SFSourceUpdate.target_process_node where SFProcessComponent.process_id='{{process_id}}' AND configuration_type='Source Update'",
              queryParams: {
                  process_id: sfmopdocProcess[0].process_id
              }
          }).then(SVMX.proxy(this, function(targetUpdateDataIn){
              if(targetUpdateDataIn.length === 0){
                d.resolve();
                return d;
              }
              var saveTargetRecord = SVMX.create("com.servicemax.client.offline.sal.model.sfmdelivery.operations.SaveTargetRecord");

              SVMX.array.forEach(targetUpdateDataIn, function(updateData) {
                  saveTargetRecord.executeOneSourceObjectUpdate(null, request.sourceRecord, updateData);
              });

              request.sourceRecord.writeRecord(
                  function(isInsert, syncRecordData) {
                      var syncInsertRecords = [], syncUpdateRecords = [];

                      if(syncRecordData){
                          if(isInsert){
                              syncInsertRecords.push(syncRecordData);
                          }else{
                              syncUpdateRecords.push(syncRecordData);
                          }
                      }

                      OfflineDataUtils.writeSyncRecords(
                          syncInsertRecords, syncUpdateRecords, [],
                          SVMX.proxy( this, function(){
                              //SVMX.getCurrentApplication().getSyncImpl().onSaveCompleted();
                              d.resolve();
                          })
                      );
                  },
                  function(e) {
                      logger.error("Failed to write sourceObjectUpdate record " + inId + ": " + e.message + "; " + e.stack);
                      d.resolve();
                  }
              );
          }));
        }));
        return d;
    },

    finalizeLocal : function(request, callback, context){
        var processId = request.ProcessId, recordId = request.RecordId, htmlContent = this.__parseHTMLContentForStyle(request.HTMLContent);
        var sourceRecord = request.SourceRecord;
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
          var request = nativeService.createPDFRequest();
          var me = this;

      request.bind("REQUEST_COMPLETED", function(evt) {
              if(evt.data !== undefined && evt.data != null &&
                      evt.data.parameters !== undefined && evt.data.parameters !== null &&
                      evt.data.parameters.operation !== undefined && evt.data.parameters.operation !== null) {
                  var processId = evt.data.parameters.processId;
                  var sourceRecord = evt.data.parameters.sourceRecord;
                  var recId = evt.data.parameters.recordId;
                  var path = evt.data.data;
                  var context = evt.data.parameters.context;
                  var callback = evt.data.parameters.callback;
                  var processIdQuery = SVMX.string.substitute("SELECT process_id FROM SFProcess WHERE process_unique_id = '{{process_id}}'",
                          {process_id: processId});
                  this.__executeQuery(processIdQuery, function(result){
                      OfflineDataUtils.executeSourceUpdateMapping({
                          processId: result[0].process_id,
                          data: sourceRecord
                      }).then(function() {
                            OfflineAttachmentsUtils.copyAttachmentIntoDownloads(path, function(response) {
                                if (response.success) {
                                    var file = new com.servicemax.client.offline.sal.model.nativeservice.File(response.targetPath + "/" + response.targetFileName);
                                    var userInfo  = OfflineSystemUtils.getUserInfo();
                                    var offset = userInfo.TimezoneOffset;
                                    var modified_date = com.servicemax.client.lib.datetimeutils.DatetimeUtil.getTimestampWithSaveFormat();
                                    modified_date = DatetimeUtils.convertToTimezone(modified_date, offset, true);
                                      var reqFormat = DatetimeUtils.macroDrivenDatetime('Now', "YYYYMMDD", "HHmmss").replace(/\s+/g, '');
                                      var name = processId + '_' + recId + '_' + reqFormat + '.pdf';
                                    var newid = "local_" + new Date().getTime();
                                    file.execute();
                                    file.info().then(SVMX.proxy(this, function(inSuccess, inFileInfo) {
                                        var author = OfflineSystemUtils.getUserInfo().UserId;
                                        /*Ashwini : Escape single quotes (') in the filename*/
                                        var filePathValue = file.getPath();
                                        filePathValue = filePathValue.replace(/'/g, "''");
                                        name = name.replace(/'/g, "''");
                                        return execQuery({
                                            query: "INSERT INTO SFAttachments " +
                                                "(Id, parent_id, file_path, name, last_modified_date, content_length, created_by_id, downloaded) " +
                                                "VALUES('{{id}}', '{{record_id}}', '{{target_path}}', '{{file_name}}', '{{last_modified}}', {{size}}, '{{author}}', 'true')",
                                            queryParams: {
                                                id: newid,
                                                record_id: recId,
                                                file_name: name,
                                                target_path: filePathValue,
                                                last_modified: modified_date,
                                                size: inFileInfo.size,
                                                author: author
                                            }
                                        });
                                    })).then(SVMX.proxy(this, function() {
                                        var service = SVMX.getClient().getService("com.servicemax.client.attachmentnotifications").getInstance();
                                        var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                                            "ATTACHMENTS_CHANGED", this, {
                                                request : {
                                                    recordId: sourceRecord.Id
                                                }
                                            }
                                        );
                                        service.triggerEvent(evt);
                                    }));
                                    SyncUtils.insertAttachment({
                                        Id: newid,
                                        isAttachment: true
                                    });

                                }
                            });

                            OfflineAttachmentsUtils.copyAttachmentIntoUploads(path, function(response) {
                                if (response.success) {
                                    //Enrty into SFAttachments done via downloads
                                }
                            });

                            callback.call(context, true);
                      });
                  }, this);
              }

          }, this);

          request.bind("REQUEST_ERROR", function(evt) {
              SVMX.getLoggingService().getLogger("createSignatureRequest Failed" + evt.data);
          });

          request.execute({
              operation : "GENERATEPDF",
              type : "GENERATEPDF",
              recordId : recordId,
              processId : processId,
              htmlContent : htmlContent,
              sourceRecord : sourceRecord,
              callback : callback,
              context : context,
              async : false
          });


    },

    finalizeRemote : function(request, callback, context){
      var processId = request.ProcessId, recordId = request.RecordId, htmlContent = this.__parseHTMLContentForStyle(request.HTMLContent);
      var sourceRecord = request.SourceRecord;

      //Create a filename that matches iPad's naming convention {process name}_{recordid}_{YYYYMMDDHHMMAA}.html
      var currentTime = new Date();
      var year = currentTime.getFullYear();
      var month = (currentTime.getMonth()+1);
      var day = currentTime.getDate();
      var hour = currentTime.getHours();
      var minute = currentTime.getMinutes();
      var second = currentTime.getSeconds();

      var timestamp = "" + year + month + day + hour + minute + second;
      var htmlName = processId + '_' + recordId +  '_' + timestamp + '.html';

      // Strip some HTML tags because the server will wrap content with them
      htmlContent = htmlContent.replace(/(<\/?html>)/ig, '').replace(/(<\/?head>)/ig, '');

      var fileRequest = com.servicemax.client.offline.sal.model.nativeservice.Facade.createFileRequest();
      fileRequest.bind("REQUEST_ERROR", function(evt){
          console.error('Unable to upload output document at '+htmlName);
          return callback.call(context, true);
      });
      fileRequest.bind("REQUEST_COMPLETED", function(evt){
          var processId = evt.data.parameters.processId;
          var sourceRecord = evt.data.parameters.sourceRecord;
          var processIdQuery = SVMX.string.substitute("SELECT process_id FROM SFProcess WHERE process_unique_id = '{{process_id}}'",
                    {process_id: processId});
          this.__executeQuery(processIdQuery, function(result){
              OfflineDataUtils.executeSourceUpdateMapping({
                  processId: result[0].process_id,
                  data: sourceRecord
              }).then(function() {
                  execQuery({
                      query: "INSERT INTO SmartDocHTML " +
                          "(Id, name, process_id, record_id) " +
                          "VALUES('{{Id}}', '{{name}}', '{{process_id}}', '{{record_id}}')",
                      queryParams: {
                          Id: 'smd_local_'+(new Date().getTime()),
                          name: htmlName,
                          process_id: processId,
                          record_id: recordId
                      }
                  })
                  .then(function() {
                      execQuery({
                          query: "UPDATE SmartDocSignature " +
                              "SET html_name = '{{html_name}}' WHERE html_name IS NULL OR html_name = ''",
                          queryParams: {
                              html_name: htmlName
                          }
                      })
                  })
                  .then(function() {
                      var service = SVMX.getClient().getService("com.servicemax.client.attachmentnotifications").getInstance();
                      var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                          "ATTACHMENTS_CHANGED", this, {
                              request : {
                                  recordId: sourceRecord.Id
                                }
                              }
                            );
                      service.triggerEvent(evt);

                      callback.call(context, true);
                  });
              });
          }, this);
      }, this);

      fileRequest.execute({
          operation : "WRITE",
          file      : '{UploadDirectory}/'+htmlName,
          data      : htmlContent,
          recordId  : recordId,
          processId : processId,
          sourceRecord : sourceRecord
      });
    },

    getDownloadsPath : function(callback){
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
          var request = nativeService.createInstallationsRequest();

          request.bind("REQUEST_COMPLETED", function(evt) {
              var data = evt.data.data, result;
              if(data){
                  callback(data);
              }else{
                  callback(null);
              }
          }, this);

          request.bind("REQUEST_ERROR", function(evt) {
              SVMX.getLoggingService().getLogger("getDownloadsPath Failed" + evt.data.data);
          });

          request.execute({
              operation : "GETDOWNLOADFOLDERPATH",
              type : "MISC",
              async : true
          });
    },

    submitQuery : function(requestData, callback){
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
          var request = nativeService.createSQLRequest();

          request.bind("REQUEST_COMPLETED", function(evt) {
              var data = evt.data.data, me = this;
              if(data && data.length){
                  var imageName = data[0].Id + "_" + data[0].DeveloperName + "." + data[0].Type;
                  //Need to introduce an API @ .NET layer to get the Downloads folder location
                  me.getDownloadsPath(function(result){
                      var imageLocation =  result + "\\" + imageName;
                      callback(imageLocation);
                  });
              }
          }, this);

          request.bind("REQUEST_ERROR", function(evt) {
              SVMX.getLoggingService().getLogger("Submit Query Failed" + evt.data.data);
          });

          request.execute({
              query : requestData.Query,
              async : true
          });
    }

  }, {});

};

})();

// end of file
