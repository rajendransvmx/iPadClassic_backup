(function() {
    var impl = SVMX.Package("com.servicemax.client.offline.sal.model.toolspages.operations");
    impl.init = function() {
        var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;
        var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
        var utils = com.servicemax.client.offline.sal.model.sfwdeliveryutils.Utils;
        var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.toolspages");

        /**
         *  Updates conflict resolution in local database
         *
         *  @class      com.servicemax.client.offline.sal.model.toolspages.operations.UpdateConflict
         *  @extends    com.servicemax.client.mvc.api.Operation
         */
         impl.Class("UpdateConflict", com.servicemax.client.mvc.api.Operation, {
            __constructor : function() {
                this.__base();
            },

            /**
             *
             * @param    {Object}    request         data request object
             * @param    {Object}    responder       responder object
             */
             performAsync : function(request, responder) {
                 var action = request.action;
                 var record = request.record;

                 var query = "UPDATE ClientSyncConflict SET override_flag = '" + action
                     + "' WHERE local_id = '" + record.local_id + "' AND Id = '" + record.Id + "';";
                 this.__executeQuery(query, function(result) {
                     responder.result(result);
                 })
             },


             __executeQuery : function(query, binds, callback){

                 if(typeof binds === "function"){
                     callback = binds;
                     binds = {};
                 }

                 var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                 var request = nativeService.createSQLRequest();

                 request.bind("REQUEST_COMPLETED", function(evt){
                     callback.call(this, SVMX.toObject(evt.data.data));
                 }, this);

                 request.bind("REQUEST_ERROR", function(evt){
                     SVMX.getLoggingService().getLogger(evt.data);
                     callback.call(this, false);
                 }, this);

                 request.execute({query : query, async : true, queryBinds: binds });
             }
         });

         /**
          *  Get number of output docs count
          *
          *  @class      com.servicemax.client.offline.sal.model.toolspages.operations.GetOutputDocsCount
          *  @extends    com.servicemax.client.mvc.api.Operation
          */
          impl.Class("GetOutputDocsCount", com.servicemax.client.mvc.api.Operation, {
             __constructor : function() {
                 this.__base();
             },

             /**
              *
              * @param    {Object}    request         data request object
              * @param    {Object}    responder       responder object
              */
              performAsync : function(request, responder) {
                  var clientType = SVMX.getClient().getApplicationParameter("client-type").toLowerCase();
                  var query;
                  if(clientType == "laptop") {
                      query = "SELECT Id FROM SFAttachments WHERE Id LIKE 'local_%'";
                  }
                  else if(clientType == "mobile") {
                      query = "SELECT Id FROM SmartDocHTML";
                  }

                  this.__executeQuery(query, function(result) {
                      responder(result.length);
                  })
              },


              __executeQuery : function(query, binds, callback){

                  if(typeof binds === "function"){
                      callback = binds;
                      binds = {};
                  }

                  var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                  var request = nativeService.createSQLRequest();

                  request.bind("REQUEST_COMPLETED", function(evt){
                      callback.call(this, SVMX.toObject(evt.data.data));
                  }, this);

                  request.bind("REQUEST_ERROR", function(evt){
                      SVMX.getLoggingService().getLogger(evt.data);
                      callback.call(this, false);
                  }, this);

                  request.execute({query : query, async : true, queryBinds: binds });
              }
          });

          impl.Class("AllowApiAccess", com.servicemax.client.mvc.api.Operation, {
             __constructor : function() {
                 this.__base();
             },

             /**
              *
              * @param    {Object}    request         data request object
              * @param    {Object}    responder       responder object
              */
              performAsync : function(request, responder) {
                  var clientType = SVMX.getClient().getApplicationParameter("client-type").toLowerCase();
                  var query;
                  if (clientType == "laptop") {
                      query = "SELECT value as api_key FROM MobileDeviceSettings WHERE setting_id = 'Allow API Access';";
                      this.__executeQuery(query, function(result) {
                          responder(result);
                      })
                  }
                  else if (clientType == "mobile") {
                      responder(false);
                  }

              },


              __executeQuery : function(query, binds, callback){

                  if(typeof binds === "function"){
                      callback = binds;
                      binds = {};
                  }

                  var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                  var request = nativeService.createSQLRequest();

                  request.bind("REQUEST_COMPLETED", function(evt){
                      callback.call(this, SVMX.toObject(evt.data.data[0].api_key));
                  }, this);

                  request.bind("REQUEST_ERROR", function(evt){
                      SVMX.getLoggingService().getLogger(evt.data);
                      callback.call(this, false);
                  }, this);

                  request.execute({query : query, async : true, queryBinds: binds });
              }
          });


    }
})();
