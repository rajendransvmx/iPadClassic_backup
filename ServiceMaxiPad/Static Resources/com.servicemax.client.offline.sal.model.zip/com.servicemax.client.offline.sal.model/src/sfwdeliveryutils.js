
/**
 * # Package #
 *
 * This file needs a description
 *
 * @class com.servicemax.client.offline.sal.model.sfwdeliveryutils
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function() {
    var impl = SVMX.Package("com.servicemax.client.offline.sal.model.sfwdeliveryutils");
impl.init = function() {

        var OfflineExprUtils = com.servicemax.client.offline.sal.model.utils.Expressions;
        var SyncUtils = com.servicemax.client.offline.sal.model.utils.SyncData;
        var MetaDataUtils = com.servicemax.client.offline.sal.model.utils.MetaData;
        var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;

        var DataUtils = com.servicemax.client.offline.sal.model.utils.Data;
        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
        var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("SFWDELIVERY");


        function execQuery(inParams) {
            var d = $.Deferred();
            var req = nativeService.createSQLRequest();
            req.bind("REQUEST_COMPLETED", function(evt) {
                d.resolve(evt.data.data);
            });
            req.bind("REQUEST_ERROR", function(evt) {
                d.reject(evt.data.data);
            });

            req.execute({
                query: inParams.query,
                queryParams: inParams.queryParams
            });
            return d;
        }

        /**
         *  provides methods to process wizard data
         *
         *  @class      com.servicemax.client.offline.sal.model.sfwdeliveryutils.Utils
         *  @extends    com.servicemax.client.lib.api.Object
         */
        impl.Class("Utils", com.servicemax.client.lib.api.Object, {}, {
            /**
             * Takes in rawdata records and contructs a structrue data model
             *
             * @param    {Object}      inRawData
             *
             * @return    {Deferred}
             */
            processWizardRawData: function(inRawData) {
                var defer = SVMX.Deferred();
                var me = this;

                this.__fetchWizardData( inRawData )
                .then(
                    SVMX.proxy(this, function(wizards){
                        /*
                        wizards = [
                            {
                                expression_id: "",
                                is_active: "true",
                                local_id: "44",
                                object_name: "SVMXC__Service_Order__c",
                                sequence: "401",
                                wizard_description: "",
                                wizard_id: "a0ao0000000GA69AAG",
                                wizard_name: "Smart Documents",
                                install_base: "" // A string if it is an InstallBase object
                            }
                        ]
                        */
                        if (wizards && wizards.length > 0) {
                            var i, l = wizards.length,
                                wids = [],
                                wizardMap = {};
                            for (i = 0; i < l; i++) {
                                wids.push(wizards[i].wizard_id);

                                // steps
                                wizardMap[wizards[i].wizard_id] = [];

                                // TODO: expressions
                            }
                            //get the wizard steps
                            this.__fetchWizardStepsData( inRawData, wids )
                            .then(SVMX.proxy(this, this.__filterExternalSteps, inRawData, wids))
                            .then(function(steps) {
                                /*
                                steps = [
                                    {
                                        action_description: "Does things"
                                        action_id: "a0ao0000001D053AAC"
                                        action_name: "Lookup Test"
                                        action_type: "SFM"
                                        class_name: ""
                                        expressionPassed: true
                                        expression_id: ""
                                        local_id: "78"
                                        method_name: ""
                                        perform_sync: "false"
                                        process_id: "a0ao0000000GDA4AAO"
                                        sequence: "1.00"
                                        wizard_id: "a0ao0000000GDANAA4"
                                    }
                                ]
                                */
                                if (steps && steps.length > 0) {
                                    var i, l = steps.length;


                                    // segregate the steps
                                    for (i = 0; i < l; i++) {
                                        wizardMap[steps[i].wizard_id].push(steps[i]);
                                    }

                                    // populate the wizards with steps
                                    l = wizards.length;
                                    for (i = 0; i < l; i++) {
                                        wizards[i].steps = wizardMap[wizards[i].wizard_id];
                                    }
                                }

                                // If InstallBase application installed
                                var externalInstalled = SVMX.getClient().getApplicationParameter("InstallBase");
                                var testObjName = SVMX.OrgNamespace + "__Service_Order__c";
                                var currObjName = inRawData && inRawData.attributes && inRawData.attributes.type;
                                var externalWizard;

                                if (externalInstalled && testObjName === currObjName) {
                                    // This is a WorkOrder, need to see if we have any details to send to external application
                                    //TODO: Also look on main object
                                    var found = me.__checkHaveProductsServiced(inRawData);
                                    // Cycle through each child type

                                    externalWizard = {
                                        expression_id: "",
                                        is_active: "true",
                                        local_id: "99999999",
                                        object_name: wizards[0].object_name,
                                        sequence: "99999999",
                                        wizard_description: TS.T("TODO", ""),
                                        wizard_id: "",
                                        wizard_name: TS.T("TAG0028", "ProductIQ"),
                                        steps: [{
                                            action_description: TS.T("TODO", ""),
                                            action_id: "",
                                            action_name: TS.T("TAG0029", "Open tree view"),
                                            action_type: "EXTERNAL",
                                            class_name: "",
                                            expressionPassed: found,
                                            expression_id: "",
                                            local_id: "999999",
                                            method_name: "",
                                            perform_sync: "false",
                                            process_id: "Products Serviced",
                                            sequence: "1.00",
                                            wizard_id: ""
                                        }]
                                    };
                                    wizards.unshift(externalWizard);

                                }

                                // Add a new wizard step if this is an InstallBase object.
                                if (externalInstalled && wizards && wizards.length > 0 && wizards[0].install_base) {
                                    externalWizard = {
                                        expression_id: "",
                                        is_active: "true",
                                        local_id: "99999999",
                                        object_name: wizards[0].object_name,
                                        sequence: "99999999",
                                        wizard_description: TS.T("TODO", ""),
                                        wizard_id: "",
                                        wizard_name: TS.T("TAG0028", "ProductIQ"),
                                        steps: [{
                                            action_description: TS.T("TODO", ""),
                                            action_id: "",
                                            action_name: TS.T("TAG0029", "Open tree view"),
                                            action_type: "EXTERNAL",
                                            class_name: "",
                                            expressionPassed: true,
                                            expression_id: "",
                                            local_id: "999999",
                                            method_name: "",
                                            perform_sync: "false",
                                            process_id: "View",
                                            sequence: "1.00",
                                            wizard_id: ""
                                        }]
                                    };
                                    wizards.unshift(externalWizard);
                                }

                                defer.resolve( wizards );
                            });
                        } else {
                            defer.resolve( [] );
                        }
                    }),
                    SVMX.proxy(this, function(data) {
                        defer.resolve( data );
                    })
                );

                return defer;
            },

            /**
             * Search for the existence of an Installed Product ID in a record
             *
             *
             */
            __hasInstalledProductField : function(record) {
                var fieldDef, fields, i, found = false;
                var serialObjectName = SVMX.OrgNamespace + "__Installed_Product__c";

                if (record && record._fields && record._fields.fields) {
                    fields = record._fields.fields;
                    for (var key in fields) {
                        if (fields.hasOwnProperty(key)) {
                            fieldDef = fields[key];
                            if (fieldDef && fieldDef.referenceTo && fieldDef.referenceTo instanceof Array) {
                                for (k = 0; k < fieldDef.referenceTo.length; k++) {
                                    if (fieldDef.referenceTo[k] == serialObjectName) {
                                        var componentName = fieldDef.name;
                                        var component = record[componentName];
                                        if (component && component.fieldvalue && component.fieldvalue.key) {
                                            found = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                return found;
            },

            /**
             * Search for the existence of an Installed Product ID in a record
             * searching both Header and details.
             *
             */
            __checkHaveProductsServiced : function(inRawData) {
                var found = false;

                var serialObjectName = SVMX.OrgNamespace + "__Installed_Product__c";
                var i, k, lines;
                var serialIds = [];

                if (!found) {
                    // Look in the header record for an component aka installed product
                    found = this.__hasInstalledProductField(inRawData);
                }

                if (!found && inRawData.details) {
                    for(var prop in inRawData.details) {
                       lines = inRawData.details[prop].lines.length;
                       for (k = 0; !found && k < lines; k++) {
                            var record = inRawData.details[prop].lines[k][serialObjectName];
                            found = this.__hasInstalledProductField(record);
                        }
                    }
                }

                return found;
            },

            /*
             * Filter InstallBase aka Installigence aka ProductIQ processes
             *
             */

            __filterExternalSteps : function(inRawData, wids, steps) {
                var defer = SVMX.Deferred();
                // If InstallBase application installed
                var externalInstalled = SVMX.getClient().getApplicationParameter("InstallBase");

                if (externalInstalled && steps && steps.length > 0 && wids && wids.length > 0) {
                    var i, l = steps.length;
                    // Get object types

                    var processIds = [];
                    var opProcessIds = [];
                    // CheckList SFMs are okay to have available for InstallBase objects.
                    for (i = 0; i < l; i++) {
                        if (steps[i].action_type === 'SFM') {
                            processIds.push("'" + steps[i].process_id + "'");
                        } else if (steps[i].action_type === 'OUTPUT_DOCUMENT') {
                            opProcessIds.push("'" + steps[i].process_id + "'");
                        }
                    }
                    if (processIds.length > 0 || opProcessIds.length > 0) {
                        var joined = processIds.join(',');
                        var opJoined = opProcessIds.join(',');

                        var query = "SELECT pc.process_id as process_id FROM SFProcessComponent AS pc"
                            + " JOIN InstallBaseObject as ib ON ib.object_name = pc.object_name"
                            + " JOIN SFSourceUpdate AS su ON pc.process_id = su.process"
                            + " WHERE pc.process_id in (" + joined + ")"
                            + " UNION"
                            + " SELECT pc.process_id as process_id FROM SFProcessComponent as pc"
                            + " JOIN InstallBaseObject as ib ON ib.object_name = pc.object_name"
                            + " JOIN SFProcess as p ON pc.process_id = p.process_id"
                            + " WHERE pc.component_type in ('TARGET', 'TARGETCHILD')"
                            + " AND p.process_type != 'VIEW RECORD' AND pc.process_id IN (" + joined + ")";
                        var opQuery = "SELECT pc.process_id FROM SFProcessComponent AS pc"
                            + " JOIN InstallBaseObject as ib ON ib.object_name = pc.object_name"
                            + " JOIN SFSourceUpdate AS su ON pc.Id = su.target_process_node"
                            + " WHERE pc.process_id in (" + opProcessIds + ")";

                        var skipResults = this.__executeDeferredQuery( query );
                        var skipOPResults = this.__executeDeferredQuery( opQuery );
                        SVMX.when([skipResults, skipOPResults]).then(function(stepResults, opStepResults) {
                            var tempSkip = {};
                            for (i = 0; i < stepResults.length; i++) {
                                tempSkip[stepResults[i].process_id] = true;
                            }
                            for (i = 0; i < opStepResults.length; i++) {
                                tempSkip[opStepResults[i].process_id] = true;
                            }
                            for (i = 0; i < l; i++) {
                                if (tempSkip[steps[i].process_id]) {
                                    steps[i].expressionPassed = false;
                                }
                            }

                            defer.resolve(steps);
                        });
                    } else {
                        defer.resolve(steps);
                    }
                } else {
                    // Just pass on the steps
                    defer.resolve(steps);
                }

                return defer;
            },

            __fetchExternalObjectTypes : function() {
                var query = "SELECT Object_Name FROM InstallBaseObject";
                var deferQueryResults = this.__executeDeferredQuery( query );
                var defer = SVMX.Deferred();

                deferQueryResults.then(
                    SVMX.proxy(this, function(results){
                        defer.resolve( results );
                    }),
                    SVMX.proxy(this, function(results){
                        defer.reject( results );
                    })
                );

                return defer;
            },

            /*
             * generates the wizard fetch sql and executes it
             *
             * @private
             * @param    {Object}      inRawData
             *
             * @return    {Deferred}
             */
            __fetchWizardData : function(inData) {
                var sql = "SELECT w.*, ib.object_name AS install_base FROM SFWizard AS w " +
                "LEFT JOIN InstallBaseObject AS ib ON ib.object_name = w.object_name " +
                "WHERE w.{{key}}='{{value}}' ORDER BY CAST(w.sequence AS INTEGER)",
                    data = {
                        key: "object_name",
                        value: inData.attributes.type
                    },
                    query = SVMX.string.substitute( sql, data ),
                    deferQueryResults = this.__executeDeferredQuery( query ),
                    defer = SVMX.Deferred();

                deferQueryResults.then(
                    SVMX.proxy(this, function(results){
                        this.__filterDataByExpression( inData, results)
                        .then( function(filteredWizard){
                            defer.resolve( filteredWizard );
                        });
                    }),
                    SVMX.proxy(this, function(results){
                        defer.reject( results );
                    })
                );

                return defer;
            },

            /*
             * filters and evaluates the wizard data after the sql execution
             *
             * @private
             * @param    {Object}      inRawData
             * @param    {Object}      inWizData
             *
             * @return    {Deferred}
             */
            __filterDataByExpression : function(inRawData, inWizData) {
                //prep work for the deferred collection
                var collection = [],
                    wizardExpressions = [],
                    expressionResults = {},
                    defer = $.Deferred(),
                    i = 0;

                for (; i < inWizData.length; i++) {
                    if (inWizData[i].expression_id) {
                        expressionResults[ inWizData[i].expression_id ] = undefined;
                        wizardExpressions.push( inWizData[i] );
                        collection.push( $.Deferred() );
                    }
                }

                //
                SVMX.when( collection )
                .done(
                    SVMX.proxy(this, function(){
                        // this is carry over code logic from the old process
                        var filteredWizard = SVMX.array.filter(inWizData, function(wizard) {
                            return !wizard.expression_id || expressionResults[ wizard.expression_id ];
                        });

                        /*
                            After we have removed cells from our rows, our sequence changes
                                    Grid Display
                            Original    After (D, F, G) removed
                            A B         A B
                            C D         C H
                            E F         E J
                            G H         I
                            I J

                                    Row Display
                            Original
                            A B C D E F G H I J

                            After (D, F, G) removed
                            A B C H E J I

                            Before fix with (D, F, G) removed using just sequence
                            A B C E H I J
                        */

                        //Generate 3 buckets for our wizards (Column 1, Column 2, No Column)
                        var orderedWizards = [];
                        var noSeqWizards = []; //Holder for wizards without a sequence
                        var column = '1';
                        var notBlank = false;
                        while (filteredWizard.length) {
                            notBlank = true;
                            for (var i = 0; i < filteredWizard.length; i++) {
                                //Remove wizards without a sequence to be handled later
                                if (filteredWizard[i].sequence == '') {
                                    noSeqWizards.push(filteredWizard[i]);
                                    filteredWizard.splice(i, 1);
                                    notBlank = false;
                                    break;
                                }
                                if (SVMX.stringEndsWith(filteredWizard[i].sequence, column)) {
                                    orderedWizards.push(filteredWizard[i]);
                                    filteredWizard.splice(i, 1);
                                    break;
                                }
                            }

                            if (notBlank) {
                                //Switch between columns
                                column = (column == '1') ? '2' : '1';
                            }
                        }

                        //Merge back or non sequenced wizards back on the list
                        orderedWizards = orderedWizards.concat(noSeqWizards);

                        defer.resolve( orderedWizards );
                    })
                );

                SVMX.array.forEach(wizardExpressions, SVMX.proxy(this, function(record, idx) {
                    OfflineExprUtils.evaluate({
                        expressionId: record.expression_id,
                            data: [inRawData],
                            onSuccess: SVMX.proxy(this, function(result) {
                                expressionResults[record.expression_id] = result[0];
                                collection[ idx ].resolve( result );
                            }),
                            // If it fails to execute the expression, show it just to be safe.
                            onError: SVMX.proxy(this, function(result) {
                                expressionResults[record.expression_id] = true;
                                collection[ idx ].resolve( result );
                            })
                        });
                }));

                return defer;
            },

            /*
             * generates the wizard steps fetch sql and executes it
             *
             * @private
             * @param    {Object}      inRawData
             * @param    {Object}      inWizards
             *
             * @return    {Deferred}
             */
            __fetchWizardStepsData : function(inData, inWizards) {
                var value = SVMX.string.substitute(
                        "'{{value}}'", {
                            value: inWizards.join("','")
                        }
                    );
                var sql = "select * from SFWizardComponent where {{key}} in ({{value}}) AND (action_type IN ('SFM', 'OUTPUT_DOCUMENT', 'CHECKLIST', 'OTHERS')) ORDER BY CAST(sequence AS FLOAT)",
                    data = {
                        key: "wizard_id",
                        value: value
                    },
                    query = SVMX.string.substitute( sql, data ),
                    deferQueryResults = this.__executeDeferredQuery( query ),
                    defer = $.Deferred();

                deferQueryResults.then(
                    SVMX.proxy(this, function(results){
                        this.__filterWizardStepsByExpressions(inData, results)
                        .then( function(wizardSteps){
                            defer.resolve( wizardSteps );
                        });
                    }),
                    SVMX.proxy(this, function(results){
                        defer.resolve( results );
                    })
                );

                return defer;
            },

            /*
             * filters and evaluates wizard step expressions after the sql execution
             *
             * @private
             * @param    {Object}      inRawData
             * @param    {Object}      inWizStepsData
             *
             * @return    {Deferred}
             */
            __filterWizardStepsByExpressions: function(inRawData, inWizStepsData) {
                //prep work
                var collection = [],
                    defer = $.Deferred();

                for (var i = 0; i < inWizStepsData.length; i++) {
                    collection.push( $.Deferred() );
                }

                SVMX.when( collection )
                .done( function(tmp){
                    defer.resolve( inWizStepsData );
                });

                SVMX.array.forEach(inWizStepsData, SVMX.proxy(this, function(record, idx) {
                    if (!record.expression_id){
                        record.expressionPassed = true;
                        collection[ idx ].resolve();
                    } else {
                        OfflineExprUtils.evaluate({
                            expressionId: record.expression_id,
                                data: [inRawData],
                                onSuccess: SVMX.proxy(this, function(result) {
                                    record.expressionPassed = result[0];
                                    collection[ idx ].resolve( result );
                                }),
                                // If it fails to execute the expression, show it just to be safe.
                                onError: SVMX.proxy(this, function(result) {
                                    record.expressionPassed = true;
                                    collection[ idx ].resolve( result );
                                })
                            });
                    }
                }));

                return defer;
            },

            /*
             * executes a deferred query
             *
             * @private
             * @param    {Object}      inQuery
             *
             * @return    {Deferred}
             */
            __executeDeferredQuery: function(inQuery) {
                var defer = SVMX.Deferred();
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var request = nativeService.createSQLRequest();

                request.bind("REQUEST_COMPLETED", function(evt) {
                    defer.resolve(SVMX.toObject(evt.data.data));
                }, this);

                request.bind("REQUEST_ERROR", function(evt) {
                    SVMX.getLoggingService().getLogger(evt.data);
                    defer.reject(evt.data);
                }, this);

                request.execute({
                    query: inQuery,
                    async: true
                });

                return defer;
            }
        }, {});

        /**
         *  provides methods to process wizard data
         *
         *  @class      com.servicemax.client.offline.sal.model.sfwdeliveryutils.PlatformSpecifics
         *  @extends    com.servicemax.client.lib.api.Object
         */
        impl.Class("PlatformSpecifics", com.servicemax.client.lib.api.Object, {
            __logger: null,
            __constructor: function() {
                this.__logger = SVMX.getLoggingService().getLogger("SFW:Offline:PlatformSpecifics");
                /*Variables for Custom Actions */
                this.__wizCompData = {};
                this.__customParamArray = [];
                this.__record = {};
                this.__ApiKey = this.__getApiKey();
                
            },

            getSupportedActionTypes: function() {
                return [];
            },

            /**
             * Start the SFM action.
             * Returns a Promise that will resolve immediately unless the actionType
             * is OTHER. If OTHER it will resolve right before the Custom URL is launched
             * or Web-Service resolves or fails.
             * If it fails an object in the form {text:"", type:""} will be passed to fail.
             */
            performAction: function(action) {
                var d = SVMX.Deferred();
                var type = action.actionType;

                if (type == "SFM") {
                    d.resolve();
                    this.__performSFMAction(action);
                } else if (type == "OUTPUT_DOCUMENT") {
                    d.resolve();
                    this.__performOUTPUTDOCUMENTAction(action);
                } else if (type == "EXTERNAL") {
                    d.resolve();
                    this.__performExternalAction(action);
                } else if (type == "CHECKLIST") {
                    d.resolve();
                    this.__performChecklistAction(action);
                } else if(type == "OTHERS"){
                    d = this.__performCustomAction(action);
                }

                return d.promise();
            },

            /**
            * Perform launching of Custom URL or WebService based on customActionType
            */
            __performCustomAction : function(action){
                var d = SVMX.Deferred();

                this.__logger.info("Performing SFM action => " + action.getName());
                var me = this;
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var request = nativeService.createSQLRequest();
                var recId = action.getRoot().recordId;
                var processId = action.getData().actionDef[SVMX.OrgNamespace + "__Process__r"][SVMX.OrgNamespace + "__ProcessID__c"];
                var record = action.getRoot().record; //gives the row data of current record

                request.bind("REQUEST_COMPLETED", function(evt) {
                    var data = evt.data.data;
                    if(data && data[0]){
                        var processRowData = data[0];
                        var innerD;
                        if(processRowData.customActionType.toLowerCase() == "url"){
                            innerD = me.__getParametersForCustomAction(processRowData, record, processId, recId);
                            innerD = innerD.then(SVMX.proxy(this, function(customParameters) {
                                return me.__buildUrlAndLaunch(record, recId, customParameters, processRowData);
                            }));
                            //innerD = me.__buildUrlAndLaunch(processRowData, record, processId);
                            innerD = innerD.done(SVMX.proxy(this, function() {
                                d.resolve();
                            }));
                            innerD = innerD.fail(SVMX.proxy(this, function(error) {
                                d.reject(error);
                            }));
                        }else if (processRowData.customActionType.toLowerCase() == "web-service"){
                            innerD = me.__getParametersForCustomAction(processRowData, record, processId, recId);
                            innerD = innerD.then(SVMX.proxy(this, function(customParameters) {
                                return me.__performWebServiceCall(record, recId, customParameters, processRowData);
                            }));
                            // TODO: Clean up so we do not need below, innerD can be d
                            innerD = innerD.done(SVMX.proxy(this, function(result) {
                                d.resolve(result);
                            }));
                            innerD = innerD.fail(SVMX.proxy(this, function(error) {
                                d.reject(error);
                            }));
                        } else {
                            d.reject({
                                text: SVMX.string.substitute(TS.T("TODO", "Unkown process type {{processType}}. Please contact your administrator."), {
                                        processType: processRowData.customActionType
                                    }),
                                type: "ERROR"
                            });
                        }
                    }
                });

                request.bind("REQUEST_ERROR", function(evt) {
                    SVMX.getLoggingService().getLogger("__getRealProcessId Failed" + evt.data.data);

                    d.reject({
                        text: TS.T("IPAD.IPAD023_TAG006", "Process not found; check your configuration"),
                        type: "ERROR"
                    });
                });

                request.execute({
                       query: "SELECT * FROM SFWizardComponent WHERE process_id = '"+processId+"'"
                });

                return d.promise();
            },

            /**
            * Creates url by appending the encoded parameters
            */
            __buildUrlAndLaunch : function(record, recId, customParameters, processRowData){
                var urlData = this.__buildURLPayload(record, recId, customParameters, processRowData);
                var needInstanceURL = (processRowData.customUrl.indexOf("/") == 0) ? true : false;
                var d;
                if(needInstanceURL){
                    d = this.__checkConnectivity();
                }else{
                    d = this.__checkConnectivityAlwaysTrue();
                }
                d = d.then(SVMX.proxy(this, function(isConnected) {
                    var innerD = SVMX.Deferred();
                    if (isConnected) {
                        // Do we need instance url
                        if (needInstanceURL) {
                            // Will force InstanceURL to be set
                            innerD = this.__getUserInfoFromWeb();
                        } else {
                            innerD.resolve(false);
                        }
                     } else {
                        innerD.reject({
                            text: TS.T('IPAD018_TAG031', 'Internet connectivity lost. Please retry when connectivity is available.'),
                            type: "INFO"
                        });
                    }
                    return innerD.promise();
                }));

                d = d.then(SVMX.proxy(this, function(needInstanceURL) {
                    var innerD = SVMX.Deferred();
                    if (needInstanceURL) {
                        innerD = this.__loginInfo(); // Need InstanceUrl
                    } else {
                        innerD.resolve(false);
                    }

                    return innerD.promise();
                }));

                d = d.then(SVMX.proxy(this, function(loginInfo) {
                    var innerD = SVMX.Deferred();
                    // Pre-append with Instance URL if it starts with /
                    var correctedUrl = processRowData.customUrl;
                    if (loginInfo && loginInfo.InstanceURL) {
                        correctedUrl = loginInfo.InstanceURL + correctedUrl;
                    }

                    // if the link does not have a colon, we are assuming this is a url, so we prepend http://
                    correctedUrl = (correctedUrl.indexOf(":") == -1) ? "http://" + correctedUrl : correctedUrl;
                    var fullUrl = correctedUrl;
                    if(urlData.length > 0){
                      fullUrl = correctedUrl + "?" + urlData.join("&");
                    }
                    //var fullUrl = correctedUrl + "?" + urlData.join("&");
                    // We are done this will open a browser that is out of our control.
                    //innerD.resolve();
                    innerD = this.__launchUrl(fullUrl);

                    return innerD.promise();
                }));

                return d.promise();
            },

            __loginInfo : function() {
                var d = SVMX.Deferred();
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var request = nativeService.createLoginInfoRequest();

                request.bind("REQUEST_COMPLETED", function(evt){
                    var result = evt.data.data;
                    d.resolve(result);
                }, this);
                request.bind("REQUEST_ERROR", function(evt){
                    d.reject({
                        text: TS.T('TODO', 'Could not determine destination.'),
                        type: "INFO"
                    });
                }, this);

                request.execute();

                return d.promise();
            },

            __buildURLPayload : function(record, recId, customParams, wizardConfig) {
                // Go through each parameter and set appropriatly
                var map;
                var urlData = [];
                for (var i = 0; i < customParams.length; i++) {
                    map = this.__extractRecordData(customParams[i].ParameterName, customParams[i].ParameterType, customParams[i].ParameterValue, record);
                    if (map) {
                        urlData.push(encodeURIComponent(map.valueMap.key) + "=" + encodeURIComponent(map.valueMap.value));
                    }
                }

                return urlData;
            },

            /**
            * Method to launch url.
            * For MFL its opening window with url. other clients may need a native request
            **/
          __launchUrl : function(urlToLaunch) {
                var d = SVMX.Deferred();
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var browserRequest = nativeService.createBrowserRequest();

                browserRequest.bind("REQUEST_COMPLETED", function(evt){
                    var result = evt.data.data;
                    d.resolve(result);
                }, this);
                browserRequest.bind("REQUEST_ERROR", function(evt){
                    d.reject({
                      text: TS.T("TODO", "The application does not exist. Please contact your system administrator to update the application path or install the necessary software."),
                      type: "INFO"
                    });
                }, this);

                browserRequest.execute({
                    link: urlToLaunch
                });

                return d.promise();
            },

            /**
             * Method to get the custom action parameters stored in CustomActionParam table
            **/
            //duplicate need to make it generic
            __getParametersForCustomAction : function(rowData, record, dispatchId, recId){
                var d = SVMX.Deferred();

                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var sqlReq = nativeService.createSQLRequest();
                var me = this;
                var urlParams = {};
                sqlReq.bind("REQUEST_COMPLETED", function(evt) {
                    var customParameters = evt.data.data;
                    d.resolve(customParameters);
                });

                sqlReq.bind("REQUEST_ERROR", function(evt) {
                    SVMX.getLoggingService().getLogger("__getRealProcessId Failed" + evt.data.data);

                    d.reject({
                        text: TS.T("TODO", "Unable to determine parameters."),
                        type: "ERROR"
                    });
                });

                sqlReq.execute({
                    query: "Select * from CustomActionParams where DispatchProcessId = '"+dispatchId+"'"
                });

                return d.promise();
             },

             __generateStringValueMap : function(key, value, value1) {
                 key = key || "";
                 value = value || "";
                 value1 = value1 || "";

                 return {
                     stringMap: {
                         key: key,
                         value1: value1,
                         value: value
                     }
                 };
             },
             __generateValueMap : function(key, value) {
                 key = key || "";
                 value = value || "";

                 return {
                     valueMap: {
                         value: value,
                         key: key,
                         valueMap: "",
                         values: ""
                     }
                 };
            },

            /**
             * Method to get parent and child data required for custom web service
            **/
            __performWebServiceCall : function(record, recId, customParams, wizardConfig){
                var outerD = SVMX.Deferred();
                // Check connection
                var d = this.__checkConnectivity();

                d = d.then(SVMX.proxy(this, function(isConnected) {
                    var innerD = SVMX.Deferred();
                    if (isConnected) {
                        innerD = this.__getUserInfoFromWeb();
                    } else {
                        innerD.reject({
                            text: TS.T('IPAD018_TAG031', 'Internet connectivity lost. Please retry when connectivity is available.'),
                            type: "INFO"
                        });
                    }

                    return innerD.promise();
                }));

                d = d.then(SVMX.proxy(this, function(userInfo) {
                    return this.__makeHttpWSCall(record, recId, customParams, wizardConfig, userInfo);
                }));

                d = d.done(SVMX.proxy(this, function(result) {
                    outerD.resolve(result);
                }));

                d = d.fail(SVMX.proxy(this, function(error) {
                    error = error || {};
                    error.type = error.type || "INFO";
                    error.text = error.text ||  "Unknown Exception during WS call.";

                    outerD.reject({text: error.text, type: error.type});
                }));

                return outerD.promise();
            },

             __extractRecordData : function(parameterName, parameterType, parameterValue, record) {
                var key = parameterName || null;
                var value = null;
                var valueMap = null;

                if (key) {
                    if (parameterType == "Field Name") {
                        var obj = record[parameterValue];
                        if (obj === undefined || obj === null || typeof obj === 'string') {
                            value = obj || "";
                        } else if (obj.fieldvalue && obj.fieldvalue.key) {
                            value = obj.fieldvalue.key || "";
                        } else {
                            value = "";
                        }
                    } else {
                    	value = this.__checkingForLitralsAndPassValue(parameterValue, record);
                    	//value = parameterValue || "";
                    }

                    valueMap = this.__generateValueMap(key, value);
                }

                return valueMap;
            },
            
            __checkingForLitralsAndPassValue : function(value, record){
            	var litralValue = value.toUpperCase();
            	var att = "";
            	switch (litralValue) {
                case "SVMX.PRODUCTIQWORKORDERID": // Here passing name os the WO
                	if(this.__IsThisWORecord(record.attributes.type)){
                		var obj = record["Id"];
						if (obj === undefined || obj === null || typeof obj === 'string') {
							value = obj || "";
						} else if (obj.fieldvalue && obj.fieldvalue.key) {
							value = obj.fieldvalue.key || "";
						} else {
							value = "";
						}
                	}else{
						value = "";
					}
                    att = value;
                    break;
                case "SVMX.USERNAME":
                	var userName = SVMX.getCurrentApplication().__userInfo.UserLogin;
                    att = userName;
                    break;
                case "SVMX.DATAACCESSAPIKEY":
                    att = this.__ApiKey;;
                    break;
                default:
        			att = value || "";;
                }
                return att ;
            },
            
        __IsThisWORecord : function(record){
        	var workOrderObjName = SVMX.OrgNamespace + "__Service_Order__c";
        	if(record == workOrderObjName)
        		return true
    
        	return false;
        },
        	
		__getApiKey : function() {
            var me = this;
            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var request = nativeService.createGenerateApiKeyRequest();
            request.bind("REQUEST_COMPLETED", function(evt){
               me.__ApiKey = evt.data.data;
            }, this);

            request.bind("REQUEST_ERROR", function(evt){
                me.__ApiKey = "";
            }, this);
            request.execute();
        },

            __buildWSSoapPayload : function(record, recId, customParams, wizardConfig) {
                // Build standard data which is always present.
                var soapData = SVMX.toXML({userId: ""}) + SVMX.toXML({groupId: ""}) + SVMX.toXML({profileId: ""}) + SVMX.toXML({fieldsToNull: ""});
                soapData += SVMX.toXML(this.__generateStringValueMap("key", record.attributes.type, recId));

                // Now go through each parameter and set appropriatly
                var valueMap;
                for (var i = 0; i < customParams.length; i++) {
                    valueMap = this.__extractRecordData(customParams[i].ParameterName, customParams[i].ParameterType, customParams[i].ParameterValue, record);
                    if (valueMap) {
                        soapData += SVMX.toXML(valueMap);
                    }
                }

                return soapData;
            },

            __makeHttpWSCall : function(record, recId, customParams, wizardConfig, userInfo) {
                var d = SVMX.Deferred();
                // Build payload, copied from what we saw delivered from iPad
                var soapData = this.__buildWSSoapPayload(record, recId, customParams, wizardConfig);
                var sync = (wizardConfig.perform_sync === "true") ? true : false;

                var params = {
                    method: "POST",
                    protocol: "SOAP",
                    methodName : wizardConfig.method_name,
                    endPoint : wizardConfig.class_name,
                    soapData : soapData
                };

                var sr = new window.com.servicemax.client.sal.impl.WSSoapRequest({
                    sessionId : userInfo.UserSessionId,
                    endPoint : wizardConfig.class_name
                });

                var rtm = new window.com.servicemax.client.sal.impl.RPRuntimeMode();

                params.uri = rtm.getApexSoapUrl(params.endPoint);
                params.data = sr._getData(params.soapData, params);

                params.headers = {
                    "SOAPAction" : wizardConfig.method_name,
                    "Content-Type" : "text/xml"
                };

                var http = com.servicemax.client.offline.sal.model.nativeservice.Facade.createHTTPRequest();

                http.bind("REQUEST_COMPLETED", function(evt){
                    var syncManagerDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
                    var syncManager = syncManagerDef.getInstance();
                    if (sync && syncManager) {
                        syncManager.startSync({type: "AGGRESSIVE"});
                    }

                    d.resolve(evt.data.data);
                });
                http.bind("REQUEST_ERROR", function(evt){
                    // Parse response and get error message
                    var response = evt.data.data;
                    var message = TS.T("TODO", "Unable to make request");
                    if ((typeof response === 'string')) {
                        var jsonResponse = SVMX.toObject(response);
                        if ((typeof jsonResponse !== 'string') && jsonResponse.ResponseBody) {
                            var xml = SVMX.stringToXML(jsonResponse.ResponseBody);
                            if(xml){
                                var jsonXML = SVMX.xmlToJson(xml);
                                if (jsonXML && jsonXML.Envelope && jsonXML.Envelope.Body && jsonXML.Envelope.Body.Fault && jsonXML.Envelope.Body.Fault.faultstring) {
                                    message = jsonXML.Envelope.Body.Fault.faultstring;
                                }
                            }
                        }
                    }

                    d.reject({
                        text: message,
                        type: "ERROR"
                    });
                });

                http.execute(params);

                return d.promise();
            },

            // Make call to get user info which will contain the current Session ID.
            // This way the native layer will be responsible to refresh it rather than getting a possibly stale version from the DB.
            __getUserInfoFromWeb :  function() {
                var d = SVMX.Deferred();

                var http = com.servicemax.client.offline.sal.model.nativeservice.Facade.createHTTPRequest();

                var request = {
                    method : "POST",
                    uri : "/services/apexrest/"+SVMX.OrgNamespace+"/svmx/MobServiceIntf/getUserInfo",
                    data : {}
                };

                http.bind("REQUEST_COMPLETED", function(evt){
                    if (evt.data.status == "200") {
                        d.resolve(evt.data.data);
                    } else {
                        d.reject();
                    }
                }, this);

                http.bind("REQUEST_ERROR", function(evt){
                    d.reject();
                }, this);

                http.execute(request);

                return d.promise();
            },

            /**
             * Method to check the internet connectivity
            **/
            __checkConnectivity : function(){
                var d = SVMX.Deferred();
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var req = nativeService.createConnectivityRequest();

                req.bind("REQUEST_COMPLETED", function(evt){
                    var result = evt.data.data.toLowerCase();
                    var isConnected = result === "true" ? true : false;

                    d.resolve(isConnected);
                }, this);

                req.bind("REQUEST_ERROR", function(evt){
                    d.resolve(false);
                }, this);

                req.execute();

                return d.promise();
            },

            __checkConnectivityAlwaysTrue : function(){
                var d = SVMX.Deferred();
                d.resolve(true);
                return d.promise();
            },
            /**
            * Generic method to show message
            **/
            __showMessage : function(messageText, messageType){
                SVMX.getCurrentApplication()
                .getApplicationMessageUIHandler()
                .showMessage({
                    type: messageType,
                    text: messageText
                });
            },
            /**
             * Generate Template Checklist SFM
             */
            __performChecklistAction: function(action) {
                this.__logger.info("Performing SFM action => " + action.getName());
                var recId = action.getRoot().recordId;

                var request = {
                    SVMX_recordId: recId,
                    SVMX_action: action.actionType
                };
                SVMX.getCurrentApplication().launchConsoleApp("sfmdelivery", request);
            },

            __performOUTPUTDOCUMENTAction1: function(action) {
                this.__logger.info("Performing OUTPUT_DOCUMENT action => " + action.getName());
                var recId = action.getRoot().recordId;
                if (!recId) {
                    var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("SFWDELIVERY");
                    var errorHandler = SVMX.getCurrentApplication().getApplicationErrorHandler();
                    // TODO: This code is temporary; once sync has been fixed, this limitation will go away.
                    errorHandler.notifyApplicationError({
                        message: TS.T("TAG0027", "You can not generate a document until this record has synced")
                    });
                    return;
                }
                var record = action.getRoot().record;
                var procId = action.getData().actionDef[SVMX.OrgNamespace + "__Process__r"][SVMX.OrgNamespace + "__ProcessID__c"];
                var selectTplAtRuntime = action.getData()
                    .actionDef[SVMX.OrgNamespace + "__Select_Template_At_Runtime__c"],
                    me = this;
                var de = action.getRoot().getDeliveryEngine();


                MetaDataUtils.getProcess({
                    salesforceProcessId: procId,
                    onSuccess : SVMX.proxy(this, function(evt) {
                        var process= evt.data.data[0];
                        var request = {
                            SVMX_processId: process.process_unique_id,
                            SVMX_recordId: recId,
                            SVMX_record: record,
                            SVMX_selectTplAtRuntime: selectTplAtRuntime,
                            de: de
                        };

                        SVMX.getCurrentApplication().launchConsoleApp("sfmopdocdelivery", request);
                    })
                });
            },

            __performOUTPUTDOCUMENTAction: function(action) {
                this.__logger.info("Performing OUTPUT_DOCUMENT action => " + action.getName());
                var recId = action.getRoot().recordId;
                if (!recId) {
                    var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("SFWDELIVERY");
                    var errorHandler = SVMX.getCurrentApplication().getApplicationErrorHandler();
                    // TODO: This code is temporary; once sync has been fixed, this limitation will go away.
                    errorHandler.notifyApplicationError({
                        message: TS.T("SFWDELIVERY.TAG0027", "You can not generate a document until this record has synced")
                    });
                    return;
                }
                var record = action.getRoot().record;
                var procId = action.getData().actionDef[SVMX.OrgNamespace + "__Process__r"][SVMX.OrgNamespace + "__ProcessID__c"];
                var selectTplAtRuntime = action.getData()
                    .actionDef[SVMX.OrgNamespace + "__Select_Template_At_Runtime__c"],
                    me = this;
                var de = action.getRoot().getDeliveryEngine();


                MetaDataUtils.getProcess({
                    salesforceProcessId: procId,
                    onSuccess : SVMX.proxy(this, function(evt) {
                        var process= evt.data.data[0];
                        var request = {
                            SVMX_processId: process.process_unique_id,
                            SVMX_recordId: recId,
                            SVMX_record: record,
                            SVMX_selectTplAtRuntime: selectTplAtRuntime,
                            de: de
                        };

                        me.__openOutputDocReport(request, action, process, function(response) {
                            //generation status and path to crystal report
                            var fileLocation = response.fileLocation,
                                success = response.success;
                            if (success) {
                                // Assume this is successful and that no actions need to occur onSuccess
                                DataUtils.executeSourceUpdateMapping({
                                    processId: process.process_id,
                                    data: record
                                });

                                me.__copyOutputDocReportIntoDownloads(request, action, fileLocation, function(response) {
                                    if (response.success) {
                                        var file = new com.servicemax.client.offline.sal.model.nativeservice.File(response.targetPath + "/" + response.targetFileName);
                                        var newid = "local_" + new Date().getTime();
                                        file.info().then(SVMX.proxy(this, function(inSuccess, inFileInfo) {
                                            var author = OfflineSystemUtils.getUserInfo().UserId;
                                            /*Ashwini : Escape single quotes (') in the filename - issue 031278*/
                                            var fileNameValue = process.process_name + (response.targetFileName.replace(/^.*\./, ".") || "");
                                            var targetPathValue = file.getPath();
                                            fileNameValue = fileNameValue.replace(/'/g, "''");
                                            targetPathValue = targetPathValue.replace(/'/g, "''");

                                            return execQuery({
                                                query: "INSERT INTO SFAttachments " +
                                                    "(Id, parent_id, file_path, name, last_modified_date, content_length, created_by_id, downloaded) " +
                                                    "VALUES('{{id}}', '{{record_id}}', '{{target_path}}', '{{file_name}}', '{{last_modified}}', {{size}}, '{{author}}', 'true')",
                                                queryParams: {
                                                    id: newid,
                                                    record_id: recId,
                                                    file_name: fileNameValue,
                                                    target_path: targetPathValue,
                                                    last_modified: com.servicemax.client.lib.datetimeutils.DatetimeUtil.getTimestampWithSaveFormat(),
                                                    size: inFileInfo.size,
                                                    author: author
                                                }
                                            }).then(SVMX.proxy(this, function() {
                                                SVMX.getCurrentApplication().getSyncImpl().performAggressiveSync();
                                            }));
                                        })).then(SVMX.proxy(this, function() {
                                            var service = SVMX.getClient().getService("com.servicemax.client.attachmentnotifications").getInstance();
                                            var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                                                "ATTACHMENTS_CHANGED", this, {
                                                    request : {
                                                        recordId: record.Id
                                                    }
                                                }
                                            );
                                            service.triggerEvent(evt);
                                        }));
                                        SyncUtils.insertAttachment({
                                            Id: newid,
                                            isAttachment: true
                                        });
                                    }
                                });

                                me.__copyOutputDocReportIntoUploads(request, action, fileLocation, function(response) {
                                    if (response.success) {
                                        //Enrty into SFAttachments done via downloads
                                    }
                                });
                            } else {
                                me.__performOUTPUTDOCUMENTAction1(action);
                            }
                        });

                    })
                });
            },

            __copyOutputDocReportIntoDownloads: function(request, action, fileLocation, callback) {
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var nativeRequest = nativeService.createFileRequest();

                var targetFile = this.getTargetFileName(fileLocation);

                var params = {
                    file: fileLocation,
                    operation: "COPY",
                    targetPath: "{UploadDirectory}",
                    targetFile: targetFile
                };

                nativeRequest.bind("REQUEST_COMPLETED", function(evt) {
                    //append target name with time stamp before extension
                    var result = {
                        success: evt.data.success,
                        targetPath: evt.data.parameters.targetPath,
                        targetFileName: evt.data.parameters.targetFile
                    };
                    callback(result);
                });

                nativeRequest.execute(params);
            },

            __copyOutputDocReportIntoUploads: function(request, action, fileLocation, callback) {
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var nativeRequest = nativeService.createFileRequest();

                var targetFile = this.getTargetFileName(fileLocation);

                var params = {
                    file: fileLocation,
                    operation: "COPY",
                    targetPath: "{DownloadDirectory}",
                    targetFile: targetFile
                };

                nativeRequest.bind("REQUEST_COMPLETED", function(evt) {
                    var result = {
                        success: evt.data.success,
                        targetPath: evt.data.parameters.targetPath,
                        targetFileName: evt.data.parameters.targetFile
                    };
                    callback(result);
                });

                nativeRequest.execute(params);
            },

            getTargetFileName: function(filePath) {
                var targetFileName = "";
                if (filePath.indexOf("\\") > -1) {
                    targetFileName = filePath.split("\\").pop();
                } else if (filePath.indexOf("/") > -1) {
                    targetFileName = filePath.split("/").pop();
                }

                var ind = targetFileName.lastIndexOf("."),
                    extension = targetFileName.substring(ind, targetFileName.length);
                //Append time stamp to the filename
                targetFileName = targetFileName.substring(0, ind) + new Date().getTime() + extension;

                return targetFileName;
            },

            __openOutputDocReport: function(request, action, process, callback) {
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var nativeRequest = nativeService.createReportRequest();

                nativeRequest.bind("REQUEST_COMPLETED", function(evt) {
                    var result = {
                        fileLocation: evt.data.fileLocation,
                        success: evt.data.success
                    };
                    callback(result);
                });

                nativeRequest.bind("REQUEST_ERROR", function(evt) {
                    var result = {
                        fileLocation: evt.data.fileLocation,
                        success: evt.data.success
                    };
                    callback(result);
                }, this);

                var de = request.de,
                    params = {
                        recId: request.SVMX_recordId,
                        processId: request.SVMX_processId
                    };

                if (request.SVMX_selectTplAtRuntime == true) {
                    getUserSelection(function(selection) {
                        execute(selection, params);
                    });
                } else {
                    execute("", params);
                }

                function execute(selection, params) {
                    if (selection) {
                        params.processId = selection.pid;
                    }

                    if (process.expression_id) {
                        com.servicemax.client.offline.sal.model.utils.Expressions.evaluate({
                            data: request.SVMX_record,
                            expressionId: process.expression_id,
                            returnMessage: true,
                            onSuccess : SVMX.proxy(this, function(response) {
                                if (response[0].result) {
                                    nativeRequest.execute(params);
                                } else {
                                    // invalid criteria
                                    SVMX.getCurrentApplication()
                                        .getApplicationMessageUIHandler()
                                        .showMessage({
                                            type: "ERROR",
                                            text: response[0].message
                                        });
                                }
                            })
                        });
                    } else {
                        nativeRequest.execute(params);
                    }
                }

                function getUserSelection(callback) {
                    var actions = action.getRoot().availableActions,
                        i, l = actions.length,
                        validActions = [];
                    for (i = 0; i < l; i++) {
                        if (actions[i][SVMX.OrgNamespace + "__Purpose__c"] == "OUTPUT DOCUMENT") {
                            validActions.push({
                                pid: actions[i][SVMX.OrgNamespace + "__ProcessID__c"],
                                name: actions[i][SVMX.OrgNamespace + "__Name__c"],
                                desc: actions[i][SVMX.OrgNamespace + "__Description__c"]
                            });
                        }
                    }

                    var win = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXWindow", {
                        width: 500,
                        height: 300,
                        modal: true,
                        resizable: false,
                        title: de.translate("CONF016_TAG113"),
                        items: [{
                            xtype: "svmx.listcomposite",
                            height: 240,
                            store: {
                                xtype: "svmx.store",
                                fields: ['name'],
                                data: validActions
                            },
                            columns: [{
                                text: '',
                                dataIndex: 'name',
                                flex: 1
                            }],
                            viewConfig: {
                                emptyText: de.translate("CONF016_TAG115"),
                                deferEmptyText: false
                            },
                            listeners: {
                                itemdblclick: function(dataview, record, item, index, e) {
                                    callback(record.raw);
                                    win.close();
                                }
                            }
                        }],
                        dockedItems: [{
                            xtype: "svmx.toolbar",
                            dock: "bottom",
                            items: [{
                                xtype: 'tbfill'
                            }, {
                                xtype: "svmx.button",
                                text: de.translate("CONF016_TAG114"),
                                handler: function() {
                                    var lst = win.items.getAt(0);
                                    var selected = lst.getSelectionModel().getSelection();
                                    if (selected && selected.length > 0) {
                                        callback(selected[0].raw);
                                        win.close();
                                    }
                                }
                            }, {
                                xtype: "svmx.button",
                                text: de.translate("CONF016_TAG032"),
                                handler: function() {
                                    win.close();
                                }
                            }]
                        }]
                    }).show();
                }
            },

            __extractInstalledProductField : function(record) {
                var fieldDef, fields, i;
                var serialObjectName = SVMX.OrgNamespace + "__Installed_Product__c";
                var serials = [];

                if (record && record._fields && record._fields.fields) {
                    fields = record._fields.fields;
                    for (var key in fields) {
                        if (fields.hasOwnProperty(key)) {
                            fieldDef = fields[key];
                            if (fieldDef && fieldDef.referenceTo && fieldDef.referenceTo instanceof Array) {
                                for (k = 0; k < fieldDef.referenceTo.length; k++) {
                                    if (fieldDef.referenceTo[k] == serialObjectName) {
                                        var componentName = fieldDef.name;
                                        var component = record[componentName];
                                        var serial = (typeof component === 'string') ? component : component && component.fieldvalue && component.fieldvalue.key;
                                        if (serial) {
                                            if (serials.indexOf(serial) == -1) {
                                                serials.push(serial);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                return serials;
            },

            __getProductsServicedSerials: function(inRawData) {
                // This is a WorkOrder, need to see if we have any details to send to external application
                // Cycle through each child type
                var me = this;
                var d = SVMX.Deferred();

                // First get serials from header, then details
                var i, k, l;
                var serialIds = this.__extractInstalledProductField(inRawData);
                var detailObjectName = SVMX.OrgNamespace+"__Service_Order_Line__c";

                // TODO: should not have to fetch details like this
                // Instead they should come as inRawData.details
                // If this breaks, put in the effort to restore that approach
                var request = nativeService.createSQLRequest();
                request.bind("REQUEST_COMPLETED", function(evt) {
                    var details = evt.data.data;
                    if(!details.length){
                        d.resolve(serialIds);
                    }
                    MetaDataUtils.describeObject({
                        objectName: detailObjectName,
                        onSuccess: function(objectInfo) {
                            // Now pull them from
                            for(var i = 0; i < details.length; i++) {
                                var record = details[i];
                                record._fields = {fields: objectInfo.fields};
                                var lineIds = me.__extractInstalledProductField(record);
                                for (k = 0; k < lineIds.length; k++) {
                                    if (serialIds.indexOf(lineIds[k]) == -1) {
                                        serialIds.push(lineIds[k]);
                                    }
                                }
                            }
                            /*
                            if (inRawData.details) {
                                for(var prop in inRawData.details) {
                                   l = inRawData.details[prop].lines.length;
                                   for (i = 0; i < l; i++) {
                                        var record = inRawData.details[prop].lines[i];

                                        var lineIds = me.__extractInstalledProductField(record);
                                        for (k = 0; k < lineIds.length; k++) {
                                            if (serialIds.indexOf(lineIds[k]) == -1) {
                                                serialIds.push(lineIds[k]);
                                            }
                                        }

                                    }
                                }
                            }
                            */

                            d.resolve(serialIds);
                        }
                    });
                });
                request.bind("REQUEST_ERROR", function(evt) {
                    SVMX.getLoggingService().getLogger("Error retrieving details");
                });
                request.execute({
                    query: "SELECT * FROM "+SVMX.OrgNamespace+"__Service_Order_Line__c WHERE "
                        +SVMX.OrgNamespace+"__Service_Order__c = '"+inRawData.Id+"'"
                });
                return d;
            },

            __performExternalAction: function(action) {
                var externalInstalled = SVMX.getClient().getApplicationParameter("InstallBase");
                this.__logger.info("Performing External SFM action (" + externalInstalled + ") => " + action.getName());

                // Only do this if we have the external application installed.
                // We should not have made it this far if we don't, just double checking
                if (externalInstalled) {
                    var recId = action.getRoot().recordId;
                    var record = action.getRoot().record;
                    var objectName = record.attributes.type;
                    var procId = action.getData().actionDef[SVMX.OrgNamespace + "__Process__r"][SVMX.OrgNamespace + "__ProcessID__c"];

                    var message = {
                        action      : 'VIEW',
                        recordIds   : [recId],
                        object      : objectName
                    };

                    if (procId === 'Products Serviced') {
                        this.__getProductsServicedSerials(record)
                        .done(function(serials){
                            if (serials && serials.length) {
                                message = {
                                    action      : 'VIEW',
                                    recordIds   : serials,
                                    object      : objectName,
                                    sourceRecordName : record.Name || ""
                                };
                            }
                            performExternal();
                        });
                    }else{
                        performExternal();
                    }

                    function performExternal(){
                        // Call External application
                        var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                        var request = nativeService.createSendExternalRequest();

                        request.bind("REQUEST_COMPLETED", function(evt) {
                            console.log("SUCCESS", evt);
                        });

                        request.bind("REQUEST_ERROR", function(evt) {
                            console.log("ERROR", evt);
                        });

                        // Fire and forget, for now
                        request.execute({
                            appName         : "Installigence",
                            externalRequest : SVMX.toJSON(message)
                        });
                    }
                }

            },

            __performSFMAction: function(action) {
                this.__logger.info("Performing SFM action => " + action.getName());
                var recId = action.getRoot().recordId;
                var record = action.getRoot().record;
                var procId = action.getData().actionDef[SVMX.OrgNamespace + "__Process__r"][SVMX.OrgNamespace + "__ProcessID__c"];
                this.__getRealProcessId(procId, function(params) {
                    if (params) {
                        var request = {
                            SVMX_processId: params.inProcessId,
                            SVMX_recordId: recId,
                            SVMX_record: record
                        };
                        SVMX.getCurrentApplication().launchConsoleApp("sfmdelivery", request);
                    } else {
                        var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("IPAD");
                        var errorHandler = SVMX.getCurrentApplication().getApplicationErrorHandler();
                        errorHandler.notifyApplicationError({
                            message: TS.T("IPAD023_TAG006", "Process not found; check your configuration")
                        });
                    }
                });
            },

            __getRealProcessId: function(inProcessId, callback) {
                var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
                var request = nativeService.createSQLRequest();

                request.bind("REQUEST_COMPLETED", function(evt) {
                    var data = evt.data.data;
                    var result = (data && data.length) ? {
                        inProcessId: SVMX.toObject(data)[0].process_unique_id
                    } : null;
                    callback(result);
                });

                request.bind("REQUEST_ERROR", function(evt) {
                    SVMX.getLoggingService().getLogger("__getRealProcessId Failed" + evt.data.data);
                });

                request.execute({
                    query: "SELECT process_unique_id FROM SFProcess WHERE process_id = '{{process_id}}'",
                    queryParams: {
                        process_id: inProcessId
                    }
                });
            }

}, {});
    };
})();

// end of file
