/**
 * This file needs a description
 * @class com.servicemax.client.offline.sal.model.sfmcreateutils
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){
var impl = SVMX.Package("com.servicemax.client.offline.sal.model.sfmcreateutils");

    impl.Class("Utils", com.servicemax.client.lib.api.Object, {
        __constructor : function(){},

        getCreateProcessInfo : function(params, callback, context){
            this.prepareCreateProcessInfo(params, function(resp){
                callback.call(context, resp);
            });
        },

        prepareCreateProcessInfo : function(params, callback){
            var me = this;
            var externalInstalled = SVMX.getClient().getApplicationParameter("InstallBase");

            var sqlstr = "SELECT DISTINCT p.process_id as id, " +
                "p.process_name as name, " +
                "p.process_description as description, " +
                "pc.object_name as objectName " +
                "FROM SFProcess AS p " +
                "JOIN SFProcessComponent AS pc ON p.process_id = pc.process_id " +
                "WHERE " +
                "pc.component_type = 'TARGET' AND " +
                "p.process_type = 'STANDALONE CREATE' ";

            // Ignore InstallBase objects, if installed
            if (externalInstalled) {
                sqlstr = sqlstr + " AND pc.object_name NOT IN (SELECT object_name FROM InstallBaseObject)";
            }

            var q = SVMX.string.substitute(sqlstr,{});
            me.__executeQuery(q, function(info){
                var allProcessInfo = [], objectNames = [];
                if(info !== false){
                    allProcessInfo = info;
                    var i, l = allProcessInfo.length;
                    for(i = 0; i < l; i++){
                        objectNames.push(allProcessInfo[i].objectName);
                    }

                    sqlstr = "SELECT DISTINCT object_name as objectName, label " +
                    "FROM SFObjectDescribe where object_name in ('{{value}}')";
                    q = SVMX.string.substitute(sqlstr, {value : objectNames.join("','")});
                    me.__executeQuery(q, function(info){

                        for(i = 0; i < l; i++){
                            allProcessInfo[i].objectLabel = getLabelFor(allProcessInfo[i].objectName);
                        }

                        function getLabelFor(objectName){
                            var j, c = info.length, ret = objectName;
                            for(j = 0; j < c; j++){
                                if(info[j].objectName == objectName){
                                    ret = info[j].label;
                                    break;
                                }
                            }
                            return ret;
                        }
                        me.__filterCreateProcessInfo(allProcessInfo, callback);
                    });

                }else{
                    callback(info);
                }
            });
        },

        __filterCreateProcessInfo : function(allProcessInfo, callback){
            // Filter Event create process depending 'GLOB001_GBL025'
            // which may equal 'Event' or 'ServiceMax Event'
            var filteredProcessInfo = [];
            var sql = "SELECT value FROM MobileDeviceSettings WHERE setting_id = 'GLOB001_GBL025'";
            this.__executeQuery(sql, function(result){
                var settingValue = result && result[0] && result[0].value;
                var filterObjectName = (settingValue === 'ServiceMax Event')
                    ? 'Event' : SVMX.OrgNamespace+'__SVMX_Event__c';
                for(var i = 0; i < allProcessInfo.length; i++){
                    var processInfo = allProcessInfo[i];
                    if(processInfo.objectName !== filterObjectName){
                        filteredProcessInfo.push(processInfo);
                    }
                }
                callback(filteredProcessInfo);
            });
        },

        __executeQuery : function(query, callback){

            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var request = nativeService.createSQLRequest();

            request.bind("REQUEST_COMPLETED", function(evt){
                callback(SVMX.toObject(evt.data.data));
            }, this);

            request.bind("REQUEST_ERROR", function(evt){
                SVMX.getLoggingService().getLogger(evt.data);
                callback(false);
            }, this);

            request.execute({query : query, async : true });
        }
    }, {});

    impl.Class("PlatformSpecifics", com.servicemax.client.lib.api.Object, {
        __constructor : function(){

        },

        performAction : function(action){

            this.__getRealProcessId(action.id, function(pid){
                var request = {SVMX_processId : pid};
                SVMX.getCurrentApplication().launchConsoleApp("sfmdelivery", request);

            });
        },

        __getRealProcessId : function(inProcessId, callback) {
            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var request = nativeService.createSQLRequest();

            request.bind("REQUEST_COMPLETED", function(evt) {
                var result = SVMX.toObject(evt.data.data)[0].process_unique_id;
                callback(result);
            });

            request.bind("REQUEST_ERROR", function(evt){
              SVMX.getLoggingService().getLogger("__getRealProcessId Failed" + evt.data.data);
            });

            request.execute({
                query : "SELECT process_unique_id FROM SFProcess WHERE process_id = '{{process_id}}'",
                queryParams: {process_id: inProcessId}
             });
        }

    }, {});
})();

// end of file
