/**
 * # Package #
 *
 * This file needs a description
 *
 * @class com.servicemax.client.offline.sal.model.sfwdelivery.operations
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function() {
    var impl = SVMX.Package("com.servicemax.client.offline.sal.model.sfwdelivery.operations");
impl.init = function() {

        var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;
        var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;
        var utils = com.servicemax.client.offline.sal.model.sfwdeliveryutils.Utils;
        var logger = SVMX.getLoggingService().getLogger("com.servicemax.client.offline.sal.model.sfwdelivery");

        /**
         *  this class provides methods to fetch the wizard contents
         *
         *  @class      com.servicemax.client.offline.sal.model.sfwdelivery.operations.GetWizardInfo
         *  @extends    com.servicemax.client.mvc.api.Operation
         */
        impl.Class("GetWizardInfo", com.servicemax.client.mvc.api.Operation, {
            __constructor: function() {
                this.__base();
            },

            /*
              The data model
             * {
             * 		SFWs : [
             * 			{
             * 				SFWDef : {
             * 					Id : <>,
             * 					__Name__c : <>
             * 				},
             * 				actions : [
             * 					{
             * 						__Action_Type__c : <>,
             * 						__Enable_Confirmation_Dialog__c : <>,
             * 						__Mode_Of_Execution__c : <>,
             * 						__Handover__c : <>,
             * 						__Confirmation_Message__c : <>,
             * 						__Name__c : <>,
             * 						Id : <>
             * 						__Process__r : {
             * 							__ProcessID__c : <>
             * 						}
             * 					}
             * 				]
             * 			}
             * 		]
             * }
             */

            /**
             *
             * @param    {Object}    request         data request object
             * @param    {Object}    responder       responder object
             */
            performAsync: function(request, responder) {
                if (request.Record) {
                    this.__onGetRecordSuccess(request, responder, request.Record);
                } else {
                    SVMX.doLater(function() {
                        OfflineDataUtils.getRecord({
                            Id: request.RecordId,
                            loadReferences: true,
                            convertPicklists: true
                        }).then(
                            SVMX.proxy(this, "__onGetRecordSuccess", request, responder),
                            SVMX.proxy(this, "__onGetRecordFail", request, responder)
                        );
                    }, this);
                }
            },

            /*
             * @private
             * @param    {Object}    request         data request object
             * @param    {Object}    responder       responder object
             * @param    {Object}    record          record data object
             */
            __onGetRecordSuccess: function(request, responder, record) {
                /*
                Returns a deferred that always resolves
                */
                utils.processWizardRawData( record )
               	.then(SVMX.proxy(this, function(data){
                    var i = 0;
                    var l = data.length;
                    var ret = {
                            SFWs: [],
                            RecordId: request.RecordId,
                            Record: record
                        };

                    var w, j, c, steps, s;

                    for (i = 0; i < l; i++) {
                        ret.SFWs[i] = {
                            SFWDef: {},
                            actions: []
                        };

                        // sfw definition
                        ret.SFWs[i].SFWDef["Id"] = data[i].wizard_id;
                        ret.SFWs[i].SFWDef[SVMX.OrgNamespace + "__Name__c"] = data[i].wizard_name;

                        // sfw steps
                        steps = data[i].steps;
                        c = steps ? steps.length : 0;
                        for (j = 0; j < c; j++) {
                            s = {
                                actionDef: {}
                            };

                            s.Enabled = steps[j].expressionPassed;

                            // TODO: Could not find the action Id!
                            // TODO: Could not find the confirmation message
                            s.actionDef["Id"] = steps[j].local_id;
                            s.actionDef[SVMX.OrgNamespace + "__Action_Type__c"] = steps[j].action_type;
                            s.actionDef[SVMX.OrgNamespace + "__Custom_Action_Type__c"] = steps[j].customActionType;
                            s.actionDef[SVMX.OrgNamespace + "__Enable_Confirmation_Dialog__c"] = false;
                            s.actionDef[SVMX.OrgNamespace + "__Mode_Of_Execution__c"] = "Interactive";
                            s.actionDef[SVMX.OrgNamespace + "__Handover__c"] = false;
                            s.actionDef[SVMX.OrgNamespace + "__Confirmation_Message__c"] = null;
                            s.actionDef[SVMX.OrgNamespace + "__Name__c"] = steps[j].action_name;
                            s.actionDef[SVMX.OrgNamespace + "__Description__c"] = steps[j].action_description;

                            s.actionDef[SVMX.OrgNamespace + "__Process__r"] = {};
                            s.actionDef[SVMX.OrgNamespace + "__Process__r"][SVMX.OrgNamespace + "__ProcessID__c"] = steps[j].process_id;
                            ret.SFWs[i].actions.push(s);
                        }
                    }

                    responder.result( ret );
                }));
            },

            __onGetRecordFail : function(request, responder, error) {
                logger.error("Failed to get record for sfw:" + error);
                responder.fault( error );
            }
        }, {});


};
})();

// end of file
