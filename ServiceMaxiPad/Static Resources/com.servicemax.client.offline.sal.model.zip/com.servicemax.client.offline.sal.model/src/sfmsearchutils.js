/**
 * Utilities for sfmsearch
 * @author Indresh M S
 * @class com.servicemax.client.offline.sal.model.sfmsearch.utils.impl
 * @since: The minimum version where this file is supported
 *
 * @copyright 2013 ServiceMax, Inc
 */
(function(){

  var utilsImpl = SVMX.Package("com.servicemax.client.offline.sal.model.sfmsearch.utils.impl");

  // constants
  var DB_KEY = "F1-SFMSEARCH-INFO";
  // end constants

  // in memory cache
  var searchDef = null;
  // end cache

utilsImpl.init = function(){
  var OfflineMetaUtils  = com.servicemax.client.offline.sal.model.utils.MetaData;
  var OfflineDataUtils  = com.servicemax.client.offline.sal.model.utils.Data;
  var OfflineCacheUtils = com.servicemax.client.offline.sal.model.utils.Cache;
  var DatetimeUtils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
  var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("SFMSEARCH");
  var TSIPAD = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("IPAD");


  utilsImpl.Class("Utils", com.servicemax.client.lib.api.Object, {
    __constructor : function(){

    },

    getSearchDefinitionFor : function(params, callback, context){
        this.getSearchDefinition({}, function(def){
            var searchProcessId = params.ProcessId, searchObjectId = params.ObjectId, ret;

            // extract
            var allSearchInfo = def.lstSearchInfo || [], i, l = allSearchInfo.length, si;
            var allSearchDetails, j, c, sd;

            for(i = 0; i < l; i++){
                si = allSearchInfo[i];
                allSearchDetails = si.searchDetails || []; c = allSearchDetails.length;
                for(j = 0; j < c; j++){
                    sd = allSearchDetails[j];
                    if(sd.objectDetails.Id == searchObjectId){
                        ret = SVMX.cloneObject(sd);
                        break;
                    }
                }
            }
            // end
            callback.call(context, ret);
        }, context);
    },

    __getAllSearchProcesses : function(callback){
        var q = SVMX.string.substitute(
                "select * from {{ns}}__ServiceMax_Processes__c where {{ns}}__Rule_Type__c ='{{type}}' ORDER BY {{ns}}__Name__c",
                {ns : SVMX.OrgNamespace, type : "SRCH_NAMED_SEARCH"});
        this.__executeQuery(q, function(response){
          callback(response);
        });
    },

    __getAllSearchObjects : function(allProcesses, callback){
        var allProcesses = allProcesses || [], i, l = allProcesses.length, pids = [];

        for(i = 0; i < l; i++){
            pids.push(allProcesses[i].Id);
        }

        var q = SVMX.string.substitute(
                "select * from {{ns}}__ServiceMax_Processes__c where {{ns}}__Module__c in ('{{processes}}')",
                {ns : SVMX.OrgNamespace, processes : pids.join("' , '")});

        this.__executeQuery(q, function(response){
          callback(response);
        });
    },

    __getAllSearchFields : function(allObjects, callback){
        var allObjects = allObjects || [], i, l = allObjects.length, oids = [];

        for(i = 0; i < l; i++){
            oids.push(allObjects[i].Id);
        }

        var q = SVMX.string.substitute("select * from {{ns}}__ServiceMax_Config_Data__c where {{ns}}__Expression_Rule__c in ('{{oids}}')",
                       {ns : SVMX.OrgNamespace, oids : oids.join("' , '")});

        this.__executeQuery(q, function(response){
          callback(response);
        });
    },

    getSearchDefinition : function(params, callback, context){
      var me = this;

      if(searchDef != null && !params.clearCache){
         SVMX.doLater(function(){
             callback.call(context, SVMX.cloneObject(searchDef));
         });
      }else{
          me.__getSearchDefinitionFromCache({}, function(def){
            if(!def){
                me.createSearchDefinition(params, callback, context);
            }else{
                SVMX.getLoggingService().getLogger("sfmsearch").info("Search information found in cache");
                searchDef = def;
                callback.call(context, SVMX.cloneObject(searchDef));
            }
          });
      }
    },

    __getSearchDefinitionFromCache : function(params, callback){
            OfflineCacheUtils.readObjectFromDBCache(DB_KEY, callback, this);
    },

    __createSearchDefinitionInCache : function(data, callback){
            OfflineCacheUtils.writeObjectToDBCache(DB_KEY, data, callback, this);
    },

    createSearchDefinition : function(params, callback, context){
      var me = this;

      me.__getAllSearchProcesses(function(allProcesses){
        me.__getAllSearchObjects(allProcesses, function(allObjects){

            me.__getAllSearchFields(allObjects, function(allFields){

                // describe SFDC object information for each search object configuration
                me.__getAllSFDCObjectsDescribe(allFields, function(allDescribes){

                    var resp = me.__createDefinitionResponse({allProcesses : allProcesses, allObjects : allObjects,
                       allFields : allFields, allDescribes : allDescribes});

                    // update the cache
                    //me.__createSearchDefinitionInCache(resp, function(){
                        searchDef = resp;
                        callback.call(context, SVMX.cloneObject(searchDef));
                    //});
                });

            });

        });
      });
    },

    __getAllSFDCObjectsDescribe : function(allSearchObjects, callback){
      var ret = [], i, count, stack = 0, me = this, logger = SVMX.getLoggingService().getLogger("sfmsearch");
      var objectName;

      if(allSearchObjects !== false && allSearchObjects.length > 0){
        count = allSearchObjects.length;
        for(i = 0; i < count; i++){
          stack++;
          objectName = allSearchObjects[i][SVMX.OrgNamespace + "__Object_Name2__c"];
          if(!objectName || objectName.length == 0){
              objectName = allSearchObjects[i][SVMX.OrgNamespace + "__Object_Name__c"];
          }
          describeObject(objectName);
        }
      }else{
        callback(ret);
      }

      function describeObject(objectName){
          logger.info("Describing => " + objectName);

          me.describeObject(objectName, function(info){
              describeObjectComplete(info);
          }, {});
      }

      function describeObjectComplete(data){
        --stack;

        if(data){
            ret.push(data);
            logger.info("Describing complete => " + data.name + ", stack => " + stack);
        }

        if(stack === 0){
          callback(ret);
        }
      }
    },

    describeObject : function(objectName, callback, context){
        OfflineMetaUtils.describeObject({
            objectName: objectName,
            onSuccess: SVMX.proxy(this, "__describeObjectSuccess", callback, context),
            onError: SVMX.proxy(this, "__describeObjectError", callback, context)
        });
    },

    __describeObjectError : function(callback, context, info) {
        callback.call(context, null);
    },

    __describeObjectSuccess : function(callback, context, info) {

          var fields = info.fields, i, count = fields.length;

          // create a field map for faster access
          // create a short cut for name field name
          info.fieldMap = {};

          for(i = 0; i < count; i++){
              info.fieldMap[fields[i].name] = fields[i];

              if(fields[i].nameField === true){
                  info.objectNameField = fields[i].name;;
              }
          }

          callback.call(context, info);
    },

    executeQuery : function(query, callback, context){
        this.__executeQuery(query, function(resp){
            callback.call(context, resp);
        });
    },

    __executeQuery : function(query, callback){

      var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
      var request = nativeService.createSQLRequest();

      request.bind("REQUEST_COMPLETED", function(evt){
        callback(SVMX.toObject(evt.data.data));
      }, this);

      request.bind("REQUEST_ERROR", function(evt){
        callback(false);
      }, this);

      request.execute({query : query, async : true });
    },

    /**
     * {
     *   lstSearchInfo : [
     *     {
     *       searchDef : <search definition>
     *       searchDetails : [
     *         {
     *           objectDetails : <object definition>
     *           fields : [],
     *           fieldsLable : [] // spelling mistake
     *           objectLable : "" // spelling mistake
     *         }
     *       ]
     *     }
     *   ],
     *   stringMap : [
     *     {key : <key>, value : <value>}
     *   ]
     * }
     */
    __createDefinitionResponse : function(data){
      var res = { lstSearchInfo : [], stringMap : [] }, i, count;

      var allProcesses = data.allProcesses, allObjects = data.allObjects, process = null;
      var allDescribes = data.allDescribes, allFields = data.allFields;

      if(allProcesses !== false){
          count = allProcesses.length;
          for(i = 0; i < count; i++){
              process = allProcesses[i];

              var results = extractProcessObjectsFor(process);
              if (results.searchDetails.length) {
                  res.lstSearchInfo.push(results);
              } else {
                  SVMX.getLoggingService().getLogger("sfmsearch").error("Major Error in Search: '" + process[SVMX.OrgNamespace + "__Name__c"] + "' had no valid search tabs and will be left out of UI");
              }
          }
      }

      function extractProcessObjectsFor(process){
        var ret = {searchDef : process, searchDetails : []}, i, count, po = null;

        if(allObjects !== false){
          count = allObjects.length;
          for(i = 0; i < count; i++){
            var searchObject = allObjects[i];
            if(searchObject[SVMX.OrgNamespace + "__Module__c"] == process.Id){

                var od = getObjectDescribe(searchObject[SVMX.OrgNamespace + "__Target_Object_Name__c"]);
                if(od){
                    po = {objectDetails : searchObject, fields : null, fieldsLable : []};

                    // set up the object label
                    po.objectLable = searchObject[SVMX.OrgNamespace + "__Name__c"]; // spelling mistake in the service!
                    searchObject.objectApiName = od.name;
                    searchObject.objectNameField = od.objectNameField;

                    po.fields = extractFieldsFor(po, searchObject, od);
                    if (po.fields.length) {
                      ret.searchDetails.push(po);
                    }
                }
            }
          }
        }

        return ret;
      }

      function extractFieldsFor(po, searchObject, objDescribe){
        var ret = [], i , count, fld, fldDescribe, fldName, lookupFieldName;
        var objectDescribe;
        if(allFields !== false){
          count = allFields.length;
          for(i = 0; i < count; i++){
            fld = allFields[i];
            if(fld[SVMX.OrgNamespace + "__Expression_Rule__c"] == searchObject.Id){
              fldName = fld[SVMX.OrgNamespace + "__Field_Name__c"];
              lookupFieldName = fld[SVMX.OrgNamespace + "__Lookup_Field_API_Name__c"];
              fldDescribe = lookupFieldName ? null : objDescribe.fieldMap[fldName];

              if(!fldDescribe){
                // Object2 ??
                try{
                    objectDescribe = getObjectDescribe(fld[SVMX.OrgNamespace + "__Object_Name2__c"]);
                    fldDescribe = objectDescribe ? objectDescribe.fieldMap[fldName] : null;
                    // ignore any field that doesn't exist and isn't hardcoded into the query condition (i.e. has an Operator)
                    if (!fldDescribe && !fld[SVMX.OrgNamespace + "__Operator__c"]) {
                        SVMX.getLoggingService().getLogger("sfmsearch").error("Minor Error in Search: '" + searchObject[SVMX.OrgNamespace + "__Name__c"] + "' Uses the field '" + fldName + "' which is not available to this user.");
                        continue;
                    } else if (!fldDescribe) {
                        SVMX.getLoggingService().getLogger("sfmsearch").error("Major Error in Search: '" + searchObject[SVMX.OrgNamespace + "__Name__c"] + "' Uses the field '" + fldName + "' which is not available to this user; search skipped.");
                        return [];
                    }
                  fldDescribe.label = fldDescribe.label;
                }catch(e){

                }
              }

              if(fldDescribe){
                  fld.fldDescribe = fldDescribe;
                  po.fieldsLable.push({key : fldDescribe.name, value : fldDescribe.label, value1: fld.Id});
                  ret.push(fld);
              }
            }
          }
        }

        return ret;
      }

      function getObjectDescribe(objectName){
        var i , count, ret = null;

        if(allDescribes !== false){
          count = allDescribes.length;
          for(i = 0; i < count; i++){

            if(allDescribes[i].name == objectName){
              ret = allDescribes[i];
              break;
            }
          }
        }
        return ret;
      }

      return res;
    }

  }, {});

    utilsImpl.Class("PlatformSpecifics", com.servicemax.client.lib.api.Object, {
        __logger: null,
        __constructor: function() {
            this.__logger = SVMX.getLoggingService().getLogger("SFMSearch : PlatformSpecifics");
        },


        showRecord: function(info) {
          var d = SVMX.Deferred();

            //Navigate to the record
            this.__logger.info("Performing SFM action => ");

        	//recordID and obj name
            var recId = info.key;
            var objectName = info.objectName;
            if (!objectName) {
                objectName = this.__getObjectName(recId);
            }

            OfflineDataUtils.getRecord({
                Id: recId,
                loadReferences: true, // TODO: Test expressions using reference values
                convertPicklists: true // TODO: Test expressions using picklist values
            })
            .then(SVMX.proxy(this, function(record) {
                //get the first view process from the list of all view processes for the object type
                this.__getProcessId(record, objectName)
                    .done(function(inProcessId) {
                      //Recents UI Changes
                      var lastAccessed = DatetimeUtils.getCurrentDatetimeGMT(DatetimeUtils.getSaveFormat('dateTime'));
                      var nameField = OfflineMetaUtils.getNameField(objectName);
                      var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                        "RECENTS.ADD_RECENTS", this, {
                          request: {
                            recordId : recId,
                            objectName : objectName,
                            lastAccessed : lastAccessed,
                            nameField : nameField  ,
                            type : "VIEW"          
                          },
                          responder:{
                            result:function(){
                              //Added to recents
                              SVMX.getLoggingService().getLogger("sfmsearch").info("Added Record to Recents");
                            }
                          }
                      });
                      var currentApp = SVMX.getCurrentApplication();
                      currentApp.triggerEvent(evt);
                            var request = {
                                SVMX_processId: inProcessId,
                                SVMX_recordId: recId,
                                SVMX_record: record
                            };
                            SVMX.getCurrentApplication().launchConsoleApp("sfmdelivery", request);
                            d.resolve();
                    })
                    //Fails because alert is shown, which resolves to fix doubletapping defect
                    .fail(function() {
                        d.reject();
                    });
            }))
            .fail(function(){
                d.reject()
            });

            return d;
        },

        __getProcessId: function(record, objectName, callback, noAlert) {
        	var d = SVMX.Deferred();
            OfflineMetaUtils.getQualifiedProcessesForRecord({
                objectName: objectName,
                record: record,
                processType: "VIEW RECORD",
                considerDefaultView: true
            })
            .then(SVMX.proxy(this, function(viewProcesses, record) {
                if (viewProcesses.length) {
                    var result = viewProcesses[0].process_unique_id;
                    d.resolve(result);
                } else if (noAlert) {
                    d.resolve(null);
                } else { //must show dialog stating "no view process associated with this record"

                    var message = TSIPAD.T("TODO", "View not configured for this record. Please contact your system administrator");
                    
                    SVMX.getCurrentApplication()
                        .getApplicationMessageUIHandler()
                        .showMessage({
                            type: "INFO",
                            text: message
                        });
                    //Reject because of alert shown rather than show new view
                    d.reject();
                }
                d.resolve();
            }));
            return d;
        },

        __getObjectName: function(rid, callback) {
            return OfflineMetaUtils.getTableForId(rid);
        }

    }, {});
};

})();

// end of file
