/**
 * This file needs a description
 * @class com.servicemax.client.offline.sal.model.impl
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){

  var salModelImpl = SVMX.Package("com.servicemax.client.offline.sal.model.impl");
  

  salModelImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {

    __constructor : function(){
      this.__base();
      this.__self.instance = this;
      this.__logger = SVMX.getLoggingService().getLogger("OFFLINE-SAL-MODEL");
    },

    beforeInitialize : function(){
        com.servicemax.client.offline.sal.model.nativeservice.init();
        
    },

    initialize : function(){
      

    },

    afterInitialize : function(){
      
    }


    

  }, { });
})();

// end of file
