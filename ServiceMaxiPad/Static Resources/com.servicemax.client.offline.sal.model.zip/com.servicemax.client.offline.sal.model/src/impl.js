/**
 * This file needs a description
 * @class com.servicemax.client.offline.sal.model.impl
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){

  var salModelImpl = SVMX.Package("com.servicemax.client.offline.sal.model.impl");


  salModelImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {

    __constructor : function(){
      this.__base();
      this.__self.instance = this;
      this.__logger = SVMX.getLoggingService().getLogger("OFFLINE-SAL-MODEL");
    },

    beforeInitialize : function(){
        com.servicemax.client.offline.sal.model.nativeservice.init();
        com.servicemax.client.offline.sal.model.utils.init();

        com.servicemax.client.offline.sal.model.sfmsearchdelivery.operations.init();

        // sfmsearch
        com.servicemax.client.offline.sal.model.sfmsearch.utils.impl.init();
        com.servicemax.client.offline.sal.model.sfmsearchdelivery.operations.init();
        // end sfmsearch

        // sfw delivery
        com.servicemax.client.offline.sal.model.sfwdeliveryutils.init();
        com.servicemax.client.offline.sal.model.sfwdelivery.operations.init();
        // end sfw

        // sfm opdoc
        com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.init();
        com.servicemax.client.offline.sal.model.sfmopdocdelivery.operations.init();
        //end sfmopdoc

        // sfm create
        com.servicemax.client.offline.sal.model.sfmcreatedelivery.operations.init();
        com.servicemax.client.offline.sal.model.sfmconsole.operations.init();
        com.servicemax.client.offline.sal.model.sync.operations.init();
        // end sfm create

        com.servicemax.client.offline.sal.model.toolspages.operations.init();

        com.servicemax.client.offline.sal.model.tasks.operations.init();

        com.servicemax.client.offline.sal.model.sfchatterfeedutils.init();
        com.servicemax.client.offline.sal.model.troubleshootdelivery.operations.init();
        com.servicemax.client.offline.sal.model.recents.operations.init();
    },

    initialize : function(){
      com.servicemax.client.offline.sal.model.sfmeventdelivery.operations.init();
      // register with the READY client event
      SVMX.getClient().bind("SFMOPDOCDELIVERY.JSEE_CREATED", function(evt) {
        var jsee = evt.data.jsee;
        var imageCache = {}, me = this;
        jsee.addInterceptor("$IMAGE", function(value, params){
          if(params && params.node){
            if (imageCache[value] != null) {
              $(params.node).attr("src", imageCache[value]);
            }
            else {
              var q = new com.servicemax.client.offline.sal.model.sfmopdocdelivery.operations.SubmitQuery();
              params.pendingNodeItems.addItem(value, value);
              var result = q._performInternal({
                queryConfig: {
                  api: "Document",
                  fields: "Id, Description, DeveloperName, Type",
                  condition: "DeveloperName='" + value + "'"
                }
              }, function(result){
                params.pendingNodeItems.removeItem(value);
                if (result) {
                  imageCache[value] = result;
                  $(params.node).attr("src", imageCache[value]);
                  //to parse the image names in server
                  $(params.node).attr("svmx-data", value);
                }
              }, me);

            }
          }else{
            if(jsee  != null && jsee.getProperty("ImageNameId")&& jsee.getProperty("ImageNameId")[value]){
              return '/servlet/servlet.FileDownload?file=' + jsee.getProperty("ImageNameId")[value];
            }
            else{
              SVMX.getLoggingService().getLogger().error("Image was not found in collection: " + value);
              return '';
            }
          }
        });
      });

    },

    afterInitialize : function(){
      com.servicemax.client.offline.sal.model.sfmdelivery.operations.init();
      com.servicemax.client.offline.sal.model.sync.extensions.init();
      var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
            var syncManager = servDef.getInstance();
            syncManager.bind("SYNC_STARTED", function(evt){
                if (syncManager.getSyncType() == "INITIAL" || syncManager.getSyncType() == "CONFIG") {
                    com.servicemax.client.offline.sal.model.utils.Cache.resetAllJSCaches();
                }
            }, this);
    },


    // Copied cluelessly from online version
    createServiceRequest : function(params, operationObj){
      var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.offline.sal.service.factory");
      servDef.getInstanceAsync({handler : function(service){
        var options = params.options || {};
        var p = {type : options.type || "REST", endPoint : options.endPoint || "SFMDeliveryServiceIntf",
                  nameSpace : options.namespace === null ? null : SVMX.OrgNamespace};
        var sm = service.createServiceManager(p);
        var sRequest = sm.createService();
        //this.registerForSALEvents(sRequest, operationObj);
        params.handler.call(params.context, sRequest);
      }, context:this });
    },

    checkResponseStatus: function() {
        var evt;
      var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("SFMDELIVERY");
      var quickMessage = TS.T("TAG020", "Saved Succesfully");

      var currentApp = SVMX.getCurrentApplication();

      if(quickMessage && typeof(quickMessage) == 'string'){
          evt = SVMX.create("com.servicemax.client.lib.api.Event",
          "SFMDELIVERY.NOTIFY_QUICK_MESSAGE", this, {request :
            {message : quickMessage, type : 'SVMX_SUCCESS'}, responder : {}});
          currentApp.triggerEvent(evt);
        }
    }
  }, {
    instance : null
  });

  salModelImpl.Class("AttachmentNotificationService", com.servicemax.client.lib.api.EventDispatcher, {
  });


  salModelImpl.Class("StorageProvider", com.servicemax.client.lib.api.Object, {
    __constructor : function(){

    },

    get:function(key){
      return com.servicemax.client.offline.sal.model.utils.Cache.readFromSynchronousDBCache("SVMX__DB__Cache", key);
    },

    set:function(key, value){
      com.servicemax.client.offline.sal.model.utils.Cache.writeToSynchronousDBCache("SVMX__DB__Cache", key, value);
    },

    clear:function(){},

    getStorageObject:function(){
      //return the storage object from the db
    }

  });


  salModelImpl.Class("PlatformSpecifics", com.servicemax.client.lib.api.Object, {

    __logger: null,

    __constructor : function(){
      this.__logger = SVMX.getLoggingService().getLogger("SFMDelivery : PlatformSpecifics");
      this.__clientType = SVMX.getClient().getApplicationParameter("client-type");
    },

    checkConnectivity : function(){
      var d = SVMX.Deferred();
      var me = this;
      var params = {
          type : "CONNECTIVITY",
          method : "CHECKCONNECTIVITY"
      };
      var req = com.servicemax.client.offline.sal.model.nativeservice.Facade.createConnectivityRequest();
      req.bind("REQUEST_COMPLETED", function(evt){
          d.resolve(evt.data.data);
      }, me);
      req.bind("REQUEST_ERROR", function(evt){
          d.resolve("False");
      }, me);
      req.execute(params);
      return d;
    },

    isEventSupported : function(eventInfo){
      var ret = false;

      if(eventInfo[SVMX.OrgNamespace + "__Event_Call_Type__c"] == "JAVASCRIPT"){
        ret = true;
      }

      return ret;
    },

    isActionButtonVisible : function(buttonInfo){
      // Indresh: iPad?? really??
      var showInOffline = buttonInfo.buttonDetail[SVMX.OrgNamespace + "__Show_In_iPad__c"];
      return !!showInOffline;
    },

    showRecordFrombubbleInfo : function(info){
            var ps = SVMX.getClient().getServiceRegistry()
            .getService("com.servicemax.client.sfmevent.platformspecifics")
            .getInstance();
                ps.showRecord(info);
    },

    getProcessLMD : function(){
      return window['svmx_sfm_delivery_process_lmd'];
    },

    getAttachmentsEnabled : function() {
      return "svmx_sfm_delivery_attachments_enabled" in window ? window['svmx_sfm_delivery_attachments_enabled'] : true;
    },

    /**
     * Figure out what value should be displayed for a Lookup field that is a reference.
     *
     *
     */
    getRefDisplayValue : function(path, value, metaModelData) {
      //path: SVMXC__Component__c, ignored!
      //value: {fieldvalue: {key: "a0NJ000000814XRMAY", value: "IB0514}}
      //metaModelData: {
      //          {
      //            fieldDetail: {
      //              SVMXC__DataType__c: "reference",
      //              SVMXC__Field_API_Name__c: "SVMXC__Component__c",
      //              SVMXC__Related_Object_Name__c: "SVMXC__Installed_Product__c",
      //              SVMXC__Named_Search__r: {
      //                SVMXC__Default_Lookup_Column__c: "SVMXC__City__c"
      //              }
      //            }
      //          }

      var TS = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.translation").getInstance().getDictionary("SFMDELIVERY");
      var d = new $.Deferred();
      var needResolved = true; //We may not need to wait for any query results and just need to resolve
      //Check if we have an ID to look up
      var field = metaModelData;
      if (field) {
        //   if (field.fieldDetail && field.fieldDetail.SVMXC__DataType__c == 'reference' &&
        //    field.fieldDetail.SVMXC__Field_API_Name__c == path) {
          //Now check if we need special handling
          if (field.fieldDetail.SVMXC__Named_Search__r
              && field.fieldDetail.SVMXC__Named_Search__r.SVMXC__Default_Lookup_Column__c
              && field.fieldDetail.SVMXC__Related_Object_Name__c) {
            //Generate query and get results, we will resolve on this track
            needResolved = false;
            //Step 1 get the ID or value from main data
            var recordId = value.fieldvalue.key;
            var fieldName = field.fieldDetail.SVMXC__Named_Search__r.SVMXC__Default_Lookup_Column__c;
            var refTable = field.fieldDetail.SVMXC__Related_Object_Name__c;
            var defaultNameField = field.fieldDetail.SVMXC__Related_Object_Name_Field__c;
            var deferred = com.servicemax.client.offline.sal.model.utils.Data.getRefDisplayValue(recordId, fieldName, refTable, defaultNameField);

            deferred.always(SVMX.proxy(this, function(results) {
              if (results.length) {
                var displayName = results[0].DisplayName;
                var refName = results[0].RefName || results[0].DefaultName || TS.T("TAG031");
                value.fieldvalue.value = displayName ? displayName : refName;
                value.fieldvalue.isNameSyncData = !refName; // If not ref name, then it uses sync data in SFRecordName table.
              }
              else {
                // Defect 012198: Flag whether record exists and use that to determine whether to show link.
                value.fieldvalue.isNameSyncData = true;
              }
              d.resolve(value);
            }));
         }
      }

      if (needResolved) {
        //Nothing to do, just let the value through
        d.resolve(value);
      }

        return d;
    },

    getQualificationInfo : function(recordID, record, processId, callback){
      //TODO : chk where isSFMProcess info comes from
      var OfflineExprUtils = com.servicemax.client.offline.sal.model.utils.Expressions;
      OfflineExprUtils.evaluate({
        recordId: recordID,
        data: record,
        processId: processId,
        returnMessage: true,
        onSuccess: SVMX.proxy(this, function(exprResults) {

          var TS = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.translation").getInstance().getDictionary("SFMDELIVERY");
          if(exprResults[0].result == false && SVMX.getCurrentApplication().getRoot().hideLoading){
            //TODO : Not the right way to hide loading...consult Indresh and check if an
            //API must be introduced
            // MK: PROBABLY NEED THE STATE_CHANGE EVENT
            SVMX.getCurrentApplication().getRoot().hideLoading();
          }
          var result = {
            isSFMProcess: true,
            isQualified: exprResults[0].result,
            errorMessage: (exprResults[0].result === true) ?
              "" : exprResults[0].message || TS.T("IPAD023_TAG005", "This record does not meet the qualification criteria for this SFM Transaction")
          };
          callback(result);
        }),
        onError: SVMX.proxy(this, function(inError) {
          SVMX.getLoggingService()
                        .getLogger("OFFLINE-SAL-MODEL-PlatformSpecifics")
                        .error("IGNORING ERROR: Failed to get expressions in GetObjectData");
          // TODO: Need better error handling than just approving the process...
          callback({isSFMProcess:true, isQualified:true});
        })
      });
    },

    getBasicDisplayTags : function(){
      var ret = {};
      return ret;
    },

    performNewAfterSave : function(params, engine){
      var processId = params.data.processId;
      var de = engine, container = de.getRootContainerId(), nextStepId = de.nextStepId;
      var returnUrl = de.returnUrl, onEngineReady = de.onEngineReady, onEngineRendered = de.onEngineRendered;
      var requestClose = de.requestClose;

      var options = {processId : processId, returnUrl : "", nextStepId : "", container : container,
              returnUrl : returnUrl, nextStepId : nextStepId,
              onEngineReady :onEngineReady, onEngineRendered : onEngineRendered,
              requestClose : requestClose
            };

      //Not the right way to access to engine methods..introduce a new api.
      de.__loadInternal(options);
    },

   navigateToTargetRecord : function(resultantRecord, callback, delEng, reqEvtBind){

      var eng = delEng;
      if(resultantRecord){
          this.showRecordFrombubbleInfo({key : resultantRecord});
      }

      var viewLoadedHandler =  function(evt){
            if(eng){
              eng.doClose.call(eng);
              var currentApp = SVMX.getCurrentApplication();

              if(evt.data &&  evt.data.getId()){
                var windowId = evt.data.getId(),
                newDelEng = currentApp.findConsoleAppByWindowId(windowId);

                newDelEng.__opener =  eng.requestClose.context.getOpener() || null;
                currentApp.showConsoleApp(windowId)
              }
            eng = null;
            currentApp.unbind("SFMDELIVERY.VIEW_LOADED", viewLoadedHandler, this);
          }
      };

      //Binding Event Only for MFL
      if(reqEvtBind && this.__clientType && this.__clientType.toLowerCase() === 'laptop'){
        eng.unblockApplication();
        SVMX.getCurrentApplication().bind("SFMDELIVERY.VIEW_LOADED", viewLoadedHandler, this);
      }
      else{
        callback(true);
      }

    },

    getItemFromCache : function(key){
      var ret = false;
      return ret;
    },

    validateEmail : function(email){
      var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    },

    getFormattedDateTimeValue : function(value, timeZoneOffset){
      // Date Times are now always passed around as save format in GMT
      if (!value) {
        value ="";
      }

      return value;
    },

    getFormattedDateValue : function(value){
      // Date Times are now always passed around as save format in GMT
      if (!value) {
        value ="";
      }

      return value;
    },

    //Method to launch the record in view mode, if view process is available.
    showRecord: function(info) {
        var d = SVMX.Deferred();

          //Navigate to the record
          this.__logger.info("Performing SFM action => ");

          //recordID and obj name
          var recId = info.key;
          var objectName = info.objectName;
          if (!objectName) {
              objectName = this.__getObjectName(recId);
          }

          var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;
          OfflineDataUtils.getRecord({
              Id: recId,
              loadReferences: true, // TODO: Test expressions using reference values
              convertPicklists: true // TODO: Test expressions using picklist values
          })
          .then(SVMX.proxy(this, function(record) {
              //get the first view process from the list of all view processes for the object type
              this.__getProcessId(record, objectName)
                  .done(function(inProcessId) {
                        var DatetimeUtils = com.servicemax.client.lib.datetimeutils.DatetimeUtil;
                        var OfflineMetaUtils  = com.servicemax.client.offline.sal.model.utils.MetaData;
                        var currentApp = SVMX.getCurrentApplication();
                        var lastAccessed = DatetimeUtils.getCurrentDatetimeGMT(DatetimeUtils.getSaveFormat('dateTime'));
                        var nameField = OfflineMetaUtils.getNameField(objectName);
                        if(inProcessId && inProcessId != undefined && inProcessId.length > 0) {
                            //LAP-6115 Recents - Item accessed from Account/Product history should show in Recent Items
                            var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                            "RECENTS.ADD_RECENTS", this, {
                              request: {
                                recordId : recId,
                                objectName : objectName,
                                lastAccessed : lastAccessed,
                                nameField : nameField,
                                type : "VIEW"
                              },
                              responder:{
                                result:function(){
                                  //Added to recents
                                  SVMX.getLoggingService().getLogger("sfmsearch").info("Added Record to Recents");
                                }
                              }
                            });
                            currentApp.triggerEvent(evt);
                            var request = {
                                SVMX_processId: inProcessId,
                                SVMX_recordId: recId,
                                SVMX_record: record
                            };
                            SVMX.getCurrentApplication().launchConsoleApp("sfmdelivery", request);
                            d.resolve();
                        }  else {
                            var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("IPAD");
                            var message = TS.T("TODO", "View not configured for this record. Please contact your system administrator.");

                            SVMX.getCurrentApplication()
                                .getApplicationMessageUIHandler()
                                .showMessage({
                                    type: "INFO",
                                    text: message,
                                    buttons: ['OK'],
                                    handler: function(buttonId) {
                                        d.reject();
                                    }
                            });
                        }
                  })
                  //Fails because alert is shown, which resolves to fix doubletapping defect
                  .fail(function() {
                      d.reject();
                  });
          }))
          .fail(function(){
              d.reject()
          });

          return d;
      },

    createNavigation: function(param) {

      var d = SVMX.Deferred();
      var recId = param.recordId;
      var objectName = this.__getObjectName(recId);
      var OfflineDataUtils = com.servicemax.client.offline.sal.model.utils.Data;

      OfflineDataUtils.getRecord({
            Id: recId,
            loadReferences: true, // TODO: Test expressions using reference values
            convertPicklists: true // TODO: Test expressions using picklist values
        })
        .then(SVMX.proxy(this, function(record) {

            //get the first view process from the list of all view processes for the object type
            this.__getProcessId(record, objectName)
                .done(function(inProcessId) {
                    if(inProcessId && inProcessId != undefined && inProcessId.length > 0) {
                        var options = {
                            SVMX_processId: inProcessId,
                            SVMX_recordId: recId,
                            SVMX_record: record
                        };

                        var stateManager = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.statemanager");
                        stateManager.replaceState({
                          app: "sfmdelivery",
                          options: options
                        });

                    } else {

                        var TS = SVMX.getClient().getServiceRegistry().getServiceInstance("com.servicemax.client.translation").getDictionary("IPAD");
                        var message = TS.T("TODO", "View not configured for this record. Please contact your system administrator.");

                        SVMX.getCurrentApplication()
                            .getApplicationMessageUIHandler()
                            .showMessage({
                                type: "INFO",
                                text: message,
                                buttons: ['OK'],
                                handler: function(buttonId) {
                                    d.reject();
                                }
                            });
                    }
                })
                .fail(function() {
                    d.reject();
                });
        }))
        .fail(function(){
            d.reject()
        });
        return d;
    },

    __getProcessId: function(record, objectName, callback, noAlert) {
          var d = SVMX.Deferred();
          var OfflineMetaUtils = com.servicemax.client.offline.sal.model.utils.MetaData;

            OfflineMetaUtils.getQualifiedProcessesForRecord({
                objectName: objectName,
                record: record,
                processType: "VIEW RECORD",
                considerDefaultView: true
            })
            .then(SVMX.proxy(this, function(viewProcesses, record) {
                if (viewProcesses.length) {
                    var result = viewProcesses[0].process_unique_id;
                    d.resolve(result);
                } else if (noAlert) {
                    d.resolve(null);
                }
                d.resolve();
            }));
            return d;
        },

        __getObjectName: function(rid, callback) {
          var OfflineMetaUtils = com.servicemax.client.offline.sal.model.utils.MetaData;
          return OfflineMetaUtils.getTableForId(rid);
        }

  }, {});

  salModelImpl.Class("SFMDeliveryData", com.servicemax.client.lib.api.EventDispatcher, {
    __data : null, _targetRecordId : null, _sourceRecordId : null, __logger : null, __deletedRecords : null,
    __error: null,
    __constructor : function(data){
      this.__base();
      this.__logger = SVMX.getLoggingService().getLogger("SFMDELIVERY-SAL_DATA");
      this.__data = data;
      this.__error = data.error;
      this.__deletedRecords = [];
      this._initialize();
    },

    _initialize : function(){
      this._targetRecordId = this.__data.pageDataSet.sobjectinfo.Id;
      this._sourceRecordId = this.__data.pageDataSet.sourceRecordID;

      this._initialize2();
    },

    _resolveRecordTypes: function(sobjectinfo, tableName) {
      var recordTypeId = sobjectinfo.RecordTypeId;
      if (sobjectinfo.RecordTypeId && sobjectinfo.RecordTypeId.fieldvalue && sobjectinfo.RecordTypeId.fieldvalue.key) {
        var recordTypeId = sobjectinfo.RecordTypeId.fieldvalue.key;
        var recordTypeEntries = com.servicemax.client.offline.sal.model.utils.Cache.readFromJSCache("SFMDELIVERY.RecordTypes", tableName);
        var recordTypeEntry = SVMX.array.get(recordTypeEntries, function(entry) {
          return entry.recordTypeId == recordTypeId;
        });

        var recordTypeName = recordTypeEntry ? recordTypeEntry.name : null;
        if (recordTypeName) {
          sobjectinfo.RecordTypeId.fieldvalue.value = recordTypeName;
        }
      }

    },


    _initialize2 : function(){
      /**
       * Set up a new node "sfmData" which consolidates header and details in way that
       * they can be referenced by a structure agnostic path/expression
       */

      this.__data.sfmData = this.__extractData(this.__data.pageDataSet);

      // No attributes if this is created via an error handler instead of a success handler
      if (this.__data.sfmData.attributes) {
        this._resolveRecordTypes(this.__data.sfmData, this.__data.sfmData.attributes.type);
      }


      // set up the details
      this.__data.sfmData.details = {};
      var ds = this.__data.detailDataSet;
      if(ds){

        if(!(ds instanceof Array)){
          ds = [ds];
        }

        var i, l = ds.length;  // all data sets
        for(i = 0; i < l; i++){
          var pds = ds[i].pageDataSet, id = ds[i].aliasName;
          var detail = {lines : []};
          if(pds){    // all the lines

            if(!(pds instanceof Array)){
              pds = [pds];
            }

            if(pds.length > 0){
              var j, pdsLength = pds.length;
              for(j = 0; j < pdsLength; j++){
                detail.lines[j] = this.__extractData(pds[j]);
                this._resolveRecordTypes(detail.lines[j], detail.lines[j].attributes.type);
              }
            }
          }
          this.__data.sfmData.details[id] = detail;
        }
      }
    },

    /**
     * Extract the data from the bubble info!. This is required to get the values
     * for reference fields.
     *
     * @param pageDataSet
     * @returns
     */
    __extractData : function(pageDataSet){
      var sobject = pageDataSet.sobjectinfo, bubbleInfo = pageDataSet.bubbleInfo, i, l = 0;

      if(bubbleInfo){
        if(!(bubbleInfo instanceof Array)){
          bubbleInfo = [bubbleInfo];
        }
        l = bubbleInfo.length;
      }

      for(i = 0; i < l; i++){
        var bi = bubbleInfo[i], apiName = bi.fieldapiname, value = {};
        value.fieldapiname = apiName;
        value.fieldvalue = {};

        // make sure that Id is available as a simple attribute to generate target record consistently
        if(apiName == "Id"){
          value = bi.fieldvalue.value;
        }else{
          // the data is slightly different when got from GetData Vs when returned from event response
          if(bi.fieldvalue){
            if(bi.fieldvalue.value1){
              value.fieldvalue = {key : bi.fieldvalue.value, value : bi.fieldvalue.value1};
            }else{
              value.fieldvalue = {key : bi.fieldvalue.key, value : bi.fieldvalue.value};
            }
            if ("isNameSyncData" in bi.fieldvalue) {
              value.fieldvalue.isNameSyncData = bi.fieldvalue.isNameSyncData;
            }
            if ("hasViewSFM" in bi.fieldvalue) {
              value.fieldvalue.hasViewSFM = bi.fieldvalue.hasViewSFM;
            }
          }
        }

        sobject[apiName] = value;
      }

      // setup the source record ID, specifically for details
      // when a SOAP service is invoked, even though sourceRecordID is null, when converting from XML to JSON object,
      // the empty element in the XML gets converted to empty object! So we have to check if is a string.
      if(pageDataSet.sourceRecordID && typeof(pageDataSet.sourceRecordID) == 'string'){
        sobject.sourceRecordID = pageDataSet.sourceRecordID;
      }

      // setup the record ID
      // when a SOAP service is invoked, even though Id is null, when converting from XML to JSON object,
      // the empty element in the XML gets converted to empty object! So we have to check if is a object.
      if(sobject.Id && typeof(sobject.Id) == 'object'){
        delete sobject.Id;
      }
      return sobject;
    },

    reset : function(newData, notifyListeners){
      this.__logger.info("Performing reset of sal-model");

      this.__data = newData;
      this._initialize2();

      this.__logger.info("Notifying the listeners that the sal-model has been reset");
      // notify the model listeners
      if(notifyListeners){
        var evt = SVMX.create("com.servicemax.client.lib.api.Event", "MODEL_UPDATED", this, {});
        this.triggerEvent(evt);
      }
    },

    updateFromEvent : function(newData){
      this.reset(newData, true);
    },

    copyFromTargetRecord : function(targetRecord){
      // this happens when we an event is executed that runs locally (for example, JS events)

      var newData = {
          pageDataSet : {
              sobjectinfo : {
                  attributes : {
                       type: targetRecord.headerRecord.objName,
                       url: "TODO"
                  }
              },
              bubbleInfo : []},
        detailDataSet : []};

      // copy the header
      var hr = targetRecord.headerRecord.records[0].targetRecordAsKeyValue, i, l = hr.length;
      for(i = 0; i < l; i++){
        newData.pageDataSet.bubbleInfo[i] = {fieldapiname : hr[i].key, fieldvalue : {key : hr[i].value, value : hr[i].value1}};
        if(newData.pageDataSet.bubbleInfo[i].fieldvalue.value === null || newData.pageDataSet.bubbleInfo[i].fieldvalue.value === undefined){
          newData.pageDataSet.bubbleInfo[i].fieldvalue.value = newData.pageDataSet.bubbleInfo[i].fieldvalue.key;
        }
      }

      // copy details
      var details = targetRecord.detailRecords, l = details.length;
      for(i = 0; i < l; i++){
        var detail = details[i], aliasName = detail.aliasName,
          records = detail.records, j, rl = records.length, detailDataSetItem = null;

        detailDataSetItem = {aliasName : aliasName, pageDataSet : []};
        for(j = 0; j < rl; j++){
          var sourceRecord = records[j].targetRecordAsKeyValue, k, srl = sourceRecord.length, m;
          detailDataSetItem.pageDataSet[j] = {sobjectinfo : {
              attributes: {
                  type: detail.objName, url: "TODO"
              }
           }};
          var bi = detailDataSetItem.pageDataSet[j].bubbleInfo = [];

          // setup the source record ID
          if(records[j].sourceRecordId){
            detailDataSetItem.pageDataSet[j].sobjectinfo.sourceRecordID = records[j].sourceRecordId;
          }

          for(k = 0, m = 0; k < srl; k++){

            if(sourceRecord[k].key == "Id"){
              detailDataSetItem.pageDataSet[j].sobjectinfo.Id = sourceRecord[k].value;
            }else{
              bi[m] = {fieldapiname : sourceRecord[k].key, fieldvalue : {key : sourceRecord[k].value, value : sourceRecord[k].value1}};
              if(bi[m].fieldvalue.value === null || bi[m].fieldvalue.value === undefined){
                bi[m].fieldvalue.value = bi[m].fieldvalue.key;
              }
              m++;
            }
          }
        }

        newData.detailDataSet[newData.detailDataSet.length] = detailDataSetItem;
      }
      this.updateFromEvent(newData);
    },

    getTargetRecordId : function(){
      return this._targetRecordId;
    },

    setTargetRecordId : function(value){
      this._targetRecordId = value;
    },

    getSourceRecordId : function(){
      return this._sourceRecordId;
    },

    getDeletedRecords : function(){
      return this.__deletedRecords;
    },

    getValueFromPath : function(path){
      var pathItems = path.split("."), i, l = pathItems.length, value = this.__data.sfmData;
      for(i = 0; i < l; i++){
        value = value[pathItems[i]];

        if(!value) break;
      }
      return value;
    },

    getRawData : function(){
      return this.__data;
    },

/**
     * getRawValues
     * @param {Object} inOptions:
     *    {String} [referenceValue] "key" or "value" or null to get entire reference value
     *    {Object} [data] If provided, then use this data instead of sobjectinfo.  Why use this?
     *             So that we don't have to call getRawValues on all 300 line items all at once,
     *             and can pass in line items as inData.
     *    {boolean} [includeLineItems] include the values of all line items.  If false, we just return
     *              the raw data without conversion. TODO: NOT YET IMPLEMENTED
     *    {Object} [fieldTypes] If converting fields, we need a hash describing the field types.
     *              See request.deliveryEngine.__page.getFieldTypes().
     *
      * TODO: find d away for online and offline to share this method which is an exact copy!
     */
    getRawValues : function(inOptions) {
      if (!inOptions) return this.__data.sfmData;

      var obj = {}, key;
      var src = inOptions.data || this.__data.sfmData;
      var field = inOptions.referenceValue;
      for (key in src) {
        if (key == "details") {
          obj.details = src.details;
        } else if (field && src[key] && typeof src[key] === "object" && "fieldvalue" in src[key] && field in src[key].fieldvalue) {
          obj[key] = src[key].fieldvalue[field];
        } else {
          obj[key] = src[key];
        }

        if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== "object" && inOptions.fieldTypes && "attributes" in src) {
          var objectType = src.attributes.type;
          var objectFields = inOptions.fieldTypes[objectType];
          var fieldType = objectFields ? objectFields[key] : "string";
          obj[key] = this.__convertFieldValue(obj[key], fieldType);
        }
      }
      return obj;
    },

        /*
         * validates a data object, retuns true or false
         *
         * @param   {Object}    inDate
         *
         * @return  {Boolean}
         */
        __isDateObject : function(inDate) {
            var valid = com.servicemax.client.lib.datetimeutils.DatetimeUtil.isValidDate(inDate);

            if (!valid) this.__logger.error("Invalid Date Object;", inDate);
            return valid;
        },
        /*
         * converts the field to a particular type
         *
         * @param   {String}    inValue
         * @param   {String}    inValue
         *
         * @return  {String|Date|Number}
         */
    __convertFieldValue : function(inValue, inType) {
      switch(inType) {
        case "date":
          if (!inValue) return inValue;
                    var d = com.servicemax.client.lib.datetimeutils.DatetimeUtil.parseDate(inValue);

                    if (this.__isDateObject(d)) {
                d.setHours(0,0,0);
                    }
                    return d;

        case "datetime":
                    if (!inValue) return inValue;
                    var d = com.servicemax.client.lib.datetimeutils.DatetimeUtil.parseDate(inValue);
          //quick check logs it if it's invalid
                    this.__isDateObject(d)

                    return d;
        case "boolean":
          return inValue === "true" || inValue === true;
        case "double":
        case "percent":
        case "currency":
          if (typeof inValue === "string") {
            return Number(inValue);
          } else {
            return inValue;
          }
        default:
          return inValue;
      }
    },
    deleteDetailRecords : function(records, alias){
      var bindingPath = "details." + alias,
        details = this.getValueFromPath(bindingPath),
        i, l = records.length, rowIndex;
      for(i = 0; i < l; i++){
        rowIndex = records[i].rowIndex;
        var deletedLine = details.lines.splice(rowIndex, 1),
          id = deletedLine[0].Id;
        if(id){
          this.__deletedRecords.push({alias : alias, id :id});
        }
      }

      // notify the model listeners
      var evt = SVMX.create("com.servicemax.client.lib.api.Event", "DETAIL_RECORDS_DELETED",
            this, {lines : records, bindingPath : bindingPath});
      this.triggerEvent(evt);
    },

    addNewDetailRecords : function(records, alias, callback){
      var bindingPath = "details." + alias, details = this.getValueFromPath(bindingPath),
            i, l = records.length, newRecords = {lines : []};
      for(i = 0; i < l; i++){
          var r = records[i].sobjectinfo;
          var r2 = {};
          if (r instanceof com.servicemax.client.data.impl.Record) {
              r.forEachField(function(fieldDef) {
                  var v = r.getValue(fieldDef);
                  if (v !== undefined) {
                       r2[fieldDef.name] = r.getValue(fieldDef);
                  }
              });
              r2.attributes = {type: r.getTableName(), url: "TODO"};
              if (r.__new) r2.__new = true;
          } else {
              r2 = SVMX.cloneObject(r);
          }
          var recordToExtract = {bubbleInfo: SVMX.cloneObject(records[i].bubbleInfo), sobjectinfo: r2};
        newRecords.lines[i] = details.lines[details.lines.length] = this.__extractData(recordToExtract);
      }

      // notify the model listeners
      var evt = SVMX.create("com.servicemax.client.lib.api.Event", "DETAIL_RECORDS_ADDED",
            this, {
                newRecords : SVMX.toObject(SVMX.toJSON(newRecords)),
                bindingPath : bindingPath,
                onSuccess : callback
            });
      this.triggerEvent(evt);
    },

    setValueToPath : function(path, value){

      var pathItems = path.split("."), i, l = pathItems.length, data = this.__data.sfmData, item, itemPath;
      for(i = 0; i < l; i++){
        item = data;
        itemPath = pathItems[i];
        data = data[itemPath];

        if(!data) break;
      }

      item[itemPath] = value;
    },
    getError : function() {return this.__error;}
  }, {});



  /**
   * The REST service manager class. Does nothing; copied from online version
   */
  salModelImpl.Class("RestServiceManager", com.servicemax.client.lib.api.Object, {
    params : null,

    __constructor : function(params){
      this.params = params;
    },

    createService : function(){
      var s =  SVMX.create("com.servicemax.client.offline.sal.impl.Placeholder", this);
      return s;
    }
  }, {});

  /**
   * The SOAP service manager class. Does nothing; copied from online version
   */
  salModelImpl.Class("SoapServiceManager", com.servicemax.client.lib.api.Object, {
    params : null,

    __constructor : function(params){
      this.params = params;
    },

    createService : function(){
      var s =  SVMX.create("com.servicemax.client.offline.sal.model.impl.Placeholder", this);
      return s;
    }
  }, {});

  salModelImpl.Class("Placeholder", com.servicemax.client.lib.core.Service, {
    __constructor : function(){

    },
    bind: function(fname, callback, context) {
      callback.call(context, {data: "Not implemented"});
    },
    callMethodAsync: function() {
    }
  }, {});
/**
   * The service manager factory; copied from online version without change
   */
  salModelImpl.Class("ServiceManagerFactory", com.servicemax.client.lib.api.Object, {

    __constructor : function(){

    },

    createServiceManager : function(params){
      if(!params) params = {};

      // serviceMax Service API Version
      params.svmxServiceVersion = SVMX.getClient().getApplicationParameter("svmx-api-version");

      // sfdc session id
      params.sessionId = SVMX.getClient().getApplicationParameter("session-id");

      if(params.type == "SOAP")
        return new salModelImpl.SoapServiceManager(params);
      else
        return new salModelImpl.RestServiceManager(params);
    }

  }, { });
})();

// end of file
