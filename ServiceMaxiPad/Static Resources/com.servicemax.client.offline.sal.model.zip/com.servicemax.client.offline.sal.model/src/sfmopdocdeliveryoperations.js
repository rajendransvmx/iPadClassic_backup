/**
 * This file needs a description
 * @class com.servicemax.client.tablet.sal.sfmopdoc.model.operations
 * @singleton
 * @author unknown
 *
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){
    var sfmopdocdeliveryoperations = SVMX.Package("com.servicemax.client.offline.sal.model.sfmopdocdelivery.operations");

sfmopdocdeliveryoperations.init = function(){

    var OfflineSystemUtils = com.servicemax.client.offline.sal.model.utils.SystemData;

    sfmopdocdeliveryoperations.Class("GetUserInfo", com.servicemax.client.mvc.api.Operation, {

        __constructor: function(){
            this.__base();
        },

        performAsync: function(request, responder){
           var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.Utils");
           responder.result(utils.getUserInfo());
        }
    }, {});

    sfmopdocdeliveryoperations.Class("GetTemplate", com.servicemax.client.mvc.api.Operation, {

        __constructor: function(){
            this.__base();
        },

        performAsync: function(request, responder){
            var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.Utils");
            var requestData = { ProcessId : request.processId };
            var params = {ProcessId : requestData.ProcessId};
            utils.getTemplate(params, function(resp){
                responder.result(resp);
            });
        }

    }, {});

    sfmopdocdeliveryoperations.Class("GetDocumentMetadata", com.servicemax.client.mvc.api.Operation, {

        __constructor: function(){
            this.__base();
        },

        performAsync: function(request, responder){
            var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.Utils");
            var requestData = {ProcessId   : request.processId};
            var params = {ProcessId : requestData.ProcessId};
            utils.getDocumentMetaData(params, function(resp){
                responder.result(resp);
            })
        }

    }, {});

    sfmopdocdeliveryoperations.Class("CreatePDF", com.servicemax.client.mvc.api.Operation, {

        __constructor: function(){
            this.__base();
        },

        performAsync: function(request, responder){
            var requestData = {
                DocumentId: request.documentId,
                RecordId: request.recordId
            };
        }

    }, {});

    sfmopdocdeliveryoperations.Class("DescribeObject", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {
            var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.Utils");
            utils.describeObject(request, responder).always(
                SVMX.proxy(this, function(resp) {
                    responder.result(resp);
                })
            );
        }

    }, {});

    sfmopdocdeliveryoperations.Class("GetDocumentData", com.servicemax.client.mvc.api.Operation, {

        __constructor: function(){
            this.__base();
        },

        performAsync: function(request, responder){
            var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.Utils");
            var requestData = {ProcessId   : request.processId, RecordId : request.recordId};
            var params = {ProcessId : requestData.ProcessId, RecordId : requestData.RecordId};
            setTimeout(function(){
                utils.getDocumentData(params, function(resp){
                    responder.result(resp);
                })
            },100);

        }

    }, {});

    sfmopdocdeliveryoperations.Class("CaptureSignature", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {

            // Figure out if we want to use to capture the signature: device or html (MFL and iOS use device).
            var captureType = SVMX.getClient().getApplicationParameter("svmx-sfm-opdoc-sig-capture");
            var nativeService = com.servicemax.client.offline.sal.model.nativeservice.Facade;
            var deviceCheckRequest = nativeService.createSignatureDeviceCheckRequest();
            var isSigDeviceConnected;

            deviceCheckRequest.bind("REQUEST_COMPLETED", function(evt) {
                isSigDeviceConnected = evt.data.data;
            }, this);

            deviceCheckRequest.bind("REQUEST_ERROR", function(evt) {
                SVMX.getLoggingService().getLogger("deviceCheckRequest Failed: " + evt.data);
                console.warn("error" + evt.data);
            });

            deviceCheckRequest.execute({
                async : false
            });

            var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.Utils");
            var requestData = {
                    recordId         : request.recordId,
                    processId        : request.processId,
                    uniqueName       : request.uniqueName,
                    captureSignature : request.captureSignature,
                    imgHeight        : request.imgHeight,
                    imgWidth         : request.imgWidth
            };

            setTimeout(function(){
                // if the captureType is html or the Topaz signature device isn't connected, use the html signature capture
                if ((captureType && captureType === "html") && (isSigDeviceConnected === undefined || isSigDeviceConnected === "False")) {
                    utils.captureHtmlSignature(requestData, function(resp){
                       responder.result(resp);
                    });
                } else { // use the Topaz device for the signature
                    utils.captureDeviceSignature(requestData, function(resp){
                       responder.result(resp);
                    });

                }
            },100);
        }

    }, {});

    sfmopdocdeliveryoperations.Class("Finalize", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },
        performAsync : function(request, responder) {
            var requestData = {
                ProcessId   : request.processId,
                RecordId    : request.recordId,
                HTMLContent : request.htmlContent,
                SourceRecord: request.sourceRecord
            };

            var me = this;
            var requestClose = request.requestClose;
            var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.Utils");

              // Figure out if we want to finalize locally (MFL) or if we need to do it remotely (Mobile).
              var isMobile = SVMX.getClient().getApplicationParameter("svmx-mobile");

              var localRequestClose = function() {
                  // Trigger refresh, since target object might has been updated.
                  var evt = SVMX.create("com.servicemax.client.lib.api.Event",
                          "SFMOPDOCDELIVERY.NOTIFY_DATA_CHANGE", me,{
                            request : {
                              processId   : request.processId,
                              recordId    : request.recordId
                            }
                        });

                  var app = SVMX.getCurrentApplication();
                  app.triggerEvent(evt);

                  requestClose.handler.apply(requestClose.context);

              };
              if (isMobile && isMobile == "true" && SVMX.getClient().isLaptop() === false) {
                  var pdf = utils.finalizeRemote(requestData, function(success){
                      SVMX.getLoggingService()
                          .getLogger("OFFLINE-SAL-MODEL-PlatformSpecifics")
                          .info("PDF Generated Successfully!");
                      localRequestClose();
                      me._performAggressiveSync();

                  }, me);
              } else {
                  var pdf = utils.finalizeLocal(requestData, function(success){
                      SVMX.getLoggingService()
                          .getLogger("OFFLINE-SAL-MODEL-PlatformSpecifics")
                          .info("PDF Generated Successfully!");
                      localRequestClose();
                      me._performAggressiveSync();
                  }, me);
              }
        },

        _performAggressiveSync: function(){
            // Perfom Aggressive Sync
            SVMX.getCurrentApplication().getSyncImpl().performAggressiveSync();
        }

    }, {});

    sfmopdocdeliveryoperations.Class("SubmitQuery", com.servicemax.client.mvc.api.Operation, {

        __constructor: function(){
            this.__base();
        },

        _performInternal: function(request, callback, context){
            var utils = SVMX.create("com.servicemax.client.offline.sal.model.sfmopdocdeliveryutils.Utils");
            var qc = request.queryConfig;
            var q = "SELECT " + qc.fields + " FROM " + qc.api;
            if (qc.condition && qc.condition != "") {
                q += " WHERE " + qc.condition;
            }
            var requestData = {
                Query: q
            };
           utils.submitQuery(requestData, function(resp){
                callback.call(context, resp);
           })
        },

        performAsync: function(request, responder){

        }

    }, {});

    sfmopdocdeliveryoperations.Class("GetDisplayTags", com.servicemax.client.mvc.api.Operation, {

        __constructor : function(){ this.__base(); },

        performAsync : function(request, responder) {

            var requestData = {};
            var TS = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.translation").getInstance().getDictionary("IPAD");
            responder.result({
                              "SFM004_TAG003" : TS.T("SFM004_TAG003", "This record does not meet the qualification criteria for this Output Document"),
                              "SFM004_TAG006" : TS.T("SFM004_TAG006", "Finalize"),
                              "SFM004_TAG009" : TS.T("SFM004_TAG009", "Checklist result for"),
                              "SFM004_TAG010" : TS.T("SFM004_TAG010", "Section"),
                              "SFM004_TAG011" : TS.T("SFM004_TAG011", "Question"),
                              "SFM004_TAG012" : TS.T("SFM004_TAG012", "Answer")
                            });
        }
    }, {});

    sfmopdocdeliveryoperations.Class("PlatformSpecifics", com.servicemax.client.lib.api.Object, {
        __constructor : function(){

        },

        getQualificationInfo : function(recordID, processId, callback, context){
            var OfflineExprUtils = com.servicemax.client.offline.sal.model.utils.Expressions;
            OfflineExprUtils.evaluate({
                recordId: recordID,
                processId: processId,
                returnMessage: true,
                onSuccess: SVMX.proxy(this, function(exprResults) {
                    var TS = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.translation").getInstance().getDictionary("SFMDELIVERY");
                    if(exprResults[0].result == false){
                        SVMX.getCurrentApplication().getRoot().hideLoading();
                    }
                    var result = {
                        isSFMProcess: true,
                        isQualified: exprResults[0].result,
                        errorMessage: (exprResults[0].result === true) ?
                            "" : exprResults[0].message || TS.T("SFM004_TAG003", "This record does not meet the qualification criteria for this Output Document")
                    };
                    callback.call(context, result);
                }),
                onError: SVMX.proxy(this, function(inError) {
                    SVMX.getLoggingService()
                        .getLogger("OFFLINE-SAL-MODEL-PlatformSpecifics")
                        .error("IGNORING ERROR: Failed to get expressions in GetObjectData");
                    // TODO: Need better error handling than just approving the process...
                    callback.call(context, {isSFMProcess:true, isQualified:true});
                })
            });
        },

        alert : function(msg, requestClose){
            SVMX.getCurrentApplication().showMessage({
                type: "INFO",
                title: " ",
                text: msg,
                buttons: ['OK'],
                handler: function(buttonId) {
                    // When this fails, either we are openning a new process, in which case we don't yet have a root and need
                    // to close the window, OR we are navigating to a new process or record (linked processes) and its failed,
                    // in which case we need to reset the recordId, processId, etc... even though the UI hasn't changed.
                    requestClose.handler.apply(requestClose.context);
                }
            });
        },
        navigateBack : function(retUrl){

        },

        getSettingsInfo : function(){
            return {};
        }
    }, {});

};
})();

// end of file
