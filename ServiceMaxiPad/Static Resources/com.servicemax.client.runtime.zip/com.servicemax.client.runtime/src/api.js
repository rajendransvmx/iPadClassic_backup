/**
 * This file needs a description 
 * @class com.servicemax.client.runtime.api
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	var runtimeApi = SVMX.Package("com.servicemax.client.runtime.api");
	
	runtimeApi.Class("AbstractNamedInstance", com.servicemax.client.lib.api.Object, {
		
		__constructor : function(){
			
		},
		
		initialize : function(name, data, params){
			
		}
	}, {});
})();

// end of file