var getRecord;
QUnit.module("operationValidator", {
    setup: function() {
        //initialize code
        getRecord = SVMX.create("com.servicemax.client.installigence.offline.model.operations.GetRecords", {},{});
    },
    teardown: function() {
        //cleanup code
        if(getRecord){
            getRecord.__findLocalRecords.restore();
            getRecord.__findRemoteRecords.restore(); 
            getRecord.__findServerRecords.restore(); 
        }
    }
});

test("GetRecordValidator", function(){
    var request = {
        objectName : "Account",
        onlineChecked : true,
        mflChecked : true,
        parentNodeId: '03456767'

    };
    var responder = {};
    responder.result = function(){};
    var localRecordFound = null;
    var remoteRecordFound = null;
    var serverRecordFound = null;

    sinon.stub(getRecord, "__findLocalRecords", function(){
        localRecordFound = [{Name : "IB001"}];
        var d = SVMX.Deferred();
        d.resolve(localRecordFound);
        return d;
    });
    
    sinon.stub(getRecord, "__findRemoteRecords", function(){
        remoteRecordFound = [{Name : "IB003"}];
        var d = SVMX.Deferred();
        d.resolve(remoteRecordFound);
        return d;
    });

    sinon.stub(getRecord, "__findServerRecords", function(){
        serverRecordFound = [{Name : "IB002"}];
        var d = SVMX.Deferred();
        d.resolve(serverRecordFound);
        return d;
    });
    
    getRecord.performAsync(request,responder);
    equal(localRecordFound[0].Name, "IB001", "Local Records Found");
    equal(remoteRecordFound[0].Name, "IB003", "Remote Records Found");
    equal(serverRecordFound[0].Name, "IB002", "Server Records Found");
});

