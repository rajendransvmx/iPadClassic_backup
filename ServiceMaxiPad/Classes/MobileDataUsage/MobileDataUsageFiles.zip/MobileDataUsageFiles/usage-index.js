
(function($){

	window.__SVMX_LOAD_APPLICATION__ = function(options){

		$(document).ready(function(){

			// create the client instance
			var client = new com.servicemax.client.lib.core.Client();
			if(options.handler){
                   var handler = options.handler;
                   var context = options.context;
                   client.addApplicationParameter("onappload-handler", {handler : handler, context : context});
                   }
			var configType = options.configType ? options.configType : "remote";
			var configData = options.configData ? options.configData : "usage-config.json";
			client.run({configType : configType, data : configData, loadVersion : options.loadVersion});
		});

	};

})(jQuery);

// end of file