(function(){
	window.external = {};
	var ext = window.external;
	
	ext.execute = function(paramStr){
		var req = SVMX.toObject(paramStr);
		if(req.Type == "SQL"){
			executeSQL(req);
		}else if(req.Type == "HTTP"){
			executeHTTP(req);
		}else if(req.Type == "EXTERNALAPP"){
			executeExternalApp(req);
		}else if(req.Type == "CHECKCONNECTIVITY") {
			executeCheckConnectivity(req);
        }else if(req.Type == "MISC") {
        	if (req.MethodName == "LAUNCHURL") {
				executeCustomActionURL(req);
			} 
			else if (req.MethodName == "GETSETTINGVALUE") {
				executeGetSettingValue(req);
			}
			else if (req.MethodName == "DEVICEINFO") {
				executeGetDeviceInfo(req);
			}
			else if (req.MethodName == "LOGININFO") {
				executeLoginInfo(req);
			}
			else if(req.MethodName == "ERRORDETAILS"){
				executeErrorDetails(req);
			}
			else {
				  executeLoginInfo(req);
			}
        }
        else if(req.Type == "SETMESSAGEHANDLER") {
            executeSetMessageHandler(req);
        } 
        else if(req.Type == "FILEIO") 
        {
            if (req.MethodName == "READOPENFILE") {
				executeReadOpenFile(req);
			} 
        }

        else{
			//alert(SVMX.toJSON(req));
		}
	};

	function executeExternalApp(req){
		if(req.MethodName == "APPINFO"){
			setTimeout(function(){
				var request = {
					RequestId : req.RequestId,
					MethodName : req.MethodName,
					Type : req.Type,
					jsCallback : req.jsCallback
				};

				var response = {
					Status : true,
					RequestId : req.RequestId,
					MethodName : req.MethodName,
					Type : req.Type,
					CurrentPage : 1,
					TotalPages : 1,
					Result : SVMX.toJSON([{Installed : false}])
				};

				respond(request, response);
			}, 10);
		}else{
			//alert(SVMX.toJSON(req));
		}
	}

	function executeHTTP2(req){
		var res = {};
		var p = SVMX.toObject(req.ParameterString), uri = p.Uri, data = p.RequestBody, method = p.RequestMethod;
		var headers = SVMX.toObject(p.HttpRequestHeaders) || [];
	
		HTTP.sendRequest({
			uri : uri,
			method : method,
			data : data,
			headers : headers,
			onSuccess : function(data, headers, code){
				res.Status = true;
				var response = {ResponseHeaders : headers, ResponseBody : data, StatusCode : code};
				res.Result = SVMX.toJSON(response);
				res.CurrentPage = res.TotalPages = 1;
				respond(req, res);
			},
			onError : function(message){
				res.Status = false;
				res.Result = message;
				respond(req, res);
			}
		});
	}
    
	function executeHTTP(req){
		var p = SVMX.toObject(req.ParameterString), uri = p.Uri, body = p.RequestBody ? p.RequestBody : "{}", method = p.RequestMethod;
		var r = {
				type : req.Type, 
				requestId : req.RequestId, 
				methodName : req.MethodName,
				isNonSalesforceUrl: p.isNonSalesforceUrl,
				httpRequestHeaders: p.HttpRequestHeaders,
				parameterString: req.ParameterString,
				currentPage: req.CurrentPage,
				totalPages:req.TotalPages,
				uri : uri, 
				body : body, 
				method : method, 
				nativeCallbackHandler : "nativeCallbackHandlerHTTP", 
				jsCallback : req.jsCallback,
				className  : "MobileDataUsage"
			};
		BRIDGE.invoke("HTTP", "callServer", r);
	}

	

	


	window.nativeCallbackHandlerHTTP = function(resp){
		resp = SVMX.toObject(resp);
		var request = {
			RequestId : resp.requestId,
			MethodName : resp.methodName,
			Type : resp.type,
			jsCallback : resp.jsCallback
		};

		var response = {
			Status : true,
			RequestId : resp.requestId,
			MethodName : resp.methodName,
			Type : resp.type,
			CurrentPage : 1,
			TotalPages : 1,
			Result : SVMX.toJSON({ResponseBody : resp.responseText, StatusCode : 200})
		};
		respond(request, response);
	}

	function executeSQL(req){
		console.log(req.ParameterString);
		var query = SVMX.toObject(req.ParameterString).SQL;
		var r = {type : req.Type, requestId : req.RequestId, methodName : req.MethodName, 
					query : query, nativeCallbackHandler : "nativeCallbackHandlerSQL", jsCallback : req.jsCallback};
		INFO(r.query);
		BRIDGE.invoke("DB", "executeQuery", r);
	}

	window.nativeCallbackHandlerSQL = function(resp){
		resp = SVMX.toObject(resp);
		var request = {
			RequestId : resp.requestId,
			MethodName : resp.methodName,
			Type : resp.type,
			jsCallback : resp.jsCallback
		};

		var response = {
			Status : true,
			RequestId : resp.requestId,
			MethodName : resp.methodName,
			Type : resp.type,
			CurrentPage : 1,
			TotalPages : 1,
			Result : SVMX.toJSON(resp.rows)
		};

		respond(request, response);
	};

	function executeCheckConnectivity(req) {
        console.log(req.ParameterString);
        var r = {type : req.Type, requestId : req.RequestId, methodName : req.MethodName,
                 nativeCallbackHandler : "nativeCallbackHandlerConnectivity", jsCallback : req.jsCallback};
        BRIDGE.invoke("Misc", "checkNetworkReachability", r);

	}
 
   window.nativeCallbackHandlerConnectivity = function(resp){
        resp = SVMX.toObject(resp);
        var request = {
        RequestId : resp.requestId,
        MethodName : resp.methodName,
        Type : resp.type,
        jsCallback : resp.jsCallback
        };
 
        var response = {
            Status : true,
            RequestId : resp.requestId,
            MethodName : resp.methodName,
            Type : resp.type,
            CurrentPage : 1,
            TotalPages : 1,
            Result : SVMX.toJSON(resp.networkStatus)
        };
 
    respond(request, response);
	};
 
 
    function executeLoginInfo(req) {
            console.log(req.ParameterString);
            var r = {type : req.Type, operation : "LOGININFO", requestId : req.RequestId, methodName : req.MethodName, nativeCallbackHandler : "nativeCallbackHandlerLoginInfo", jsCallback : req.jsCallback,className:"MobileDataUsage"};
            BRIDGE.invoke("Misc", "getLoginUserInfo", r);
    }
 
 
    window.nativeCallbackHandlerLoginInfo = function(resp){
            resp = SVMX.toObject(resp);
            var request = {
                RequestId : resp.requestId,
                MethodName : resp.methodName,
                Operation : resp.operation,
                Type : resp.type,
                jsCallback : resp.jsCallback
            };
 
            var response = {
                Status : true,
                RequestId : resp.requestId,
                MethodName : resp.methodName,
                Operation : resp.operation,
                Type : resp.type,
                CurrentPage : 1,
                TotalPages : 1,
                Result : SVMX.toJSON([resp.loginUserInfo])
            };
 
            respond(request, response);
	};
 
    function executeSetMessageHandler(req) {
        console.log(req.ParameterString);
        var r = {type : req.Type, operation : "SETMESSAGEHANDLER", requestId : req.RequestId, methodName : req.MethodName, nativeCallbackHandler : "nativeCallbackMessageHandler", jsCallback : req.jsCallback};
        BRIDGE.invoke("MessageHandler", "executeMessageHandler", r);
    }
 
    window.nativeCallbackMessageHandler = function(resp){
        resp = SVMX.toObject(resp);
        var request = {
            RequestId : resp.requestId,
            MethodName : resp.methodName,
            Operation : resp.operation,
            Type : resp.type,
            jsCallback : "externalRequestHandler"
        };
 
        var response = resp.data;
 
        respond(request, response);
	};

	function executeCustomActionURL(req) {
        console.log(req.ParameterString);
        var r = {type : req.Type, operation : "", requestId : req.RequestId, methodName : req.MethodName, nativeCallbackHandler : "nativeCallbackCustomActionHandler", jsCallback : req.jsCallback,params:req.ParameterString};
        BRIDGE.invoke("CustomActionURLHandler", "executeCustomActionURLHandler", r);
    }
    
    window.nativeCallbackCustomActionHandler = function(resp){
        resp = SVMX.toObject(resp);
        var request = {
            RequestId : resp.requestId,
            MethodName : resp.methodName,
            Operation : resp.operation,
            Type : resp.type,
            jsCallback : "externalRequestHandler"
        };
 
        var response = resp.data;
 
        respond(request, response);
	};

	function executeGetSettingValue(req) {
        console.log(req.ParameterString);
        var r = {type : req.Type, operation : "", requestId : req.RequestId, methodName : req.MethodName, nativeCallbackHandler : "nativeCallbackSettingValueHandler", jsCallback : req.jsCallback,params:req.ParameterString};
        BRIDGE.invoke("MobileDataUsageManager", "getSettingValue", r);
    }

    window.nativeCallbackSettingValueHandler = function(resp)
    {
      resp = SVMX.toObject(resp);
      var request = {
                RequestId : resp.requestId,
                MethodName : resp.methodName,
                Operation : resp.operation,
                Type : resp.type,
                jsCallback : resp.jsCallback
      };
      var response = {
		      	Result: "[{\"Key\":\"ToolsServerUrl\",\"Value\":\"" + resp.ToolsServerUrl + "\"}]", 
		      	Status: true,
		      	RequestId : resp.requestId,
				MethodName : resp.methodName,
				Type : resp.type,
				CurrentPage : 1,
				TotalPages : 1
      }
      respond(request, response);

    }
 
    function executeGetDeviceInfo(req) {
        console.log(req.ParameterString);
        var r = {type : req.Type, operation : "", requestId : req.RequestId, methodName : req.MethodName, nativeCallbackHandler : "nativeCallbackDeviceInfoHandler", jsCallback : req.jsCallback,params:req.ParameterString};
        BRIDGE.invoke("MobileDataUsageManager", "getDeviceInfo", r);
    }

    window.nativeCallbackDeviceInfoHandler = function(resp)
    {
      resp = SVMX.toObject(resp);
      var request = {
                RequestId : resp.requestId,
                MethodName : resp.methodName,
                Operation : resp.operation,
                Type : resp.type,
                jsCallback : resp.jsCallback
      };
      var response = {
		      	Result: SVMX.toJSON([resp.deviceInfo]), 
		      	Status: resp.status,
		      	RequestId : resp.requestId,
				MethodName : resp.methodName,
				Type : resp.type,
				CurrentPage : 1,
				TotalPages : 1
      };
      respond(request, response);

    }
 
    function executeReadOpenFile(req) {
        console.log(req.ParameterString);
        var r = {type : req.Type, operation : "", requestId : req.RequestId, methodName : req.MethodName, nativeCallbackHandler : "nativeCallbackReadOpenFileHandler", jsCallback : req.jsCallback,params:req.ParameterString};
        BRIDGE.invoke("MobileDataUsageManager", "getReadOpenFile", r);
    }

    window.nativeCallbackReadOpenFileHandler = function(resp)
    {
    	debugger;
      resp = SVMX.toObject(resp);
      var request = {
                RequestId : resp.requestId,
                MethodName : resp.methodName,
                Operation : resp.operation,
                Type : resp.type,
                jsCallback : resp.jsCallback
      };
      var response = {
		      	Result: SVMX.toJSON(resp.error), 
		      	Status: resp.Status,
		      	RequestId : resp.requestId,
				MethodName : resp.methodName,
				Type : resp.type,
				CurrentPage : 1,
				TotalPages : 1
      };
      respond(request, response);

    }
  
    function executeErrorDetails(req) {
        console.log(req.ParameterString);
        var r = {type : req.Type, operation : "", requestId : req.RequestId, methodName : req.MethodName, nativeCallbackHandler : "nativeCallbackErrorDetailsHandler", jsCallback : req.jsCallback,params:req.ParameterString};
        BRIDGE.invoke("MobileDataUsageManager", "getErrorDetails", r);
    }
    window.nativeCallbackErrorDetailsHandler = function(resp)
    {
      resp = SVMX.toObject(resp);
      var request = {
                RequestId : resp.requestId,
                MethodName : resp.methodName,
                Operation : resp.operation,
                Type : resp.type,
                jsCallback : resp.jsCallback
      };
      var response = {
		      	Result: SVMX.toJSON([{logType: resp.logType, exceptions: resp.exceptions, syncType: resp.syncType, toolsServerURL: resp.toolsServerURL}]), 
		      	Status: resp.status,
		      	RequestId : resp.requestId,
				MethodName : resp.methodName,
				Type : resp.type,
				CurrentPage : 1,
				TotalPages : 1
      };
      respond(request, response);

    }

	
	function respond(req, res){
		res.RequestId = req.RequestId;
		res.Type = req.Type;
		res.MethodName = req.MethodName;
		window[req.jsCallback](res);
	}
	
	function INFO(msg){
		SVMX.getLoggingService().getLogger("MOBILE-NATIVE-SERVICE").info(msg);
	}
	
	function ERROR(msg){
		SVMX.getLoggingService().getLogger("MOBILE-NATIVE-SERVICE").error(msg);
	}
})();