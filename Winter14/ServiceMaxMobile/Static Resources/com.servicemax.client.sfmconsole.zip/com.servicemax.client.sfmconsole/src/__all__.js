// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\api.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.api
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */
(function(){
	
	var clientConsoleApi = SVMX.Package("com.servicemax.client.sfmconsole.api");
	
	clientConsoleApi.Class("AbstractConsoleApp", com.servicemax.client.lib.api.Object, {
		__parent                    : null,
		__container                 : null,
		__size                      : [], 
		__visibilty                 : null,
		__group                     : null,
		__windowTitle               : null,
		__closeCallBack             : null,
		__callbackContext           : null,
		__uniqueProcessIdentifier   : null,
		
		__constructor : function(parent,container,options){
			this.__parent = parent;
			this.__container = container;
			this.__size.width = options.size.width;
			this.__size.height = options.size.height;
			this.__uniqueProcessIdentifier = options.upi;
		},
		
		start : function() {

		},

		requestClose : function () {
			var localOptions = {};
			localOptions.uniqueProcessIdentifier = this.getUniqueProcessIdentifier();
			localOptions.group = this.__group;
			this.__parent.destroyConsoleApp(localOptions);
		},		
		
		onCanClose : function (callback) {
			callback(true);
		},
		
		/**
		 * @event
		 * Subclasses override onClose to be notified when they are being closed so that they have time to clean up
		 * all resources and call destroy on anything needing destroying.
		 * The parent method is currently empty, but may be used to clean up resources at the window level
		 */
		onClose : function (options) {
			
		},
				
		refreshAppView : function () {
			
		},
		
		showLoadMask : function(target) {
			this.__parent.showLoadMask(target || this.__container);
		},
		
		hideLoadMask : function(target) {
			this.__parent.hideLoadMask(target || this.__container);
		},
		
		getGroup : function () {
			return this.__group;
		},
		
		getUniqueProcessIdentifier : function () {
			return this.__uniqueProcessIdentifier;
		},
		
		setWindowTitle : function(title){
			this.__windowTitle = title;
			this.__container.setTitle(this.__windowTitle);
		},
		
		getWindowTitle : function () {
			return this.__windowTitle;
		},
		
		getCloseCallBack : function () {
			return this.__closeCallBack;
		},
				
		getCallBackContext : function() {
			return this.__callbackContext;
		},
		
		setAppInfo : function (options) {
			options = options || {};
			
			this.__group = options.groupName;
			this.__windowTitle = options.windowTitle;
			this.__closeCallBack = options.closeCallback;
			this.__callbackContext = options.context;
		},
				
		getConsoleAppContainer : function() {
			return this.__container;
		},
		
		setRootContainer : function (container) {
			this.getConsoleAppContainer().add(container);
			this.onAppResize(this.getSize());
		},
		
		getSize : function() {
			return this.__size;
		},
		
		setSize : function() {
			
		},
		
		getVisibility : function(){
			return this.visibility;
		},
		
		setVisibility : function (){
			
		},
		
		closeConsoleApp : function (){

		}
	}, {});
	
	clientConsoleApi.Class("AbstractSync", com.servicemax.client.lib.api.Object, {
		__syncManager : null,
		__constructor : function(){},
		run : function() {},
		getSyncManager : function(){
			return this.__syncManager;
		}
	}, {});
		
	clientConsoleApi.Class("AbstractDeliveryEngine", com.servicemax.client.lib.api.Object, {
		
		__constructor : function(){
			
		},
		
		initAsync : function(options){},
		
		run : function(options){},
		
		getInterface : function(){
			return this;
		}
		
	}, {});
	
	clientConsoleApi.Class("CompositionMetaModel", com.servicemax.client.lib.api.EventDispatcher, {
		_data : null, _parent : null, _children : null, isDisplayOnly : false,
		
		__constructor : function(data, parent, isDisplayOnly){
			this.__base();
			this._data = data;
			this._parent = parent;
			this._children = {};
			if(parent){
				this.isDisplayOnly = parent.isDisplayOnly;
			}else{
				this.isDisplayOnly = false;
			}
		},
		
		getChildNode : function(name){
			return this._children[name];
		},
		
		getData : function(){
			return this._data;
		},
		
		getRoot : function(){
			if(this._parent === null) 
				return this;
			else
				return this._parent.getRoot();
		},
		
		resolveDependencies : function(){}
		
	}, {});

})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\commands.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.commands
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	var sfmconsolecommands = SVMX.Package("com.servicemax.client.sfmconsole.commands");
	
sfmconsolecommands.init = function(){
	// moved all the commands to delivery engines




     sfmconsolecommands.Class("GetUserInfo", com.servicemax.client.mvc.api.Command, {
        
        __constructor : function(){ this.__base(); },
        
        /**
         * 
         * @param request
         * @param responder
         */
        executeAsync : function(request, responder){
            this._executeOperationAsync(request, responder, {operationId : "SFMCONSOLE.GET_USERINFO"});
        }
    }, {});

     // TODO: Move this to responders.js
    sfmconsolecommands.Class("GetUserInfoResponder", com.servicemax.client.mvc.api.Responder, {
            __parent : null,
            __constructor : function(parent) { 
                this.__base(); 
                this.__parent = parent;
            },
            
            result : function(data) { 
                    this.__parent.onGetUserInfoCompleted(data);
            },
            
            fault : function(data) { 
                // TODO:
            }
            
        }, {});

};

})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\constants.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.constants
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	
	var constantsImpl = SVMX.Package("com.servicemax.client.sfmconsole.constants");

constantsImpl.init = function(){
	constantsImpl.Class("Constants", com.servicemax.client.lib.api.Object, {
		__constructor : function(){}
	}, {
		PREF_LOGGING					: "LOGGING"
	});
}	
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\expressionbridge.js
/**
 * @description This file acts as a bridge between the snippet and the jsee.
 * @class com.servicemax.client.sfmconsole.expressionbridge
 * @author Indresh MS
 * @copyright 2013 ServiceMax, Inc.
 */

(function(){
	var bridgeImpl = SVMX.Package("com.servicemax.client.sfmconsole.expressionbridge");
	
bridgeImpl.init = function(){

	if(window.$EXPR == undefined || window.$EXPR == null) window.$EXPR = {};
	
	/////////////////////////////// CORE ///////////////////////////
	
	/**
	 * The core API method to evaluate the JS expression
	 * 
	 * @param expression String the expression that needs to be evaluated
	 * @param context Object the contextual data that this expression works on
	 * @param callId String the unique identifier assigned to a particular call. This serves as a index to the call back function
	 */
	$EXPR.SVMXEvalExpression = function(expression, context, callbackHandler, callBackContext){
		// simulate the asynchronous nature by executing the rest of the method on a timeout
		setTimeout(function(){
			var callbackContext = {
					callbackHandler : callbackHandler,
					callBackContext : callBackContext,
					handler : function(result){
						this.callbackHandler.call(this.callBackContext, result);		
					}
			};
			
			try{
			// trigger the evaluation
			$EXPR.executeExpression(
				expression, context, callbackContext.handler, callbackContext, true);
			}catch(e){
				$EXPR.Logger.error("Error while performing EVAL! Please check for syntax error in the JS snippet! =>" + e);
				callbackContext.handler(context);
			}
		}, 0);
	};
	
	$EXPR.showMessage = function(options){
		SVMX.getCurrentApplication().getApplicationMessageUIHandler().showMessage(options);
	};
	
	/////////////////////////// END CORE ///////////////////////////	
	
};

})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\impl.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.impl
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */
(function(){
	
	var consoleImpl = SVMX.Package("com.servicemax.client.sfmconsole.impl");
	
	consoleImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
		
		__runMode : null,
	
		__constructor : function(){
			this.__base();
			this._logger = SVMX.getLoggingService().getLogger("CONSOLE-IMPL");
			
			// set up a static variable for global access
			consoleImpl.Module.instance = this;
			
			// set up the org namespace
			var ons = SVMX.getClient().getApplicationParameter("org-name-space");
			if(!ons || ons === "") ons = "SVMXC";
			
			SVMX.OrgNamespace = ons;
			// end set up namespace
			
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
		},
		
		beforeInitialize : function(){
			com.servicemax.client.sfmconsole.utils.init();
			com.servicemax.client.sfmconsole.commands.init();
			com.servicemax.client.sfmconsole.expressionbridge.init();
			com.servicemax.client.sfmconsole.constants.init();
		},
		
		initialize : function(){
			if(this.__runMode == "CONSOLE") com.servicemax.client.sfmconsole.ui.api.init();
		},
		
		afterInitialize : function(){
			var serv = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.preferences").getInstance();
			serv.addPreferenceKey(com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING);
		}
		
	}, {
		instance : null
	});
	
	consoleImpl.Class("Application", com.servicemax.client.lib.api.AbstractApplication,{
		
		__parent : null, 
		__logger : null, 
		__namedInstanceService  : null,
		__applicationStateHandler : null, 
		__applicationErrorHandler : null,
		__applicationMessageUIHandler : null, 
		__applicationQuickMessageHandler : null,
		__consoleAppContainer : null, 
		__eventBus: null,
		__processGroups : null,
		consoleAppConfigs : null,
		runningConsoleApps : null,
		processCount : 0,
		userInfo: null,
		__initialLoader : null,
		__processMenuStatus : null,

		__constructor : function(){
			this.__parent = consoleImpl.Module.instance;
			this.__logger = this.__parent.getLogger();
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
			
			this.__processGroups = [];
			this.consoleAppConfigs = {};
			this.runningConsoleApps = {};
		},
		
		triggerEvent : function(e) {
			SVMX.getLoggingService().getLogger("SFMConsoleApplication").warn("Trigger event : " + e.type);
			return this.__base(e);
		},
		
		beforeRun : function(options){ 
			// create the named default controller
			var ni = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance(); 
			//this.__eventBus = SVMX.create("com.servicemax.client.sfmdelivery.impl.SFMDeliveryEngineEventBus", {});
			
			// create the named default controller
			ni.createNamedInstanceAsync("CONTROLLER",{ handler : function(controller){
				// now create the named default model
				ni.createNamedInstanceAsync("MODEL",{ handler : function(model){
					controller.setModel(model);
					options.handler.call(options.context);
				}, context : this});
				
			}, context : this, additionalParams : { eventBus : this }});			
		},
		
		run : function(){
			this.__logger.info("Application runMode is " + this.__runMode);
			this.__logger.info("Great to be standing on my own legs!");
			this.__logger.info("Caching is => " + SVMX.isCachingEnabled());
			// log preference
			var serv = SVMX.getClient().getServiceRegistry()
						.getService("com.servicemax.client.preferences").getInstance(),
				key = com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING;
			
			var pref = serv.getPreference(key) || {enabled : true, constraint : "DEBUG"};
			SVMX.getLoggingService().setFilterPreference(pref);
			// end log preference
						
			if(this.__runMode == "CONSOLE"){this.__runConsole();} 
			else {this.__runEngine();}
		},

		getRoot : function(){
			return this.__root;
		},

		__runConsole : function () {
			this.__runSync();
		},

		__discoverConsoleApps : function(){
			var declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.consoleapp");
			var definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length === 0){
				this.__logger.error("No console apps defined.");
				return;
			}
								
			var discovered = [];
			for(var i=0;i<definitions.length;i++){
				var key = definitions[i].config.app.id;	
				this.consoleAppConfigs[key] = definitions[i].config;
				if(this.consoleAppConfigs[key].discover) {
					discovered.push(
						{	weight : definitions[i].config.positionWeight,
							context : this,"key":key,
							iconClass : this.consoleAppConfigs[key].icon['large-css-class'],
							tooltip : this.consoleAppConfigs[key].tooltip
						});
				}
			}
			discovered.sort(function(a, b){return a.weight-b.weight;});
			for(var t=0;t<discovered.length;t++){
				discovered[t] && this.__root.addConsoleNavLaunchButton(
						discovered[t].context,discovered[t].key,discovered[t].iconClass, discovered[t].tooltip);
			}
		},

		__buildRootContainer : function(){
			this.__root = SVMX.create("com.servicemax.client.sfmconsole.ui.api.RootContainer",{
				renderTo : SVMX.getDisplayRootId(), console : this
			});
		},

		getCurrentConsoleApp : function() {
			var result;
			SVMX.forEachProperty(this.runningConsoleApps, function(inKey, inValue) {
				if (inValue.consoleAppContainer.hidden === false) result = inValue.upi;
			});
			if(!result){
				result = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start");
			}
			return result;
		},
		
		launchConsoleApp : function (consoleAppId, options) {
			options = options || {};
			
			var lastOpener = this.getCurrentConsoleApp();
						
			this.__initialLoader.close();			
			this.__hideAllAppWindows();

            var appConfig = this.consoleAppConfigs[consoleAppId];
            var isSingleton = appConfig ? !appConfig.multiple : false;
			
			var isAppBooted = false;
			if(this.runningConsoleApps[consoleAppId]) isAppBooted = true;

			if(isAppBooted && (consoleAppId != "sfmdelivery" && consoleAppId != "sfmtestapp")){
				this.runningConsoleApps[consoleAppId].consoleAppInstance.__container.show();
				this.__logger.info("Instance of App '" + consoleAppId + "' already running, showing...");				
			}
			else {
				if(!this.consoleAppConfigs[consoleAppId]) {
					this.__logger.error("Console App Not Defined: " + consoleAppId);
				}else {
					options.isClosable = false;
					options.lastOpener = lastOpener;
					
					if(this.consoleAppConfigs[consoleAppId].multiple)options.isClosable = true;
					var consoleAppContainer = this.__root.createConsoleAppContainer(consoleAppId,options);
					
					try {
						var uniqueProcessIdentifier = this.consoleAppConfigs[consoleAppId].app.id;
						if (!isSingleton) uniqueProcessIdentifier += this.processCount;
						
						var consoleAppInstance = SVMX.create(this.consoleAppConfigs[consoleAppId].app["class-name"],this,
								consoleAppContainer,{upi : uniqueProcessIdentifier, size :{height : this.__root.getContentAreaMaxHeight()}});
						this.runningConsoleApps[uniqueProcessIdentifier] = {"consoleAppInstance" : consoleAppInstance, "consoleAppContainer" : consoleAppContainer};
						
						// The setAppInfo method; while all apps should call this, some apps currently don't (sync test app) so everything
						// in here should be optional code
						options.handler = function () {
							consoleAppContainer.setTitle(consoleAppInstance.getWindowTitle());
							if(consoleAppId == "sfmdelivery" || consoleAppId == "sfmtestapp") {
								options.uniqueProcessIdentifier = uniqueProcessIdentifier;
								options.group = consoleAppInstance.getGroup();
								options.text = consoleAppInstance.getWindowTitle();
								
								this.__addProcessToMenu(options);
							//}else {
							//	uniqueProcessIdentifier = this.consoleAppConfigs[consoleAppId].app["id"];
							}
							
							consoleAppInstance.__uniqueProcessIdentifier = uniqueProcessIdentifier;
							this.runningConsoleApps[uniqueProcessIdentifier].upi = uniqueProcessIdentifier;
							
						};
						
						options.context = this;
						consoleAppInstance.start(options);
					} catch (err) {
						this.__logger.error(err);	
						return false;
					}
				}				
			}
		},
												
		__addProcessToMenu	: function (options) {
			this.processCount++;
			this.__root.addProcessMenuItem(options);
		},
								
		__getSyncImpl : function() {
			declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.synchronizer");
			definitions = SVMX.getClient().getDefinitionsFor(declaration);
			
			var className = definitions[0].config.impl['class-name'];
			var syncImpl = SVMX.create(className, this);
			
			return syncImpl;
		},
		
		__runSync : function(){
			
			declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.synchronizer");
			definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length === 0 || SVMX.getClient().getApplicationParameter("sfmconsole-skip-sync")){
				return this.__syncCompleted();
			}
			
			var className = definitions[0].config.impl['class-name'];
			var syncImpl = SVMX.create(className, this);
			
			this.__initialLoader = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection",{
				layout	: {
					type	: 'vbox',
					align	: 'center',
					pack	: 'center'
				},
				header		: false,
				frame       : false, 
				border		: false,
				height		: 250,
				id          : 'firstLoader',
				bodyStyle	:{"background":"transparent"},
				renderTo    : document.getElementById('client_display_root')
			});
			
			var targetCmp = document.getElementById('firstLoader');
			this.titleSpinner = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXSpinner",{
				lines: 13,length: 20, width: 10,radius: 30,corners: 1,rotate: 0,direction: 1, 
				color: '#FF9944',speed: 1,trail: 60, shadow: false,  hwaccel: false, 
				className: 'spinner', zIndex: 2e9,top: 'auto', left: 'auto',
				target : targetCmp
			});	
			
			this.__initialLoader.show();
							
			syncImpl.run({
				handler : this.__syncCompleted, context : this
			});
		},
				
		runManualSyncBackground : function () {
			var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
			this.__syncManager = servDef.getInstance();
			this.__syncManager.startSync({type: "INCREMENTAL"});
		},
		
		showSyncUI : function () {		
			if(Ext.getCmp("syncWindow")){
				Ext.getCmp("syncWindow").show();
				Ext.getCmp("detailPane").hide();
				Ext.getCmp("subPanel").hide();
			}	
		},
		
		__syncCompleted : function(lastSync){
			this.userInfo = lastSync.user;
			this.__buildRootContainer();
			this.__root.setUserInfo(this.userInfo);
			this.__discoverConsoleApps();
			this.__openFirstConsoleApp();
			this.__startIncrementalReSync();
		},	
				
		closeConsoleApp : function(appWindowId,options){
			var me = this;
			var appInstance;
			
			if(this.runningConsoleApps[options.uniqueProcessIdentifier]){
				appInstance = this.runningConsoleApps[options.uniqueProcessIdentifier].consoleAppInstance;
			}
			
			if(appInstance){
				var closeTest = appInstance.onCanClose(function(canClose){
					if(canClose === true) me.destroyConsoleApp(options);
				});	
			}
			else {
				Ext.getCmp(options.uniqueProcessIdentifier).destroy();
				this.__root.manageConsoleAppContainerClose(options);
			}
		},
		
		destroyConsoleApp : function(options) {
			appInstance = this.runningConsoleApps[options.uniqueProcessIdentifier].consoleAppInstance;
			appInstance.onClose(options);
			appInstance.__container.destroy();
			this.__root.manageConsoleAppContainerClose(options);
		},
		
		__openFirstConsoleApp : function () {
			var consoleAppId = (SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start") || null);
			if(!consoleAppId || consoleAppId === ""){
				this.__logger.error("sfmconsole-runtime-start is not set in application config.");
				return false;
			}
			this.launchConsoleApp(consoleAppId,{});	
		},
						
		__hideConsoleApp : function(target) {
			target.hide();
		},
		
		__hideAllAppWindows : function () {
			for(var container in this.runningConsoleApps){
				this.__hideConsoleApp(this.runningConsoleApps[container].consoleAppContainer);
			}			
		},		

		__startIncrementalReSync : function(){
			if(this.userInfo && this.userInfo.reSync){
				this.runManualSyncBackground();
			}
		},
				
		getUserInfo : function () {
			return this.userInfo;
		},
		
		showLoadMask : function(loadMaskTarget){
			this.__root.showLoading(loadMaskTarget);
		},
		
		hideLoadMask : function() {
			this.__root.hideLoading();
		},
		
		showAppWindow : function(appWindowId){
			this.__hideAllAppWindows();
			appInstance = this.runningConsoleApps[appWindowId].consoleAppInstance;
			appInstance.__container.show();
		},
		
		__appShow : function(consoleAppInstance) {
			this.__root.showApp(this.__consoleAppContainer);	
		},
		
		__appHide : function(consoleAppInstance) {
			this.__root.hideApp(this.__consoleAppContainer);
		},
		
		consoleResizeApp : function(consoleAppInstance) {
			this.__root.resizeApp(this.__consoleAppContainer);
		},
					
		__runEngine : function(){
			var client = SVMX.getClient();
			
			// set up the application title
			SVMX.setWindowTitle(client.getApplicationTitle());
			
			// look for the content providers
			// right now, only sfm delivery engine
			var declaration = client.getDeclaration("com.servicemax.client.sfmconsole.deliveryengine");
			var definitions = client.getDefinitionsFor(declaration);

			var sfmdefinition = null;
			var preferEngineId = SVMX.getClient().getApplicationParameter('sfmconsole-engine-id');
			if(preferEngineId){
				for(var i = 0; i < definitions.length; i++){
					if(preferEngineId == definitions[i].config.engine.id){
						sfmdefinition = definitions[i];
						break;
					}
				}
			}else{
				sfmdefinition = definitions[0];
			}
			if(sfmdefinition === null){
				this.__logger.error("Cannot find any delivery engines." + (preferEngineId && "("+preferEngineId+")"));
				return;
			}
			
			sfmdefinition = definitions[0];
			var engineConfig = sfmdefinition.config.engine;
			var engineClassName = engineConfig["class-name"];
			
			sfmdefinition.createInstanceAsnc(engineClassName, {handler : function(engine){
				
				// initialize the engine
				engine.initAsync({handler : function(){
					// start the engine
					engine.run({});
					
				}, context : this});
				
			}, context : this});
		},
		
		setApplicationStateHandler : function(stateHandler){
			
			// set up the application state handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application UI state will
			// be managed by SFMConsole itself.
			this.__applicationStateHandler = stateHandler;
		},
		
		getApplicationStateHandler : function(){
			return this.__applicationStateHandler;
		},
		
		setApplicationErrorHandler : function(errorHandler){
			
			// set up the application error handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application errors will
			// be managed by SFMConsole itself.
			this.__applicationErrorHandler = errorHandler;
		},
		
		getApplicationErrorHandler : function(){
			return this.__applicationErrorHandler || this;
		},
		
		setApplicationMessageUIHandler : function(messageUIHandler){
			
			// set up the application message UI handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application message UI will
			// be managed by SFMConsole itself.
			this.__applicationMessageUIHandler = messageUIHandler;
		},
		
		getApplicationMessageUIHandler : function(){
			return this.__applicationMessageUIHandler || this;
		},
		
		setApplicationQuickMessageHandler : function(quickMessageUIHandler){
			
			// set up the application quick message handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application quick messages will
			// be managed by SFMConsole itself.
			this.__applicationQuickMessageHandler = quickMessageUIHandler;
		},
		
		getApplicationQuickMessageHandler : function(){
			return this.__applicationQuickMessageHandler;
		},
		
		notifyApplicationError : function(error){
			if(!error) return;

			var message = error.message;
			if(!(message instanceof Array)){
				message = [{message : message, msgDetail : error.msgDetail}];
			}
			
			var messageText = message[0].message;
	
			Ext.Msg.show({
				title : 'Error',msg : messageText,buttons: Ext.Msg.OK,icon: Ext.Msg.ERROR
			});

		},
		
		/** 
		 * @param {Object} options
		 *     @param {String} options.type: QUESTION, WARN, ERROR, INFO
		 *     @param {String} options.text
		 *     @param {[Object]} options.buttons Array of ["OK", "CANCEL", "YES", "NO"]
		 */
		showMessage : function(options){
			if(!options) return;
			if (!options.buttons) options.buttons = ["OK"];
			
			var TS = com.servicemax.client.sfmdelivery.impl.Module.TS;

			var type = options.type, msgText = options.text, buttons = options.buttons;
			var handler = options.handler, msgBox;
	
			var msgType = function(){
				return {"QUESTION": {type : Ext.Msg.QUESTION},
						"WARN"    : {type : Ext.Msg.WARNING},
						"ERROR"   : {type : Ext.Msg.ERROR},
						"INFO"    : {type : Ext.Msg.INFO}};
			}; 
	
			var msgButtons = function(){
				return {"OK"      : {btnText : TS.T("TAG067"), svmxBtntype : "OK"},
						"CANCEL"  : {btnText : TS.T("TAG004"), svmxBtntype : "CANCEL"},
						"YES"     : {btnText : TS.T("TAG017"), svmxBtntype : "YES"},
						"NO"      : {btnText : TS.T("TAG016"), svmxBtntype : "NO"}};
			};
			
			var currentMsgType = msgType()[type];
			var icon = (currentMsgType) ? currentMsgType.type : options.type;
			var dispButtons = [];
			
			for(var i = 0; i < buttons.length; i++){
				dispButtons.push({text: msgButtons()[buttons[i]].btnText, 
					svmxBtntype : msgButtons()[buttons[i]].svmxBtntype, 
						handler: function(btn) {
							msgBox.destroy(); 
							if ($.isFunction(options.handler)) {
								options.handler( btn.svmxBtntype );
							}
						}
					});
			}
			
			msgBox = Ext.create('Ext.window.MessageBox', {buttons :dispButtons});
			
			msgBox.show({ title : TS.T("TAG033"), msg : msgText,  icon : icon, closable : false});
			msgBox.getEl().setStyle('z-index','51000');//should more more than load mask
		}
	},{});
	
	consoleImpl.Class("CompositionEngine", com.servicemax.client.lib.api.Object,{
		__metamodel : null, __parent : null,
		
		__constructor : function(metamodel, parent){
			this.__metamodel = metamodel;
			this.__parent = parent;
		},
		
		compose : function(){
			var composition = this.__parent.__self.composition;
			return this.__composeInternal(this.__metamodel, composition, this.__parent);
		},
		
		__composeInternal : function(metamodel, composition, parent){
			var length = composition.length, i;
			for(i = 0; i < length; i++){
				var compositionItem = composition[i];
				var compositionMetamodel = metamodel.getChildNode(compositionItem.name);
				
				if(compositionMetamodel){
					var compositionItemObj = null,
						compositionItemClass = compositionItem.className;
					
					if(compositionMetamodel instanceof Array === false){
						compositionMetamodel = [compositionMetamodel];
					}
					var compositionMetamodelLength = compositionMetamodel.length, j, compositionMetamodelItem;
					for(j = 0; j < compositionMetamodelLength; j++){
						compositionMetamodelItem = compositionMetamodel[j];
						compositionItemObj = SVMX.create(compositionItemClass, {compositionMetamodel : compositionMetamodelItem});
						if(compositionItemObj.__self.composition !== undefined){
							this.__composeInternal(compositionMetamodelItem, compositionItemObj.__self.composition, compositionItemObj);
						}
						parent.onCompositionChildCreate(compositionItemObj, compositionItem.name);
					}
				}
			}
		}
	}, {});
	
})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\patterns\api.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.ui.components.api
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	
	var compsApi = SVMX.Package("com.servicemax.client.sfmconsole.ui.components.api");
	
	compsApi.Class("ViewComposite", com.servicemax.client.lib.api.EventDispatcher, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	compsApi.Class("ViewContainer", compsApi.ViewComposite, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	compsApi.Class("ViewPlan", compsApi.ViewContainer, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	compsApi.Class("ViewModel", com.servicemax.client.lib.api.EventDispatcher, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	compsApi.Class("ViewModelNode", com.servicemax.client.lib.api.EventDispatcher, {
		__constructor : function(){
			this.__base();
		}
	}, {});
	
	
	compsApi.Class("ViewEngine", com.servicemax.client.lib.api.Object, {
		__constructor : function(){
			this.__base();
		}
	}, {});
})();

// end of file

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\ui\api.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.ui.api
 * @singleton
 * @author Timothy Ashton 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */
(function(){
	var _apiImpl = SVMX.Package("com.servicemax.client.sfmconsole.ui.api");
		
	_apiImpl.init = function(){
		
		Ext.define(
				"com.servicemax.client.sfmconsole.ui.api.RootContainer",{
				extend              : "com.servicemax.client.ui.components.composites.impl.SVMXSection",
				alias				: 'widget.sfmconsolecontainer',
				__logger            : null,
				__console           : null, 
				__contentAreaMargin : 0,
				__resourcePath      : null,
				__syncStarted		: false,
				
				constructor : function(config){
					this.__logger = SVMX.getLoggingService().getLogger("SFMCONSOLE-ROOT");	
					this.__console = config.console;	
					this.__resourcePath = (window["__SVMX_CLIENT_LIB_PATH__"] || "");
					this.__resourcePath && this.__resourcePath.match(/\/$/) ? this.__resourcePath+="/" : false;
									
					config = Ext.apply({
						closable    : false,
						collapsible : false,
						id          : 'consoleMain',
						height      : this.__getBodyHeight(),
						layout      : "border",
						autoScroll  : false
					}, config || {});
					
					this.__contentAreaMargin = 5;
					
					this.callParent([config]);
					this.run();
					
					this.onResize();
					SVMX.onWindowResize(this.onResize, this);
				},
	
				onResize : function(){				
					var size = this.getAppViewSize();
					size.width = size.width - (0 * 2);
					this.setWidth(size.width);
					this.setHeight(size.height);
					
					size.width = size.width - (0 * 2);
					size.height = this.getContentAreaMaxHeight();
					if(this.consoleAppContentArea){
						this.consoleAppContentArea.setHeight(size.height);
						this.consoleAppContentArea.setWidth(size.width);
						this.consoleAppContentArea.doLayout();
					}
					
					if(this.__console && this.__console.runningConsoleApps){
						var apps = this.__console.runningConsoleApps;
						for(var i in apps){
							if(apps[i].consoleAppInstance){
								apps[i].consoleAppInstance.onAppResize(size);
							}
						}
					}
				},
				
				getContentAreaMaxHeight : function(){
					var size = this.getAppViewSize();
					size.height = size.height - this.consoleNavBar.getHeight() - (this.__contentAreaMargin * 8);
					return size.height;
				},
				
				getAppViewSize : function(){
					var size = Ext.getBody().getViewSize();
					return size;
				},

				getSyncManager : function(){
					if(!this.__syncManager){
						var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
						this.__syncManager = servDef.getInstance();
					}
					return this.__syncManager;
				},
				
				run : function () {
					var me = this;			
					this.tbfill = {xtype : 'tbfill'};
					
					this.menuBtnObj = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton",{
						id		: "processMenu",
						margin	: 0,
						disabled: true,
						plain	: true,
						split   : false,
						iconCls : "sfm-console-windows-icon",
						scale   : "large",
						width   : 52,
						height	: 52,
						ui		: "sfm-console-toolbar-btn",
						hideCollapseTool : true,
						menu    : {
							cls		: "sfm-console-toolbar-btn-menu",
							id      : "thisMenu"
						},
						listeners: {
							afterrender: function(){
								var arrowOverlayEl = new Ext.dom.Element(this.getEl().dom.firstChild);
								arrowOverlayEl.removeCls("svmx-btn-arrow svmx-btn-arrow-right");
							},
						}
					});
					
					this.consoleNavBar = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						region		: 'south',
						layout      : 'column', 
						collapsible	: false	
					});					
					this.add(this.consoleNavBar);
					
					this.consoleToolbar = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXToolbar", {
							ui      : 'sfm-console-toolbar',
							dock    : 'bottom',
							id      : 'toolbar',
							items   : [{
							xtype : 'box',
							autoEl: {
								tag: 'img', 
								src:this.__resourcePath + '/resources/images/servicemax_logo_sm.png'
							},
							width	: 55,
							height	: 52,
							margin	: 10
						}]
					});
					this.consoleToolbar.add(this.tbfill);
						
					this.navbarButtonGroup = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXButtonGroup", {
						id    : 'navbarButtonGroup',
						items : [
							this.btnObj
						]
					});
					this.consoleToolbar.add(this.navbarButtonGroup);		
					
					this.helpButton = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton", {
						handler	: function() {
							// me.launchHelp();
						},
						iconCls : 'sfm-console-offline-help-icon1',
						margin	: 2,
						scale	: 'large',
						ui		: 'sfm-console-toolbar-btn',
						tooltip	: 'Help'
					});
					// this.consoleToolbar.add(this.helpButton);
					
					this.navbar = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXButtonGroup", {
						autoScroll  : true,
						id          : 'navbar',
						margin      : 0
					});
					
					this.consoleToolbar.add(this.navbar);
					this.navbar.add(this.menuBtnObj);
					this.consoleToolbar.add(this.tbfill);
									
					this.syncIcon = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXSplitButton", {
						id      : "syncIcon",
						iconCls : "sfm-console-sync-icon",
						width	: 60,
						height	: 52,
						margin	: 10,
						handler	: function () {
							if(!me.__syncStarted){
								// me.getSyncManager().startSync({type : 'INCREMENTAL'});	
								
    	        				var syncImpl = me.__console.__getSyncImpl();
    	        				syncImpl.performSync('INCREMENTAL');
							}
							else{ // Second click
								if(Ext.getCmp("syncWindow")){
									Ext.getCmp("syncWindow").show();
									Ext.getCmp("detailPane").hide();
									Ext.getCmp("subPanel").hide();
								}
							}
							return false;
						},
						menu    : {
							xtype	: 'menu',
							cls     : SVMX.baseCSSPrefix + 'split-btn-menu-items',
							plain	: true,
							items	: [
								{
									text	: 'Progress',
									hidden  : true,
									id		: 'viewProgress',
									handler	: function() {
										if(Ext.getCmp("syncWindow")){Ext.getCmp("syncWindow").show();
									}
								}
								},
								{
									text	: 'Conflicts',
									handler	: function () {
										com.servicemax.client.sync.errormgmt.impl.ErrorManager.showErrorUI();
									}
								},
								{
									text	: 'Options',
									handler	: function() {
										me.__console.launchConsoleApp("synctestapp",{});
									}
								}
							]
						}
					});
					this.consoleToolbar.add(this.syncIcon);
					
					this.sfmconsoleusermenupanel = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton", {
						id      : "sfmconsoleusermenupanel",
						cls     : 'sfm-console-settings-menu-btn',
						menu	: {
							xtype       : 'menu',
							plain       : true,
							iconAlign   : 'left',
							cls         : 'sfm-console-settings-menu-items',
							items       : [
								{
									text		: 'Settings',
									displayText	: 'Settings',
									tooltip		: 'Settings',
									hidden		: true,
									iconCls		: 'sfm-console-setting-icon',
									handler		: function () {
										alert("Launch Settings");
									}
								},
								{
									text		: 'Help',
									displayText	: 'Help',
									tooltip		: 'help',
									iconCls		: 'sfm-console-help-icon',
									handler		: function () {
										// me.launchHelp();
									}
								}
							]
						}						
					});
					this.consoleToolbar.add(this.sfmconsoleusermenupanel);			
					this.consoleNavBar.addDocked(this.consoleToolbar);

					this.__bindSyncEventHandlers();
				},
  
				__bindSyncEventHandlers : function(){
					var self = this;
					var sync = this.getSyncManager();
					sync.bind("SYNC_STARTED", function(evt){
						self.__syncStarted = true;
						if(Ext.getCmp("syncIcon")){
							Ext.getCmp("syncIcon").btnIconEl.dom.className = "svmx-btn-icon sfm-console-sync-icon-ani";
							Ext.getCmp("viewProgress").show();
						}
					});
					sync.bind("SYNC_COMPLETED", function(evt){
						self.__syncStarted = false;
						if(Ext.getCmp("syncIcon")){
							Ext.getCmp("syncIcon").btnIconEl.dom.className = "svmx-btn-icon sfm-console-sync-icon";
							Ext.getCmp("viewProgress").hide();
						}	
					});
					sync.bind("SYNC_FAILED", function(evt){
						self.__syncStarted = false;
						if(Ext.getCmp("syncIcon")){
							Ext.getCmp("syncIcon").btnIconEl.dom.className = "svmx-btn-icon sfm-console-sync-icon";
							Ext.getCmp("viewProgress").hide();
						}	
					});
				},

				launchHelp : function () {
					var f = new com.servicemax.client.offline.sal.model.nativeservice.File("help.txt");
					f.execute().then(function(isSuccess, inResult) {
						if (isSuccess) { // TODO :: Replace with loggers
							alert("Success.");
						} else {
							alert("Fail :: " + inResult);
						}
					});
				},
				
				setUserInfo: function(userInfo) {
					var panel = Ext.getCmp("sfmconsoleusermenupanel");
					panel.setText(userInfo.UserName);
				},
												
				addProcessMenuItem : function (options) {
					this.menuBtnObj.enable();
					var appWindowId = options.uniqueProcessIdentifier;
					
					var menuItem = {
							text	: "&nbsp;&nbsp;&nbsp;" + options.text,
							id		: options.uniqueProcessIdentifier,
							group	: options.group,
							handler	: function () {
								SVMX.getCurrentApplication().showAppWindow(appWindowId);
							}
						};
											
					if(!Ext.getCmp(options.group)){
						var menuHeader = {
							text		: options.group,
							id			: options.group,
							group		: options.group,
							margin		: '0 0 2 0',
							disabled    : true,
							disabledCls : "svmx-console-process-menu-header-disabled"
						};
						
						var menuSpacer = {
							height	: 13,
							disabled: true,
							id		: options.group + "Spacer"
						};
						
						this.menuBtnObj.menu.add(menuHeader);
						this.menuBtnObj.menu.add(menuItem);	
						this.menuBtnObj.menu.add(menuSpacer);	
					}
					else {
						var locateHeader = 0;
						var currentMenuItems = this.menuBtnObj.menu.items.items;
						var currentGroup = options.group;
						for(var p in currentMenuItems){
							if(currentMenuItems[p].group == currentGroup){break;} 
							else {locateHeader++;}
						}			

						Ext.getCmp("processMenu").menu.insert(locateHeader+1,menuItem);	
					}	
					
					var itemsMenu = Ext.getCmp("processMenu").menu.items;
					var items = itemsMenu.items;
					var lastIndex = itemsMenu.length - 1;
					var lastItem = itemsMenu.items[lastIndex];
					
					for(var i in items){
						if(items[i].id.indexOf("Spacer") != "-1") items[i].show();
					}
					
					if(lastItem.id.indexOf("Spacer") != "-1") lastItem.hide();
				},
				
				removeProcessMenuItem : function (options) {
					Ext.getCmp(options.uniqueProcessIdentifier).hide();				
				},
				
				addConsoleNavLaunchButton : function (parentObj, consoleAppId, btnCssClass, tooltip) { // TODO :: btnCssClass is a hack because I cannot get the ocnfigs array from partent Obj					
					tooltip = tooltip || "";
					this.toolbarButton = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton", {
						handler	: function() {
							parentObj.launchConsoleApp(consoleAppId,{});
						},
						iconCls : btnCssClass,
						margin	: 5,
						scale	: "large",
						ui		: "sfm-console-toolbar-btn",
						tooltip	: tooltip
					});
					Ext.getCmp('navbarButtonGroup').add(this.toolbarButton);
				},
								
				createConsoleAppContainer : function (consoleAppId,options) {
					var consoleAppContainer = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						collapsible : false,
						frame       : true,
						title       : options.title,
						closable    : options.isClosable,
						region      : 'center',
						margin      : this.__contentAreaMargin,
						listeners   : {
							beforeClose: function(){
								SVMX.getCurrentApplication().closeConsoleApp(consoleAppId,options);
								return false;
							}
						}
					});
					
					this.add(consoleAppContainer);
					return consoleAppContainer;
				},
				
				manageConsoleAppContainerClose : function (options) {
					var appContainer = Ext.getCmp(options.uniqueProcessIdentifier);
					if(appContainer){
						appContainer.destroy();
						
						var currentGroup = options.group;
						var currentMenuItems = this.menuBtnObj.menu.items.items;
						var itemCount = 0;
						for(var p in currentMenuItems){
							if(currentMenuItems[p].group == currentGroup) itemCount++;
						}
						
						if(itemCount == 1){
							Ext.getCmp(currentGroup).destroy();
							Ext.getCmp(currentGroup + "Spacer").destroy();
						}
						
						groupLength = this.menuBtnObj.menu.items.length;
						if(groupLength === 0){									
							this.menuBtnObj.disable();
						}
					}
					
					var appId = null;
					if(options.lastOpener) appId = options.lastOpener;
					
					var isAppBooted = false;
					if(appId && this.__console.runningConsoleApps[appId]) isAppBooted = true;
					if(!isAppBooted) appId = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start");
					SVMX.getCurrentApplication().launchConsoleApp(appId,{});					
				},
				
				showLoading : function(loadMaskTarget) {
					if(!this.__loadMask) this.__loadMask = new com.servicemax.client.ui.components.utils.LoadMask({parent : this});
					this.__loadMask.show();
					this.__loadMask.setZIndex(50000);
				},
				
				hideLoading : function() {
					if(this.__loadMask !== null) this.__loadMask.hide();				
				},				
				
				createConsoleAppContentArea : function () {
					this.consoleAppContentArea = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						alias		: 'widget.consoleAppContentArea',
						collapsible : false,
						id			: 'consoleAppContentArea',
						frame		: false,						
						header		: false,
						autoScroll	: false
					});
					this.add(this.consoleAppContentArea);
				},
								
				__getBodyHeight : function(){
					return Ext.getBody().getViewSize().height;
				}
			});
	};
})();

// Code: C:\Users\Framework\.hudson\jobs\SFMDelivery_sfdc_dev\workspace\src\modules\com.servicemax.client.sfmconsole\src\utils.js
/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.utils
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	var sfmconsoleutil = SVMX.Package("com.servicemax.client.sfmconsole.utils");
	
sfmconsoleutil.init = function(){
	
	/**
	 * Use this class when want to batch a series of MVC events. All the events are processed
	 * simultaneously. The result of all the calls are made available on the callback handler.
	 */
	sfmconsoleutil.Class("EventCollection", com.servicemax.client.lib.api.Object,{
		__eventBus : null, __eventItems : null, __stackIndex : 0, __handler : null, __context : null,
		__constructor : function(eventBus, items){
			this.__eventBus = eventBus;
			this.__eventItems = [];
			this.__stackIndex = 0;
			
			for(var i = 0; i < items.length; i++){
				var ei = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollectionItem", items[i]);
				
				this.__eventItems[i] = ei;
				this.__eventItems[i].itemParent = this;
			}
		},
		
		addEvent : function(evt){
			var ei = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollectionItem", evt);
				
			this.__eventItems[this.__eventItems.length] = ei;
			this.__eventItems[this.__eventItems.length - 1].itemParent = this;
		},
		
		triggerAll : function(handler, context){
			this.__handler = handler;
			this.__context = context;
			
			for(var i = 0; i < this.__eventItems.length; i++){
				this.__stackIndex++;
				this.__eventItems[i].trigger();
			}
		},
		
		handleResponse : function(eventItem){
			this.__stackIndex--;
			if(this.__stackIndex == 0){
				this.__handler.call(this.__context, this);
			}
		},
		
		getEventBus : function(){
			return this.__eventBus;
		},
		
		items : function(){
			return this.__eventItems;
		}
	},{});
	
	sfmconsoleutil.Class("EventCollectionItem", com.servicemax.client.mvc.api.Responder,{
		__event : null, response : null, itemParent : null,
		__constructor : function(event){
			this.__event = event;
			this.__event.data.responder = this;
		},
		
		trigger : function(){
			this.itemParent.getEventBus().triggerEvent(this.__event);
		},
		
		type : function(){
			return this.__event.type;
		},
		
		getEventObj : function(){
			return this.__event;
		},
		
		result : function(data) { 
			this.response = data;
			this.itemParent.handleResponse(this);
		},
		
		fault : function(data) { 
			var err = "Error during event <" + this.__event.type + ">";
			SVMX.getLoggingService().getLogger().error(err);
			throw new Error(err);
		}
	},{});
	
	/**
	 * This class is responsible for managing the translation related activities
	 * Right now, it looks at the structure from SVMXC.COMM_TagsDefinition
	 */
	sfmconsoleutil.Class("Translation", com.servicemax.client.lib.api.Object, {
		__data : null,
		__constructor : function(data){
			this.__data = {};
			if ($.isArray(data)) {
				var i, l = data.length;
				for(i = 0; i < l; i++){
					this.__data[data[i].Key] = data[i].Value;
				}
			} else {
				this.__data = data;
			}
		},
		
		T : function(key){
			return this.__data[key];
		}
	
	}, {});
	
	sfmconsoleutil.Class("TranslationService", com.servicemax.client.lib.api.Object, {
		__data : null,
		__constructor : function(){},
		
		setTranslationData : function(data){
			this.__data = data;
		},
		
		T : function(key){
			var ret = key;
			
			// There are cases when translation is accessed (ex, during load errors) before it is initialized.
			// So if translation is not available, return the key itself.
			if(this.__data){
				ret = this.__data.T(key);
			}
			
			return ret;
		}
	}, {});
};

})();

// end of file

