/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.commands
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	var sfmconsolecommands = SVMX.Package("com.servicemax.client.sfmconsole.commands");
	
sfmconsolecommands.init = function(){
	// moved all the commands to delivery engines




     sfmconsolecommands.Class("GetUserInfo", com.servicemax.client.mvc.api.Command, {
        
        __constructor : function(){ this.__base(); },
        
        /**
         * 
         * @param request
         * @param responder
         */
        executeAsync : function(request, responder){
            this._executeOperationAsync(request, responder, {operationId : "SFMCONSOLE.GET_USERINFO"});
        }
    }, {});

     // TODO: Move this to responders.js
    sfmconsolecommands.Class("GetUserInfoResponder", com.servicemax.client.mvc.api.Responder, {
            __parent : null,
            __constructor : function(parent) { 
                this.__base(); 
                this.__parent = parent;
            },
            
            result : function(data) { 
                    this.__parent.onGetUserInfoCompleted(data);
            },
            
            fault : function(data) { 
                // TODO:
            }
            
        }, {});

};

})();

// end of file