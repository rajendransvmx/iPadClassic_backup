/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.api
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */
(function(){
	
	var clientConsoleApi = SVMX.Package("com.servicemax.client.sfmconsole.api");
	
	clientConsoleApi.Class("AbstractConsoleApp", com.servicemax.client.lib.api.Object, {
		__parent                    : null,
		__container                 : null,
		__size                      : [], 
		__visibilty                 : null,
		__group                     : null,
		__windowTitle               : null,
		__closeCallBack             : null,
		__callbackContext           : null,
		__uniqueProcessIdentifier   : null,
		
		__constructor : function(parent,container,options){
			this.__parent = parent;
			this.__container = container;
			this.__size.width = options.size.width;
			this.__size.height = options.size.height;
			this.__uniqueProcessIdentifier = options.upi;
		},
		
		start : function() {

		},

		requestClose : function () {
			var localOptions = {};
			localOptions.uniqueProcessIdentifier = this.getUniqueProcessIdentifier();
			localOptions.group = this.__group;
			this.__parent.destroyConsoleApp(localOptions);
		},		
		
		onCanClose : function (callback) {
			callback(true);
		},
		
		/**
		 * @event
		 * Subclasses override onClose to be notified when they are being closed so that they have time to clean up
		 * all resources and call destroy on anything needing destroying.
		 * The parent method is currently empty, but may be used to clean up resources at the window level
		 */
		onClose : function (options) {
			
		},
				
		refreshAppView : function () {
			
		},
		
		showLoadMask : function(target) {
			this.__parent.showLoadMask(target || this.__container);
		},
		
		hideLoadMask : function(target) {
			this.__parent.hideLoadMask(target || this.__container);
		},
		
		getGroup : function () {
			return this.__group;
		},
		
		getUniqueProcessIdentifier : function () {
			return this.__uniqueProcessIdentifier;
		},
		
		setWindowTitle : function(title){
			this.__windowTitle = title;
			this.__container.setTitle(this.__windowTitle);
		},
		
		getWindowTitle : function () {
			return this.__windowTitle;
		},
		
		getCloseCallBack : function () {
			return this.__closeCallBack;
		},
				
		getCallBackContext : function() {
			return this.__callbackContext;
		},
		
		setAppInfo : function (options) {
			options = options || {};
			
			this.__group = options.groupName;
			this.__windowTitle = options.windowTitle;
			this.__closeCallBack = options.closeCallback;
			this.__callbackContext = options.context;
		},
				
		getConsoleAppContainer : function() {
			return this.__container;
		},
		
		setRootContainer : function (container) {
			this.getConsoleAppContainer().add(container);
			this.onAppResize(this.getSize());
		},
		
		getSize : function() {
			return this.__size;
		},
		
		setSize : function() {
			
		},
		
		getVisibility : function(){
			return this.visibility;
		},
		
		setVisibility : function (){
			
		},
		
		closeConsoleApp : function (){

		}
	}, {});
	
	clientConsoleApi.Class("AbstractSync", com.servicemax.client.lib.api.Object, {
		__syncManager : null,
		__constructor : function(){},
		run : function() {},
		getSyncManager : function(){
			return this.__syncManager;
		}
	}, {});
		
	clientConsoleApi.Class("AbstractDeliveryEngine", com.servicemax.client.lib.api.Object, {
		
		__constructor : function(){
			
		},
		
		initAsync : function(options){},
		
		run : function(options){},
		
		getInterface : function(){
			return this;
		}
		
	}, {});
	
	clientConsoleApi.Class("CompositionMetaModel", com.servicemax.client.lib.api.EventDispatcher, {
		_data : null, _parent : null, _children : null, isDisplayOnly : false,
		
		__constructor : function(data, parent, isDisplayOnly){
			this.__base();
			this._data = data;
			this._parent = parent;
			this._children = {};
			if(parent){
				this.isDisplayOnly = parent.isDisplayOnly;
			}else{
				this.isDisplayOnly = false;
			}
		},
		
		getChildNode : function(name){
			return this._children[name];
		},
		
		getData : function(){
			return this._data;
		},
		
		getRoot : function(){
			if(this._parent === null) 
				return this;
			else
				return this._parent.getRoot();
		},
		
		resolveDependencies : function(){}
		
	}, {});

})();