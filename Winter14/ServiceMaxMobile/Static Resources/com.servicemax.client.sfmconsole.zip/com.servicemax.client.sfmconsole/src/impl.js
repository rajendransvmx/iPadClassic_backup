/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.impl
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */
(function(){
	
	var consoleImpl = SVMX.Package("com.servicemax.client.sfmconsole.impl");
	
	consoleImpl.Class("Module", com.servicemax.client.lib.api.ModuleActivator, {
		
		__runMode : null,
	
		__constructor : function(){
			this.__base();
			this._logger = SVMX.getLoggingService().getLogger("CONSOLE-IMPL");
			
			// set up a static variable for global access
			consoleImpl.Module.instance = this;
			
			// set up the org namespace
			var ons = SVMX.getClient().getApplicationParameter("org-name-space");
			if(!ons || ons === "") ons = "SVMXC";
			
			SVMX.OrgNamespace = ons;
			// end set up namespace
			
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
		},
		
		beforeInitialize : function(){
			com.servicemax.client.sfmconsole.utils.init();
			com.servicemax.client.sfmconsole.commands.init();
			com.servicemax.client.sfmconsole.expressionbridge.init();
			com.servicemax.client.sfmconsole.constants.init();
		},
		
		initialize : function(){
			if(this.__runMode == "CONSOLE") com.servicemax.client.sfmconsole.ui.api.init();
		},
		
		afterInitialize : function(){
			var serv = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.preferences").getInstance();
			serv.addPreferenceKey(com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING);
		}
		
	}, {
		instance : null
	});
	
	consoleImpl.Class("Application", com.servicemax.client.lib.api.AbstractApplication,{
		
		__parent : null, 
		__logger : null, 
		__namedInstanceService  : null,
		__applicationStateHandler : null, 
		__applicationErrorHandler : null,
		__applicationMessageUIHandler : null, 
		__applicationQuickMessageHandler : null,
		__consoleAppContainer : null, 
		__eventBus: null,
		__processGroups : null,
		consoleAppConfigs : null,
		runningConsoleApps : null,
		processCount : 0,
		userInfo: null,
		__initialLoader : null,
		__processMenuStatus : null,

		__constructor : function(){
			this.__parent = consoleImpl.Module.instance;
			this.__logger = this.__parent.getLogger();
			this.__runMode = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-mode");
			
			this.__processGroups = [];
			this.consoleAppConfigs = {};
			this.runningConsoleApps = {};
		},
		
		triggerEvent : function(e) {
			SVMX.getLoggingService().getLogger("SFMConsoleApplication").warn("Trigger event : " + e.type);
			return this.__base(e);
		},
		
		beforeRun : function(options){ 
			// create the named default controller
			var ni = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.niservice").getInstance(); 
			//this.__eventBus = SVMX.create("com.servicemax.client.sfmdelivery.impl.SFMDeliveryEngineEventBus", {});
			
			// create the named default controller
			ni.createNamedInstanceAsync("CONTROLLER",{ handler : function(controller){
				// now create the named default model
				ni.createNamedInstanceAsync("MODEL",{ handler : function(model){
					controller.setModel(model);
					options.handler.call(options.context);
				}, context : this});
				
			}, context : this, additionalParams : { eventBus : this }});			
		},
		
		run : function(){
			this.__logger.info("Application runMode is " + this.__runMode);
			this.__logger.info("Great to be standing on my own legs!");
			this.__logger.info("Caching is => " + SVMX.isCachingEnabled());
			// log preference
			var serv = SVMX.getClient().getServiceRegistry()
						.getService("com.servicemax.client.preferences").getInstance(),
				key = com.servicemax.client.sfmconsole.constants.Constants.PREF_LOGGING;
			
			var pref = serv.getPreference(key) || {enabled : true, constraint : "DEBUG"};
			SVMX.getLoggingService().setFilterPreference(pref);
			// end log preference
						
			if(this.__runMode == "CONSOLE"){this.__runConsole();} 
			else {this.__runEngine();}
		},

		getRoot : function(){
			return this.__root;
		},

		__runConsole : function () {
			this.__runSync();
		},

		__discoverConsoleApps : function(){
			var declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.consoleapp");
			var definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length === 0){
				this.__logger.error("No console apps defined.");
				return;
			}
								
			var discovered = [];
			for(var i=0;i<definitions.length;i++){
				var key = definitions[i].config.app.id;	
				this.consoleAppConfigs[key] = definitions[i].config;
				if(this.consoleAppConfigs[key].discover) {
					discovered.push(
						{	weight : definitions[i].config.positionWeight,
							context : this,"key":key,
							iconClass : this.consoleAppConfigs[key].icon['large-css-class'],
							tooltip : this.consoleAppConfigs[key].tooltip
						});
				}
			}
			discovered.sort(function(a, b){return a.weight-b.weight;});
			for(var t=0;t<discovered.length;t++){
				discovered[t] && this.__root.addConsoleNavLaunchButton(
						discovered[t].context,discovered[t].key,discovered[t].iconClass, discovered[t].tooltip);
			}
		},

		__buildRootContainer : function(){
			this.__root = SVMX.create("com.servicemax.client.sfmconsole.ui.api.RootContainer",{
				renderTo : SVMX.getDisplayRootId(), console : this
			});
		},

		getCurrentConsoleApp : function() {
			var result;
			SVMX.forEachProperty(this.runningConsoleApps, function(inKey, inValue) {
				if (inValue.consoleAppContainer.hidden === false) result = inValue.upi;
			});
			if(!result){
				result = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start");
			}
			return result;
		},
		
		launchConsoleApp : function (consoleAppId, options) {
			options = options || {};
			
			var lastOpener = this.getCurrentConsoleApp();
						
			this.__initialLoader.close();			
			this.__hideAllAppWindows();

            var appConfig = this.consoleAppConfigs[consoleAppId];
            var isSingleton = appConfig ? !appConfig.multiple : false;
			
			var isAppBooted = false;
			if(this.runningConsoleApps[consoleAppId]) isAppBooted = true;

			if(isAppBooted && (consoleAppId != "sfmdelivery" && consoleAppId != "sfmtestapp")){
				this.runningConsoleApps[consoleAppId].consoleAppInstance.__container.show();
				this.__logger.info("Instance of App '" + consoleAppId + "' already running, showing...");				
			}
			else {
				if(!this.consoleAppConfigs[consoleAppId]) {
					this.__logger.error("Console App Not Defined: " + consoleAppId);
				}else {
					options.isClosable = false;
					options.lastOpener = lastOpener;
					
					if(this.consoleAppConfigs[consoleAppId].multiple)options.isClosable = true;
					var consoleAppContainer = this.__root.createConsoleAppContainer(consoleAppId,options);
					
					try {
						var uniqueProcessIdentifier = this.consoleAppConfigs[consoleAppId].app.id;
						if (!isSingleton) uniqueProcessIdentifier += this.processCount;
						
						var consoleAppInstance = SVMX.create(this.consoleAppConfigs[consoleAppId].app["class-name"],this,
								consoleAppContainer,{upi : uniqueProcessIdentifier, size :{height : this.__root.getContentAreaMaxHeight()}});
						this.runningConsoleApps[uniqueProcessIdentifier] = {"consoleAppInstance" : consoleAppInstance, "consoleAppContainer" : consoleAppContainer};
						
						// The setAppInfo method; while all apps should call this, some apps currently don't (sync test app) so everything
						// in here should be optional code
						options.handler = function () {
							consoleAppContainer.setTitle(consoleAppInstance.getWindowTitle());
							if(consoleAppId == "sfmdelivery" || consoleAppId == "sfmtestapp") {
								options.uniqueProcessIdentifier = uniqueProcessIdentifier;
								options.group = consoleAppInstance.getGroup();
								options.text = consoleAppInstance.getWindowTitle();
								
								this.__addProcessToMenu(options);
							//}else {
							//	uniqueProcessIdentifier = this.consoleAppConfigs[consoleAppId].app["id"];
							}
							
							consoleAppInstance.__uniqueProcessIdentifier = uniqueProcessIdentifier;
							this.runningConsoleApps[uniqueProcessIdentifier].upi = uniqueProcessIdentifier;
							
						};
						
						options.context = this;
						consoleAppInstance.start(options);
					} catch (err) {
						this.__logger.error(err);	
						return false;
					}
				}				
			}
		},
												
		__addProcessToMenu	: function (options) {
			this.processCount++;
			this.__root.addProcessMenuItem(options);
		},
								
		__getSyncImpl : function() {
			declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.synchronizer");
			definitions = SVMX.getClient().getDefinitionsFor(declaration);
			
			var className = definitions[0].config.impl['class-name'];
			var syncImpl = SVMX.create(className, this);
			
			return syncImpl;
		},
		
		__runSync : function(){
			
			declaration = SVMX.getClient().getDeclaration("com.servicemax.client.sfmconsole.synchronizer");
			definitions = SVMX.getClient().getDefinitionsFor(declaration);
			if(definitions.length === 0 || SVMX.getClient().getApplicationParameter("sfmconsole-skip-sync")){
				return this.__syncCompleted();
			}
			
			var className = definitions[0].config.impl['class-name'];
			var syncImpl = SVMX.create(className, this);
			
			this.__initialLoader = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection",{
				layout	: {
					type	: 'vbox',
					align	: 'center',
					pack	: 'center'
				},
				header		: false,
				frame       : false, 
				border		: false,
				height		: 250,
				id          : 'firstLoader',
				bodyStyle	:{"background":"transparent"},
				renderTo    : document.getElementById('client_display_root')
			});
			
			var targetCmp = document.getElementById('firstLoader');
			this.titleSpinner = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXSpinner",{
				lines: 13,length: 20, width: 10,radius: 30,corners: 1,rotate: 0,direction: 1, 
				color: '#FF9944',speed: 1,trail: 60, shadow: false,  hwaccel: false, 
				className: 'spinner', zIndex: 2e9,top: 'auto', left: 'auto',
				target : targetCmp
			});	
			
			this.__initialLoader.show();
							
			syncImpl.run({
				handler : this.__syncCompleted, context : this
			});
		},
				
		runManualSyncBackground : function () {
			var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
			this.__syncManager = servDef.getInstance();
			this.__syncManager.startSync({type: "INCREMENTAL"});
		},
		
		showSyncUI : function () {		
			if(Ext.getCmp("syncWindow")){
				Ext.getCmp("syncWindow").show();
				Ext.getCmp("detailPane").hide();
				Ext.getCmp("subPanel").hide();
			}	
		},
		
		__syncCompleted : function(lastSync){
			this.userInfo = lastSync.user;
			this.__buildRootContainer();
			this.__root.setUserInfo(this.userInfo);
			this.__discoverConsoleApps();
			this.__openFirstConsoleApp();
			this.__startIncrementalReSync();
		},	
				
		closeConsoleApp : function(appWindowId,options){
			var me = this;
			var appInstance;
			
			if(this.runningConsoleApps[options.uniqueProcessIdentifier]){
				appInstance = this.runningConsoleApps[options.uniqueProcessIdentifier].consoleAppInstance;
			}
			
			if(appInstance){
				var closeTest = appInstance.onCanClose(function(canClose){
					if(canClose === true) me.destroyConsoleApp(options);
				});	
			}
			else {
				Ext.getCmp(options.uniqueProcessIdentifier).destroy();
				this.__root.manageConsoleAppContainerClose(options);
			}
		},
		
		destroyConsoleApp : function(options) {
			appInstance = this.runningConsoleApps[options.uniqueProcessIdentifier].consoleAppInstance;
			appInstance.onClose(options);
			appInstance.__container.destroy();
			this.__root.manageConsoleAppContainerClose(options);
		},
		
		__openFirstConsoleApp : function () {
			var consoleAppId = (SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start") || null);
			if(!consoleAppId || consoleAppId === ""){
				this.__logger.error("sfmconsole-runtime-start is not set in application config.");
				return false;
			}
			this.launchConsoleApp(consoleAppId,{});	
		},
						
		__hideConsoleApp : function(target) {
			target.hide();
		},
		
		__hideAllAppWindows : function () {
			for(var container in this.runningConsoleApps){
				this.__hideConsoleApp(this.runningConsoleApps[container].consoleAppContainer);
			}			
		},		

		__startIncrementalReSync : function(){
			if(this.userInfo && this.userInfo.reSync){
				this.runManualSyncBackground();
			}
		},
				
		getUserInfo : function () {
			return this.userInfo;
		},
		
		showLoadMask : function(loadMaskTarget){
			this.__root.showLoading(loadMaskTarget);
		},
		
		hideLoadMask : function() {
			this.__root.hideLoading();
		},
		
		showAppWindow : function(appWindowId){
			this.__hideAllAppWindows();
			appInstance = this.runningConsoleApps[appWindowId].consoleAppInstance;
			appInstance.__container.show();
		},
		
		__appShow : function(consoleAppInstance) {
			this.__root.showApp(this.__consoleAppContainer);	
		},
		
		__appHide : function(consoleAppInstance) {
			this.__root.hideApp(this.__consoleAppContainer);
		},
		
		consoleResizeApp : function(consoleAppInstance) {
			this.__root.resizeApp(this.__consoleAppContainer);
		},
					
		__runEngine : function(){
			var client = SVMX.getClient();
			
			// set up the application title
			SVMX.setWindowTitle(client.getApplicationTitle());
			
			// look for the content providers
			// right now, only sfm delivery engine
			var declaration = client.getDeclaration("com.servicemax.client.sfmconsole.deliveryengine");
			var definitions = client.getDefinitionsFor(declaration);

			var sfmdefinition = null;
			var preferEngineId = SVMX.getClient().getApplicationParameter('sfmconsole-engine-id');
			if(preferEngineId){
				for(var i = 0; i < definitions.length; i++){
					if(preferEngineId == definitions[i].config.engine.id){
						sfmdefinition = definitions[i];
						break;
					}
				}
			}else{
				sfmdefinition = definitions[0];
			}
			if(sfmdefinition === null){
				this.__logger.error("Cannot find any delivery engines." + (preferEngineId && "("+preferEngineId+")"));
				return;
			}
			
			sfmdefinition = definitions[0];
			var engineConfig = sfmdefinition.config.engine;
			var engineClassName = engineConfig["class-name"];
			
			sfmdefinition.createInstanceAsnc(engineClassName, {handler : function(engine){
				
				// initialize the engine
				engine.initAsync({handler : function(){
					// start the engine
					engine.run({});
					
				}, context : this});
				
			}, context : this});
		},
		
		setApplicationStateHandler : function(stateHandler){
			
			// set up the application state handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application UI state will
			// be managed by SFMConsole itself.
			this.__applicationStateHandler = stateHandler;
		},
		
		getApplicationStateHandler : function(){
			return this.__applicationStateHandler;
		},
		
		setApplicationErrorHandler : function(errorHandler){
			
			// set up the application error handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application errors will
			// be managed by SFMConsole itself.
			this.__applicationErrorHandler = errorHandler;
		},
		
		getApplicationErrorHandler : function(){
			return this.__applicationErrorHandler || this;
		},
		
		setApplicationMessageUIHandler : function(messageUIHandler){
			
			// set up the application message UI handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application message UI will
			// be managed by SFMConsole itself.
			this.__applicationMessageUIHandler = messageUIHandler;
		},
		
		getApplicationMessageUIHandler : function(){
			return this.__applicationMessageUIHandler || this;
		},
		
		setApplicationQuickMessageHandler : function(quickMessageUIHandler){
			
			// set up the application quick message handler since SFMConsole cannot handle it.
			// once SFMConsole takes over the complete control of the UI, application quick messages will
			// be managed by SFMConsole itself.
			this.__applicationQuickMessageHandler = quickMessageUIHandler;
		},
		
		getApplicationQuickMessageHandler : function(){
			return this.__applicationQuickMessageHandler;
		},
		
		notifyApplicationError : function(error){
			if(!error) return;

			var message = error.message;
			if(!(message instanceof Array)){
				message = [{message : message, msgDetail : error.msgDetail}];
			}
			
			var messageText = message[0].message;
	
			Ext.Msg.show({
				title : 'Error',msg : messageText,buttons: Ext.Msg.OK,icon: Ext.Msg.ERROR
			});

		},
		
		/** 
		 * @param {Object} options
		 *     @param {String} options.type: QUESTION, WARN, ERROR, INFO
		 *     @param {String} options.text
		 *     @param {[Object]} options.buttons Array of ["OK", "CANCEL", "YES", "NO"]
		 */
		showMessage : function(options){
			if(!options) return;
			if (!options.buttons) options.buttons = ["OK"];
			
			var TS = com.servicemax.client.sfmdelivery.impl.Module.TS;

			var type = options.type, msgText = options.text, buttons = options.buttons;
			var handler = options.handler, msgBox;
	
			var msgType = function(){
				return {"QUESTION": {type : Ext.Msg.QUESTION},
						"WARN"    : {type : Ext.Msg.WARNING},
						"ERROR"   : {type : Ext.Msg.ERROR},
						"INFO"    : {type : Ext.Msg.INFO}};
			}; 
	
			var msgButtons = function(){
				return {"OK"      : {btnText : TS.T("TAG067"), svmxBtntype : "OK"},
						"CANCEL"  : {btnText : TS.T("TAG004"), svmxBtntype : "CANCEL"},
						"YES"     : {btnText : TS.T("TAG017"), svmxBtntype : "YES"},
						"NO"      : {btnText : TS.T("TAG016"), svmxBtntype : "NO"}};
			};
			
			var currentMsgType = msgType()[type];
			var icon = (currentMsgType) ? currentMsgType.type : options.type;
			var dispButtons = [];
			
			for(var i = 0; i < buttons.length; i++){
				dispButtons.push({text: msgButtons()[buttons[i]].btnText, 
					svmxBtntype : msgButtons()[buttons[i]].svmxBtntype, 
						handler: function(btn) {
							msgBox.destroy(); 
							if ($.isFunction(options.handler)) {
								options.handler( btn.svmxBtntype );
							}
						}
					});
			}
			
			msgBox = Ext.create('Ext.window.MessageBox', {buttons :dispButtons});
			
			msgBox.show({ title : TS.T("TAG033"), msg : msgText,  icon : icon, closable : false});
			msgBox.getEl().setStyle('z-index','51000');//should more more than load mask
		}
	},{});
	
	consoleImpl.Class("CompositionEngine", com.servicemax.client.lib.api.Object,{
		__metamodel : null, __parent : null,
		
		__constructor : function(metamodel, parent){
			this.__metamodel = metamodel;
			this.__parent = parent;
		},
		
		compose : function(){
			var composition = this.__parent.__self.composition;
			return this.__composeInternal(this.__metamodel, composition, this.__parent);
		},
		
		__composeInternal : function(metamodel, composition, parent){
			var length = composition.length, i;
			for(i = 0; i < length; i++){
				var compositionItem = composition[i];
				var compositionMetamodel = metamodel.getChildNode(compositionItem.name);
				
				if(compositionMetamodel){
					var compositionItemObj = null,
						compositionItemClass = compositionItem.className;
					
					if(compositionMetamodel instanceof Array === false){
						compositionMetamodel = [compositionMetamodel];
					}
					var compositionMetamodelLength = compositionMetamodel.length, j, compositionMetamodelItem;
					for(j = 0; j < compositionMetamodelLength; j++){
						compositionMetamodelItem = compositionMetamodel[j];
						compositionItemObj = SVMX.create(compositionItemClass, {compositionMetamodel : compositionMetamodelItem});
						if(compositionItemObj.__self.composition !== undefined){
							this.__composeInternal(compositionMetamodelItem, compositionItemObj.__self.composition, compositionItemObj);
						}
						parent.onCompositionChildCreate(compositionItemObj, compositionItem.name);
					}
				}
			}
		}
	}, {});
	
})();