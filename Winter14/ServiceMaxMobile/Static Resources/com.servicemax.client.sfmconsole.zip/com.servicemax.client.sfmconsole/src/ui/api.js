/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.ui.api
 * @singleton
 * @author Timothy Ashton 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */
(function(){
	var _apiImpl = SVMX.Package("com.servicemax.client.sfmconsole.ui.api");
		
	_apiImpl.init = function(){
		
		Ext.define(
				"com.servicemax.client.sfmconsole.ui.api.RootContainer",{
				extend              : "com.servicemax.client.ui.components.composites.impl.SVMXSection",
				alias				: 'widget.sfmconsolecontainer',
				__logger            : null,
				__console           : null, 
				__contentAreaMargin : 0,
				__resourcePath      : null,
				__syncStarted		: false,
				
				constructor : function(config){
					this.__logger = SVMX.getLoggingService().getLogger("SFMCONSOLE-ROOT");	
					this.__console = config.console;	
					this.__resourcePath = (window["__SVMX_CLIENT_LIB_PATH__"] || "");
					this.__resourcePath && this.__resourcePath.match(/\/$/) ? this.__resourcePath+="/" : false;
									
					config = Ext.apply({
						closable    : false,
						collapsible : false,
						id          : 'consoleMain',
						height      : this.__getBodyHeight(),
						layout      : "border",
						autoScroll  : false
					}, config || {});
					
					this.__contentAreaMargin = 5;
					
					this.callParent([config]);
					this.run();
					
					this.onResize();
					SVMX.onWindowResize(this.onResize, this);
				},
	
				onResize : function(){				
					var size = this.getAppViewSize();
					size.width = size.width - (0 * 2);
					this.setWidth(size.width);
					this.setHeight(size.height);
					
					size.width = size.width - (0 * 2);
					size.height = this.getContentAreaMaxHeight();
					if(this.consoleAppContentArea){
						this.consoleAppContentArea.setHeight(size.height);
						this.consoleAppContentArea.setWidth(size.width);
						this.consoleAppContentArea.doLayout();
					}
					
					if(this.__console && this.__console.runningConsoleApps){
						var apps = this.__console.runningConsoleApps;
						for(var i in apps){
							if(apps[i].consoleAppInstance){
								apps[i].consoleAppInstance.onAppResize(size);
							}
						}
					}
				},
				
				getContentAreaMaxHeight : function(){
					var size = this.getAppViewSize();
					size.height = size.height - this.consoleNavBar.getHeight() - (this.__contentAreaMargin * 8);
					return size.height;
				},
				
				getAppViewSize : function(){
					var size = Ext.getBody().getViewSize();
					return size;
				},

				getSyncManager : function(){
					if(!this.__syncManager){
						var servDef = SVMX.getClient().getServiceRegistry().getService("com.servicemax.client.syncmanager");
						this.__syncManager = servDef.getInstance();
					}
					return this.__syncManager;
				},
				
				run : function () {
					var me = this;			
					this.tbfill = {xtype : 'tbfill'};
					
					this.menuBtnObj = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton",{
						id		: "processMenu",
						margin	: 0,
						disabled: true,
						plain	: true,
						split   : false,
						iconCls : "sfm-console-windows-icon",
						scale   : "large",
						width   : 52,
						height	: 52,
						ui		: "sfm-console-toolbar-btn",
						hideCollapseTool : true,
						menu    : {
							cls		: "sfm-console-toolbar-btn-menu",
							id      : "thisMenu"
						},
						listeners: {
							afterrender: function(){
								var arrowOverlayEl = new Ext.dom.Element(this.getEl().dom.firstChild);
								arrowOverlayEl.removeCls("svmx-btn-arrow svmx-btn-arrow-right");
							},
						}
					});
					
					this.consoleNavBar = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						region		: 'south',
						layout      : 'column', 
						collapsible	: false	
					});					
					this.add(this.consoleNavBar);
					
					this.consoleToolbar = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXToolbar", {
							ui      : 'sfm-console-toolbar',
							dock    : 'bottom',
							id      : 'toolbar',
							items   : [{
							xtype : 'box',
							autoEl: {
								tag: 'img', 
								src:this.__resourcePath + '/resources/images/servicemax_logo_sm.png'
							},
							width	: 55,
							height	: 52,
							margin	: 10
						}]
					});
					this.consoleToolbar.add(this.tbfill);
						
					this.navbarButtonGroup = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXButtonGroup", {
						id    : 'navbarButtonGroup',
						items : [
							this.btnObj
						]
					});
					this.consoleToolbar.add(this.navbarButtonGroup);		
					
					this.helpButton = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton", {
						handler	: function() {
							// me.launchHelp();
						},
						iconCls : 'sfm-console-offline-help-icon1',
						margin	: 2,
						scale	: 'large',
						ui		: 'sfm-console-toolbar-btn',
						tooltip	: 'Help'
					});
					// this.consoleToolbar.add(this.helpButton);
					
					this.navbar = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXButtonGroup", {
						autoScroll  : true,
						id          : 'navbar',
						margin      : 0
					});
					
					this.consoleToolbar.add(this.navbar);
					this.navbar.add(this.menuBtnObj);
					this.consoleToolbar.add(this.tbfill);
									
					this.syncIcon = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXSplitButton", {
						id      : "syncIcon",
						iconCls : "sfm-console-sync-icon",
						width	: 60,
						height	: 52,
						margin	: 10,
						handler	: function () {
							if(!me.__syncStarted){
								// me.getSyncManager().startSync({type : 'INCREMENTAL'});	
								
    	        				var syncImpl = me.__console.__getSyncImpl();
    	        				syncImpl.performSync('INCREMENTAL');
							}
							else{ // Second click
								if(Ext.getCmp("syncWindow")){
									Ext.getCmp("syncWindow").show();
									Ext.getCmp("detailPane").hide();
									Ext.getCmp("subPanel").hide();
								}
							}
							return false;
						},
						menu    : {
							xtype	: 'menu',
							cls     : SVMX.baseCSSPrefix + 'split-btn-menu-items',
							plain	: true,
							items	: [
								{
									text	: 'Progress',
									hidden  : true,
									id		: 'viewProgress',
									handler	: function() {
										if(Ext.getCmp("syncWindow")){Ext.getCmp("syncWindow").show();
									}
								}
								},
								{
									text	: 'Conflicts',
									handler	: function () {
										com.servicemax.client.sync.errormgmt.impl.ErrorManager.showErrorUI();
									}
								},
								{
									text	: 'Options',
									handler	: function() {
										me.__console.launchConsoleApp("synctestapp",{});
									}
								}
							]
						}
					});
					this.consoleToolbar.add(this.syncIcon);
					
					this.sfmconsoleusermenupanel = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton", {
						id      : "sfmconsoleusermenupanel",
						cls     : 'sfm-console-settings-menu-btn',
						menu	: {
							xtype       : 'menu',
							plain       : true,
							iconAlign   : 'left',
							cls         : 'sfm-console-settings-menu-items',
							items       : [
								{
									text		: 'Settings',
									displayText	: 'Settings',
									tooltip		: 'Settings',
									hidden		: true,
									iconCls		: 'sfm-console-setting-icon',
									handler		: function () {
										alert("Launch Settings");
									}
								},
								{
									text		: 'Help',
									displayText	: 'Help',
									tooltip		: 'help',
									iconCls		: 'sfm-console-help-icon',
									handler		: function () {
										// me.launchHelp();
									}
								}
							]
						}						
					});
					this.consoleToolbar.add(this.sfmconsoleusermenupanel);			
					this.consoleNavBar.addDocked(this.consoleToolbar);

					this.__bindSyncEventHandlers();
				},
  
				__bindSyncEventHandlers : function(){
					var self = this;
					var sync = this.getSyncManager();
					sync.bind("SYNC_STARTED", function(evt){
						self.__syncStarted = true;
						if(Ext.getCmp("syncIcon")){
							Ext.getCmp("syncIcon").btnIconEl.dom.className = "svmx-btn-icon sfm-console-sync-icon-ani";
							Ext.getCmp("viewProgress").show();
						}
					});
					sync.bind("SYNC_COMPLETED", function(evt){
						self.__syncStarted = false;
						if(Ext.getCmp("syncIcon")){
							Ext.getCmp("syncIcon").btnIconEl.dom.className = "svmx-btn-icon sfm-console-sync-icon";
							Ext.getCmp("viewProgress").hide();
						}	
					});
					sync.bind("SYNC_FAILED", function(evt){
						self.__syncStarted = false;
						if(Ext.getCmp("syncIcon")){
							Ext.getCmp("syncIcon").btnIconEl.dom.className = "svmx-btn-icon sfm-console-sync-icon";
							Ext.getCmp("viewProgress").hide();
						}	
					});
				},

				launchHelp : function () {
					var f = new com.servicemax.client.offline.sal.model.nativeservice.File("help.txt");
					f.execute().then(function(isSuccess, inResult) {
						if (isSuccess) { // TODO :: Replace with loggers
							alert("Success.");
						} else {
							alert("Fail :: " + inResult);
						}
					});
				},
				
				setUserInfo: function(userInfo) {
					var panel = Ext.getCmp("sfmconsoleusermenupanel");
					panel.setText(userInfo.UserName);
				},
												
				addProcessMenuItem : function (options) {
					this.menuBtnObj.enable();
					var appWindowId = options.uniqueProcessIdentifier;
					
					var menuItem = {
							text	: "&nbsp;&nbsp;&nbsp;" + options.text,
							id		: options.uniqueProcessIdentifier,
							group	: options.group,
							handler	: function () {
								SVMX.getCurrentApplication().showAppWindow(appWindowId);
							}
						};
											
					if(!Ext.getCmp(options.group)){
						var menuHeader = {
							text		: options.group,
							id			: options.group,
							group		: options.group,
							margin		: '0 0 2 0',
							disabled    : true,
							disabledCls : "svmx-console-process-menu-header-disabled"
						};
						
						var menuSpacer = {
							height	: 13,
							disabled: true,
							id		: options.group + "Spacer"
						};
						
						this.menuBtnObj.menu.add(menuHeader);
						this.menuBtnObj.menu.add(menuItem);	
						this.menuBtnObj.menu.add(menuSpacer);	
					}
					else {
						var locateHeader = 0;
						var currentMenuItems = this.menuBtnObj.menu.items.items;
						var currentGroup = options.group;
						for(var p in currentMenuItems){
							if(currentMenuItems[p].group == currentGroup){break;} 
							else {locateHeader++;}
						}			

						Ext.getCmp("processMenu").menu.insert(locateHeader+1,menuItem);	
					}	
					
					var itemsMenu = Ext.getCmp("processMenu").menu.items;
					var items = itemsMenu.items;
					var lastIndex = itemsMenu.length - 1;
					var lastItem = itemsMenu.items[lastIndex];
					
					for(var i in items){
						if(items[i].id.indexOf("Spacer") != "-1") items[i].show();
					}
					
					if(lastItem.id.indexOf("Spacer") != "-1") lastItem.hide();
				},
				
				removeProcessMenuItem : function (options) {
					Ext.getCmp(options.uniqueProcessIdentifier).hide();				
				},
				
				addConsoleNavLaunchButton : function (parentObj, consoleAppId, btnCssClass, tooltip) { // TODO :: btnCssClass is a hack because I cannot get the ocnfigs array from partent Obj					
					tooltip = tooltip || "";
					this.toolbarButton = SVMX.create("com.servicemax.client.ui.components.controls.impl.SVMXButton", {
						handler	: function() {
							parentObj.launchConsoleApp(consoleAppId,{});
						},
						iconCls : btnCssClass,
						margin	: 5,
						scale	: "large",
						ui		: "sfm-console-toolbar-btn",
						tooltip	: tooltip
					});
					Ext.getCmp('navbarButtonGroup').add(this.toolbarButton);
				},
								
				createConsoleAppContainer : function (consoleAppId,options) {
					var consoleAppContainer = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						collapsible : false,
						frame       : true,
						title       : options.title,
						closable    : options.isClosable,
						region      : 'center',
						margin      : this.__contentAreaMargin,
						listeners   : {
							beforeClose: function(){
								SVMX.getCurrentApplication().closeConsoleApp(consoleAppId,options);
								return false;
							}
						}
					});
					
					this.add(consoleAppContainer);
					return consoleAppContainer;
				},
				
				manageConsoleAppContainerClose : function (options) {
					var appContainer = Ext.getCmp(options.uniqueProcessIdentifier);
					if(appContainer){
						appContainer.destroy();
						
						var currentGroup = options.group;
						var currentMenuItems = this.menuBtnObj.menu.items.items;
						var itemCount = 0;
						for(var p in currentMenuItems){
							if(currentMenuItems[p].group == currentGroup) itemCount++;
						}
						
						if(itemCount == 1){
							Ext.getCmp(currentGroup).destroy();
							Ext.getCmp(currentGroup + "Spacer").destroy();
						}
						
						groupLength = this.menuBtnObj.menu.items.length;
						if(groupLength === 0){									
							this.menuBtnObj.disable();
						}
					}
					
					var appId = null;
					if(options.lastOpener) appId = options.lastOpener;
					
					var isAppBooted = false;
					if(appId && this.__console.runningConsoleApps[appId]) isAppBooted = true;
					if(!isAppBooted) appId = SVMX.getClient().getApplicationParameter("sfmconsole-runtime-start");
					SVMX.getCurrentApplication().launchConsoleApp(appId,{});					
				},
				
				showLoading : function(loadMaskTarget) {
					if(!this.__loadMask) this.__loadMask = new com.servicemax.client.ui.components.utils.LoadMask({parent : this});
					this.__loadMask.show();
					this.__loadMask.setZIndex(50000);
				},
				
				hideLoading : function() {
					if(this.__loadMask !== null) this.__loadMask.hide();				
				},				
				
				createConsoleAppContentArea : function () {
					this.consoleAppContentArea = SVMX.create("com.servicemax.client.ui.components.composites.impl.SVMXSection", {
						alias		: 'widget.consoleAppContentArea',
						collapsible : false,
						id			: 'consoleAppContentArea',
						frame		: false,						
						header		: false,
						autoScroll	: false
					});
					this.add(this.consoleAppContentArea);
				},
								
				__getBodyHeight : function(){
					return Ext.getBody().getViewSize().height;
				}
			});
	};
})();