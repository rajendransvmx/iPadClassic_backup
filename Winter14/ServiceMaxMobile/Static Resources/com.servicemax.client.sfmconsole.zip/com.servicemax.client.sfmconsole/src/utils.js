/**
 * This file needs a description 
 * @class com.servicemax.client.sfmconsole.utils
 * @singleton
 * @author unknown 
 * 
 * @copyright 2013 ServiceMax, Inc. 
 */

(function(){
	var sfmconsoleutil = SVMX.Package("com.servicemax.client.sfmconsole.utils");
	
sfmconsoleutil.init = function(){
	
	/**
	 * Use this class when want to batch a series of MVC events. All the events are processed
	 * simultaneously. The result of all the calls are made available on the callback handler.
	 */
	sfmconsoleutil.Class("EventCollection", com.servicemax.client.lib.api.Object,{
		__eventBus : null, __eventItems : null, __stackIndex : 0, __handler : null, __context : null,
		__constructor : function(eventBus, items){
			this.__eventBus = eventBus;
			this.__eventItems = [];
			this.__stackIndex = 0;
			
			for(var i = 0; i < items.length; i++){
				var ei = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollectionItem", items[i]);
				
				this.__eventItems[i] = ei;
				this.__eventItems[i].itemParent = this;
			}
		},
		
		addEvent : function(evt){
			var ei = SVMX.create("com.servicemax.client.sfmconsole.utils.EventCollectionItem", evt);
				
			this.__eventItems[this.__eventItems.length] = ei;
			this.__eventItems[this.__eventItems.length - 1].itemParent = this;
		},
		
		triggerAll : function(handler, context){
			this.__handler = handler;
			this.__context = context;
			
			for(var i = 0; i < this.__eventItems.length; i++){
				this.__stackIndex++;
				this.__eventItems[i].trigger();
			}
		},
		
		handleResponse : function(eventItem){
			this.__stackIndex--;
			if(this.__stackIndex == 0){
				this.__handler.call(this.__context, this);
			}
		},
		
		getEventBus : function(){
			return this.__eventBus;
		},
		
		items : function(){
			return this.__eventItems;
		}
	},{});
	
	sfmconsoleutil.Class("EventCollectionItem", com.servicemax.client.mvc.api.Responder,{
		__event : null, response : null, itemParent : null,
		__constructor : function(event){
			this.__event = event;
			this.__event.data.responder = this;
		},
		
		trigger : function(){
			this.itemParent.getEventBus().triggerEvent(this.__event);
		},
		
		type : function(){
			return this.__event.type;
		},
		
		getEventObj : function(){
			return this.__event;
		},
		
		result : function(data) { 
			this.response = data;
			this.itemParent.handleResponse(this);
		},
		
		fault : function(data) { 
			var err = "Error during event <" + this.__event.type + ">";
			SVMX.getLoggingService().getLogger().error(err);
			throw new Error(err);
		}
	},{});
	
	/**
	 * This class is responsible for managing the translation related activities
	 * Right now, it looks at the structure from SVMXC.COMM_TagsDefinition
	 */
	sfmconsoleutil.Class("Translation", com.servicemax.client.lib.api.Object, {
		__data : null,
		__constructor : function(data){
			this.__data = {};
			if ($.isArray(data)) {
				var i, l = data.length;
				for(i = 0; i < l; i++){
					this.__data[data[i].Key] = data[i].Value;
				}
			} else {
				this.__data = data;
			}
		},
		
		T : function(key){
			return this.__data[key];
		}
	
	}, {});
	
	sfmconsoleutil.Class("TranslationService", com.servicemax.client.lib.api.Object, {
		__data : null,
		__constructor : function(){},
		
		setTranslationData : function(data){
			this.__data = data;
		},
		
		T : function(key){
			var ret = key;
			
			// There are cases when translation is accessed (ex, during load errors) before it is initialized.
			// So if translation is not available, return the key itself.
			if(this.__data){
				ret = this.__data.T(key);
			}
			
			return ret;
		}
	}, {});
};

})();

// end of file