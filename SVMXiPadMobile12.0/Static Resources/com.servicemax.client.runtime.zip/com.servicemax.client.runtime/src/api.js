
(function(){
	var runtimeApi = SVMX.Package("com.servicemax.client.runtime.api");
	
	runtimeApi.Class("AbstractNamedInstance", com.servicemax.client.lib.api.Object, {
		
		__constructor : function(){
			
		},
		
		initialize : function(name, data, params){
			
		}
	}, {});
})();

// end of file