
(function(){
    var sfmopdocdeliveryoperations = SVMX.Package("com.servicemax.client.tablet.sal.sfmopdoc.model.operations");
    
sfmopdocdeliveryoperations.init = function(){

	sfmopdocdeliveryoperations.Class("GetUserInfo", com.servicemax.client.mvc.api.Operation, {
    
        __constructor: function(){
            this.__base();
        },
        
        performAsync: function(request, responder){
        	
            var requestData = {
                
            };
			
			GetUserInfo(requestData, function(result, evt){
                responder.result(result);
            }, this);           
        }       
    }, {});

    sfmopdocdeliveryoperations.Class("GetTemplate", com.servicemax.client.mvc.api.Operation, {
    
        __constructor: function(){
            this.__base();
        },
        
        performAsync: function(request, responder){
        
            var requestData = {
                ProcessId : request.processId
            };
			
		 	GetTemplate(requestData, function(result, evt){
                responder.result(result);
            }, this);
        }
        
    }, {});
    
    sfmopdocdeliveryoperations.Class("SubmitDocument", com.servicemax.client.mvc.api.Operation, {
    
        __constructor: function(){
            this.__base();
        },
        
        performAsync: function(request, responder){
        
            var requestData = {
                Document: request.document
            };  
        }
        
    }, {});
    
    sfmopdocdeliveryoperations.Class("CreatePDF", com.servicemax.client.mvc.api.Operation, {
    
        __constructor: function(){
            this.__base();
        },
        
        performAsync: function(request, responder){
        
            var requestData = {
                DocumentId: request.documentId,
				RecordId: request.recordId
            };
        }
        
    }, {});
    
    sfmopdocdeliveryoperations.Class("SubmitQuery", com.servicemax.client.mvc.api.Operation, {
    
        __constructor: function(){
            this.__base();
        },
        
        _performInternal: function(request, callback, context){
        
            var qc = request.queryConfig;
            var q = "SELECT " + qc.fields + " FROM " + qc.api;
            if (qc.condition && qc.condition != "") {
                q += " WHERE " + qc.condition;
            }
            var requestData = {
                Query: q
            };            
            
			SubmitQuery(requestData,function(result, evt){
				callback.call(context, result);
			}, this);
        },
        
        performAsync: function(request, responder){
			responder.result("");
        
        }
        
    }, {});
    
    sfmopdocdeliveryoperations.Class("ViewDocument", com.servicemax.client.mvc.api.Operation, {
    
        __constructor: function(){
            this.__base();
        },
        
        performAsync: function(request, responder){
			
            //SVMX.navigateTo("/apex/OPDOC_DocumentViewer?SVMX_AttID=" + request.attachmentId + "&SVMX_RecId=" + request.recordId);
        }
        
    }, {});
	
    sfmopdocdeliveryoperations.Class("GetDocumentMetadata", com.servicemax.client.mvc.api.Operation, {
    
        __constructor: function(){
            this.__base();
        },
        
        performAsync: function(request, responder){
			
			var requestData = {
                ProcessId   : request.processId
            };
			
			GetDocumentMetadata(requestData, function(result, evt){
                responder.result(result);
        	}, this);            
        }		
        
    }, {});
	
	sfmopdocdeliveryoperations.Class("GetDocumentData", com.servicemax.client.mvc.api.Operation, {
    
        __constructor: function(){
            this.__base();
        },
        
        performAsync: function(request, responder){
			
			var requestData = {
                ProcessId   : request.processId,
				RecordId    : request.recordId
            }; 
			
			GetDocumentData(requestData, function(result, evt){
                responder.result(result);
        	}, this);            
            
        }
        
    }, {});
	
	sfmopdocdeliveryoperations.Class("DescribeObject", com.servicemax.client.mvc.api.Operation, {
		
		__constructor : function(){ this.__base(); },
		
		performAsync : function(request, responder) {			
			var requestData = {objectName : request.objectName};
				
			DescribeObject(requestData,function(result, evt){
				
				responder.result(result);
			}, this);				
		}		
		
	}, {});
	
	sfmopdocdeliveryoperations.Class("CaptureSignature", com.servicemax.client.mvc.api.Operation, {
		
		__constructor : function(){ this.__base(); },
		
		performAsync : function(request, responder) {			
			var requestData = {
				ProcessId   : request.processId,
				RecordId    : request.recordId,
				UniqueName  : request.uniqueName,
				CaptureSignature : request.captureSignature
			};
				
			CaptureSignature(requestData,function(result, evt){
				
				responder.result(result);
			}, this);				
		}		
	
	}, {});
	
	sfmopdocdeliveryoperations.Class("Finalize", com.servicemax.client.mvc.api.Operation, {
		
		__constructor : function(){ this.__base(); },
		
		performAsync : function(request, responder) {			
			var requestData = {
				ProcessId   : request.processId,
				RecordId    : request.recordId,
				HTMLContent : request.htmlContent
			};
				
			Finalize(requestData,function(result, evt){
				
				//responder.result(result);
			}, this);				
		}		
	
	}, {});
    
};
})();

// end of file
